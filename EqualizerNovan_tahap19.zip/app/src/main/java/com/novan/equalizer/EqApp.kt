package com.novan.equalizer

import android.app.Application

class EqApp : Application() {
    override fun onCreate() {
        super.onCreate()
        EqEngine.init(this)
    }
}
