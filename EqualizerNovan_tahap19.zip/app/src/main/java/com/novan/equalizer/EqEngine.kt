package com.novan.equalizer

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.ln
import kotlin.math.sqrt

/** Aplikasi pemutar yang pernah memberi tahu nomor sesinya; [hasProfile] bila punya kurva sendiri. */
data class AppEntry(val pkg: String, val hasProfile: Boolean)

/** Pengaturan dinamika dan keluaran. */
data class Dyn(
    val compOn: Boolean = false,
    val compThr: Float = -24f,
    val compRatio: Float = 3f,
    val compAtk: Float = 10f,
    val compRel: Float = 200f,
    val compMakeup: Float = 0f,
    val limOn: Boolean = true,
    val limThr: Float = -2f,
    val limRatio: Float = 10f,
    val limAtk: Float = 1f,
    val limRel: Float = 60f,
    val outGain: Float = 0f,
    val balance: Float = 0f,
)

/** Keadaan equalizer yang disimpan. [route]: 0 otomatis, 1 hanya global, 2 hanya sesi aplikasi. */
data class EqState(
    val enabled: Boolean = false,
    val bandCount: Int = 10,
    val gains10: List<Float> = List(10) { 0f },
    val gains32: List<Float> = List(32) { 0f },
    val preamp: Float = 0f,
    val route: Int = 0,
    val preset: String = "Datar",
    val custom10: Map<String, List<Float>> = emptyMap(),
    val custom32: Map<String, List<Float>> = emptyMap(),
    val fine: Boolean = false,
    val dyn: Dyn = Dyn(),
    val autoProfile: Boolean = false,
    val perApp: Boolean = false,
    val bass: Float = 0f,
    val treble: Float = 0f,
    /** Penguatan area artikulasi vokal 1,5–4 kHz, 0–100 persen. */
    val clarity: Int = 0,
    /** Intensitas bass adaptif 0–100 persen; membentuk low shelf dan mengurangi area boomy. */
    val smartBass: Int = 0,
    /** Intensitas pemerataan dinamika untuk suara pelan, 0–100 persen. */
    val softVolume: Int = 0,
    val width: Int = 0,
) {
    /** Kurva pita ditambah rak bass (di bawah sekitar 200 Hz) dan rak treble (di atas sekitar 3,5 kHz). */
    fun effGains(): List<Float> {
        val g = gains()
        if (bass == 0f && treble == 0f && clarity == 0 && smartBass == 0) return g
        val c = Bands.centers(bandCount)
        return g.mapIndexed { i, v ->
            val f = c[i].toDouble()
            val wb = 1.0 / (1.0 + Math.pow(f / 200.0, 2.0))
            val wt = 1.0 / (1.0 + Math.pow(3500.0 / f, 2.0))
            // Bell lebar di wilayah kejelasan artikulasi; tidak mengangkat frekuensi tinggi ekstrem.
            val logDistance = ln(f / 2600.0)
            val vocalBell = Math.exp(-(logDistance * logDistance) / (2.0 * 0.62 * 0.62))
            val vocalLift = clarity.coerceIn(0, 100) * 0.045 * vocalBell
            // Bass cerdas: dorongan halus pada 45–120 Hz, lalu potongan lebar 180–350 Hz
            // untuk mengurangi bunyi boomy/muddy. Tidak memerlukan efek bass khusus perangkat.
            val sb = smartBass.coerceIn(0, 100) / 100.0
            val lowShelf = 1.0 / (1.0 + Math.pow(f / 145.0, 2.2))
            val mudBell = Math.exp(-Math.pow(ln(f / 245.0), 2.0) / (2.0 * 0.48 * 0.48))
            val smartLift = 4.5 * sb * lowShelf
            val mudCut = 2.2 * sb * mudBell
            (v + bass * wb + treble * wt + vocalLift + smartLift - mudCut).toFloat().coerceIn(-18f, 18f)
        }
    }

    fun gains(): List<Float> = if (bandCount == 32) gains32 else gains10
    fun customs(): Map<String, List<Float>> = if (bandCount == 32) custom32 else custom10
}

/** Frekuensi pita. 10 pita memakai titik standar, 32 pita tersebar rata (sekitar sepertiga oktaf) dari 20 Hz sampai 20 kHz. */
object Bands {
    val centers10 = floatArrayOf(31.5f, 63f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
    val centers32 = FloatArray(32) { i -> (20.0 * Math.pow(1000.0, i / 31.0)).toFloat() }

    fun centers(n: Int): FloatArray = if (n == 32) centers32 else centers10

    /** Batas atas tiap pita (Hz), titik tengah geometrik antar dua pita bertetangga. */
    fun edges(n: Int): FloatArray {
        val c = centers(n)
        return FloatArray(n) { i -> if (i == n - 1) 21000f else sqrt(c[i].toDouble() * c[i + 1]).toFloat() }
    }

    private fun fmt(x: Double): String {
        val r = Math.round(x * 100) / 100.0
        return if (r % 1.0 == 0.0) r.toInt().toString() else r.toString().replace('.', ',')
    }

    fun label(f: Float): String =
        if (f >= 1000f) fmt(f / 1000.0) + " kHz"
        else fmt(if (f >= 100f) Math.round(f).toDouble() else Math.round(f * 10) / 10.0) + " Hz"

    fun spoken(f: Float): String = label(f).replace("kHz", "kilohertz").replace("Hz", "hertz")
}

object Presets {
    val names = listOf(
        "Datar", "Pop", "Rock", "Bass", "Bass kuat", "Vokal", "Treble", "Hip hop", "Elektronik", "Dance",
        "Dangdut", "Akustik", "Jazz", "Klasik", "Metal", "Suara jernih", "Film", "Volume pelan",
    )

    private val data: Map<String, FloatArray> = mapOf(
        "Datar" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Bass" to floatArrayOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Treble" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 1f, 2f, 4f, 5f, 6f),
        "Vokal" to floatArrayOf(-2f, -2f, -1f, 1f, 3f, 4f, 3f, 1f, 0f, -1f),
        "Rock" to floatArrayOf(5f, 4f, 2f, -1f, -2f, -1f, 2f, 4f, 5f, 5f),
        "Pop" to floatArrayOf(-1f, 1f, 3f, 4f, 3f, 0f, -1f, -1f, 1f, 2f),
        "Klasik" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, -2f, -2f, -2f, -4f),
        "Jazz" to floatArrayOf(3f, 2f, 1f, 2f, -2f, -2f, 0f, 1f, 2f, 3f),
        "Dance" to floatArrayOf(6f, 5f, 3f, 0f, 0f, -2f, -3f, -3f, 0f, 0f),
        "Bass kuat" to floatArrayOf(9f, 8f, 6f, 3f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Hip hop" to floatArrayOf(6f, 5f, 3f, 1f, -1f, -1f, 1f, 0f, 2f, 3f),
        "Elektronik" to floatArrayOf(5f, 4f, 1f, 0f, -2f, 2f, 1f, 2f, 4f, 5f),
        "Dangdut" to floatArrayOf(5f, 4f, 3f, 1f, 0f, 1f, 2f, 3f, 2f, 1f),
        "Akustik" to floatArrayOf(3f, 3f, 2f, 1f, 1f, 1f, 2f, 3f, 3f, 2f),
        "Metal" to floatArrayOf(4f, 3f, 0f, -2f, -3f, 0f, 3f, 4f, 4f, 3f),
        "Suara jernih" to floatArrayOf(-4f, -3f, -1f, 0f, 2f, 4f, 4f, 2f, 0f, -2f),
        "Film" to floatArrayOf(5f, 4f, 2f, 0f, 0f, 2f, 3f, 2f, 2f, 1f),
        "Volume pelan" to floatArrayOf(5f, 3f, 0f, 0f, 0f, 0f, 0f, 0f, 2f, 3f),
    )

    /** Kurva preset untuk [n] pita; untuk 32 pita kurva 10 pita diinterpolasi pada skala frekuensi logaritmik. */
    fun gains(name: String, n: Int): List<Float> {
        val g10 = data[name] ?: data.getValue("Datar")
        if (n == 10) return g10.toList()
        val c10 = Bands.centers10
        return Bands.centers32.map { f ->
            when {
                f <= c10.first() -> g10.first()
                f >= c10.last() -> g10.last()
                else -> {
                    var j = 0
                    while (j < c10.size - 2 && f >= c10[j + 1]) j++
                    val t = ((ln(f.toDouble()) - ln(c10[j].toDouble())) / (ln(c10[j + 1].toDouble()) - ln(c10[j].toDouble()))).toFloat()
                    g10[j] + (g10[j + 1] - g10[j]) * t
                }
            }
        }.map { Math.round(it * 2f) / 2f }
    }
}

/**
 * Mesin equalizer. Android 9 ke atas memakai DynamicsProcessing (jumlah pita bebas, jadi 10 dan 32 pita sama-sama mungkin);
 * Android 7 sampai 8.1 memakai Equalizer bawaan sistem lewat [Fx]. Efek dipasang di dua jalur: sesi global (nomor 0, semua suara HP) dan sesi tiap aplikasi
 * (nomor sesi diberikan pemutar lewat siaran OPEN_AUDIO_EFFECT_CONTROL_SESSION).
 */
object EqEngine {
    private var prefs: SharedPreferences? = null
    private val lock = Any()
    private val _state = MutableStateFlow(EqState())
    val state: StateFlow<EqState> = _state.asStateFlow()
    private val _status = MutableStateFlow("Equalizer mati.")
    val status: StateFlow<String> = _status.asStateFlow()

    private var globalDp: Fx? = null
    private val tracked = LinkedHashSet<Int>()
    private val sessionDp = HashMap<Int, Fx>()
    private val sessionEff = HashMap<Int, EqState>()
    private val sessionPkg = HashMap<Int, String>()
    private val knownApps = LinkedHashSet<String>()
    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps.asStateFlow()
    private var attachSessions = false

    fun init(ctx: Context) {
        synchronized(lock) {
            if (prefs != null) return
            prefs = ctx.applicationContext.getSharedPreferences("eq", Context.MODE_PRIVATE)
            _state.value = load()
            loadKnownApps()
            curKind = detectOutput(ctx)
            if (_state.value.autoProfile) adoptProfile(curKind)
            rebuild()
        }
    }

    private fun load(): EqState {
        val p = prefs ?: return EqState()
        fun list(k: String, n: Int): List<Float> =
            p.getString(k, null)?.split(",")?.mapNotNull { it.toFloatOrNull() }?.takeIf { it.size == n }
                ?.map { it.coerceIn(-12f, 12f) } ?: List(n) { 0f }
        return EqState(
            enabled = p.getBoolean("on", false),
            bandCount = if (p.getInt("n", 10) == 32) 32 else 10,
            gains10 = list("g10", 10),
            gains32 = list("g32", 32),
            preamp = p.getFloat("pre", 0f).coerceIn(-12f, 12f),
            route = p.getInt("route", 0).coerceIn(0, 2),
            preset = p.getString("preset", "Datar") ?: "Datar",
            custom10 = parseCustom(p.getString("cp10", null), 10),
            custom32 = parseCustom(p.getString("cp32", null), 32),
            fine = p.getBoolean("fine", false),
            autoProfile = p.getBoolean("auto", false),
            perApp = p.getBoolean("perApp", false),
            bass = p.getFloat("bass", 0f).coerceIn(-12f, 12f),
            treble = p.getFloat("treble", 0f).coerceIn(-12f, 12f),
            clarity = p.getInt("clarity", 0).coerceIn(0, 100),
            smartBass = p.getInt("smartBass", 0).coerceIn(0, 100),
            softVolume = p.getInt("softVolume", 0).coerceIn(0, 100),
            width = p.getInt("width", 0).coerceIn(0, 100),
            dyn = Dyn(
                compOn = p.getBoolean("cOn", false),
                compThr = p.getFloat("cThr", -24f).coerceIn(-60f, 0f),
                compRatio = p.getFloat("cRat", 3f).coerceIn(1f, 20f),
                compAtk = p.getFloat("cAtk", 10f).coerceIn(1f, 200f),
                compRel = p.getFloat("cRel", 200f).coerceIn(10f, 2000f),
                compMakeup = p.getFloat("cMk", 0f).coerceIn(0f, 12f),
                limOn = p.getBoolean("lOn", true),
                limThr = p.getFloat("lThr", -2f).coerceIn(-30f, 0f),
                limRatio = p.getFloat("lRat", 10f).coerceIn(1f, 20f),
                limAtk = p.getFloat("lAtk", 1f).coerceIn(0.5f, 50f),
                limRel = p.getFloat("lRel", 60f).coerceIn(10f, 1000f),
                outGain = p.getFloat("out", 0f).coerceIn(-12f, 12f),
                balance = p.getFloat("bal", 0f).coerceIn(-12f, 12f),
            ),
        )
    }

    private fun parseCustom(raw: String?, n: Int): Map<String, List<Float>> {
        val out = LinkedHashMap<String, List<Float>>()
        raw?.split("\n")?.forEach { line ->
            val parts = line.split("|")
            if (parts.size != 2 || parts[0].isBlank()) return@forEach
            val g = parts[1].split(",").mapNotNull { it.toFloatOrNull() }
            if (g.size == n) out[parts[0]] = g.map { it.coerceIn(-12f, 12f) }
        }
        return out
    }

    private fun serializeCustom(m: Map<String, List<Float>>): String =
        m.entries.joinToString("\n") { it.key + "|" + it.value.joinToString(",") }

    private fun save(s: EqState) {
        prefs?.edit()
            ?.putBoolean("on", s.enabled)
            ?.putInt("n", s.bandCount)
            ?.putString("g10", s.gains10.joinToString(","))
            ?.putString("g32", s.gains32.joinToString(","))
            ?.putFloat("pre", s.preamp)
            ?.putInt("route", s.route)
            ?.putString("preset", s.preset)
            ?.putString("cp10", serializeCustom(s.custom10))
            ?.putString("cp32", serializeCustom(s.custom32))
            ?.putBoolean("fine", s.fine)
            ?.putBoolean("auto", s.autoProfile)
            ?.putBoolean("perApp", s.perApp)
            ?.putFloat("bass", s.bass)
            ?.putFloat("treble", s.treble)
            ?.putInt("clarity", s.clarity)
            ?.putInt("smartBass", s.smartBass)
            ?.putInt("softVolume", s.softVolume)
            ?.putInt("width", s.width)
            ?.putBoolean("cOn", s.dyn.compOn)
            ?.putFloat("cThr", s.dyn.compThr)
            ?.putFloat("cRat", s.dyn.compRatio)
            ?.putFloat("cAtk", s.dyn.compAtk)
            ?.putFloat("cRel", s.dyn.compRel)
            ?.putFloat("cMk", s.dyn.compMakeup)
            ?.putBoolean("lOn", s.dyn.limOn)
            ?.putFloat("lThr", s.dyn.limThr)
            ?.putFloat("lRat", s.dyn.limRatio)
            ?.putFloat("lAtk", s.dyn.limAtk)
            ?.putFloat("lRel", s.dyn.limRel)
            ?.putFloat("out", s.dyn.outGain)
            ?.putFloat("bal", s.dyn.balance)
            ?.apply()
        if (s.autoProfile) prefs?.edit()?.putString("prof$curKind", serializeProfile(s))?.apply()
    }

    // ── Profil per keluaran: 0 speaker HP, 1 earphone kabel, 2 Bluetooth ──
    private var curKind = 0
    private val kindNames = listOf("Speaker HP", "Earphone kabel", "Bluetooth")

    fun detectOutput(ctx: Context): Int {
        val am = ctx.getSystemService(AudioManager::class.java)
        val types = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { it.type }
        val bt = types.any {
            it == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || (Build.VERSION.SDK_INT >= 31 && it == AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
        if (bt) return 2
        val wired = types.any {
            it == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it == AudioDeviceInfo.TYPE_WIRED_HEADSET || it == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        return if (wired) 1 else 0
    }

    private fun serializeProfile(s: EqState): String =
        "${s.bandCount};${s.gains10.joinToString(",")};${s.gains32.joinToString(",")};${s.preamp};${s.bass};${s.treble};${s.preset};${s.clarity};${s.smartBass};${s.softVolume}"

    private fun loadKnownApps() {
        prefs?.getString("apps", null)?.split("\n")?.filter { it.isNotBlank() }?.let { knownApps.addAll(it) }
        refreshApps()
    }

    private fun refreshApps() {
        _apps.value = knownApps.map { AppEntry(it, prefs?.contains("app_$it") == true) }
    }

    private fun parseProfile(raw: String, base: EqState): EqState? {
        val p = raw.split(";", limit = 10)
        // Format 5 dan 7 bagian dari versi sebelumnya tetap dibaca.
        val old = p.size == 5
        val withTone = p.size == 7
        val withSmartBass = p.size >= 9
        val withSoftVolume = p.size == 10
        if (!old && !withTone && p.size != 8 && !withSmartBass) return null
        val n = p[0].toIntOrNull()?.takeIf { it == 10 || it == 32 } ?: return null
        fun l(x: String, k: Int) =
            x.split(",").mapNotNull { it.toFloatOrNull() }.takeIf { it.size == k }?.map { it.coerceIn(-12f, 12f) }
        val g10 = l(p[1], 10) ?: return null
        val g32 = l(p[2], 32) ?: return null
        val pre = p[3].toFloatOrNull()?.coerceIn(-12f, 12f) ?: return null
        if (old) return base.copy(bandCount = n, gains10 = g10, gains32 = g32, preamp = pre, preset = p[4])
        val bs = p[4].toFloatOrNull()?.coerceIn(-12f, 12f) ?: return null
        val tr = p[5].toFloatOrNull()?.coerceIn(-12f, 12f) ?: return null
        val clarity = if (withTone) 0 else p[7].toIntOrNull()?.coerceIn(0, 100) ?: return null
        val smartBass = if (withSmartBass) p[8].toIntOrNull()?.coerceIn(0, 100) ?: return null else 0
        val softVolume = if (withSoftVolume) p[9].toIntOrNull()?.coerceIn(0, 100) ?: return null else 0
        return base.copy(bandCount = n, gains10 = g10, gains32 = g32, preamp = pre, bass = bs, treble = tr, preset = p[6], clarity = clarity, smartBass = smartBass, softVolume = softVolume)
    }

    private fun adoptProfile(kind: Int): Boolean {
        val raw = prefs?.getString("prof$kind", null) ?: return false
        _state.value = parseProfile(raw, _state.value) ?: return false
        return true
    }

    /** Dipanggil layanan saat perangkat keluaran suara berganti. */
    fun onOutputChanged(kind: Int) {
        synchronized(lock) {
            if (kind == curKind) return
            val st = _state.value
            if (st.autoProfile) prefs?.edit()?.putString("prof$curKind", serializeProfile(st))?.apply()
            curKind = kind
            if (st.autoProfile && adoptProfile(kind)) {
                save(_state.value)
                rebuild()
            } else {
                save(_state.value)
                publishStatus()
            }
        }
    }

    fun setAutoProfile(on: Boolean) {
        synchronized(lock) {
            val ns = _state.value.copy(autoProfile = on)
            _state.value = ns
            save(ns)
            publishStatus()
        }
    }

    private fun create(session: Int, st: EqState): Fx? = FxFactory.create(session, st)

    private fun releaseAll() {
        runCatching { globalDp?.release() }
        globalDp = null
        sessionDp.values.forEach { runCatching { it.release() } }
        sessionDp.clear()
        sessionEff.clear()
    }

    private fun rebuild() {
        releaseAll()
        val st = _state.value
        attachSessions = false
        if (st.enabled) {
            if (st.route != 2) globalDp = create(0, st)
            attachSessions = st.route == 2 || (st.route == 0 && globalDp == null)
            if (attachSessions) tracked.forEach { s -> createSession(s, st) }
        }
        publishStatus()
    }

    private fun publishStatus() {
        val st = _state.value
        _status.value = if (!st.enabled) "Equalizer mati." else buildString {
            append("Aktif, ${st.bandCount} pita, ${st.preset}.")
            if (st.autoProfile) append(" ${kindNames[curKind]}.")
            if (st.route != 2 && globalDp == null) append(" Mode global tidak didukung.")
            val anyFx = globalDp ?: sessionDp.values.firstOrNull()
            if (st.width > 0 && anyFx != null && !anyFx.widthActive) append(" Lebar stereo tidak didukung.")
            val dev = globalDp?.deviceBands ?: sessionDp.values.firstOrNull()?.deviceBands ?: 0
            if (dev > 0) append(" Dipetakan ke $dev pita HP.")
            if (attachSessions) append(" Sesi aplikasi ${sessionDp.size}/${tracked.size}.")
        }
    }

    private fun createSession(s: Int, st: EqState) {
        val pkg = sessionPkg[s]
        val prof = if (st.perApp && pkg != null) prefs?.getString("app_$pkg", null)?.let { parseProfile(it, st) } else null
        create(s, prof ?: st)?.let {
            sessionDp[s] = it
            if (prof != null) sessionEff[s] = prof
        }
    }

    /** Hanya jalur global dan sesi yang tidak punya profil aplikasi. */
    private inline fun forEachFree(f: (Fx) -> Unit) {
        globalDp?.let { runCatching { f(it) } }
        for ((s, dp) in sessionDp) if (!sessionEff.containsKey(s)) runCatching { f(dp) }
    }

    /** Penguat, pembatas, kompresor ke semua jalur; sesi berprofil tetap memakai penguat awalnya sendiri. */
    private fun applyAllLevels(ns: EqState) {
        globalDp?.let { runCatching { it.setLevels(ns) } }
        for ((s, dp) in sessionDp) runCatching { dp.setLevels(sessionEff[s]?.copy(dyn = ns.dyn) ?: ns) }
    }

    // ── Dipanggil dari siaran pemutar ──
    fun attachSession(session: Int, pkg: String? = null) {
        synchronized(lock) {
            tracked.add(session)
            if (!pkg.isNullOrBlank() && !pkg.contains("\n")) {
                sessionPkg[session] = pkg
                if (knownApps.add(pkg)) {
                    prefs?.edit()?.putString("apps", knownApps.joinToString("\n"))?.apply()
                }
                refreshApps()
            }
            val st = _state.value
            if (st.enabled && attachSessions && !sessionDp.containsKey(session)) {
                createSession(session, st)
            }
            publishStatus()
        }
    }

    fun detachSession(session: Int) {
        synchronized(lock) {
            tracked.remove(session)
            sessionDp.remove(session)?.let { runCatching { it.release() } }
            sessionEff.remove(session)
            sessionPkg.remove(session)
            publishStatus()
        }
    }

    // ── Dipanggil dari layar ──
    fun setEnabled(on: Boolean) {
        synchronized(lock) {
            val ns = _state.value.copy(enabled = on)
            _state.value = ns
            save(ns)
            rebuild()
        }
    }

    fun setBandCount(n: Int) {
        synchronized(lock) {
            val st = _state.value
            if (st.bandCount == n) return
            val ns = st.copy(bandCount = n)
            _state.value = ns
            save(ns)
            rebuild()
        }
    }

    fun setRoute(r: Int) {
        synchronized(lock) {
            val ns = _state.value.copy(route = r.coerceIn(0, 2))
            _state.value = ns
            save(ns)
            rebuild()
        }
    }

    fun setGain(index: Int, value: Float) {
        synchronized(lock) {
            val st = _state.value
            val n = st.bandCount
            if (index !in 0 until n) return
            val g = value.coerceIn(-12f, 12f)
            val list = st.gains().toMutableList()
            list[index] = g
            val ns = if (n == 32) st.copy(gains32 = list, preset = "Kustom") else st.copy(gains10 = list, preset = "Kustom")
            _state.value = ns
            save(ns)
            val edge = Bands.edges(n)[index]
            forEachFree { it.setBand(index, edge, ns.effGains()[index], ns) }
            if (st.preset != "Kustom") publishStatus()
        }
    }

    fun setPreamp(value: Float) {
        synchronized(lock) {
            val v = value.coerceIn(-12f, 12f)
            val ns = _state.value.copy(preamp = v)
            _state.value = ns
            save(ns)
            applyAllLevels(ns)
        }
    }

    fun applyPreset(name: String) {
        synchronized(lock) {
            val st = _state.value
            val n = st.bandCount
            val g = (st.customs()[name] ?: Presets.gains(name, n)).map { it.coerceIn(-12f, 12f) }
            val ns = if (n == 32) st.copy(gains32 = g, preset = name) else st.copy(gains10 = g, preset = name)
            _state.value = ns
            save(ns)
            forEachFree { it.setBands(ns) }
            publishStatus()
        }
        // Headroom sudah diatur otomatis di Fx (tahap 16); penguat awal cukup dikembalikan ke 0
        // supaya tidak terpotong dua kali (dulu turun otomatis di sini dan turun lagi di Fx).
        setPreamp(0f)
    }

    /** Lebar stereo 0 sampai 100 persen (0 mati), lewat Virtualizer bawaan Android. */
    fun setWidth(pct: Int) {
        synchronized(lock) {
            val ns = _state.value.copy(width = pct.coerceIn(0, 100))
            _state.value = ns
            save(ns)
            applyAllLevels(ns)
            publishStatus()
        }
    }

    /** Atur bass dan treble (rak nada); berlaku ke semua jalur. */
    fun setTone(bass: Float, treble: Float) {
        synchronized(lock) {
            val ns = _state.value.copy(bass = bass.coerceIn(-12f, 12f), treble = treble.coerceIn(-12f, 12f))
            _state.value = ns
            save(ns)
            globalDp?.let { runCatching { it.setBands(ns) } }
            for ((s, dp) in sessionDp) runCatching { dp.setBands(sessionEff[s]?.copy(bass = ns.bass, treble = ns.treble) ?: ns) }
        }
    }

    /** Atur bass cerdas; perubahan kurva langsung diterapkan ke jalur global dan sesi aplikasi. */
    fun setSmartBass(percent: Int) {
        synchronized(lock) {
            val ns = _state.value.copy(smartBass = percent.coerceIn(0, 100))
            _state.value = ns
            save(ns)
            globalDp?.let { runCatching { it.setBands(ns) } }
            for ((session, fx) in sessionDp) runCatching {
                fx.setBands(sessionEff[session]?.copy(smartBass = ns.smartBass) ?: ns)
            }
            publishStatus()
        }
    }

    /** Pemerataan suara pelan: kompresi multiband ringan pada Android 9+, penguatan terbatas pada Android lama. */
    fun setSoftVolume(percent: Int) {
        synchronized(lock) {
            val old = _state.value
            val ns = old.copy(softVolume = percent.coerceIn(0, 100))
            _state.value = ns
            save(ns)
            // MBC harus tersedia saat fitur mulai aktif; konfigurasi DynamicsProcessing tidak dapat
            // menambah blok MBC setelah dibuat, sehingga bangun ulang hanya saat berpindah mati/aktif.
            if ((old.softVolume == 0) != (ns.softVolume == 0)) {
                rebuild()
            } else {
                applyAllLevels(ns)
                globalDp?.let { runCatching { it.setBands(ns) } }
                for ((session, fx) in sessionDp) runCatching {
                    fx.setBands(sessionEff[session]?.copy(softVolume = ns.softVolume) ?: ns)
                }
            }
            publishStatus()
        }
    }

    /** Atur kejernihan vokal dengan bell lebar pada rentang artikulasi; diterapkan langsung ke semua sesi. */
    fun setClarity(percent: Int) {
        synchronized(lock) {
            val ns = _state.value.copy(clarity = percent.coerceIn(0, 100))
            _state.value = ns
            save(ns)
            globalDp?.let { runCatching { it.setBands(ns) } }
            for ((session, fx) in sessionDp) runCatching {
                fx.setBands(sessionEff[session]?.copy(clarity = ns.clarity) ?: ns)
            }
            publishStatus()
        }
    }

    /** Pindah ke preset berikutnya (bawaan lalu kustom), berputar. */
    fun nextPreset() {
        val st = _state.value
        val all = Presets.names + st.customs().keys.filter { it !in Presets.names }
        applyPreset(all[(all.indexOf(st.preset) + 1) % all.size])
    }

    /** Profil per aplikasi memaksa mode Hanya sesi aplikasi agar efek tidak tertumpuk dengan jalur global; saat dimatikan, mode kerja lama dipulihkan. */
    fun setPerApp(on: Boolean) {
        synchronized(lock) {
            val st = _state.value
            var route = st.route
            if (on) {
                if (route != 2) prefs?.edit()?.putInt("routePrev", route)?.apply()
                route = 2
            } else if (route == 2 && prefs?.contains("routePrev") == true) {
                route = prefs?.getInt("routePrev", 0) ?: 0
                prefs?.edit()?.remove("routePrev")?.apply()
            }
            val ns = st.copy(perApp = on, route = route)
            _state.value = ns
            save(ns)
            rebuild()
        }
    }

    fun saveAppProfile(pkg: String) {
        synchronized(lock) {
            prefs?.edit()?.putString("app_$pkg", serializeProfile(_state.value))?.apply()
            refreshApps()
            rebuild()
        }
    }

    fun deleteAppProfile(pkg: String) {
        synchronized(lock) {
            prefs?.edit()?.remove("app_$pkg")?.apply()
            refreshApps()
            rebuild()
        }
    }

    fun setFine(on: Boolean) {
        synchronized(lock) {
            val ns = _state.value.copy(fine = on)
            _state.value = ns
            save(ns)
        }
    }

    /** Ubah pengaturan dinamika/keluaran. Pembangunan ulang hanya bila kompresor dihidupkan atau dimatikan. */
    fun updateDyn(f: (Dyn) -> Dyn) {
        synchronized(lock) {
            val st = _state.value
            val nd = f(st.dyn)
            val ns = st.copy(dyn = nd)
            _state.value = ns
            save(ns)
            if (st.dyn.compOn != nd.compOn) rebuild() else applyAllLevels(ns)
        }
    }

    /** Gaya cepat: 0 mati, 1 ringan, 2 sedang, 3 kuat. */
    fun dynStyle(i: Int) {
        updateDyn {
            when (i) {
                1 -> it.copy(compOn = true, compThr = -20f, compRatio = 2f, compAtk = 20f, compRel = 250f, compMakeup = 1f)
                2 -> it.copy(compOn = true, compThr = -26f, compRatio = 3f, compAtk = 10f, compRel = 200f, compMakeup = 3f)
                3 -> it.copy(compOn = true, compThr = -32f, compRatio = 5f, compAtk = 5f, compRel = 150f, compMakeup = 6f)
                else -> it.copy(compOn = false)
            }
        }
    }

    fun resetDyn() = updateDyn { Dyn() }

    /** Teks kurva untuk disalin: EQN1;jumlah pita;gain,gain,...;penguat awal */
    fun exportCurve(): String {
        val st = _state.value
        return "EQN1;${st.bandCount};${st.gains().joinToString(",")};${st.preamp}"
    }

    fun importCurve(text: String): Boolean {
        val parts = text.trim().split(";")
        if (parts.size != 4 || parts[0] != "EQN1") return false
        val n = parts[1].toIntOrNull() ?: return false
        if (n != 10 && n != 32) return false
        val g = parts[2].split(",").map { it.toFloatOrNull() ?: return false }
        if (g.size != n) return false
        val pre = parts[3].toFloatOrNull() ?: return false
        if (!pre.isFinite() || g.any { !it.isFinite() }) return false
        synchronized(lock) {
            val st = _state.value
            val gg = g.map { it.coerceIn(-12f, 12f) }
            var ns = st.copy(bandCount = n, preamp = pre.coerceIn(-12f, 12f), preset = "Kustom")
            ns = if (n == 32) ns.copy(gains32 = gg) else ns.copy(gains10 = gg)
            _state.value = ns
            save(ns)
            if (st.bandCount != n) rebuild() else { forEachFree { it.setBands(ns) }; applyAllLevels(ns) }
        }
        return true
    }

    /** Simpan kurva sekarang sebagai preset kustom untuk jumlah pita yang sedang dipakai. Mengembalikan false bila nama tidak sah. */
    fun saveCustomPreset(rawName: String): Boolean {
        val name = rawName.trim().replace("|", " ").replace(";", " ").replace("\n", " ")
        if (name.isEmpty() || name.length > 40 || name in Presets.names || name == "Kustom") return false
        synchronized(lock) {
            val st = _state.value
            val map = LinkedHashMap(st.customs())
            map[name] = st.gains()
            val ns = if (st.bandCount == 32) st.copy(custom32 = map, preset = name) else st.copy(custom10 = map, preset = name)
            _state.value = ns
            save(ns)
        }
        return true
    }

    fun deleteCustomPreset(name: String) {
        synchronized(lock) {
            val st = _state.value
            val map = LinkedHashMap(st.customs())
            if (map.remove(name) == null) return
            var ns = if (st.bandCount == 32) st.copy(custom32 = map) else st.copy(custom10 = map)
            if (ns.preset == name) ns = ns.copy(preset = "Kustom")
            _state.value = ns
            save(ns)
        }
    }

    fun reset() {
        applyPreset("Datar")
        setPreamp(0f)
        setTone(0f, 0f)
        setSmartBass(0)
        setClarity(0)
        setSoftVolume(0)
        setWidth(0)
    }
}
