package com.novan.equalizer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Layanan latar supaya efek tetap hidup dan siaran sesi dari pemutar tetap diterima. */
class EqService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val receiver = SessionReceiver()
    private val devCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) {
            EqEngine.onOutputChanged(EqEngine.detectOutput(this@EqService))
        }

        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) {
            EqEngine.onOutputChanged(EqEngine.detectOutput(this@EqService))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Equalizer", NotificationManager.IMPORTANCE_LOW))
        }
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(EqEngine.status.value), type)
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        getSystemService(AudioManager::class.java).registerAudioDeviceCallback(devCb, Handler(Looper.getMainLooper()))
        scope.launch { EqEngine.status.collect { nm.notify(NOTIF_ID, buildNotification(it)) } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> EqEngine.setEnabled(!EqEngine.state.value.enabled)
            ACTION_NEXT -> EqEngine.nextPreset()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        runCatching { unregisterReceiver(receiver) }
        runCatching { getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(devCb) }
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        fun act(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, EqService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val on = EqEngine.state.value.enabled
        return NotificationCompat.Builder(this, CHANNEL)
            .addAction(0, if (on) "Matikan" else "Aktifkan", act(ACTION_TOGGLE, 1))
            .addAction(0, "Preset berikutnya", act(ACTION_NEXT, 2))
            .setSmallIcon(R.drawable.ic_stat_eq)
            .setContentTitle("Equalizer Novan")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    companion object {
        private const val CHANNEL = "eq"
        private const val NOTIF_ID = 1
        private const val ACTION_TOGGLE = "com.novan.equalizer.TOGGLE"
        private const val ACTION_NEXT = "com.novan.equalizer.NEXT_PRESET"
        @Volatile var running = false

        fun start(ctx: Context) {
            if (running) return
            runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, EqService::class.java)) }
        }
    }
}

/** Menerima nomor sesi suara dari pemutar musik yang mendukung equalizer sistem. */
class SessionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val session = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, AudioEffect.ERROR)
        if (session <= 0) return
        if (i.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) == ctx.packageName) return
        when (i.action) {
            AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION ->
                EqEngine.attachSession(session, i.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME))
            AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> EqEngine.detachSession(session)
        }
        EqService.start(ctx)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) EqService.start(ctx)
    }
}
