package com.novan.audiolabnovan

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat

/**
 * Tahap 76: halaman utama berupa kisi tombol fitur, meniru AudioLab asli.
 * Ketuk satu tombol untuk membuka halaman fitur itu; di sana berkas dipilih dan hanya
 * pengaturan fitur itu yang tampil, jadi kursor pembaca layar tidak tersangkut di fitur lain.
 */
open class BerandaActivity : AppCompatActivity() {

    protected fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    protected fun warna(id: Int) = ContextCompat.getColor(this, id)

    /** Fitur yang ditampilkan di kisi; kelas turunan (halaman Bagikan) boleh menyaringnya. */
    protected open fun daftarTampil(): List<Fitur.Def> = Fitur.daftar

    /** Bagian atas halaman (bilah judul); kelas turunan boleh menggantinya dan menambah tombol lain. */
    protected open fun tambahHeader(akar: LinearLayout) {
        val bar = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 24f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(warna(R.color.bar_teks))
            setBackgroundColor(warna(R.color.bar_bg))
            setPadding(dp(20), dp(14), dp(20), dp(14))
            ViewCompat.setAccessibilityHeading(this, true)
        }
        akar.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val akar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(warna(R.color.beranda_bg))
        }
        tambahHeader(akar)

        val kolom = (resources.configuration.screenWidthDp / 88).coerceIn(3, 6)
        val isi = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(16))
        }
        for (baris in daftarTampil().chunked(kolom)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (d in baris) {
                row.addView(buatTombol(d), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            // Sisa kolom di baris terakhir diisi ruang kosong agar lebar tombol tetap sama.
            repeat(kolom - baris.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            isi.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        akar.addView(ScrollView(this).apply { addView(isi) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        ViewCompat.setOnApplyWindowInsetsListener(akar) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }
        setContentView(akar)
    }

    private fun buatTombol(d: Fitur.Def): View {
        val kotak = TextView(this).apply {
            text = d.simbol
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(warna(R.color.tile_simbol))
            background = GradientDrawable().apply {
                setColor(warna(R.color.tile_bg))
                cornerRadius = dp(8).toFloat()
            }
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        val label = TextView(this).apply {
            text = d.judul
            textSize = 12f
            gravity = Gravity.CENTER
            maxLines = 3
            setTextColor(warna(R.color.tile_label))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(6))
            addView(kotak, LinearLayout.LayoutParams(dp(64), dp(64)))
            addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
            isClickable = true
            isFocusable = true
            contentDescription = d.judul
            val tv = TypedValue()
            if (theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) {
                foreground = ContextCompat.getDrawable(this@BerandaActivity, tv.resourceId)
            }
            // Dibacakan sebagai tombol oleh pembaca layar.
            ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {
                override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info.className = android.widget.Button::class.java.name
                }
            })
            setOnClickListener { buka(d) }
        }
    }

    protected open fun buka(d: Fitur.Def) {
        val tujuan = d.tujuan
        if (tujuan != null) {
            // Mikrofon tidak bisa dipakai dua tempat sekaligus (sama seperti aturan di layar lama).
            if (d.id == "karaoke" && RecState.recording) {
                Toast.makeText(this, "Perekam suara sedang berjalan. Hentikan dulu sebelum membuka Studio Karaoke.", Toast.LENGTH_LONG).show()
                return
            }
            startActivity(Intent(this, tujuan))
        } else {
            startActivity(Intent(this, MainActivity::class.java).putExtra(Fitur.EXTRA, d.id))
        }
    }
}
