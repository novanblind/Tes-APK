package com.novan.audiolabnovan.videolab;

import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.BaseAudioProcessor;
import androidx.media3.common.util.UnstableApi;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/** Efek suara sederhana pada audio PCM 16 bit: bass, jernih, radio, gema, suara tegas, penstabil volume, pembersih derau, pembersih suara angin. */
@UnstableApi
public final class VoiceFxProcessor extends BaseAudioProcessor {
    private final int mode;
    private int chCount = -1;
    private double[][] coef;      // tiap tahap: b0, b1, b2, a1, a2 (sudah dinormalisasi)
    private double[][][] state;   // [kanal][tahap][z1, z2]
    private float[][] delay;
    private int[] dPos;
    private int dLen;
    private double gain = 1.0;
    private double[] env;
    private double[] gsm;
    private double[] nf;
    private double[] wlp;        // low pass pembagi untuk pembersih angin
    private double[][] wst;      // status low pass per kanal
    private double[] envH;

    public VoiceFxProcessor(int mode) {
        this.mode = mode;
    }

    @Override
    protected AudioProcessor.AudioFormat onConfigure(AudioProcessor.AudioFormat in)
            throws AudioProcessor.UnhandledAudioFormatException {
        if (in.encoding != C.ENCODING_PCM_16BIT && in.encoding != C.ENCODING_PCM_FLOAT) {
            // Format lain dilewatkan apa adanya supaya ekspor tidak gagal.
            return AudioProcessor.AudioFormat.NOT_SET;
        }
        chCount = -1;
        return in;
    }

    private static double[] norm(double b0, double b1, double b2, double a0, double a1, double a2) {
        return new double[]{b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0};
    }

    private static double[] lowShelf(double fs, double f, double db) {
        double A = Math.pow(10, db / 40), w = 2 * Math.PI * f / fs, cs = Math.cos(w);
        double al = Math.sin(w) / 2 * Math.sqrt(2), sq = 2 * Math.sqrt(A) * al;
        return norm(A * ((A + 1) - (A - 1) * cs + sq), 2 * A * ((A - 1) - (A + 1) * cs),
                A * ((A + 1) - (A - 1) * cs - sq),
                (A + 1) + (A - 1) * cs + sq, -2 * ((A - 1) + (A + 1) * cs), (A + 1) + (A - 1) * cs - sq);
    }

    private static double[] highShelf(double fs, double f, double db) {
        double A = Math.pow(10, db / 40), w = 2 * Math.PI * f / fs, cs = Math.cos(w);
        double al = Math.sin(w) / 2 * Math.sqrt(2), sq = 2 * Math.sqrt(A) * al;
        return norm(A * ((A + 1) + (A - 1) * cs + sq), -2 * A * ((A - 1) + (A + 1) * cs),
                A * ((A + 1) + (A - 1) * cs - sq),
                (A + 1) - (A - 1) * cs + sq, 2 * ((A - 1) - (A + 1) * cs), (A + 1) - (A - 1) * cs - sq);
    }

    private static double[] highPass(double fs, double f) {
        double w = 2 * Math.PI * f / fs, cs = Math.cos(w), al = Math.sin(w) / (2 * 0.707);
        return norm((1 + cs) / 2, -(1 + cs), (1 + cs) / 2, 1 + al, -2 * cs, 1 - al);
    }

    private static double[] lowPass(double fs, double f) {
        double w = 2 * Math.PI * f / fs, cs = Math.cos(w), al = Math.sin(w) / (2 * 0.707);
        return norm((1 - cs) / 2, 1 - cs, (1 - cs) / 2, 1 + al, -2 * cs, 1 - al);
    }

    private void init() {
        int ch = inputAudioFormat.channelCount;
        double fs = inputAudioFormat.sampleRate;
        List<double[]> st = new ArrayList<>();
        gain = 1.0;
        dLen = 0;
        if (mode == 1) {
            st.add(lowShelf(fs, 150, 9));
            gain = 0.8;
        } else if (mode == 2) {
            st.add(highPass(fs, 80));
            st.add(highShelf(fs, 3000, 6));
            gain = 0.9;
        } else if (mode == 3) {
            st.add(highPass(fs, 400));
            st.add(lowPass(fs, 3400));
            gain = 1.2;
        } else if (mode == 4) {
            dLen = Math.max(1, (int) (fs * 0.25));
            gain = 0.85;
        } else if (mode == 6) {
            gain = 0.95;
        } else if (mode == 7) {
            st.add(highPass(fs, 80));
            gain = 1.0;
        } else if (mode == 8) {
            // Pembersih angin: buang dentuman sangat rendah, lalu bagian rendah (di bawah 200 Hz)
            // diredam lebih kuat saat tidak ada suara bicara di bagian tengah dan atas.
            st.add(highPass(fs, 70));
            st.add(highPass(fs, 70));
            wlp = lowPass(fs, 200);
            gain = 1.05;
        } else if (mode == 5) {
            st.add(highPass(fs, 100));
            st.add(highShelf(fs, 2500, 4));
            st.add(lowShelf(fs, 200, -3));
            gain = 0.95;
        }
        coef = st.toArray(new double[0][]);
        state = new double[ch][coef.length][2];
        delay = new float[ch][Math.max(1, dLen)];
        dPos = new int[ch];
        env = new double[ch];
        gsm = new double[ch];
        java.util.Arrays.fill(gsm, 1.0);
        nf = new double[ch];
        wst = new double[ch][2];
        envH = new double[ch];
        java.util.Arrays.fill(nf, 0.004);
        chCount = ch;
    }

    @Override
    public void queueInput(ByteBuffer inputBuffer) {
        int remaining = inputBuffer.remaining();
        if (remaining == 0) return;
        if (chCount != inputAudioFormat.channelCount) init();
        ByteBuffer out = replaceOutputBuffer(remaining);
        int channels = chCount;
        final boolean isFloat = inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT;
        final int frameBytes = channels * (isFloat ? 4 : 2);
        while (inputBuffer.remaining() >= frameBytes) {
            for (int ch = 0; ch < channels; ch++) {
                double x = isFloat ? inputBuffer.getFloat() : inputBuffer.getShort() / 32768.0;
                for (int s = 0; s < coef.length; s++) {
                    double[] k = coef[s];
                    double[] z = state[ch][s];
                    double y = k[0] * x + z[0];
                    z[0] = k[1] * x - k[3] * y + z[1];
                    z[1] = k[2] * x - k[4] * y;
                    x = y;
                }
                if (mode == 6) {
                    env[ch] = Math.max(Math.abs(x), env[ch] * 0.9995);
                    double tg = Math.max(0.7, Math.min(4.0, 0.3 / Math.max(env[ch], 0.02)));
                    gsm[ch] += (tg - gsm[ch]) * 0.002;
                    x *= gsm[ch];
                }
                if (mode == 7) {
                    // Gerbang derau adaptif: lantai derau dipelajari dari bagian paling pelan,
                    // lalu suara di bawah ambang diredam saat jeda bicara.
                    double a = Math.abs(x);
                    env[ch] = Math.max(a, env[ch] * 0.9995);
                    if (env[ch] < nf[ch]) nf[ch] = env[ch];
                    else nf[ch] = Math.min(0.05, nf[ch] + (env[ch] - nf[ch]) * 0.000002);
                    double thr = Math.max(nf[ch] * 3.0, 0.003);
                    double tg = env[ch] >= thr ? 1.0 : Math.max(0.08, Math.pow(env[ch] / thr, 1.5));
                    gsm[ch] += (tg - gsm[ch]) * (tg > gsm[ch] ? 0.02 : 0.0004);
                    x *= gsm[ch];
                }
                if (mode == 8) {
                    double[] k = wlp;
                    double[] z = wst[ch];
                    double lo = k[0] * x + z[0];
                    z[0] = k[1] * x - k[3] * lo + z[1];
                    z[1] = k[2] * x - k[4] * lo;
                    double hi = x - lo;
                    envH[ch] = Math.max(Math.abs(hi), envH[ch] * 0.9998);
                    double tg = envH[ch] > 0.012 ? 0.5 : 0.08;
                    gsm[ch] += (tg - gsm[ch]) * (tg > gsm[ch] ? 0.01 : 0.002);
                    x = hi + lo * gsm[ch];
                }
                if (dLen > 0) {
                    float d = delay[ch][dPos[ch]];
                    x = x + 0.4 * d;
                    delay[ch][dPos[ch]] = (float) x;
                    dPos[ch] = (dPos[ch] + 1) % dLen;
                }
                if (isFloat) {
                    out.putFloat((float) Math.max(-1.0, Math.min(1.0, x * gain)));
                } else {
                    int v = (int) Math.round(x * gain * 32767.0);
                    if (v > Short.MAX_VALUE) v = Short.MAX_VALUE;
                    if (v < Short.MIN_VALUE) v = Short.MIN_VALUE;
                    out.putShort((short) v);
                }
            }
        }
        out.flip();
    }
}
