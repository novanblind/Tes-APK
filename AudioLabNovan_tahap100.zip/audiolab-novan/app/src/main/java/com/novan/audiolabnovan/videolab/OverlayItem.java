package com.novan.audiolabnovan.videolab;

/** Satu teks atau stiker emoji yang muncul di waktu tertentu (milidetik, garis waktu hasil akhir). */
public class OverlayItem {
    public long startMs;
    public long endMs;
    public String text;
    /** 0 = teks, 1 = stiker emoji. */
    public int kind;
    /** 0..8: baris (atas, tengah, bawah) dikali 3 ditambah kolom (kiri, tengah, kanan). */
    public int anchor = 4;
    public int size = 1;
    public int color = 0;
    public boolean bg = false;
    /** 0 = langsung muncul, 1 = muncul perlahan, 2 = geser naik, 3 = zoom masuk. */
    public int anim = 0;

    public OverlayItem(int kind, String text, long startMs, long endMs) {
        this.kind = kind;
        this.text = text;
        this.startMs = startMs;
        this.endMs = endMs;
    }
}
