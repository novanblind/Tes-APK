package com.novan.audiolabnovan.gemini;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Permintaan TTS ke Gemini dan pemecah naskah (port dari skrip main.lua). */
public final class GeminiClient {
    private GeminiClient() {}

    public static final int OK = 0;
    public static final int QUOTA = 1;
    public static final int BADKEY = 2;
    public static final int ERROR = 3;
    /** Model/permintaan tidak didukung: lewati model ini tanpa mengulang. */
    public static final int SKIP = 4;

    public static final int MAX_CHARS = 4000;

    public static final class Result {
        public int status = ERROR;
        public String msg = "";
        public byte[] pcm;
        public int sampleRate = 24000;
    }

    public static final class Item {
        public final String speaker;
        public final String text;
        Item(String speaker, String text) {
            this.speaker = speaker;
            this.text = text;
        }
    }

    // ------------------------------------------------------------------
    // Permintaan ke API (satu percobaan)
    // ------------------------------------------------------------------
    public static Result requestTts(String apiKey, String model, String text, String speechConfigJson, OutputStream pcmOut) {
        Result r = new Result();
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setRequestProperty("x-goog-api-key", apiKey);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(90000);

            String body = "{\"contents\":[{\"parts\":[{\"text\":" + JSONObject.quote(text) + "}]}],"
                    + "\"generationConfig\":{\"responseModalities\":[\"AUDIO\"]," + speechConfigJson + "}}";
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            OutputStream os = conn.getOutputStream();
            os.write(bytes);
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            if (code == 200) {
                String resp = readAll(conn.getInputStream());
                String b64 = null;
                String mime = "";
                JSONObject root = new JSONObject(resp);
                JSONArray cands = root.optJSONArray("candidates");
                if (cands != null) {
                    outer:
                    for (int i = 0; i < cands.length(); i++) {
                        JSONObject cand = cands.optJSONObject(i);
                        if (cand == null) continue;
                        JSONObject content = cand.optJSONObject("content");
                        if (content == null) continue;
                        JSONArray parts = content.optJSONArray("parts");
                        if (parts == null) continue;
                        for (int j = 0; j < parts.length(); j++) {
                            JSONObject p = parts.optJSONObject(j);
                            if (p == null) continue;
                            JSONObject inl = p.optJSONObject("inlineData");
                            if (inl == null) inl = p.optJSONObject("inline_data");
                            if (inl != null) {
                                b64 = inl.optString("data", "");
                                mime = inl.optString("mimeType", inl.optString("mime_type", ""));
                                break outer;
                            }
                        }
                    }
                }
                if (b64 != null && b64.length() > 100) {
                    byte[] audio = Base64.decode(b64, Base64.DEFAULT);
                    boolean wav = b64.startsWith("UklGR") || mime.toLowerCase(Locale.ROOT).contains("wav");
                    int start = (wav && audio.length > 44) ? 44 : 0;
                    if (audio.length > start) pcmOut.write(audio, start, audio.length - start);
                    r.status = OK;
                } else {
                    r.status = ERROR;
                    r.msg = "Respons audio kosong dari model " + model + ".";
                }
            } else if (code == 429) {
                r.status = QUOTA;
                r.msg = "Limit kuota model " + model + " habis (HTTP 429).";
            } else {
                String errBody = "";
                InputStream es = conn.getErrorStream();
                if (es != null) errBody = readAll(es);
                String lowered = errBody.toLowerCase(Locale.ROOT);
                if (code == 401 || code == 403
                        || (code == 400 && (lowered.contains("api key") || lowered.contains("api_key")))) {
                    r.status = BADKEY;
                } else {
                    r.status = ERROR;
                }
                r.msg = "HTTP " + code + (errBody.isEmpty() ? "" : (": " + errBody));
            }
        } catch (Exception e) {
            r.status = ERROR;
            r.msg = String.valueOf(e);
        } finally {
            if (conn != null) conn.disconnect();
        }
        return r;
    }


    // ------------------------------------------------------------------
    // Model 3.8 ke atas: teks dibaca apa adanya, instruksi gaya lewat speech_metadata
    // ------------------------------------------------------------------
    private static final Pattern MODEL_VER = Pattern.compile("gemini-(\\d+)(?:\\.(\\d+))?");
    private static final Pattern RATE = Pattern.compile("rate=(\\d+)");

    public static boolean isVerbatimModel(String model) {
        if (model == null) return false;
        Matcher m = MODEL_VER.matcher(model.toLowerCase(Locale.US));
        if (!m.find()) return false;
        try {
            int maj = Integer.parseInt(m.group(1));
            int min = m.group(2) == null ? 0 : Integer.parseInt(m.group(2));
            return maj > 3 || (maj == 3 && min >= 8);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static String styleOf(int l, int v) {
        String lp = logat(l);
        String vp = vibe(v);
        if (!lp.isEmpty() && !vp.isEmpty()) return lp + ", " + vp;
        return lp.isEmpty() ? vp : lp;
    }

    private static JSONObject voiceCfg(String voiceName) throws Exception {
        return new JSONObject().put("prebuiltVoiceConfig", new JSONObject().put("voiceName", voiceName));
    }

    private static String closeSentence(String t) {
        String x = t.replaceAll("\\s+$", "");
        if (x.isEmpty()) return x;
        char c = x.charAt(x.length() - 1);
        return Character.isLetterOrDigit(c) ? x + "." : x;
    }

    private static JSONObject meta(String speaker, String style) throws Exception {
        JSONObject m = new JSONObject();
        if (speaker != null) m.put("speaker", speaker);
        if (style != null && !style.isEmpty()) m.put("style", style);
        return m;
    }

    public static JSONObject buildSpeech(boolean multi, boolean verbatim, String name1, String voice1, String name2, String voice2) throws Exception {
        if (multi) {
            JSONArray arr = new JSONArray();
            arr.put(new JSONObject().put("speaker", name1).put("voiceConfig", voiceCfg(voice1)));
            arr.put(new JSONObject().put("speaker", name2).put("voiceConfig", voiceCfg(voice2)));
            return new JSONObject().put("multiSpeakerVoiceConfig", new JSONObject().put("speakerVoiceConfigs", arr));
        }
        if (verbatim) {
            return new JSONObject().put("voiceConfig", new JSONObject().put("voice", voice1));
        }
        return new JSONObject().put("voiceConfig", voiceCfg(voice1));
    }

    public static JSONArray buildParts(String model, String chunk, boolean multi, String prefix,
                                       String name1, String name2, String style1, String style2) throws Exception {
        JSONArray parts = new JSONArray();
        if (!isVerbatimModel(model)) {
            String send = prefix.isEmpty() ? chunk : prefix + (multi ? "\n" : "") + chunk;
            return parts.put(new JSONObject().put("text", send));
        }
        if (!multi) {
            JSONObject part = new JSONObject().put("text", closeSentence(chunk));
            JSONObject md = meta(null, style1);
            if (md.length() > 0) part.put("speech_metadata", md);
            return parts.put(part);
        }
        for (String line : chunk.split("\\r?\\n")) {
            if (line.trim().isEmpty()) continue;
            String speaker = name1;
            String text = line;
            int idx = line.indexOf(": ");
            if (idx > 0) {
                String who = line.substring(0, idx);
                if (who.equals(name1) || who.equals(name2)) {
                    speaker = who;
                    text = line.substring(idx + 2);
                }
            }
            JSONObject part = new JSONObject().put("text", closeSentence(text));
            part.put("speech_metadata", meta(speaker, speaker.equals(name1) ? style1 : style2));
            parts.put(part);
        }
        return parts;
    }

    private static int le32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }

    /** Satu permintaan TTS (satu percobaan). Hasil PCM 16-bit mono ada di Result.pcm. */
    public static Result request(String apiKey, String model, JSONArray parts, JSONObject speechConfig) {
        Result r = new Result();
        HttpURLConnection conn = null;
        try {
            JSONObject content = new JSONObject().put("role", "user").put("parts", parts);
            JSONObject gen = new JSONObject()
                    .put("responseModalities", new JSONArray().put("AUDIO"))
                    .put("speechConfig", speechConfig);
            JSONObject body = new JSONObject()
                    .put("contents", new JSONArray().put(content))
                    .put("generationConfig", gen);

            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setRequestProperty("x-goog-api-key", apiKey);
            conn.setDoOutput(true);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(240000);
            byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(payload.length);
            OutputStream os = conn.getOutputStream();
            os.write(payload);
            os.flush();
            os.close();

            int code = conn.getResponseCode();
            if (code == 200) {
                parseAudio(readAll(conn.getInputStream()), model, r);
            } else if (code == 429) {
                r.status = QUOTA;
                r.msg = "Limit kuota model " + model + " habis (HTTP 429).";
            } else {
                String err = "";
                InputStream es = conn.getErrorStream();
                if (es != null) err = readAll(es);
                String low = err.toLowerCase(Locale.ROOT);
                if (code == 401 || code == 403 || (code == 400 && (low.contains("api key") || low.contains("api_key")))) {
                    r.status = BADKEY;
                } else if (code == 400 || code == 404) {
                    r.status = SKIP;
                } else {
                    r.status = ERROR;
                }
                r.msg = "HTTP " + code + (err.isEmpty() ? "" : ": " + err);
            }
        } catch (Exception e) {
            r.status = ERROR;
            r.msg = String.valueOf(e);
        } finally {
            if (conn != null) conn.disconnect();
        }
        return r;
    }

    private static void parseAudio(String resp, String model, Result r) throws Exception {
        JSONObject root = new JSONObject(resp);
        JSONArray cands = root.optJSONArray("candidates");
        String data = null;
        String mime = "";
        if (cands != null && cands.length() > 0) {
            JSONObject c0 = cands.optJSONObject(0);
            JSONObject content = c0 == null ? null : c0.optJSONObject("content");
            JSONArray parts = content == null ? null : content.optJSONArray("parts");
            if (parts != null) {
                for (int i = 0; i < parts.length(); i++) {
                    JSONObject p = parts.optJSONObject(i);
                    if (p == null) continue;
                    JSONObject inl = p.optJSONObject("inlineData");
                    if (inl == null) inl = p.optJSONObject("inline_data");
                    if (inl == null) continue;
                    String d = inl.optString("data", "");
                    if (d.length() > 100) {
                        data = d;
                        mime = inl.optString("mimeType", inl.optString("mime_type", ""));
                        break;
                    }
                }
            }
        }
        if (data == null) {
            JSONObject fb = root.optJSONObject("promptFeedback");
            if (fb != null && fb.has("blockReason")) {
                r.status = SKIP;
                r.msg = "Permintaan diblokir: " + fb.optString("blockReason");
            } else {
                r.status = ERROR;
                r.msg = "Respons audio kosong dari model " + model + ".";
            }
            return;
        }
        String lowMime = mime.toLowerCase(Locale.ROOT);
        if (lowMime.contains("mpeg") || lowMime.contains("mp3") || lowMime.contains("ogg") || lowMime.contains("aac")
                || lowMime.contains("mp4") || lowMime.contains("opus") || lowMime.contains("webm") || lowMime.contains("flac")) {
            r.status = SKIP;
            r.msg = "Model " + model + " mengirim format audio yang tidak didukung (" + mime + ").";
            return;
        }
        byte[] bytes = Base64.decode(data, Base64.DEFAULT);
        int rate = 24000;
        Matcher m = RATE.matcher(lowMime);
        if (m.find()) {
            try { rate = Integer.parseInt(m.group(1)); } catch (NumberFormatException ignored) { }
        }
        int start = 0;
        int dataSize = -1;
        boolean riff = bytes.length > 44 && bytes[0] == 'R' && bytes[1] == 'I' && bytes[2] == 'F' && bytes[3] == 'F';
        if (riff) {
            int pos = 12;
            int found = -1;
            while (pos + 8 <= bytes.length) {
                int size = le32(bytes, pos + 4);
                boolean isData = bytes[pos] == 'd' && bytes[pos + 1] == 'a' && bytes[pos + 2] == 't' && bytes[pos + 3] == 'a';
                boolean isFmt = bytes[pos] == 'f' && bytes[pos + 1] == 'm' && bytes[pos + 2] == 't';
                if (isFmt && pos + 16 <= bytes.length) {
                    int wr = le32(bytes, pos + 12);
                    if (wr >= 8000 && wr <= 96000) rate = wr;
                }
                if (isData) { found = pos + 8; dataSize = size; break; }
                if (size < 0) break;
                pos += 8 + size + (size & 1);
            }
            start = found >= 0 ? found : 44;
        } else if (lowMime.contains("wav") && bytes.length > 44) {
            start = 44;
        }
        int len = bytes.length - start;
        if (riff && dataSize > 0 && dataSize < len) len = dataSize;
        len -= len % 2;
        if (len <= 0) {
            r.status = ERROR;
            r.msg = "Respons audio kosong dari model " + model + ".";
            return;
        }
        byte[] pcm = new byte[len];
        System.arraycopy(bytes, start, pcm, 0, len);
        r.pcm = pcm;
        r.sampleRate = rate;
        r.status = OK;
    }

    private static String readAll(InputStream is) throws java.io.IOException {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            try { is.close(); } catch (Exception ignored) { }
        }
    }

    // ------------------------------------------------------------------
    // Pemecah naskah mode satu suara
    // ------------------------------------------------------------------
    private static final Pattern SENTENCE = Pattern.compile("[^.!?]+[.!?]*");

    private static List<String> hardSplit(String s, int max) {
        List<String> out = new ArrayList<>();
        if (s.length() <= max) {
            out.add(s);
        } else {
            for (int i = 0; i < s.length(); i += max) {
                out.add(s.substring(i, Math.min(s.length(), i + max)));
            }
        }
        return out;
    }

    public static List<String> splitTextIntoChunks(String text, int max) {
        List<String> chunks = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String paragraph : text.replace("\r", "").split("\n")) {
            if (paragraph.isEmpty()) continue;
            if (paragraph.length() <= max) {
                if (cur.length() + paragraph.length() + 1 <= max) {
                    if (cur.length() > 0) cur.append('\n');
                    cur.append(paragraph);
                } else {
                    if (cur.length() > 0) chunks.add(cur.toString());
                    cur = new StringBuilder(paragraph);
                }
            } else {
                Matcher m = SENTENCE.matcher(paragraph);
                while (m.find()) {
                    for (String piece : hardSplit(m.group(), max)) {
                        if (cur.length() + piece.length() <= max) {
                            cur.append(piece);
                        } else {
                            if (cur.length() > 0) chunks.add(cur.toString());
                            cur = new StringBuilder(piece);
                        }
                    }
                }
            }
        }
        if (cur.length() > 0) chunks.add(cur.toString());
        if (chunks.isEmpty()) chunks.add(text);
        return chunks;
    }

    // ------------------------------------------------------------------
    // Mode multi suara
    // ------------------------------------------------------------------
    public static List<Item> parseMultiScript(String text, String name1, String name2) {
        List<Item> items = new ArrayList<>();
        String l1 = name1.toLowerCase(Locale.ROOT);
        String l2 = name2.toLowerCase(Locale.ROOT);
        String current = name1;
        for (String line : text.replace("\r", "").split("\n")) {
            String trimmed = line.trim();
            if (trimmed.isEmpty()) continue;
            int idx = trimmed.indexOf(':');
            if (idx > 0) {
                String who = trimmed.substring(0, idx).trim().toLowerCase(Locale.ROOT);
                String rest = trimmed.substring(idx + 1).trim();
                if (who.equals(l1)) {
                    current = name1;
                    trimmed = rest;
                } else if (who.equals(l2)) {
                    current = name2;
                    trimmed = rest;
                }
            }
            if (!trimmed.isEmpty()) items.add(new Item(current, trimmed));
        }
        return items;
    }

    public static List<String> splitMultiChunks(List<Item> items, int max) {
        List<String> chunks = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (Item item : items) {
            String full = item.speaker + ": " + item.text;
            if (full.length() <= max) {
                cur = push(chunks, cur, full, max);
            } else {
                Matcher m = SENTENCE.matcher(item.text);
                while (m.find()) {
                    String s = m.group().trim();
                    if (!s.isEmpty()) cur = push(chunks, cur, item.speaker + ": " + s, max);
                }
            }
        }
        if (cur.length() > 0) chunks.add(cur.toString());
        return chunks;
    }

    private static StringBuilder push(List<String> chunks, StringBuilder cur, String s, int max) {
        if (cur.length() == 0) {
            cur.append(s);
        } else if (cur.length() + s.length() + 1 <= max) {
            cur.append('\n').append(s);
        } else {
            chunks.add(cur.toString());
            cur = new StringBuilder(s);
        }
        return cur;
    }

    public static String cleanSpeakerName(CharSequence raw, String fallback) {
        String n = String.valueOf(raw).replaceAll("[:\\s\"\\\\]", "");
        return n.isEmpty() ? fallback : n;
    }

    // ------------------------------------------------------------------
    // Instruksi logat dan emosi
    // ------------------------------------------------------------------
    private static String logat(int i) {
        return (i >= 0 && i < Data.LOGAT_PROMPTS.length) ? Data.LOGAT_PROMPTS[i] : "";
    }

    private static String vibe(int i) {
        return (i >= 0 && i < Data.VIBE_PROMPTS.length) ? Data.VIBE_PROMPTS[i] : "";
    }

    public static String buildInstructionPrefix(int logatIndex, int vibeIndex) {
        String lp = logat(logatIndex);
        String vp = vibe(vibeIndex);
        String kata = "teks";
        if (!lp.isEmpty() && !vp.isEmpty()) {
            return "Bacakan " + kata + " berikut secara fasih menggunakan " + lp + ", dengan " + vp + ": ";
        } else if (!lp.isEmpty()) {
            return "Bacakan " + kata + " berikut secara fasih menggunakan " + lp + ": ";
        } else if (!vp.isEmpty()) {
            return "Bacakan " + kata + " berikut dengan " + vp + ": ";
        }
        return "";
    }

    private static String describe(int l, int v) {
        List<String> parts = new ArrayList<>();
        String lp = logat(l);
        String vp = vibe(v);
        if (!lp.isEmpty()) parts.add("menggunakan " + lp);
        if (!vp.isEmpty()) parts.add("dengan " + vp);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(parts.get(i));
        }
        return sb.toString();
    }

    public static String buildMultiInstructionPrefix(String name1, String name2, int l1, int v1, int l2, int v2) {
        String d1 = describe(l1, v1);
        String d2 = describe(l2, v2);
        if (d1.isEmpty() && d2.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("Bacakan percakapan berikut secara fasih. ");
        boolean first = true;
        if (!d1.isEmpty()) {
            sb.append(name1).append(" berbicara ").append(d1).append(".");
            first = false;
        }
        if (!d2.isEmpty()) {
            if (!first) sb.append(" ");
            sb.append(name2).append(" berbicara ").append(d2).append(".");
        }
        sb.append(" Percakapan:");
        return sb.toString();
    }

    public static String buildVoiceConfig(String voiceName) {
        return "{\"prebuiltVoiceConfig\":{\"voiceName\":" + JSONObject.quote(voiceName) + "}}";
    }

    public static String singleSpeechConfig(String voice) {
        return "\"speechConfig\":{\"voiceConfig\":" + buildVoiceConfig(voice) + "}";
    }

    public static String multiSpeechConfig(String name1, String voice1, String name2, String voice2) {
        return "\"speechConfig\":{\"multiSpeakerVoiceConfig\":{\"speakerVoiceConfigs\":["
                + "{\"speaker\":" + JSONObject.quote(name1) + ",\"voiceConfig\":" + buildVoiceConfig(voice1) + "},"
                + "{\"speaker\":" + JSONObject.quote(name2) + ",\"voiceConfig\":" + buildVoiceConfig(voice2) + "}"
                + "]}}";
    }
}
