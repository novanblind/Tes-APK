package com.novan.audiolabnovan.videolab;

import android.content.Context;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

/**
 * Menyesuaikan video ke rasio layar tertentu dengan seluruh gambar terlihat (tanpa crop).
 * Area kosong di kiri kanan atau atas bawah diisi gambar yang sama, diperbesar dan dibuat buram,
 * sebagai pengganti bingkai hitam.
 */
@UnstableApi
public final class BlurFitEffect implements GlEffect {
    private final float aspect;

    public BlurFitEffect(float aspect) {
        this.aspect = aspect;
    }

    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr)
            throws VideoFrameProcessingException {
        return new Program(aspect, useHdr);
    }

    private static final String VERTEX =
            "attribute vec4 aFramePosition;\n"
            + "varying vec2 vTexSamplingCoord;\n"
            + "void main() {\n"
            + "  gl_Position = aFramePosition;\n"
            + "  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;\n"
            + "}\n";

    private static final String FRAGMENT =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\n"
            + "precision highp float;\n"
            + "#else\n"
            + "precision mediump float;\n"
            + "#endif\n"
            + "uniform sampler2D uTexSampler;\n"
            + "uniform vec2 uFit;\n"
            + "uniform vec2 uCover;\n"
            + "varying vec2 vTexSamplingCoord;\n"
            + "void main() {\n"
            + "  vec2 p = vTexSamplingCoord;\n"
            + "  vec2 d = abs(p - 0.5);\n"
            + "  if (d.x <= uFit.x * 0.5 && d.y <= uFit.y * 0.5) {\n"
            + "    gl_FragColor = texture2D(uTexSampler, (p - 0.5) / uFit + 0.5);\n"
            + "    return;\n"
            + "  }\n"
            + "  vec2 uv = (p - 0.5) * uCover + 0.5;\n"
            + "  vec4 sum = texture2D(uTexSampler, uv);\n"
            + "  float total = 1.0;\n"
            + "  for (int r = 1; r <= 3; r++) {\n"
            + "    float rad = (r == 1) ? 0.006 : ((r == 2) ? 0.016 : 0.034);\n"
            + "    for (int k = 0; k < 8; k++) {\n"
            + "      float a = float(k) * 0.785398;\n"
            + "      vec2 off = vec2(cos(a), sin(a)) * rad * uCover;\n"
            + "      sum += texture2D(uTexSampler, clamp(uv + off, 0.0, 1.0));\n"
            + "      total += 1.0;\n"
            + "    }\n"
            + "  }\n"
            + "  gl_FragColor = vec4((sum / total).rgb * 0.75, 1.0);\n"
            + "}\n";

    private static final class Program extends BaseGlShaderProgram {
        private final GlProgram glProgram;
        private final float aspect;
        private float fitW = 1f;
        private float fitH = 1f;

        Program(float aspect, boolean useHdr) throws VideoFrameProcessingException {
            super(useHdr, 1);
            this.aspect = aspect;
            try {
                glProgram = new GlProgram(VERTEX, FRAGMENT);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
            glProgram.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(),
                    GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) {
            float inAspect = (float) inputWidth / inputHeight;
            int outW;
            int outH;
            if (inAspect > aspect) {
                outW = inputWidth;
                outH = Math.round(inputWidth / aspect);
            } else {
                outH = inputHeight;
                outW = Math.round(inputHeight * aspect);
            }
            outW &= ~1;
            outH &= ~1;
            fitW = Math.min(1f, inAspect / aspect);
            fitH = Math.min(1f, aspect / inAspect);
            return new Size(outW, outH);
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs)
                throws VideoFrameProcessingException {
            try {
                glProgram.use();
                glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0);
                glProgram.setFloatsUniform("uFit", new float[]{fitW, fitH});
                float m = Math.min(fitW, fitH);
                glProgram.setFloatsUniform("uCover", new float[]{m / fitW, m / fitH});
                glProgram.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
                GlUtil.checkGlError();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, presentationTimeUs);
            }
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try {
                glProgram.delete();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }
    }
}
