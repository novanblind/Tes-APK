package com.novan.audiolabnovan.karaoke

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Pengaturan efek suara karaoke.
 * [rt60Detik] = lama gema (reverb) menghilang 60 dB; 0 berarti gema mati.
 * [gaungLevel] = seberapa keras gema dicampur (0..1, dibanding suara asli).
 * [echoMs] = jarak antar pengulangan echo dalam milidetik; 0 berarti echo mati.
 * [echoCampur] = seberapa keras echo dicampur; [echoUmpan] = seberapa banyak echo diulang lagi (harus di bawah 1).
 */
class KonfigEfek(
    val rt60Detik: Float,
    val gaungLevel: Float,
    val echoMs: Int,
    val echoCampur: Float,
    val echoUmpan: Float
) {
    val gaungAktif: Boolean get() = rt60Detik > 0f && gaungLevel > 0f
    val echoAktif: Boolean get() = echoMs > 0 && echoCampur > 0f
    val aktif: Boolean get() = gaungAktif || echoAktif

    companion object {
        val MATI = KonfigEfek(0f, 0f, 0, 0f, 0f)
    }
}

/**
 * Efek vokal ala studio karaoke: echo (suara berulang, makin lama makin redup dan gelap) dan gema ruang
 * (reverb gaya Freeverb: delapan tapis sisir paralel dan empat tapis lolos-semua berderet, di kiri dan kanan).
 * Lama gema dihitung dari RT60, jadi pilihan "Katedral" memang terdengar lebih panjang dari "Studio".
 *
 * Murni hitungan, tanpa kelas Android, dan hanya dipakai satu utas. Sampel PCM 16 bit bergantian antar saluran.
 */
class EfekKaraoke(private val sr: Int, private val k: KonfigEfek) {

    // ---------- Echo: dua jalur tunda (kiri sedikit lebih pendek dari kanan agar terdengar lebar) ----------
    private val tundaL = max(1, (k.echoMs * sr / 1000.0).roundToInt())
    private val tundaR = max(1, (tundaL * 1.12).roundToInt())
    private val bufEL = DoubleArray(tundaL)
    private val bufER = DoubleArray(tundaR)
    private var pEL = 0
    private var pER = 0
    private var lpL = 0.0
    private var lpR = 0.0

    /** Tapis lolos-rendah (sekitar 3,5 kHz) pada umpan balik: tiap pengulangan lebih gelap, seperti echo asli. */
    private val aLp = 1.0 - exp(-2.0 * PI * 3_500.0 / sr)

    // ---------- Gema (reverb) ----------
    private val skala = sr / 44_100.0
    private val panjangSisir = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val panjangLolos = intArrayOf(556, 441, 341, 225)
    private val sebar = 23
    private val jumlahSisir = panjangSisir.size
    private val jumlahLolos = panjangLolos.size

    private val sisirBuf: Array<DoubleArray>
    private val sisirIdx = IntArray(jumlahSisir * 2)
    private val sisirSimpan = DoubleArray(jumlahSisir * 2)
    private val sisirG = DoubleArray(jumlahSisir * 2)
    private val lolosBuf: Array<DoubleArray>
    private val lolosIdx = IntArray(jumlahLolos * 2)

    /** Peredam di umpan balik sisir: makin besar makin cepat nada tinggi hilang (gema lebih hangat). */
    private val redam = 0.3

    /** Pengali supaya gema kira-kira sama keras dengan suara masuk pada level 1,0, apa pun ukuran ruangnya. */
    private val normalisasi: Double

    private val preBuf = DoubleArray(max(1, (0.02 * sr).roundToInt()))
    private var pPre = 0

    init {
        // Peredam nada tinggi memperpendek gema yang terukur (sekitar 20 persen); dikembalikan supaya lamanya sesuai nama pilihan.
        val rt = max(0.05, k.rt60Detik.toDouble()) * 1.25
        val lenSisir = IntArray(jumlahSisir * 2)
        for (c in 0 until jumlahSisir * 2) {
            val dasar = panjangSisir[c % jumlahSisir] + if (c >= jumlahSisir) sebar else 0
            lenSisir[c] = max(2, (dasar * skala).roundToInt())
            // Umpan balik sisir supaya gema turun 60 dB tepat dalam rt detik.
            sisirG[c] = 10.0.pow(-3.0 * lenSisir[c] / (rt * sr)).coerceAtMost(0.995)
        }
        sisirBuf = Array(jumlahSisir * 2) { DoubleArray(lenSisir[it]) }
        lolosBuf = Array(jumlahLolos * 2) {
            val dasar = panjangLolos[it % jumlahLolos] + if (it >= jumlahLolos) sebar else 0
            DoubleArray(max(2, (dasar * skala).roundToInt()))
        }
        var jumlah = 0.0
        for (c in 0 until jumlahSisir) jumlah += 1.0 / (1.0 - sisirG[c] * sisirG[c])
        // Delapan sisir menjawab bersamaan pada suara wicara yang kaya nada rendah, jadi hasil ukur nyata
        // sekitar 3,3 kali lebih keras dari hitungan derau putih; faktor ini hasil pengukuran di uji.
        normalisasi = 1.0 / sqrt(jumlah) / 3.3
    }

    /** Membuang sisa gema dan echo (dipanggil saat rekaman dijeda supaya tidak terdengar sisa lama setelah lanjut). */
    fun kosongkan() {
        bufEL.fill(0.0)
        bufER.fill(0.0)
        pEL = 0; pER = 0; lpL = 0.0; lpR = 0.0
        for (b in sisirBuf) b.fill(0.0)
        for (b in lolosBuf) b.fill(0.0)
        sisirIdx.fill(0)
        sisirSimpan.fill(0.0)
        lolosIdx.fill(0)
        preBuf.fill(0.0)
        pPre = 0
    }

    /**
     * Memproses [n] nilai sampel dari [masuk] ([kIn] saluran) dan menulis hasilnya ke [keluar] ([kOut] saluran).
     * Boleh [masuk] dan [keluar] larik yang sama bila [kIn] sama dengan [kOut]. Mengembalikan banyaknya nilai
     * sampel yang ditulis. Suara asli tetap utuh; echo dan gema dicampurkan di atasnya.
     */
    fun proses(masuk: ShortArray, n: Int, kIn: Int, keluar: ShortArray, kOut: Int): Int {
        val bingkai = n / kIn
        val echoCampur = k.echoCampur.toDouble()
        val umpan = k.echoUmpan.toDouble()
        val gaungSkala = normalisasi * k.gaungLevel
        var r = 0
        var o = 0
        for (f in 0 until bingkai) {
            val dL = masuk[r].toDouble()
            val dR = if (kIn == 2) masuk[r + 1].toDouble() else dL
            r += kIn
            val x = (dL + dR) * 0.5 / 32_768.0

            var eL = 0.0
            var eR = 0.0
            if (k.echoAktif) {
                val yL = bufEL[pEL]
                val yR = bufER[pER]
                lpL += aLp * (yL - lpL)
                lpR += aLp * (yR - lpR)
                bufEL[pEL] = x + umpan * lpL
                bufER[pER] = x + umpan * lpR
                if (++pEL == tundaL) pEL = 0
                if (++pER == tundaR) pER = 0
                eL = yL * echoCampur
                eR = yR * echoCampur
            }

            var gL = 0.0
            var gR = 0.0
            if (k.gaungAktif) {
                // Jeda sangat singkat sebelum gema mulai, supaya kata tetap jelas; echo ikut digemakan.
                val tunda = preBuf[pPre]
                preBuf[pPre] = x + 0.5 * (eL + eR)
                if (++pPre == preBuf.size) pPre = 0
                var sL = 0.0
                var sR = 0.0
                for (c in 0 until jumlahSisir) {
                    sL += sisir(c, tunda)
                    sR += sisir(c + jumlahSisir, tunda)
                }
                for (a in 0 until jumlahLolos) {
                    sL = lolos(a, sL)
                    sR = lolos(a + jumlahLolos, sR)
                }
                gL = sL * gaungSkala
                gR = sR * gaungSkala
            }

            val oL = dL + (eL + gL) * 32_768.0
            val oR = dR + (eR + gR) * 32_768.0
            if (kOut == 2) {
                keluar[o++] = batasiLembut(oL)
                keluar[o++] = batasiLembut(oR)
            } else {
                keluar[o++] = batasiLembut((oL + oR) * 0.5)
            }
        }
        return o
    }

    private fun sisir(c: Int, masuk: Double): Double {
        val b = sisirBuf[c]
        val i = sisirIdx[c]
        val keluar = b[i]
        sisirSimpan[c] = keluar * (1.0 - redam) + sisirSimpan[c] * redam
        b[i] = masuk + sisirSimpan[c] * sisirG[c]
        sisirIdx[c] = if (i + 1 == b.size) 0 else i + 1
        return keluar
    }

    private fun lolos(a: Int, masuk: Double): Double {
        val b = lolosBuf[a]
        val i = lolosIdx[a]
        val tunda = b[i]
        b[i] = masuk + tunda * 0.5
        lolosIdx[a] = if (i + 1 == b.size) 0 else i + 1
        return tunda - masuk
    }
}
