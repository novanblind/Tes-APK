package com.novan.audiolabnovan.gemini

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Tahap 59: layanan latar depan penjaga selama Gemini membuat suara. Pekerjaannya sendiri berjalan di thread
 * GeminiSuaraActivity; layanan ini hanya menjaga proses tetap hidup supaya pembuatan suara yang lama
 * tidak terhenti saat layar mati atau aplikasi ditinggalkan.
 */
class GeminiJagaService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = bangunNotifikasi()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (_: Exception) {
            // Tetap lanjut tanpa mode latar depan.
        }
        return START_NOT_STICKY
    }

    private fun bangunNotifikasi(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Pembuatan suara Gemini", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Voice note Gemini")
            .setContentText("Sedang membuat suara. Jangan tutup aplikasi sampai selesai.")
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL = "gemini_suara"
        private const val CHANNEL_SELESAI = "gemini_selesai"
        private const val NOTIF_SELESAI = 5902

        /** Notifikasi hasil: audio siap atau audio tersimpan tetapi kirim WhatsApp gagal. Ketuk untuk membuka layar Gemini. */
        @JvmStatic
        fun selesai(c: Context, judul: String, teks: String) {
            try {
                val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    nm.createNotificationChannel(
                        NotificationChannel(CHANNEL_SELESAI, "Audio Gemini siap", NotificationManager.IMPORTANCE_DEFAULT)
                    )
                }
                val buka = android.app.PendingIntent.getActivity(
                    c, 0,
                    Intent(c, GeminiSuaraActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
                val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(c, CHANNEL_SELESAI)
                else @Suppress("DEPRECATION") Notification.Builder(c)
                nm.notify(
                    NOTIF_SELESAI,
                    b.setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                        .setContentTitle(judul)
                        .setContentText(teks)
                        .setStyle(Notification.BigTextStyle().bigText(teks))
                        .setContentIntent(buka)
                        .setAutoCancel(true)
                        .build()
                )
            } catch (_: Exception) {
            }
        }

        private const val NOTIF_ID = 5901

        fun mulai(c: Context) {
            try {
                val i = Intent(c, GeminiJagaService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) c.startForegroundService(i) else c.startService(i)
            } catch (_: Exception) {
                // Tanpa layanan penjaga pembuatan suara tetap jalan selama aplikasi terbuka.
            }
        }

        fun henti(c: Context) {
            try {
                c.stopService(Intent(c, GeminiJagaService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
