package com.novan.audiolabnovan.karaoke

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Skor satu baris lirik (0..100), dipakai untuk daftar baris yang perlu dilatih. */
class SkorBaris(val ms: Long, val teks: String, val skor: Int)

/**
 * Hasil penilaian.
 * [nada] = kebersihan nada; [waktu] dan [lancar] hanya ada bila ada lirik berwaktu (null bila tidak).
 * [bintang] 1..5, [peringkat] SSS sampai D, [rentetan] = deretan baris bagus terpanjang.
 */
class HasilSkor(
    val total: Int,
    val nada: Int,
    val waktu: Int?,
    val lancar: Int?,
    val bintang: Int,
    val peringkat: String,
    val rentetan: Int,
    val barisLemah: List<SkorBaris>,
    val detikBernyanyi: Int,
    val barisDinilai: Int,
    /** Kecocokan nada dengan musik pengiring (0..100); null bila peta nada lagu belum siap. */
    val melodi: Int? = null
)

/**
 * Menilai nyanyian dari deretan nada yang terdeteksi ([DeteksiNada]), tanpa perlu melodi acuan.
 *
 * Yang dinilai:
 * 1. Kebersihan nada: suara dipecah menjadi not (potongan nada yang stabil), lalu tiap not dibandingkan dengan not
 *    terdekat pada tangga nada 12 semiton. Penyetelan keseluruhan disesuaikan sendiri (lagu yang disetel agak beda
 *    dari 440 Hz tidak merugikan penyanyi). Getaran vibrato tidak dihukum karena yang dinilai nada tengah tiap not.
 * 2. Waktu masuk (butuh lirik berwaktu): seberapa dekat suara mulai dengan awal tiap baris lirik.
 * 3. Kelancaran (butuh lirik berwaktu): seberapa banyak baris itu benar-benar dinyanyikan.
 *
 * Penilaian ini belum membandingkan dengan melodi asli lagu; yang diukur: bersih tidaknya nada dan kecocokan dengan
 * lirik. Murni hitungan, tanpa kelas Android.
 */
object SkorNyanyi {

    /** Selang antar pengukuran nada (milidetik). */
    private val HOP_MS = DeteksiNada.HOP * 1000.0 / PenguraiLagu.SR
    private const val M0 = 0.72
    private const val MAKS_JENDELA_BARIS = 8_000L

    /**
     * @param hz nada tiap pengukuran (0 = tidak ada nada).
     * @param ms waktu tiap pengukuran dalam milidetik sejak musik mulai (sudah dikoreksi jeda mikrofon); menaik.
     * @param lirik lirik berwaktu (boleh kosong).
     * @param durasiMs panjang lagu yang sempat terputar.
     * @param sampaiMs hanya baris yang sudah selesai dinyanyikan sampai waktu ini yang dinilai (untuk skor sementara).
     * @param chroma peta nada lagu pengiring; bila ada, kecocokan tiap not dengan musik ikut dinilai (null = tidak).
     * @return null bila suara bernada terlalu sedikit untuk dinilai.
     */
    fun hitung(
        hz: FloatArray, ms: LongArray, n: Int, lirik: List<BarisLirik>, durasiMs: Long,
        sampaiMs: Long = Long.MAX_VALUE,
        chroma: ChromaLagu? = null
    ): HasilSkor? {
        if (n < 8) return null
        // Nada MIDI pecahan per pengukuran; 0 = tidak bernada (juga sebelum musik mulai).
        val m = DoubleArray(n)
        for (i in 0 until n) {
            m[i] = if (hz[i] > 0f && ms[i] >= 0L) PemantauNada.midi(hz[i].toDouble()) else 0.0
        }
        val s = saring(m, n)

        var bernada = 0
        for (i in 0 until n) if (s[i] > 0.0) bernada++
        val detik = (bernada * HOP_MS / 1000.0).roundToInt()
        if (bernada * HOP_MS < 2_000.0) return null

        val offset = taksirPenyetelan(s, n)
        val fs = FloatArray(n) { -1f }
        // Kecocokan tiap not dengan musik (0..1), -1 bila tidak ada datanya.
        val fm = FloatArray(n) { -1f }
        var jumlahSkor = 0.0
        var bobot = 0.0
        var jumlahMel = 0.0
        var bobotMel = 0.0

        // Potong menjadi not: berhenti bila tidak bernada atau nada melompat lebih dari 0,6 semiton dari rata-rata not.
        var i = 0
        while (i < n) {
            if (s[i] <= 0.0) {
                i++
                continue
            }
            var j = i
            var jum = s[i]
            var cacah = 1
            while (j + 1 < n && s[j + 1] > 0.0 && abs(s[j + 1] - jum / cacah) <= 0.6) {
                j++
                jum += s[j]
                cacah++
            }
            if (cacah >= 4) {
                val tengah = median(s, i, j)
                var dv = tengah - offset
                dv -= Math.round(dv).toDouble()
                val sen = abs(dv) * 100.0
                val nilai = when {
                    sen <= 25.0 -> 1.0
                    sen >= 50.0 -> 0.0
                    else -> (50.0 - sen) / 25.0
                }
                for (k in i..j) fs[k] = nilai.toFloat()
                jumlahSkor += nilai * cacah
                bobot += cacah
                if (chroma != null) {
                    // Kelas nada not yang dinyanyikan (0 = C ... 11 = B), setelah penyetelan penyanyi dikoreksi.
                    val pc = Math.floorMod(Math.round(tengah - offset).toInt(), 12)
                    val v = chroma.kecocokan(pc, ms[i], ms[j] + HOP_MS.toLong())
                    if (v >= 0f) {
                        val nm = skalaMelodi(v.toDouble())
                        for (k in i..j) fm[k] = nm.toFloat()
                        jumlahMel += nm * cacah
                        bobotMel += cacah
                    }
                }
            }
            i = j + 1
        }
        if (bobot <= 0.0) return null
        val nadaFraksi = skala(jumlahSkor / bobot)
        val nada = (nadaFraksi * 100.0).roundToInt()

        // ----- Penilaian per baris lirik -----
        val baris = ArrayList<SkorBaris>()
        val melodiHasil: Int? = if (bobotMel >= 4.0) (jumlahMel / bobotMel * 100.0).roundToInt() else null
        var jumlahWaktu = 0.0
        var jumlahLancar = 0.0
        var rentetan = 0
        var rentetanSekarang = 0
        for (b in lirik.indices) {
            val l = lirik[b]
            if (l.teks.isBlank()) continue
            val mulai = l.ms
            val berikut = if (b + 1 < lirik.size) lirik[b + 1].ms else durasiMs
            val akhir = min(min(berikut, mulai + MAKS_JENDELA_BARIS), durasiMs)
            val dur = akhir - mulai
            if (dur < 600L) continue
            // Baris yang belum selesai dinyanyikan belum dinilai.
            if (akhir > sampaiMs - 1_000L) continue

            val dari = cari(ms, n, mulai - 300L)
            val dariIsi = cari(ms, n, mulai)
            val sampai = cari(ms, n, akhir)
            var bernadaBaris = 0
            var pertama = -1
            var jumNada = 0.0
            var cacahNada = 0
            var jumMel = 0.0
            var cacahMel = 0
            for (k in dari until sampai) {
                if (s[k] > 0.0) {
                    if (pertama < 0) pertama = k
                    if (k >= dariIsi) bernadaBaris++
                }
                if (k >= dariIsi && fs[k] >= 0f) {
                    jumNada += fs[k]
                    cacahNada++
                }
                if (k >= dariIsi && fm[k] >= 0f) {
                    jumMel += fm[k]
                    cacahMel++
                }
            }
            val harap = min(max(l.teks.length * 100L, 1_200L), dur).toDouble()
            val lancar = ((bernadaBaris * HOP_MS) / (0.5 * harap)).coerceIn(0.0, 1.0)
            val waktu = if (pertama < 0) {
                0.0
            } else {
                val tunda = ms[pertama] - mulai
                when {
                    tunda <= 500L -> 1.0
                    tunda >= 1_800L -> 0.0
                    else -> (1_800L - tunda) / 1_300.0
                }
            }
            val nadaBaris = if (cacahNada > 0) skala(jumNada / cacahNada) else 0.0
            val skorBaris = if (melodiHasil != null && cacahMel > 0) {
                val melBaris = jumMel / cacahMel
                (100.0 * (0.3 * nadaBaris + 0.3 * melBaris + 0.2 * waktu + 0.2 * lancar)).roundToInt()
            } else {
                (100.0 * (0.5 * nadaBaris + 0.25 * waktu + 0.25 * lancar)).roundToInt()
            }
            baris.add(SkorBaris(mulai, l.teks, skorBaris))
            jumlahWaktu += waktu
            jumlahLancar += lancar
            if (skorBaris >= 80) {
                rentetanSekarang++
                rentetan = max(rentetan, rentetanSekarang)
            } else {
                rentetanSekarang = 0
            }
        }

        val total: Int
        val waktuHasil: Int?
        val lancarHasil: Int?
        if (baris.isEmpty()) {
            total = if (melodiHasil != null) ((nada + melodiHasil) / 2.0).roundToInt() else nada
            waktuHasil = null
            lancarHasil = null
        } else {
            val w = (jumlahWaktu / baris.size * 100.0).roundToInt()
            val c = (jumlahLancar / baris.size * 100.0).roundToInt()
            waktuHasil = w
            lancarHasil = c
            total = if (melodiHasil != null) {
                (0.3 * nada + 0.3 * melodiHasil + 0.2 * w + 0.2 * c).roundToInt()
            } else {
                (0.5 * nada + 0.25 * w + 0.25 * c).roundToInt()
            }
        }
        val lemah = baris.filter { it.skor < 60 }.sortedBy { it.skor }.take(3).sortedBy { it.ms }
        return HasilSkor(
            total = total.coerceIn(0, 100), nada = nada, waktu = waktuHasil, lancar = lancarHasil,
            bintang = bintang(total), peringkat = peringkat(total), rentetan = rentetan,
            barisLemah = lemah, detikBernyanyi = detik, barisDinilai = baris.size, melodi = melodiHasil
        )
    }

    /** Rata-rata nilai not (0..1) dibawa ke 0..1 supaya nada acak mendekati 0 dan nada bersih mendekati 1. */
    private fun skala(rata: Double): Double = ((rata - M0) / (1.0 - M0)).coerceIn(0.0, 1.0)

    /**
     * Kekuatan kelas nada di musik (0..1) dibawa ke nilai 0..1. Pada uji dengan lagu buatan, nada yang cocok dengan
     * musik rata-rata sekitar 0,7, nada acak sekitar 0,2, sehingga 0,15 ke bawah dianggap tidak cocok dan 0,65 ke
     * atas dianggap cocok penuh.
     */
    private fun skalaMelodi(v: Double): Double = ((v - 0.15) / 0.5).coerceIn(0.0, 1.0)

    fun bintang(total: Int): Int = when {
        total >= 90 -> 5
        total >= 75 -> 4
        total >= 60 -> 3
        total >= 40 -> 2
        else -> 1
    }

    fun peringkat(total: Int): String = when {
        total >= 95 -> "SSS"
        total >= 90 -> "SS"
        total >= 82 -> "S"
        total >= 72 -> "A"
        total >= 60 -> "B"
        total >= 45 -> "C"
        else -> "D"
    }

    /**
     * Membuang pengukuran sesaat dan loncatan oktaf: tiap pengukuran bernada diganti median lima tetangga bernada;
     * bila tetangga bernadanya kurang dari tiga, pengukuran itu dianggap bukan nada.
     */
    internal fun saring(m: DoubleArray, n: Int): DoubleArray {
        val keluar = DoubleArray(n)
        val w = DoubleArray(5)
        for (i in 0 until n) {
            if (m[i] <= 0.0) continue
            var c = 0
            for (j in max(0, i - 2)..min(n - 1, i + 2)) if (m[j] > 0.0) w[c++] = m[j]
            if (c < 3) continue
            java.util.Arrays.sort(w, 0, c)
            keluar[i] = w[c / 2]
        }
        return keluar
    }

    /** Penyetelan keseluruhan penyanyi (pecahan semiton, -0,5..0,5) lewat rata-rata melingkar; 0 bila tidak konsisten. */
    internal fun taksirPenyetelan(s: DoubleArray, n: Int): Double {
        var sx = 0.0
        var sy = 0.0
        var c = 0
        for (i in 0 until n) {
            if (s[i] <= 0.0) continue
            val dv = s[i] - Math.round(s[i])
            sx += cos(2.0 * PI * dv)
            sy += sin(2.0 * PI * dv)
            c++
        }
        if (c < 40) return 0.0
        val panjang = hypot(sx, sy) / c
        return if (panjang > 0.3) atan2(sy, sx) / (2.0 * PI) else 0.0
    }

    private fun median(s: DoubleArray, dari: Int, sampai: Int): Double {
        val a = s.copyOfRange(dari, sampai + 1)
        a.sort()
        return a[a.size / 2]
    }

    /** Nomor pertama di [ms] yang tidak kurang dari [t] (pencarian biner pada larik menaik). */
    private fun cari(ms: LongArray, n: Int, t: Long): Int {
        var lo = 0
        var hi = n
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (ms[mid] < t) lo = mid + 1 else hi = mid
        }
        return lo
    }

    /**
     * Mengubah deretan nada hasil [PemantauNada.salin] ke waktu musik: [vokalAwal] = nomor sampel mikrofon saat musik
     * mulai, [selarasMs] = jeda mikrofon (sama dengan "Sinkron vokal dengan musik").
     */
    fun keWaktuMusik(pusat: LongArray, n: Int, sr: Int, vokalAwal: Int, selarasMs: Int): LongArray {
        val keluar = LongArray(n)
        for (i in 0 until n) keluar[i] = (pusat[i] - vokalAwal) * 1000L / sr - selarasMs
        return keluar
    }
}
