package com.novan.audiolabnovan.videolab;

import android.graphics.Matrix;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.MatrixTransformation;

/** Zoom dengan titik fokus dan gerak kamera perlahan (zoom masuk, zoom keluar, geser). */
@UnstableApi
public final class PanZoomMatrix implements MatrixTransformation {
    private final long totalUs;
    private final float baseZoom;
    private final int focus;
    private final int motion;

    public PanZoomMatrix(long totalUs, float baseZoom, int focus, int motion) {
        this.totalUs = Math.max(1, totalUs);
        this.baseZoom = baseZoom;
        this.focus = focus;
        this.motion = motion;
    }

    @Override
    public Matrix getMatrix(long presentationTimeUs) {
        float p = Math.max(0f, Math.min(1f, presentationTimeUs / (float) totalUs));
        float fx = (focus % 3 == 0) ? -1f : (focus % 3 == 1 ? 0f : 1f);
        float fy = (focus / 3 == 0) ? 1f : (focus / 3 == 1 ? 0f : -1f);
        float z = baseZoom;
        if (motion == 1) {
            z = 1f + 0.3f * p;
        } else if (motion == 2) {
            z = 1.3f - 0.3f * p;
        } else if (motion == 3 || motion == 4) {
            z = Math.max(baseZoom, 1.25f);
            fx = motion == 3 ? (-1f + 2f * p) : (1f - 2f * p);
        }
        Matrix m = new Matrix();
        m.postScale(z, z);
        m.postTranslate(-fx * (z - 1f), -fy * (z - 1f));
        return m;
    }
}
