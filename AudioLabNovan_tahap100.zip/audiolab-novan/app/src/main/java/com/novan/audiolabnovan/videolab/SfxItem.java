package com.novan.audiolabnovan.videolab;

import android.net.Uri;

/** Satu efek suara tambahan yang dibunyikan di waktu tertentu pada hasil akhir. */
public class SfxItem {
    public final Uri uri;
    public final String name;
    public final long durMs;
    /** Waktu bunyi pada garis waktu hasil akhir, dalam milidetik. */
    public long atMs;
    public float volume = 1f;

    public SfxItem(Uri uri, String name, long atMs, long durMs) {
        this.uri = uri;
        this.name = name;
        this.atMs = atMs;
        this.durMs = durMs;
    }
}
