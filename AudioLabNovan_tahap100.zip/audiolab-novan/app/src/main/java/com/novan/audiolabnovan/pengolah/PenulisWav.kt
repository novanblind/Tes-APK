package com.novan.audiolabnovan.pengolah

import java.io.Closeable
import java.io.File
import java.io.RandomAccessFile

/**
 * Tahap 91: penulis WAV 16 bit yang menulis sedikit demi sedikit (tanpa menampung seluruh audio di memori),
 * dipakai Noise Generator dan Wave Generator. Panjang di kepala berkas diisi saat [close].
 */
class PenulisWav(f: File, private val sr: Int, private val kanal: Int) : Closeable {
    private val raf = RandomAccessFile(f, "rw")
    private var byteData = 0L
    private val blok = ByteArray(16384 * 2)

    init {
        raf.setLength(0)
        raf.write(ByteArray(44)) // kepala diisi nanti
    }

    /** Menulis [n] sampel pertama dari [pcm] (sudah bergantian antar kanal). */
    fun tulis(pcm: ShortArray, n: Int) {
        var i = 0
        while (i < n) {
            val b = minOf(16384, n - i)
            for (k in 0 until b) {
                val v = pcm[i + k].toInt()
                blok[2 * k] = (v and 0xFF).toByte()
                blok[2 * k + 1] = ((v shr 8) and 0xFF).toByte()
            }
            raf.write(blok, 0, b * 2)
            byteData += b * 2L
            i += b
        }
    }

    private fun int32(v: Long): ByteArray = byteArrayOf(
        (v and 0xFF).toByte(), ((v shr 8) and 0xFF).toByte(),
        ((v shr 16) and 0xFF).toByte(), ((v shr 24) and 0xFF).toByte()
    )

    private fun int16(v: Int): ByteArray = byteArrayOf((v and 0xFF).toByte(), ((v shr 8) and 0xFF).toByte())

    override fun close() {
        try {
            raf.seek(0)
            raf.write("RIFF".toByteArray())
            raf.write(int32(36L + byteData))
            raf.write("WAVE".toByteArray())
            raf.write("fmt ".toByteArray())
            raf.write(int32(16))
            raf.write(int16(1))
            raf.write(int16(kanal))
            raf.write(int32(sr.toLong()))
            raf.write(int32(sr.toLong() * kanal * 2))
            raf.write(int16(kanal * 2))
            raf.write(int16(16))
            raf.write("data".toByteArray())
            raf.write(int32(byteData))
        } finally {
            raf.close()
        }
    }
}
