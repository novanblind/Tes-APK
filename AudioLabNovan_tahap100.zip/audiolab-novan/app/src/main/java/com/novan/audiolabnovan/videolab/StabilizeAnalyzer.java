package com.novan.audiolabnovan.videolab;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Analisis gerak kamera sederhana. Setiap beberapa puluh milidetik satu bingkai kecil diambil,
 * lalu pergeseran antar bingkai dicari dengan pencocokan blok pada gambar abu-abu.
 * Hasilnya jejak kumulatif (pecahan lebar dan tinggi bingkai), berpasangan x lalu y.
 */
public final class StabilizeAnalyzer {
    public interface Progress { void onProgress(int percent); }

    private static final int GW = 128;
    private static final int R = 8;

    private StabilizeAnalyzer() { }

    /** Mengembalikan jejak berukuran 2 kali jumlah sampel, atau null jika gagal atau dibatalkan. */
    public static float[] analyze(Context ctx, Uri uri, long startMs, long stepMs, int count,
                                  Progress cb, AtomicBoolean cancel) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, uri);
            int vw = parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH), 0);
            int vh = parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT), 0);
            int rot = parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION), 0);
            if (vw <= 0 || vh <= 0) return null;
            if (rot == 90 || rot == 270) { int t = vw; vw = vh; vh = t; }
            int gh = Math.max(32, Math.round(GW * (float) vh / vw));
            float[] path = new float[count * 2];
            int[] prev = null;
            float cx = 0, cy = 0;
            int lastPct = -1;
            for (int i = 0; i < count; i++) {
                if (cancel != null && cancel.get()) return null;
                long us = (startMs + i * stepMs) * 1000L;
                int[] cur = grab(r, us, GW, gh);
                if (cur == null) cur = prev;
                if (prev != null && cur != null && cur != prev) {
                    float[] s = shift(prev, cur, GW, gh);
                    cx += s[0] / GW;
                    cy += s[1] / gh;
                }
                path[i * 2] = cx;
                path[i * 2 + 1] = cy;
                if (cur != null) prev = cur;
                int pct = (i + 1) * 100 / count;
                if (cb != null && pct / 10 != lastPct / 10) { lastPct = pct; cb.onProgress(pct); }
            }
            return path;
        } catch (Exception e) {
            return null;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
    }

    private static int parse(String s, int def) {
        try { return s == null ? def : Integer.parseInt(s); } catch (Exception e) { return def; }
    }

    private static int[] grab(MediaMetadataRetriever r, long us, int w, int h) {
        Bitmap b = null;
        try {
            if (Build.VERSION.SDK_INT >= 27) {
                b = r.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST, w, h);
            } else {
                Bitmap full = r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST);
                if (full != null) {
                    b = Bitmap.createScaledBitmap(full, w, h, true);
                    if (b != full) full.recycle();
                }
            }
            if (b == null) return null;
            if (b.getWidth() != w || b.getHeight() != h) {
                Bitmap s = Bitmap.createScaledBitmap(b, w, h, true);
                if (s != b) b.recycle();
                b = s;
            }
            int[] px = new int[w * h];
            b.getPixels(px, 0, w, 0, 0, w, h);
            int[] g = new int[w * h];
            for (int i = 0; i < px.length; i++) {
                int p = px[i];
                g[i] = (((p >> 16) & 255) * 77 + ((p >> 8) & 255) * 151 + (p & 255) * 28) >> 8;
            }
            return g;
        } catch (Exception e) {
            return null;
        } finally {
            if (b != null && !b.isRecycled()) b.recycle();
        }
    }

    /** Pergeseran isi gambar dari bingkai a ke bingkai b, dalam piksel kecil (positif: ke kanan dan ke bawah). */
    private static float[] shift(int[] a, int[] b, int w, int h) {
        int n = 2 * R + 1;
        float[][] sad = new float[n][n];
        int x0 = R, x1 = w - R, y0 = R, y1 = h - R;
        float best = Float.MAX_VALUE;
        int bx = 0, by = 0;
        for (int sy = -R; sy <= R; sy++) {
            for (int sx = -R; sx <= R; sx++) {
                long sum = 0;
                int cnt = 0;
                for (int y = y0; y < y1; y += 2) {
                    int rowB = y * w;
                    int rowA = (y - sy) * w;
                    for (int x = x0; x < x1; x += 2) {
                        sum += Math.abs(b[rowB + x] - a[rowA + x - sx]);
                        cnt++;
                    }
                }
                float m = cnt == 0 ? 0 : (float) sum / cnt;
                sad[sy + R][sx + R] = m;
                if (m < best) { best = m; bx = sx; by = sy; }
            }
        }
        float zero = sad[R][R];
        if (zero - best < 0.5f) return new float[]{0f, 0f};
        float fx = bx, fy = by;
        int ix = bx + R, iy = by + R;
        if (ix > 0 && ix < n - 1) fx += parabola(sad[iy][ix - 1], sad[iy][ix], sad[iy][ix + 1]);
        if (iy > 0 && iy < n - 1) fy += parabola(sad[iy - 1][ix], sad[iy][ix], sad[iy + 1][ix]);
        return new float[]{fx, fy};
    }

    private static float parabola(float l, float c, float r) {
        float d = l - 2 * c + r;
        if (d <= 1e-6f) return 0f;
        float o = 0.5f * (l - r) / d;
        return Math.max(-0.5f, Math.min(0.5f, o));
    }
}
