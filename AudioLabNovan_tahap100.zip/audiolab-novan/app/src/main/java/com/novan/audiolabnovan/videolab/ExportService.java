package com.novan.audiolabnovan.videolab;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.core.content.ContextCompat;

/** Menjaga ekspor tetap berjalan ketika aplikasi dibuka di latar belakang. */
public class ExportService extends Service {

    static void start(Context c) {
        try {
            ContextCompat.startForegroundService(c, new Intent(c, ExportService.class));
        } catch (Exception ignored) {
            // ekspor tetap jalan di aplikasi, hanya tanpa perlindungan latar belakang
        }
    }

    static void stop(Context c) {
        try {
            c.stopService(new Intent(c, ExportService.class));
        } catch (Exception ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = ExportNotifier.progress(this, 0);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ExportNotifier.ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(ExportNotifier.ID_PROGRESS, n);
            }
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    /** Android 15 ke atas membatasi layanan jenis dataSync; berhenti dengan rapi agar aplikasi tidak ditutup paksa. */
    public void onTimeout(int startId, int fgsType) {
        stopSelf();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
