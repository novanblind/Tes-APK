package com.novan.audiolabnovan.videolab;

import android.net.Uri;

public class Clip {
    public final Uri uri;
    public final String name;
    public final long durationMs;
    public long startMs;
    public long endMs;
    public float speed = 1f;
    public float volume = 1f;
    public boolean muted = false;
    public long fadeInMs = 0;
    public long fadeOutMs = 0;
    // visual
    public int rotationCw = 0;
    public float zoom = 1f;
    public float brightness = 0f;
    public float contrast = 0f;
    public int filter = 0;
    public String title = "";
    public int titlePos = 2;
    public int titleSize = 1;
    public int titleColor = 0;
    public boolean flipH = false;
    public boolean flipV = false;
    public float saturation = 0f;
    public float hue = 0f;
    public float warmth = 0f;
    public float pitch = 1f;
    public int focus = 4;
    public int motion = 0;
    public int audioFx = 0;
    public boolean isImage = false;
    public int stabLevel = 0;
    public float[] stabPath = null;
    public long stabStart = 0;
    public long stabStep = 100;
    public long stabEnd = 0;

    public Clip(Uri uri, String name, long durationMs, long startMs, long endMs) {
        this.uri = uri;
        this.name = name;
        this.durationMs = durationMs;
        this.startMs = startMs;
        this.endMs = endMs;
    }

    public Clip copy() {
        Clip c = new Clip(uri, name, durationMs, startMs, endMs);
        c.speed = speed;
        c.volume = volume;
        c.muted = muted;
        c.fadeInMs = fadeInMs;
        c.fadeOutMs = fadeOutMs;
        c.rotationCw = rotationCw;
        c.zoom = zoom;
        c.brightness = brightness;
        c.contrast = contrast;
        c.filter = filter;
        c.title = title;
        c.titlePos = titlePos;
        c.titleSize = titleSize;
        c.titleColor = titleColor;
        c.flipH = flipH;
        c.flipV = flipV;
        c.saturation = saturation;
        c.hue = hue;
        c.warmth = warmth;
        c.pitch = pitch;
        c.focus = focus;
        c.motion = motion;
        c.audioFx = audioFx;
        c.isImage = isImage;
        c.stabLevel = stabLevel;
        c.stabPath = stabPath;
        c.stabStart = stabStart;
        c.stabStep = stabStep;
        c.stabEnd = stabEnd;
        return c;
    }

    public long outDurationMs() {
        return (long) ((endMs - startMs) / speed);
    }
}
