package com.novan.audiolabnovan.videolab;

/**
 * Tahap 52: daftar fitur untuk halaman awal berbentuk kisi tombol (seperti AudioLabNovan).
 * Tiap fitur membuka VideoLabActivity dalam "mode fitur": hanya bagian yang diperlukan fitur itu yang
 * tampil. Angka di {@link Def#tampil} adalah nomor urut tampilan di activity_main.xml (anak langsung
 * rootColumn, dihitung dari 0), sama dengan urutan di berkas tata letak.
 */
final class Fitur {
    static final String EXTRA = "fitur";
    static final String SEMUA = "semua";

    static final class Def {
        final String id;
        final String judul;
        final String simbol;
        final int[] tampil;

        Def(String id, String judul, String simbol, int[] tampil) {
            this.id = id;
            this.judul = judul;
            this.simbol = simbol;
            this.tampil = tampil;
        }
    }

    /** Selalu tampil: Tambah video, urungkan/ulangi, pemutar, info, pesan, penggeser, tombol maju mundur, daftar klip. */
    static final int[] INTI = {0, 2, 7, 8, 9, 11, 12, 13, 14, 15, 125};

    /** Selalu tampil di bawah: judul Ekspor, progres, ekspor video, ekspor audio, bagikan, hasil, batalkan. */
    static final int[] EKSPOR = {136, 137, 144, 145, 146, 147, 148};

    private static int[] r(int a, int b) {
        int[] x = new int[b - a + 1];
        for (int i = 0; i < x.length; i++) x[i] = a + i;
        return x;
    }

    private static int[] plus(int[] a, int... b) {
        int[] x = new int[a.length + b.length];
        System.arraycopy(a, 0, x, 0, a.length);
        System.arraycopy(b, 0, x, a.length, b.length);
        return x;
    }

    static final Def[] DAFTAR = {
        new Def("dengar", "Potong Sambil Mendengarkan", "\u2702", plus(r(19, 28), 10, 16, 17)),
        new Def("susun", "Potong dan Susun Klip", "\u2194", r(30, 39)),
        new Def("kecepatan", "Kecepatan dan Durasi", "\u00BB", r(41, 46)),
        new Def("bentuk", "Bentuk, Gerak, dan Rasio", "\u25A3", r(47, 57)),
        new Def("warna", "Warna Klip", "\u25D0", r(59, 66)),
        new Def("suara", "Suara Klip", "\u266A", r(68, 74)),
        new Def("musik", "Musik Latar dan Narasi", "\u266B", r(75, 86)),
        new Def("sfx", "Efek Suara Tambahan", "\u2726", r(87, 90)),
        new Def("judul", "Judul Klip", "T", r(92, 96)),
        new Def("subtitle", "Subtitle", "\u2261", r(97, 114)),
        new Def("stiker", "Teks dan Stiker", "\u263A", r(115, 119)),
        new Def("gambar", "Gambar Tempel dan Watermark", "\u25A6", r(120, 123)),
        new Def("slideshow", "Slideshow Foto", "\u25A4", new int[]{1, 46}),
        new Def("kualitas", "Transisi dan Kualitas Ekspor", "\u2699", r(127, 135)),
        new Def("siap", "Ekspor Siap Pakai", "\u25B6", new int[]{130, 131, 132, 138}),
        new Def("status", "Status WhatsApp", "\u2709", new int[]{139, 140}),
        new Def(SEMUA, "Semua Pengaturan", "\u2630", new int[0])
    };

    /** Mengembalikan fitur untuk mode terbatas; null untuk "semua" atau id yang tidak dikenal. */
    static Def cari(String id) {
        if (id == null || SEMUA.equals(id)) return null;
        for (Def d : DAFTAR) if (d.id.equals(id)) return d;
        return null;
    }
}
