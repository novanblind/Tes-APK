package com.novan.audiolabnovan.generator

import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import com.novan.audiolabnovan.pengolah.AlatUi
import java.util.Locale

/**
 * Tahap 91: Wave Generator. Membuat nada murni (sinus), persegi, segitiga, atau gigi gergaji pada frekuensi 20 sampai
 * 20.000 Hz, tetap atau menyapu dari satu frekuensi ke frekuensi lain (linear atau logaritmik). Kanal bisa kiri dan
 * kanan sama, hanya kiri, hanya kanan, atau binaural (kanan lebih tinggi beberapa Hz dari kiri).
 * Persegi dan gigi gergaji memakai koreksi PolyBLEP supaya tidak berdesis (aliasing) di frekuensi tinggi.
 * Tanpa AI dan tanpa internet.
 */
class WaveGeneratorActivity : GeneratorDasarActivity() {

    companion object {
        private val BENTUK = listOf("Sinus (nada murni)", "Persegi", "Segitiga", "Gigi gergaji")
        private val KODE_BENTUK = listOf("sinus", "persegi", "segitiga", "gergaji")
        private val SAPUAN = listOf("Tidak, frekuensi tetap", "Sapuan linear ke frekuensi akhir", "Sapuan logaritmik ke frekuensi akhir")
        private val KANAL = listOf("Kiri dan kanan sama", "Hanya kiri", "Hanya kanan", "Binaural (kanan lebih tinggi dari kiri)")
        private val PERSEN = listOf(10, 25, 50, 75, 90)
        private const val F_MIN = 20.0
        private const val F_MAKS = 20000.0

        private fun bacaAngka(teks: String): Double? {
            val v = teks.trim().replace(',', '.').toDoubleOrNull() ?: return null
            return if (v.isNaN() || v.isInfinite()) null else v
        }

        private fun tampilHz(f: Double): String =
            if (Math.abs(f - Math.round(f)) < 0.005) Math.round(f).toString() else String.format(Locale("id"), "%.2f", f)
    }

    private lateinit var spBentuk: Spinner
    private lateinit var etFrekuensi: EditText
    private lateinit var spSapuan: Spinner
    private lateinit var etAkhir: EditText
    private lateinit var spKanal: Spinner
    private lateinit var etSelisih: EditText
    private lateinit var spVolume: Spinner

    override val judulLayar = "Wave Generator"
    override val keterangan = "Buat nada dari rumus, 20 sampai 20.000 Hz. Mulai dari volume HP yang pelan."
    override val subfolder = "Wave Generator"

    private fun kolomAngka(akar: LinearLayout, label: String, awal: String, hint: String): EditText {
        val et = EditText(this).apply {
            setText(awal)
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        akar.addView(AlatUi.label(this, label, et))
        akar.addView(et, AlatUi.margin(this))
        return et
    }

    override fun tambahKolom(akar: LinearLayout) {
        val c = this
        spBentuk = AlatUi.spinner(c, BENTUK)
        akar.addView(AlatUi.label(c, "Bentuk gelombang", spBentuk))
        akar.addView(spBentuk, AlatUi.margin(c))

        etFrekuensi = kolomAngka(akar, "Frekuensi (Hz), 20 sampai 20.000", "440", "Contoh 440 atau 1000,5")

        spSapuan = AlatUi.spinner(c, SAPUAN)
        akar.addView(AlatUi.label(c, "Sapuan", spSapuan))
        akar.addView(spSapuan, AlatUi.margin(c))
        etAkhir = kolomAngka(akar, "Frekuensi akhir (Hz), untuk sapuan", "2000", "Contoh 2000")

        spKanal = AlatUi.spinner(c, KANAL)
        akar.addView(AlatUi.label(c, "Kanal", spKanal))
        akar.addView(spKanal, AlatUi.margin(c))
        etSelisih = kolomAngka(akar, "Selisih binaural (Hz), 0,5 sampai 40", "10", "Contoh 10")

        spVolume = AlatUi.spinner(c, PERSEN.map { "$it persen" }).also { it.setSelection(2) }
        akar.addView(AlatUi.label(c, "Volume", spVolume))
        akar.addView(spVolume, AlatUi.margin(c))
    }

    override fun siapkan(durasiDetik: Double): GeneratorDasarActivity.Rencana? {
        val f0 = bacaAngka(etFrekuensi.text.toString())
        if (f0 == null || f0 < F_MIN || f0 > F_MAKS) {
            status("Frekuensi tidak valid. Isi angka antara 20 dan 20.000 Hz.", true)
            return null
        }
        val sapuan = spSapuan.selectedItemPosition.coerceIn(0, 2)
        var f1 = f0
        if (sapuan != 0) {
            val a = bacaAngka(etAkhir.text.toString())
            if (a == null || a < F_MIN || a > F_MAKS) {
                status("Frekuensi akhir tidak valid. Isi angka antara 20 dan 20.000 Hz.", true)
                return null
            }
            f1 = a
        }
        val kanalMode = spKanal.selectedItemPosition.coerceIn(0, 3)
        var selisih = 0.0
        if (kanalMode == 3) {
            val s = bacaAngka(etSelisih.text.toString())
            if (s == null || s < 0.5 || s > 40.0) {
                status("Selisih binaural tidak valid. Isi angka antara 0,5 dan 40 Hz.", true)
                return null
            }
            selisih = s
            if (maxOf(f0, f1) + selisih > F_MAKS) {
                status("Frekuensi tertinggi ditambah selisih binaural melewati 20.000 Hz. Turunkan frekuensi atau selisihnya.", true)
                return null
            }
        }
        val bi = spBentuk.selectedItemPosition.coerceIn(0, BENTUK.size - 1)
        val amp = PERSEN[spVolume.selectedItemPosition.coerceIn(0, PERSEN.size - 1)] / 100.0
        val ph = PenghasilGelombang(KODE_BENTUK[bi], f0, f1, sapuan, kanalMode, selisih, amp, durasiDetik)
        val tentangFrekuensi = if (sapuan == 0) "${tampilHz(f0)} Hz" else
            "menyapu ${if (sapuan == 1) "linear" else "logaritmik"} dari ${tampilHz(f0)} ke ${tampilHz(f1)} Hz"
        val nama = "Gelombang_" + KODE_BENTUK[bi].replaceFirstChar { it.uppercase() } + "_" +
            (if (sapuan == 0) "${tampilHz(f0)}Hz" else "${tampilHz(f0)}-${tampilHz(f1)}Hz").replace(',', '_')
        return GeneratorDasarActivity.Rencana(ph, nama,
            "Gelombang ${BENTUK[bi].substringBefore(" (").lowercase()}, $tentangFrekuensi, ${KANAL[kanalMode].lowercase()}" +
                (if (kanalMode == 3) ", selisih ${tampilHz(selisih)} Hz" else "") + ", volume ${(amp * 100).toInt()} persen.")
    }

    private class PenghasilGelombang(
        private val bentuk: String,
        private val f0: Double,
        private val f1: Double,
        private val sapuan: Int,
        private val kanalMode: Int,
        private val selisih: Double,
        private val amp: Double,
        private val durasiDetik: Double
    ) : GeneratorDasarActivity.Penghasil {
        override val kanal = 2
        private var fasaKiri = 0.0
        private var fasaKanan = 0.0
        private var idx = 0L
        private val totalFrame = Math.round(durasiDetik * GeneratorDasarActivity.SR).coerceAtLeast(1L)
        private val rasio = if (f0 > 0.0) f1 / f0 else 1.0

        private fun polyBlep(t: Double, dt: Double): Double {
            if (t < dt) {
                val x = t / dt
                return x + x - x * x - 1.0
            }
            if (t > 1.0 - dt) {
                val x = (t - 1.0) / dt
                return x * x + x + x + 1.0
            }
            return 0.0
        }

        private fun sampel(ph: Double, d: Double): Double = when (bentuk) {
            "persegi" -> {
                var v = if (ph < 0.5) 1.0 else -1.0
                v += polyBlep(ph, d)
                var t2 = ph + 0.5
                if (t2 >= 1.0) t2 -= 1.0
                v - polyBlep(t2, d)
            }
            "gergaji" -> 2.0 * ph - 1.0 - polyBlep(ph, d)
            "segitiga" -> 1.0 - 4.0 * Math.abs(ph - 0.5)
            else -> Math.sin(2.0 * Math.PI * ph)
        }

        private fun frekuensi(): Double {
            if (sapuan == 0) return f0
            val t = (idx.toDouble() / totalFrame).coerceIn(0.0, 1.0)
            return if (sapuan == 1) f0 + (f1 - f0) * t else f0 * Math.pow(rasio, t)
        }

        override fun isi(buf: ShortArray, frame: Int) {
            val puncak = amp * 32767.0
            var p = 0
            for (i in 0 until frame) {
                val f = frekuensi()
                val dKiri = f / GeneratorDasarActivity.SR
                val sKiri = sampel(fasaKiri, dKiri)
                fasaKiri += dKiri
                if (fasaKiri >= 1.0) fasaKiri -= 1.0
                val sKanan: Double
                if (kanalMode == 3) {
                    val dKanan = (f + selisih) / GeneratorDasarActivity.SR
                    sKanan = sampel(fasaKanan, dKanan)
                    fasaKanan += dKanan
                    if (fasaKanan >= 1.0) fasaKanan -= 1.0
                } else {
                    sKanan = sKiri
                }
                val kiri = if (kanalMode == 2) 0.0 else sKiri
                val kanan = if (kanalMode == 1) 0.0 else sKanan
                buf[p++] = (kiri * puncak).toInt().coerceIn(-32767, 32767).toShort()
                buf[p++] = (kanan * puncak).toInt().coerceIn(-32767, 32767).toShort()
                idx++
            }
        }
    }
}
