package com.novan.audiolabnovan.videolab;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.RgbMatrix;

/** Memudarkan gambar ke hitam di awal dan akhir klip. */
@UnstableApi
public final class FadeBlackMatrix implements RgbMatrix {
    private final long totalUs;
    private final long inUs;
    private final long outUs;

    public FadeBlackMatrix(long totalUs, long inUs, long outUs) {
        this.totalUs = totalUs;
        this.inUs = inUs;
        this.outUs = outUs;
    }

    @Override
    public float[] getMatrix(long presentationTimeUs, boolean useHdr) {
        float g = 1f;
        if (inUs > 0 && presentationTimeUs < inUs) {
            g = Math.max(0f, presentationTimeUs / (float) inUs);
        }
        long left = totalUs - presentationTimeUs;
        if (outUs > 0 && left < outUs) {
            g = Math.min(g, Math.max(0f, left / (float) outUs));
        }
        return new float[]{
                g, 0, 0, 0,
                0, g, 0, 0,
                0, 0, g, 0,
                0, 0, 0, 1};
    }
}
