package com.novan.audiolabnovan.karaoke

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.OpenableColumns
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/** Lagu pengiring yang sudah diurai: stereo 44,1 kHz bergantian (kiri, kanan, ...), siap diputar dan dicampur. */
class Lagu(val pcm: ShortArray, val nama: String) {
    val sr: Int get() = PenguraiLagu.SR
    val frame: Int get() = pcm.size / 2
    val durasiMs: Long get() = frame.toLong() * 1000L / PenguraiLagu.SR

    /** Peta nada lagu untuk penilaian nyanyian; diisi di utas latar sesudah lagu dimuat, null selama belum siap. */
    @Volatile var chroma: ChromaLagu? = null
}

/**
 * Mengurai berkas audio apa pun yang dikenali Android (MP3, M4A, AAC, WAV, OGG, FLAC) menjadi PCM stereo 44,1 kHz
 * di memori. Dengan begitu lagu bisa diputar lewat jalur sendiri, jam putarnya diketahui tepat, dan vokal yang
 * direkam terpisah bisa dicampur ulang kapan saja. Lagu dibatasi [MAKS_MS] supaya memori aman.
 */
object PenguraiLagu {
    const val SR = 44_100
    const val MAKS_MS = 12L * 60L * 1000L

    /** Nama berkas tanpa ekstensi, dipakai sebagai judul lagu dan bagian nama hasil. */
    fun judul(ctx: Context, uri: Uri): String {
        var nama: String? = null
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) nama = c.getString(0)
            }
        } catch (e: Exception) { }
        val n = nama ?: uri.lastPathSegment ?: "Lagu"
        val titik = n.lastIndexOf('.')
        return (if (titik > 0) n.substring(0, titik) else n).ifBlank { "Lagu" }
    }

    /**
     * Mengurai [uri]. Mengembalikan null bila gagal atau dibatalkan lewat [batal].
     * [progres] dipanggil dengan 0..100 (perkiraan dari durasi yang tertulis di berkas).
     */
    fun urai(ctx: Context, uri: Uri, batal: () -> Boolean, progres: (Int) -> Unit): Lagu? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var jalur = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    jalur = i
                    fmt = f
                    break
                }
            }
            if (jalur < 0 || fmt == null) return null
            ex.selectTrack(jalur)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            var kanal = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var laju = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else SR
            val durasiUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L

            val dc = MediaCodec.createDecoderByType(mime)
            codec = dc
            dc.configure(fmt, null, null, 0)
            dc.start()

            val info = MediaCodec.BufferInfo()
            val hasil = PenampungShort(max(1 shl 16, (durasiUs / 1_000_000L * laju * 2).coerceAtMost(40_000_000L).toInt()))
            var masukSelesai = false
            var keluarSelesai = false
            var macet = 0
            var frameAsal = 0L
            var persenTerakhir = -1
            while (!keluarSelesai) {
                if (batal()) return null
                if (!masukSelesai) {
                    val ib = dc.dequeueInputBuffer(10_000)
                    if (ib >= 0) {
                        val buf = dc.getInputBuffer(ib)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            dc.queueInputBuffer(ib, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            masukSelesai = true
                        } else {
                            dc.queueInputBuffer(ib, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val ob = dc.dequeueOutputBuffer(info, 10_000)
                when {
                    ob == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val nf = dc.outputFormat
                        if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) kanal = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) laju = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    ob >= 0 -> {
                        macet = 0
                        val out = dc.getOutputBuffer(ob)
                        if (out != null && info.size > 0) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val total = sb.remaining()
                            val tmp = ShortArray(total)
                            sb.get(tmp)
                            val k = max(1, kanal)
                            val frames = total / k
                            // Ubah ke stereo: mono digandakan; lebih dari dua saluran, ambil kiri dan kanan depan.
                            val st = ShortArray(frames * 2)
                            for (f in 0 until frames) {
                                val l = tmp[f * k]
                                val r = if (k >= 2) tmp[f * k + 1] else l
                                st[f * 2] = l
                                st[f * 2 + 1] = r
                            }
                            hasil.tambah(st, 0, st.size)
                            frameAsal += frames
                        }
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) keluarSelesai = true
                        dc.releaseOutputBuffer(ob, false)
                        if (durasiUs > 0) {
                            val p = min(99L, frameAsal * 1_000_000L / max(1, laju) * 100L / durasiUs).toInt()
                            if (p != persenTerakhir) {
                                persenTerakhir = p
                                progres(p)
                            }
                        }
                        if (frameAsal * 1000L / max(1, laju) > MAKS_MS) keluarSelesai = true
                    }
                    else -> {
                        // Tidak ada keluaran: bila masukan sudah habis dan lama tidak ada hasil, anggap selesai.
                        if (masukSelesai && ++macet > 300) keluarSelesai = true
                    }
                }
            }
            if (hasil.ukuran < 2 * 1024) return null
            val mentah = hasil.keLarik()
            val pcm = if (laju == SR) mentah else ubahLaju(mentah, laju, SR)
            progres(100)
            return Lagu(pcm, judul(ctx, uri))
        } catch (e: Exception) {
            return null
        } catch (e: OutOfMemoryError) {
            return null
        } finally {
            try { codec?.stop() } catch (e: Exception) { }
            try { codec?.release() } catch (e: Exception) { }
            try { ex.release() } catch (e: Exception) { }
        }
    }

    /** Pengubah laju sampel stereo dengan interpolasi linear (cukup untuk karaoke). */
    fun ubahLaju(stereo: ShortArray, dari: Int, ke: Int): ShortArray {
        val frameAsal = stereo.size / 2
        if (frameAsal < 2 || dari == ke) return stereo
        val frameBaru = (frameAsal.toLong() * ke / dari).toInt()
        val hasil = ShortArray(frameBaru * 2)
        val langkah = dari.toDouble() / ke
        for (i in 0 until frameBaru) {
            val pos = i * langkah
            val i0 = pos.toInt()
            val t = pos - i0
            val a = min(i0, frameAsal - 1)
            val b = min(i0 + 1, frameAsal - 1)
            for (c in 0..1) {
                val x = stereo[a * 2 + c] * (1.0 - t) + stereo[b * 2 + c] * t
                hasil[i * 2 + c] = x.toInt().toShort()
            }
        }
        return hasil
    }
}
