package com.novan.audiolabnovan.potong

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.novan.audiolabnovan.Converter
import com.novan.audiolabnovan.R
import java.util.Locale

/**
 * Tahap 52: Potong sambil mendengarkan, ramah tunanetra.
 *
 * Berkas diputar; pengguna menekan "Tandai awal di sini" dan "Tandai akhir di sini" pada saat mendengar bagian yang
 * dimaksud, lalu memilih "Simpan bagian ini saja" (potong) atau "Buang bagian ini" (hapus bagian tengah).
 * Hasilnya dikembalikan ke layar utama sebagai isian waktu, jadi proses konversi tetap memakai alur yang sama.
 * Semua tombol besar, berlabel jelas, dan setiap aksi diumumkan lewat pembaca layar. Tersedia juga geser mundur
 * dan maju (1, 5, dan 15 detik) agar penandaan bisa dibetulkan dengan teliti.
 */
class PemotongActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_NAMA = "nama"
        const val HASIL_MODE = "mode"        // "simpan" atau "buang"
        const val HASIL_DARI = "dari"        // detik, teks berformat titik
        const val HASIL_SAMPAI = "sampai"
        const val MODE_SIMPAN = "simpan"
        const val MODE_BUANG = "buang"
    }

    private var mp: MediaPlayer? = null
    private var siap = false
    private var durasi = 0               // milidetik
    private var awal = -1                // milidetik, -1 = belum ditandai
    private var akhir = -1
    private var berhentiDi = -1          // saat "dengarkan bagian terpilih": berhenti di sini
    private var sedangGeser = false
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var tvPosisi: TextView
    private lateinit var tvTanda: TextView
    private lateinit var tvStatus: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnPutar: Button
    private lateinit var btnSimpan: Button
    private lateinit var btnBuang: Button
    private lateinit var btnDengar: Button

    private val pengetik = object : Runnable {
        override fun run() {
            val p = mp
            if (p != null && siap) {
                val pos = try { p.currentPosition } catch (_: Exception) { 0 }
                if (berhentiDi in 0..pos && p.isPlaying) {
                    p.pause()
                    p.seekTo(berhentiDi)
                    berhentiDi = -1
                    segarkanTombol()
                    umumkan("Selesai memutar bagian terpilih.")
                }
                if (!sedangGeser) seek.progress = pos
                tvPosisi.text = "Posisi ${teks(pos)} dari ${teks(durasi)}"
            }
            handler.postDelayed(this, 250)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Waktu dibacakan jelas: "1 menit 5 detik". */
    private fun teks(ms: Int): String = Converter.durasiTeks(ms / 1000.0)

    private fun detik(ms: Int): String = String.format(Locale.US, "%.2f", ms / 1000.0)

    private fun tombol(label: String, aksi: () -> Unit): Button = Button(this).apply {
        text = label
        minHeight = dp(56)
        isAllCaps = false
        textSize = 17f
        setOnClickListener { aksi() }
    }

    private fun LinearLayout.tambah(v: View, atas: Int = 8) {
        addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(atas) })
    }

    private fun subjudul(t: String) = TextView(this).apply {
        text = t
        textSize = 20f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        ViewCompat.setAccessibilityHeading(this, true)
    }

    private fun umumkan(t: String) {
        tvStatus.text = t
        tvStatus.announceForAccessibility(t)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.judul_potong)
        val uri: Uri? = intent.getStringExtra(EXTRA_URI)?.let { Uri.parse(it) }
        val nama = intent.getStringExtra(EXTRA_NAMA).orEmpty()

        val akar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(akar) })

        akar.tambah(subjudul("Potong sambil mendengarkan"), 0)
        akar.tambah(TextView(this).apply {
            textSize = 16f
            text = "Berkas: $nama. Putar, lalu tekan Tandai awal saat sampai di suara yang jadi awal bagian, dan Tandai akhir saat sampai di suara yang jadi akhirnya."
        })
        tvPosisi = TextView(this).apply { textSize = 18f; text = "Memuat berkas…" }
        akar.tambah(tvPosisi, 12)

        seek = SeekBar(this).apply {
            minimumHeight = dp(48)
            contentDescription = "Posisi putar"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        ViewCompat.setStateDescription(sb!!, teks(p))
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { sedangGeser = true }
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    sedangGeser = false
                    lompat(sb?.progress ?: 0)
                }
            })
        }
        akar.tambah(seek)

        // ----- Putar -----
        akar.tambah(subjudul("Putar"), 16)
        btnPutar = tombol("Putar") { putarAtauJeda() }
        akar.tambah(btnPutar)
        val baris1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun geser(label: String, ms: Int) = tombol(label) { geserPosisi(ms) }.also {
            baris1.addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            it.contentDescription = "${if (ms < 0) "Mundur" else "Maju"} ${Math.abs(ms) / 1000} detik"
        }
        geser("−15", -15000); geser("−5", -5000); geser("−1", -1000); geser("+1", 1000); geser("+5", 5000); geser("+15", 15000)
        akar.tambah(baris1)
        akar.tambah(tombol("Ke awal berkas") { lompat(0); umumkan("Kembali ke awal berkas.") })
        akar.tambah(tombol("Baca posisi sekarang") {
            val p = mp?.currentPosition ?: 0
            umumkan("Posisi ${teks(p)} dari ${teks(durasi)}.")
        })

        // ----- Potong cepat -----
        akar.tambah(subjudul("Potong cepat"), 16)
        akar.tambah(tombol("Buang bagian depan sampai sini") { potongCepat(true) })
        akar.tambah(tombol("Buang bagian belakang dari sini") { potongCepat(false) })

        // ----- Tandai -----
        akar.tambah(subjudul("Tandai bagian (untuk bagian tengah)"), 16)
        akar.tambah(tombol("Tandai awal di sini") { tandaiAwal() })
        akar.tambah(tombol("Tandai akhir di sini") { tandaiAkhir() })
        tvTanda = TextView(this).apply { textSize = 16f }
        akar.tambah(tvTanda)
        btnDengar = tombol("Dengarkan bagian terpilih") { dengarkan() }
        akar.tambah(btnDengar)
        akar.tambah(tombol("Hapus tanda") {
            awal = -1; akhir = -1; berhentiDi = -1
            segarkanTanda(); segarkanTombol()
            umumkan("Tanda awal dan akhir dihapus.")
        })

        // ----- Pilih aksi -----
        akar.tambah(subjudul("Lalu pilih"), 16)
        btnSimpan = tombol("Simpan bagian ini saja (potong)") { selesai(MODE_SIMPAN) }
        akar.tambah(btnSimpan)
        btnBuang = tombol("Buang bagian ini (sisanya disambung)") { selesai(MODE_BUANG) }
        akar.tambah(btnBuang)
        akar.tambah(tombol("Batal, kembali tanpa mengubah") { setResult(RESULT_CANCELED); finish() })

        tvStatus = TextView(this).apply {
            textSize = 16f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        akar.tambah(tvStatus, 16)

        segarkanTanda()
        segarkanTombol()
        if (uri == null) { tvStatus.text = "Berkas tidak ada."; return }
        muat(uri)
    }

    private fun muat(uri: Uri) {
        val p = MediaPlayer()
        mp = p
        try {
            p.setDataSource(applicationContext, uri)
            p.setOnPreparedListener {
                siap = true
                durasi = it.duration
                seek.max = durasi
                tvPosisi.text = "Posisi ${teks(0)} dari ${teks(durasi)}"
                segarkanTombol()
                umumkan("Berkas siap, lama ${teks(durasi)}. Tekan Putar.")
            }
            p.setOnCompletionListener { segarkanTombol(); umumkan("Sampai di akhir berkas.") }
            p.setOnErrorListener { _, _, _ ->
                siap = false
                tvStatus.text = "Berkas tidak bisa diputar. Coba berkas lain."
                segarkanTombol()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            tvStatus.text = "Berkas tidak bisa dibuka: ${e.message}"
        }
        handler.post(pengetik)
    }

    private fun putarAtauJeda() {
        val p = mp ?: return
        if (!siap) return
        berhentiDi = -1
        if (p.isPlaying) {
            p.pause()
            umumkan("Dijeda di ${teks(p.currentPosition)}.")
        } else {
            if (p.currentPosition >= durasi - 200) p.seekTo(0)
            p.start()
            umumkan("Memutar.")
        }
        segarkanTombol()
    }

    private fun lompat(ms: Int) {
        val p = mp ?: return
        if (!siap) return
        val t = ms.coerceIn(0, durasi)
        p.seekTo(t)
        seek.progress = t
    }

    private fun geserPosisi(delta: Int) {
        val p = mp ?: return
        if (!siap) return
        val t = (p.currentPosition + delta).coerceIn(0, durasi)
        lompat(t)
        umumkan("Di ${teks(t)}.")
    }

    private fun posisiSekarang(): Int = if (siap) (mp?.currentPosition ?: 0) else 0

    private fun tandaiAwal() {
        if (!siap) return
        val t = posisiSekarang()
        if (akhir in 0..t) { umumkan("Awal harus sebelum akhir. Akhir sekarang di ${teks(akhir)}. Geser mundur dulu."); return }
        awal = t
        segarkanTanda(); segarkanTombol()
        umumkan("Awal ditandai di ${teks(t)}.")
    }

    private fun tandaiAkhir() {
        if (!siap) return
        val t = posisiSekarang()
        if (awal >= 0 && t <= awal) { umumkan("Akhir harus sesudah awal. Awal sekarang di ${teks(awal)}. Putar lebih jauh dulu."); return }
        akhir = t
        segarkanTanda(); segarkanTombol()
        umumkan("Akhir ditandai di ${teks(t)}.")
    }

    private fun dengarkan() {
        val p = mp ?: return
        if (awal < 0 || akhir <= awal) { umumkan("Tandai awal dan akhir dulu."); return }
        p.seekTo(awal)
        berhentiDi = akhir
        p.start()
        segarkanTombol()
        umumkan("Memutar bagian terpilih, ${teks(akhir - awal)}.")
    }

    /** Satu tombol: buang depan sampai posisi sekarang, atau buang belakang dari posisi sekarang. */
    private fun potongCepat(depan: Boolean) {
        if (!siap) return
        val t = posisiSekarang()
        if (depan && t <= 0) { umumkan("Putar dulu sampai titik yang dimaksud. Posisi sekarang masih di awal berkas."); return }
        if (!depan && t >= durasi - 100) { umumkan("Putar dulu sampai titik yang dimaksud. Posisi sekarang sudah di akhir berkas."); return }
        mp?.pause()
        val hasil = Intent().putExtra(HASIL_MODE, MODE_SIMPAN)
        if (depan) hasil.putExtra(HASIL_DARI, detik(t)).putExtra(HASIL_SAMPAI, "")
        else hasil.putExtra(HASIL_DARI, "0").putExtra(HASIL_SAMPAI, detik(t))
        setResult(RESULT_OK, hasil)
        finish()
    }

    private fun selesai(mode: String) {
        if (awal < 0 && mode == MODE_BUANG) { umumkan("Tandai awal dulu."); return }
        if (akhir < 0 && mode == MODE_BUANG) { umumkan("Tandai akhir dulu."); return }
        if (awal < 0 && akhir < 0) { umumkan("Tandai awal atau akhir dulu."); return }
        val dari = if (awal >= 0) awal else 0
        // Simpan tanpa tanda akhir: sampai akhir berkas (diisi 0 di layar utama).
        val sampai = if (akhir >= 0) akhir else 0
        setResult(RESULT_OK, Intent().putExtra(HASIL_MODE, mode)
            .putExtra(HASIL_DARI, detik(dari))
            .putExtra(HASIL_SAMPAI, if (sampai == 0) "" else detik(sampai)))
        finish()
    }

    private fun segarkanTanda() {
        val a = if (awal >= 0) "Awal: ${teks(awal)}" else "Awal: belum ditandai"
        val b = if (akhir >= 0) "Akhir: ${teks(akhir)}" else "Akhir: belum ditandai"
        tvTanda.text = "$a.\n$b."
    }

    private fun segarkanTombol() {
        val bermain = try { mp?.isPlaying == true } catch (_: Exception) { false }
        btnPutar.text = if (bermain) "Jeda" else "Putar"
        btnPutar.isEnabled = siap
        btnDengar.isEnabled = siap && awal >= 0 && akhir > awal
        btnSimpan.isEnabled = siap && (awal >= 0 || akhir >= 0)
        btnBuang.isEnabled = siap && awal >= 0 && akhir > awal
    }

    override fun onStop() {
        super.onStop()
        try { if (mp?.isPlaying == true) mp?.pause() } catch (_: Exception) { }
        if (::btnPutar.isInitialized) segarkanTombol()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { mp?.release() } catch (_: Exception) { }
        mp = null
        super.onDestroy()
    }
}
