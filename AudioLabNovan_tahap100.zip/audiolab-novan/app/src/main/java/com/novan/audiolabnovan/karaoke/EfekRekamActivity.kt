package com.novan.audiolabnovan.karaoke

import android.os.Bundle
import android.widget.Spinner
import com.novan.audiolabnovan.R

/**
 * Tahap 47: layar pengaturan efek langsung untuk perekam suara. Pilihan dipakai saat perekam dimulai dengan
 * sumber "Mikrofon dengan efek langsung". Semua pilihan disimpan seketika di [EfekRekamPrefs].
 */
class EfekRekamActivity : HalamanKaraoke() {

    override val judulHalaman = R.string.judul_efek_rekam

    private lateinit var ep: EfekRekamPrefs
    private val spinner = ArrayList<Spinner>()

    override fun onCreate(savedInstanceState: Bundle?) {
        ep = EfekRekamPrefs(this)
        super.onCreate(savedInstanceState)
    }

    override fun bangun() {
        info(getString(R.string.efek_rekam_petunjuk))
        tombol(getString(R.string.efek_rekam_bawaan)) {
            ep.setelBawaanKaraoke()
            toast(R.string.efek_rekam_bawaan_selesai)
            recreate()
        }
        tombol(getString(R.string.efek_rekam_matikan)) {
            ep.matikanSemua()
            toast(R.string.efek_rekam_mati_selesai)
            recreate()
        }

        bagian(getString(R.string.efek_rekam_bag_suara), 18f)
        pilihan(getString(R.string.efek_rekam_sumber), larik(R.array.k_sumber_suara), ep.sumber) { ep.sumber = it }
        pilihan(getString(R.string.efek_rekam_gain), larik(R.array.k_gain_suara), ep.gain) { ep.gain = it }
        pilihan(getString(R.string.efek_rekam_bass), larik(R.array.k_bass_suara), ep.bass) { ep.bass = it }
        pilihan(getString(R.string.efek_rekam_jernih), larik(R.array.k_jernih_suara), ep.jernih) { ep.jernih = it }

        bagian(getString(R.string.efek_rekam_bag_gema), 18f)
        pilihan(getString(R.string.karaoke_efek), larik(R.array.k_efek_preset).take(6), ep.efek) { ep.efek = it }

        bagian(getString(R.string.efek_rekam_bag_vokal), 18f)
        pilihan(getString(R.string.efek_rekam_dengung), larik(R.array.k_dengung_suara), ep.dengung) { ep.dengung = it }
        pilihan(getString(R.string.efek_rekam_gerbang), larik(R.array.k_gerbang_suara), ep.gerbang) { ep.gerbang = it }
        pilihan(getString(R.string.efek_rekam_nada), larik(R.array.k_nada_suara), ep.nada) { ep.nada = it }
        pilihan(getString(R.string.efek_rekam_kompresor), larik(R.array.k_kompresor_suara), ep.kompresor) { ep.kompresor = it }
        pilihan(getString(R.string.efek_rekam_desis), larik(R.array.k_deesser_suara), ep.deEsser) { ep.deEsser = it }
        saklar(getString(R.string.efek_rekam_pembatas), ep.pembatas) { ep.pembatas = it }

        bagian(getString(R.string.efek_rekam_bag_pantau), 18f)
        saklar(getString(R.string.karaoke_pantau), ep.pantau) { ep.pantau = it }
        info(getString(R.string.efek_rekam_pantau_info))
        tombol(getString(R.string.efek_rekam_tutup)) { finish() }
    }
}
