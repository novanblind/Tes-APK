package com.novan.audiolabnovan.pengolah

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.novan.audiolabnovan.Converter
import com.novan.audiolabnovan.OutFmt
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min

/**
 * Tahap 89: pembantu bersama untuk fitur yang mengolah PCM di memori (Vocal AutoTuner, Tambah SFX):
 * tulis WAV sementara, sandi ke MP3/M4A/FLAC/WAV lewat FFmpeg, lalu simpan ke folder Musik.
 */
object PenyimpanHasil {

    /** Menulis [pcm] (bergantian antar kanal) sepanjang [frame] frame ke berkas WAV 16 bit. */
    fun tulisWav(f: File, pcm: ShortArray, frame: Int, sr: Int, kanal: Int) {
        val n = frame * kanal
        val dataBytes = n.toLong() * 2L
        BufferedOutputStream(FileOutputStream(f), 1 shl 16).use { out ->
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray())
            h.putInt((36L + dataBytes).toInt())
            h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray())
            h.putInt(16)
            h.putShort(1)
            h.putShort(kanal.toShort())
            h.putInt(sr)
            h.putInt(sr * kanal * 2)
            h.putShort((kanal * 2).toShort())
            h.putShort(16)
            h.put("data".toByteArray())
            h.putInt(dataBytes.toInt())
            out.write(h.array())
            val blok = ByteBuffer.allocate(8192 * 2).order(ByteOrder.LITTLE_ENDIAN)
            var i = 0
            while (i < n) {
                val b = min(8192, n - i)
                blok.clear()
                for (k in 0 until b) blok.putShort(pcm[i + k])
                out.write(blok.array(), 0, b * 2)
                i += b
            }
        }
    }

    /** Menyandi [wav] ke [dest]. Memblokir (panggil dari utas latar). Mengembalikan null bila berhasil, atau pesan galat. */
    fun sandi(wav: File, dest: File, fmt: OutFmt, kbps: Int, judul: String, album: String): String? {
        val args = ArrayList<String>()
        args += listOf("-y", "-nostdin", "-i", wav.absolutePath, "-vn")
        args += fmt.codecArgs(kbps)
        args += listOf("-metadata", "title=$judul", "-metadata", "artist=AudioLab novan", "-metadata", "album=$album")
        args += dest.absolutePath
        val s = FFmpegKit.executeWithArguments(args.toTypedArray())
        return when {
            ReturnCode.isSuccess(s.returnCode) && dest.length() > 0 -> null
            ReturnCode.isCancel(s.returnCode) -> "Dibatalkan."
            else -> "Gagal menyandi (kode ${s.returnCode}): " + (s.allLogsAsString ?: "").takeLast(300).replace('\n', ' ')
        }
    }

    /**
     * Menyimpan [f] ke Musik/AudioLab Novan/[subfolder] (Android 10 ke atas lewat MediaStore). Di bawahnya disalin ke
     * folder musik milik aplikasi, supaya tidak perlu izin penyimpanan. Mengembalikan alamat berkas hasil.
     */
    fun simpan(ctx: Context, f: File, nama: String, fmt: OutFmt, subfolder: String): Uri {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, nama)
                put(MediaStore.Audio.Media.MIME_TYPE, fmt.mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/AudioLab Novan/$subfolder")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val koleksi = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val u = ctx.contentResolver.insert(koleksi, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
            try {
                Converter.copyTo(ctx, f, u)
                ctx.contentResolver.update(u, ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) {
                try { ctx.contentResolver.delete(u, null, null) } catch (_: Exception) { }
                throw e
            }
            return u
        }
        val dasar = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
        val dir = File(dasar, "AudioLab Novan/$subfolder")
        dir.mkdirs()
        val t = File(dir, nama)
        f.copyTo(t, overwrite = true)
        return Uri.fromFile(t)
    }

    fun stempel(): String = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())

    /** Nama berkas tanpa ekstensi, dibatasi 60 huruf, untuk judul metadata. */
    fun judulDari(nama: String): String = nama.substringBeforeLast('.', nama).take(60)
}
