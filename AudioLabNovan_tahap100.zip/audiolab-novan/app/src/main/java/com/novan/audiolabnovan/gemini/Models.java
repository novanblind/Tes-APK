package com.novan.audiolabnovan.gemini;

import android.content.Context;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Daftar model TTS yang tersimpan di HP (bisa diperbarui lewat tombol). */
public final class Models {
    private Models() {}

    private static final String KEY = "tts_model_list";

    public static final String[] DEFAULT_MODELS = {
            "gemini-2.5-flash-preview-tts",
            "gemini-3.1-flash-tts-preview",
            "gemini-2.5-pro-preview-tts",
            "gemini-3.8-flash-tts",
            "gemini-3.8-flash-lite-tts"
    };

    public static List<String> load(Context c) {
        List<String> r = new ArrayList<>();
        String s = GeminiStore.prefs(c).getString(KEY, null);
        if (s != null) {
            try {
                JSONArray a = new JSONArray(s);
                for (int i = 0; i < a.length(); i++) {
                    String m = a.optString(i, "");
                    if (!m.isEmpty() && !r.contains(m)) r.add(m);
                }
            } catch (Exception ignored) { }
        }
        if (r.isEmpty()) r.addAll(Arrays.asList(DEFAULT_MODELS));
        return r;
    }

    public static void save(Context c, List<String> models) {
        JSONArray a = new JSONArray();
        for (String m : models) a.put(m);
        GeminiStore.prefs(c).edit().putString(KEY, a.toString()).apply();
    }

    /** Urutan pemakaian: model 3.8 ke atas lebih dulu (instruksi tidak ikut dibacakan), lalu model lama. */
    public static List<String> ordered(Context c) {
        List<String> verbatim = new ArrayList<>();
        List<String> rest = new ArrayList<>();
        for (String m : load(c)) (GeminiClient.isVerbatimModel(m) ? verbatim : rest).add(m);
        verbatim.addAll(rest);
        return verbatim;
    }
}
