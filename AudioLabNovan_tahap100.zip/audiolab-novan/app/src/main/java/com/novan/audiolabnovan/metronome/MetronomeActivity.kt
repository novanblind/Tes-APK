package com.novan.audiolabnovan.metronome

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.novan.audiolabnovan.pengolah.AlatUi

/**
 * Tahap 92: Metronome. Ketukan dibuat langsung ke AudioTrack (bukan timer), jadi tempo stabil.
 * Tempo 30 sampai 300 BPM, 1 sampai 12 ketuk per birama (ketuk pertama beraksen), 3 bunyi, 3 volume,
 * ketuk tempo, dan henti otomatis. Tempo boleh diubah saat berjalan. Tanpa AI dan tanpa internet.
 */
class MetronomeActivity : AppCompatActivity() {

    companion object {
        private const val SR = 44_100
        private const val BPM_MIN = 30
        private const val BPM_MAKS = 300
        private val BUNYI = listOf("Klik", "Kayu", "Bip")
        private val VOLUME = listOf("Pelan" to 0.35, "Sedang" to 0.65, "Keras" to 0.95)
        private val HENTI = listOf("Tanpa batas" to 0, "1 menit" to 1, "5 menit" to 5, "10 menit" to 10, "30 menit" to 30)
    }

    @Volatile private var bpm = 100
    @Volatile private var ketuk = 4
    @Volatile private var bunyi = 0
    @Volatile private var volume = 0.65
    @Volatile private var jalan = false
    private var utas: Thread? = null

    private lateinit var etBpm: EditText
    private lateinit var tombolMulai: Button
    private lateinit var tvStatus: TextView
    private lateinit var spHenti: Spinner
    private var mengisi = false
    private val waktuKetuk = ArrayList<Long>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Metronome"
        val c = this
        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(AlatUi.judul(c, "Metronome"))
        akar.addView(AlatUi.label(c, "Ketukan tempo untuk latihan musik. Tempo bisa diubah saat berjalan."))

        tombolMulai = AlatUi.tombol(c, "Mulai") { if (jalan) berhenti(true) else mulai() }
        akar.addView(tombolMulai, AlatUi.margin(c))

        etBpm = EditText(this).apply {
            setText(bpm.toString())
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
        }
        etBpm.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, n: Int, a: Int) { }
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, n: Int) { }
            override fun afterTextChanged(s: Editable?) {
                if (mengisi) return
                val v = s?.toString()?.trim()?.toIntOrNull() ?: return
                if (v in BPM_MIN..BPM_MAKS) bpm = v
            }
        })
        akar.addView(AlatUi.label(c, "Tempo (BPM), 30 sampai 300", etBpm))
        akar.addView(etBpm, AlatUi.margin(c))

        for ((teks, d) in listOf("Kurangi 5" to -5, "Kurangi 1" to -1, "Tambah 1" to 1, "Tambah 5" to 5)) {
            akar.addView(AlatUi.tombol(c, teks) { ubahBpm(bpm + d) }, AlatUi.margin(c))
        }
        akar.addView(AlatUi.tombol(c, "Ketuk tempo (ketuk berulang sesuai irama)") { ketukTempo() }, AlatUi.margin(c))

        val spKetuk = AlatUi.spinner(c, (1..12).map { if (it == 1) "1 ketuk (tanpa aksen)" else "$it ketuk per birama" }).also { it.setSelection(3) }
        spKetuk.onItemSelectedListener = pilih { ketuk = it + 1 }
        akar.addView(AlatUi.label(c, "Birama", spKetuk))
        akar.addView(spKetuk, AlatUi.margin(c))

        val spBunyi = AlatUi.spinner(c, BUNYI)
        spBunyi.onItemSelectedListener = pilih { bunyi = it }
        akar.addView(AlatUi.label(c, "Bunyi", spBunyi))
        akar.addView(spBunyi, AlatUi.margin(c))

        val spVol = AlatUi.spinner(c, VOLUME.map { it.first }).also { it.setSelection(1) }
        spVol.onItemSelectedListener = pilih { volume = VOLUME[it].second }
        akar.addView(AlatUi.label(c, "Volume", spVol))
        akar.addView(spVol, AlatUi.margin(c))

        spHenti = AlatUi.spinner(c, HENTI.map { it.first })
        akar.addView(AlatUi.label(c, "Berhenti otomatis", spHenti))
        akar.addView(spHenti, AlatUi.margin(c))

        tvStatus = TextView(this).apply {
            textSize = 16f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(AlatUi.dp(c, 20), AlatUi.dp(c, 8), AlatUi.dp(c, 20), AlatUi.dp(c, 16))
        }
        akar.addView(tvStatus, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlatUi.pasang(this, akar)
    }

    private fun pilih(aksi: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { aksi(pos) }
        override fun onNothingSelected(p: AdapterView<*>?) { }
    }

    private fun status(t: String) {
        runOnUiThread {
            tvStatus.text = t
            tvStatus.announceForAccessibility(t)
        }
    }

    private fun ubahBpm(nilai: Int) {
        val v = nilai.coerceIn(BPM_MIN, BPM_MAKS)
        bpm = v
        mengisi = true
        etBpm.setText(v.toString())
        mengisi = false
        status("Tempo $v BPM")
    }

    private fun ketukTempo() {
        val skrg = System.currentTimeMillis()
        if (waktuKetuk.isNotEmpty() && skrg - waktuKetuk.last() > 2500) waktuKetuk.clear()
        waktuKetuk.add(skrg)
        while (waktuKetuk.size > 6) waktuKetuk.removeAt(0)
        if (waktuKetuk.size < 2) { status("Ketuk lagi."); return }
        val rata = (waktuKetuk.last() - waktuKetuk.first()).toDouble() / (waktuKetuk.size - 1)
        ubahBpm(Math.round(60000.0 / rata).toInt())
    }

    // ----------------------------------------------------------------- bunyi

    /** Satu ketukan; [aksen] = ketuk pertama birama (lebih tinggi). */
    private fun buatKlik(jenis: Int, aksen: Boolean, vol: Double): ShortArray {
        val durMs = when (jenis) { 0 -> 40; 1 -> 70; else -> 80 }
        val n = SR * durMs / 1000
        val f = when (jenis) {
            0 -> if (aksen) 1800.0 else 1200.0
            1 -> if (aksen) 1100.0 else 750.0
            else -> if (aksen) 1760.0 else 880.0
        }
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / SR
            val v = when (jenis) {
                0 -> Math.sin(2 * Math.PI * f * t) * Math.exp(-t / 0.008)
                1 -> (Math.sin(2 * Math.PI * f * t) + 0.4 * Math.sin(2 * Math.PI * f * 2.4 * t)) / 1.4 * Math.exp(-t / 0.016)
                else -> {
                    val atak = minOf(1.0, t / 0.004)
                    val lepas = minOf(1.0, (durMs / 1000.0 - t) / 0.01)
                    Math.sin(2 * Math.PI * f * t) * minOf(atak, lepas)
                }
            }
            out[i] = (v * vol * 32767.0 * 0.9).toInt().coerceIn(-32767, 32767).toShort()
        }
        return out
    }

    private fun mulai() {
        if (jalan) return
        val menit = HENTI[spHenti.selectedItemPosition.coerceIn(0, HENTI.size - 1)].second
        val akhir = if (menit > 0) System.nanoTime() + menit * 60_000_000_000L else Long.MAX_VALUE
        jalan = true
        tombolMulai.text = "Berhenti"
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status("Berjalan. Tempo $bpm BPM.")
        val t = Thread {
            var track: AudioTrack? = null
            try {
                val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SR)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                    .setBufferSizeInBytes(maxOf(minBuf, SR / 10 * 2))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track.play()
                val sunyi = ShortArray(2048)
                var sisa = 0.0
                var urut = 0
                while (jalan) {
                    if (System.nanoTime() >= akhir) {
                        runOnUiThread { berhenti(false); status("Selesai. Berhenti otomatis.") }
                        break
                    }
                    sisa += SR * 60.0 / bpm
                    val panjang = sisa.toLong()
                    sisa -= panjang
                    val b = ketuk
                    val aksen = b > 1 && urut % b == 0
                    val klik = buatKlik(bunyi, aksen, volume)
                    val kk = minOf(klik.size.toLong(), panjang).toInt()
                    track.write(klik, 0, kk)
                    var tinggal = panjang - kk
                    while (tinggal > 0 && jalan) {
                        val n = minOf(tinggal, sunyi.size.toLong()).toInt()
                        track.write(sunyi, 0, n)
                        tinggal -= n
                    }
                    urut++
                }
            } catch (e: Throwable) {
                status("Metronome gagal: ${e.message ?: e.javaClass.simpleName}")
                runOnUiThread { berhenti(false) }
            } finally {
                try { track?.stop() } catch (_: Throwable) { }
                try { track?.release() } catch (_: Throwable) { }
            }
        }
        utas = t
        t.start()
    }

    private fun berhenti(umumkan: Boolean) {
        jalan = false
        utas = null
        tombolMulai.text = "Mulai"
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (umumkan) status("Berhenti.")
    }

    override fun onDestroy() {
        jalan = false
        super.onDestroy()
    }
}
