package com.novan.audiolabnovan.videolab;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Mencari bagian video yang ada suaranya (bicara) pada garis waktu hasil ekspor, untuk menurunkan musik otomatis. */
final class SpeechMap {
    private static final int WIN_MS = 50;
    private static final long MERGE_GAP_MS = 450;
    private static final long MIN_SEG_MS = 120;

    private SpeechMap() { }

    /** Hasil: daftar {awalMs, akhirMs} pada garis waktu hasil, terurut. */
    static long[][] analyze(Context ctx, List<Clip> clips, boolean audioOnly) throws Exception {
        return analyze(ctx, clips, audioOnly, 0, 1);
    }

    /** Tahap 51: dengan kepekaan (0 normal, 1 tinggi, 2 sangat tinggi) dan kecepatan musik naik lagi (0 cepat, 1 sedang, 2 pelan). */
    static long[][] analyze(Context ctx, List<Clip> clips, boolean audioOnly, int sens, int rel) throws Exception {
        List<long[]> raw = new ArrayList<>();
        long offset = 0;
        for (Clip c : clips) {
            if (c.isImage) {
                if (!audioOnly) offset += c.outDurationMs();
                continue;
            }
            if (!c.muted && c.volume > 0.001f) {
                float[] rms = windowRms(ctx, c);
                if (rms != null && rms.length > 0) {
                    float thr = DuckDetect.threshold(rms, sens);
                    float speed = Math.max(0.1f, c.speed);
                    for (int w = 0; w < rms.length; w++) {
                        if (rms[w] >= thr) {
                            long s = offset + Math.round(w * WIN_MS / (double) speed);
                            long e = offset + Math.round((w + 1) * WIN_MS / (double) speed);
                            add(raw, s, e);
                        }
                    }
                }
            }
            offset += c.outDurationMs();
        }
        return DuckDetect.merge(raw, DuckDetect.gapMs(rel), DuckDetect.minSegMs(sens));
    }

    /**
     * Bagian klip yang dipertahankan setelah jeda hening panjang dibuang.
     * Hasil: daftar {awalMs, akhirMs} pada waktu berkas sumber, terurut. Sisa hening di tiap sisi bicara dijaga sebesar padMs.
     */
    static long[][] keepRanges(Context ctx, Clip c, long minSilenceMs, long padMs) throws Exception {
        float[] rms = windowRms(ctx, c);
        long span = Math.max(0, c.endMs - c.startMs);
        if (rms == null || rms.length == 0) return new long[][]{{c.startMs, c.endMs}};
        float thr = threshold(rms);
        List<long[]> cut = new ArrayList<>();   // bagian yang dibuang, relatif terhadap awal klip
        int n = rms.length;
        int w = 0;
        while (w < n) {
            if (rms[w] >= thr) { w++; continue; }
            int s = w;
            while (w < n && rms[w] < thr) w++;
            long runStart = (long) s * WIN_MS;
            long runEnd = (w == n) ? span : (long) w * WIN_MS;
            if (runEnd - runStart >= minSilenceMs) {
                long cs = (s == 0) ? 0 : runStart + padMs;
                long ce = (w == n) ? span : runEnd - padMs;
                if (ce - cs > 0) cut.add(new long[]{cs, ce});
            }
        }
        List<long[]> keep = new ArrayList<>();
        long pos = 0;
        for (long[] x : cut) {
            if (x[0] > pos) keep.add(new long[]{c.startMs + pos, c.startMs + x[0]});
            pos = x[1];
        }
        if (pos < span) keep.add(new long[]{c.startMs + pos, c.startMs + span});
        if (keep.isEmpty()) return new long[0][];
        return keep.toArray(new long[0][]);
    }

    /** Tingkat kerasnya suara klip (RMS linear 0..1) dihitung hanya dari bagian yang ada suaranya, atau -1 bila tidak ada. */
    static double loudness(Context ctx, Clip c) throws Exception {
        float[] rms = windowRms(ctx, c);
        if (rms == null || rms.length == 0) return -1;
        float thr = threshold(rms);
        double sum = 0;
        int n = 0;
        for (float v : rms) {
            if (v >= thr) { sum += (double) v * v; n++; }
        }
        if (n < 4) return -1;   // kurang dari sekitar 0,2 detik bersuara, tidak cukup untuk dinilai
        return Math.sqrt(sum / n);
    }

    private static void add(List<long[]> l, long s, long e) {
        if (!l.isEmpty() && s <= l.get(l.size() - 1)[1]) {
            l.get(l.size() - 1)[1] = Math.max(l.get(l.size() - 1)[1], e);
        } else {
            l.add(new long[]{s, e});
        }
    }

    /** Ambang suara bicara: dari lantai derau klip itu sendiri (bagian paling pelan), dengan batas wajar. */
    private static float threshold(float[] rms) {
        float[] sorted = rms.clone();
        Arrays.sort(sorted);
        float floor = sorted[(int) (sorted.length * 0.15f)];
        return Math.max(0.012f, Math.min(0.08f, floor * 3f));
    }

    /** RMS tiap 50 md waktu sumber, hanya pada bagian klip yang dipakai. */
    private static float[] windowRms(Context ctx, Clip c) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        try {
            ex.setDataSource(ctx, c.uri, null);
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) { track = i; fmt = f; break; }
            }
            if (track < 0) return null;
            ex.selectTrack(track);
            ex.seekTo(c.startMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            codec.configure(fmt, null, null, 0);
            codec.start();

            int rate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
            int ch = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
            boolean isFloat = false;

            long spanMs = Math.max(0, c.endMs - c.startMs);
            int nWin = (int) (spanMs / WIN_MS);
            if (nWin <= 0) return null;
            double[] sum = new double[nWin];
            long[] cnt = new long[nWin];

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inDone = false, outDone = false;
            long startUs = c.startMs * 1000L;
            long endUs = c.endMs * 1000L;
            long t0 = System.currentTimeMillis();
            long limitMs = 120000;
            while (!outDone && System.currentTimeMillis() - t0 < limitMs) {
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        int n = ex.readSampleData(ib, 0);
                        long st = ex.getSampleTime();
                        if (n < 0 || st > endUs + 200000) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, n, st, 0);
                            ex.advance();
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi >= 0) {
                    ByteBuffer ob = codec.getOutputBuffer(oi);
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        ob.order(ByteOrder.LITTLE_ENDIAN);
                        long idx = 0;
                        if (isFloat) {
                            FloatBuffer fb = ob.asFloatBuffer();
                            while (fb.remaining() >= ch) {
                                float s = 0f;
                                for (int k = 0; k < ch; k++) s += fb.get();
                                s /= ch;
                                long tUs = info.presentationTimeUs + idx * 1000000L / rate;
                                idx++;
                                put(sum, cnt, nWin, tUs, startUs, s);
                            }
                        } else {
                            ShortBuffer sb = ob.asShortBuffer();
                            while (sb.remaining() >= ch) {
                                int s = 0;
                                for (int k = 0; k < ch; k++) s += sb.get();
                                float f = s / (float) ch / 32768f;
                                long tUs = info.presentationTimeUs + idx * 1000000L / rate;
                                idx++;
                                put(sum, cnt, nWin, tUs, startUs, f);
                            }
                        }
                        if (info.presentationTimeUs > endUs) outDone = true;
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    isFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING)
                            && of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT;
                }
            }
            if (!outDone) throw new IllegalStateException("analisis suara terlalu lama");
            float[] rms = new float[nWin];
            for (int i = 0; i < nWin; i++) {
                rms[i] = cnt[i] > 0 ? (float) Math.sqrt(sum[i] / cnt[i]) : 0f;
            }
            return rms;
        } finally {
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignored) { }
                try { codec.release(); } catch (Exception ignored) { }
            }
            ex.release();
        }
    }

    private static void put(double[] sum, long[] cnt, int nWin, long tUs, long startUs, float v) {
        long rel = tUs - startUs;
        if (rel < 0) return;
        int w = (int) (rel / (WIN_MS * 1000L));
        if (w >= nWin) return;
        sum[w] += (double) v * v;
        cnt[w]++;
    }
}
