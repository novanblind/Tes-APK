package com.novan.audiolabnovan.sfx

import android.content.ContentValues
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import com.novan.audiolabnovan.Converter
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.karaoke.PenguraiLagu
import com.novan.audiolabnovan.karaoke.batasiLembut
import com.novan.audiolabnovan.pengolah.AlatUi
import com.novan.audiolabnovan.pengolah.PenulisWav
import com.novan.audiolabnovan.pengolah.PenyimpanHasil
import com.novan.audiolabnovan.video.VideoFitur
import java.io.File

/**
 * Tahap 94: Video SFX. Pilih video, susun daftar efek suara beserta waktu bunyinya, lalu simpan video baru.
 * Efek dibuat dari rumus oleh [PembuatSfx] (sama dengan Tambah SFX), tanpa AI dan tanpa internet.
 * Cara kerja: suara asli video diurai ke PCM, efek dijumlah (dibatasi lembut), lalu FFmpeg memasang suara baru
 * ke video tanpa mengubah gambar (video disalin apa adanya). Video tanpa suara diberi suara hening dulu.
 */
class VideoSfxActivity : AppCompatActivity() {

    companion object {
        private const val SR = PenguraiLagu.SR
        private const val SUBFOLDER = "Video SFX"
        private val VOLUME = listOf(25, 50, 75, 100, 150)
        private val RUNDUK = listOf(0, 3, 6, 9)
    }

    private class Dibatalkan : Exception()
    private class Butir(val id: Int, val detik: Double, val persen: Int)

    private val butir = ArrayList<Butir>()
    private var video: Uri? = null
    private var namaVideo = ""
    private var pemutar: AudioTrack? = null

    private lateinit var tvVideo: TextView
    private lateinit var spJenis: Spinner
    private lateinit var spVolume: Spinner
    private lateinit var spRunduk: Spinner
    private lateinit var spPilihButir: Spinner
    private lateinit var etWaktu: EditText
    private lateinit var tvDaftar: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tombolPilih: Button
    private lateinit var tombolProses: Button
    private lateinit var tombolBatal: Button
    private lateinit var bar: ProgressBar

    @Volatile private var batal = false
    @Volatile private var sibuk = false
    private val dialogHasil by lazy { DialogHasil(this) }

    private val pilihVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) setVideo(u, null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Video SFX"
        val c = this
        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(AlatUi.judul(c, "Video SFX"))
        akar.addView(AlatUi.label(c, "Tambahkan efek suara ke video pada waktu yang Anda tentukan."))

        tombolPilih = AlatUi.tombol(c, "Pilih video") { if (!sibuk) pilihVideo.launch(arrayOf("video/*")) }
        akar.addView(tombolPilih, AlatUi.margin(c))
        tvVideo = AlatUi.label(c, "Belum ada video dipilih.")
        akar.addView(tvVideo)

        spJenis = AlatUi.spinner(c, PembuatSfx.NAMA)
        akar.addView(AlatUi.label(c, "Jenis efek", spJenis)); akar.addView(spJenis, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Dengarkan efek ini") { dengarkan() }, AlatUi.margin(c))

        etWaktu = EditText(this).apply {
            hint = "Contoh 12 atau 1:30,5"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        akar.addView(AlatUi.label(c, "Waktu bunyi (detik atau menit:detik)", etWaktu)); akar.addView(etWaktu, AlatUi.margin(c))
        spVolume = AlatUi.spinner(c, VOLUME.map { "$it persen" }).also { it.setSelection(3) }
        akar.addView(AlatUi.label(c, "Volume efek", spVolume)); akar.addView(spVolume, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Tambah ke daftar") { tambah() }, AlatUi.margin(c))

        tvDaftar = TextView(this).apply {
            textSize = 16f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(AlatUi.dp(c, 20), AlatUi.dp(c, 8), AlatUi.dp(c, 20), AlatUi.dp(c, 8))
        }
        akar.addView(tvDaftar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        spPilihButir = AlatUi.spinner(c, listOf("(daftar kosong)"))
        akar.addView(AlatUi.label(c, "Pilih efek untuk dihapus", spPilihButir)); akar.addView(spPilihButir, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Hapus efek terpilih") {
            val i = spPilihButir.selectedItemPosition
            if (i in butir.indices) { butir.removeAt(i); segarkanDaftar(); status("Efek dihapus. Sisa ${butir.size}.", true) }
        }, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Kosongkan daftar") { butir.clear(); segarkanDaftar() }, AlatUi.margin(c))

        spRunduk = AlatUi.spinner(c, RUNDUK.map { if (it == 0) "Mati" else "Turun $it dB" }).also { it.setSelection(2) }
        akar.addView(AlatUi.label(c, "Turunkan suara video saat efek bunyi", spRunduk)); akar.addView(spRunduk, AlatUi.margin(c))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        akar.addView(bar, AlatUi.margin(c))
        tombolProses = AlatUi.tombol(c, "Tambahkan SFX dan simpan") { proses() }
        akar.addView(tombolProses, AlatUi.margin(c))
        tombolBatal = AlatUi.tombol(c, "Batalkan") { batal = true; try { FFmpegKit.cancel() } catch (_: Throwable) { } }
        tombolBatal.isEnabled = false
        akar.addView(tombolBatal, AlatUi.margin(c))

        tvStatus = TextView(this).apply {
            textSize = 16f
            setTextIsSelectable(true)
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(AlatUi.dp(c, 20), AlatUi.dp(c, 8), AlatUi.dp(c, 20), AlatUi.dp(c, 16))
        }
        akar.addView(tvStatus, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlatUi.pasang(this, akar)
        segarkanDaftar()
        intent.getStringExtra(VideoFitur.EXTRA_URI)?.let { setVideo(Uri.parse(it), null) }
    }

    private fun namaDari(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { q ->
                if (q.moveToFirst()) q.getString(0)?.let { return it }
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment ?: "video"
    }

    private fun setVideo(uri: Uri, nama: String?) {
        video = uri
        namaVideo = nama?.takeIf { it.isNotBlank() } ?: namaDari(uri)
        tvVideo.text = "Video: $namaVideo"
        status("Video dipilih. Pilih efek, isi waktunya, lalu tekan Tambah ke daftar.", true)
    }

    private fun status(t: String, umumkan: Boolean = false) {
        runOnUiThread {
            tvStatus.text = t
            if (umumkan) tvStatus.announceForAccessibility(t)
        }
    }

    private fun progres(p: Int) = runOnUiThread { bar.progress = p.coerceIn(0, 100) }

    private fun ringkas(b: Butir) = "${PembuatSfx.NAMA[b.id]}, pada ${TambahSfxActivity.tampilWaktu(b.detik)}, volume ${b.persen} persen"

    private fun segarkanDaftar() {
        tvDaftar.text = if (butir.isEmpty()) "Daftar efek masih kosong." else
            "Daftar efek (${butir.size}):\n" + butir.withIndex().joinToString("\n") { (i, b) -> "${i + 1}. ${ringkas(b)}" }
        val item = if (butir.isEmpty()) listOf("(daftar kosong)") else butir.withIndex().map { (i, b) -> "${i + 1}. ${ringkas(b)}" }
        val lama = spPilihButir.selectedItemPosition
        spPilihButir.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, item)
        spPilihButir.setSelection(lama.coerceIn(0, item.size - 1))
    }

    private fun tambah() {
        val w = TambahSfxActivity.bacaWaktu(etWaktu.text.toString())
        if (w == null) { status("Waktu tidak valid. Contoh: 12 atau 1:30.", true); return }
        val id = spJenis.selectedItemPosition.coerceIn(0, PembuatSfx.NAMA.size - 1)
        butir.add(Butir(id, w, VOLUME[spVolume.selectedItemPosition.coerceIn(0, VOLUME.size - 1)]))
        butir.sortBy { it.detik }
        segarkanDaftar()
        status("Ditambahkan: ${PembuatSfx.NAMA[id]} pada ${TambahSfxActivity.tampilWaktu(w)}. Jumlah ${butir.size}.", true)
    }

    private fun dengarkan() {
        hentikanContoh()
        try {
            val m = PembuatSfx.buat(spJenis.selectedItemPosition.coerceIn(0, PembuatSfx.NAMA.size - 1), SR)
            val pcm = ShortArray(minOf(m.size, 10 * SR)) { m[it] }
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm, 0, pcm.size)
            t.play()
            pemutar = t
        } catch (e: Throwable) {
            status("Efek tidak bisa diputar: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun hentikanContoh() {
        try { pemutar?.stop() } catch (_: Throwable) { }
        try { pemutar?.release() } catch (_: Throwable) { }
        pemutar = null
    }

    // ----------------------------------------------------------------- proses

    private fun proses() {
        val src = video
        if (src == null) { status("Pilih video dulu.", true); return }
        if (butir.isEmpty()) { status("Daftar efek masih kosong.", true); return }
        if (sibuk) return
        hentikanContoh()
        val rencana = ArrayList(butir)
        val rundukDb = RUNDUK[spRunduk.selectedItemPosition.coerceIn(0, RUNDUK.size - 1)]
        val dasarNama = namaVideo.substringBeforeLast('.', namaVideo)

        sibuk = true
        batal = false
        tombolPilih.isEnabled = false
        tombolProses.isEnabled = false
        tombolBatal.isEnabled = true
        bar.progress = 0
        bar.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status("Membaca suara video. Biarkan layar menyala sampai selesai.", true)

        Thread {
            var pesan: String? = null
            var uriHasil: Uri? = null
            var namaHasil = ""
            var mimeHasil = "video/mp4"
            var catatan = ""
            val stamp = System.currentTimeMillis()
            val tmpWav = File(cacheDir, "vsfx_$stamp.wav")
            val tmpMp4 = File(cacheDir, "vsfx_$stamp.mp4")
            val tmpMkv = File(cacheDir, "vsfx_$stamp.mkv")
            try {
                val durMs = Converter.probeDurationMs(this, src)
                if (durMs > PenguraiLagu.MAKS_MS) { pesan = "Video terlalu panjang. Paling lama 12 menit."; return@Thread }
                var terakhir = -10
                val lagu = PenguraiLagu.urai(this, src, { batal }) { p ->
                    progres(p * 40 / 100)
                    if (p - terakhir >= 20) { terakhir = p; status("Membaca suara video $p persen...") }
                }
                if (batal) throw Dibatalkan()
                val pcm: ShortArray
                val frame: Int
                if (lagu != null && lagu.frame > 0) {
                    pcm = lagu.pcm
                    frame = lagu.frame
                } else {
                    if (durMs <= 0) { pesan = "Durasi video tidak terbaca."; return@Thread }
                    frame = (durMs * SR / 1000L).toInt()
                    pcm = ShortArray(frame * 2)
                    catatan = " Video ini tidak punya suara, jadi hanya efek yang terdengar."
                }

                status("Menambahkan efek...", true)
                val cache = HashMap<Int, ShortArray>()
                fun efek(id: Int): ShortArray = cache.getOrPut(id) { PembuatSfx.buat(id, SR) }

                if (rundukDb > 0) {
                    val g = Math.pow(10.0, -rundukDb / 20.0)
                    val atak = (SR * 0.03).toInt()
                    val lepas = (SR * 0.25).toInt()
                    val selang = ArrayList<LongArray>()
                    for (b in rencana) {
                        val mulai = Math.round(b.detik * SR)
                        if (mulai >= frame) continue
                        selang.add(longArrayOf(mulai, minOf(frame.toLong(), mulai + efek(b.id).size.toLong())))
                    }
                    selang.sortBy { it[0] }
                    val gabung = ArrayList<LongArray>()
                    for (x in selang) {
                        val t = gabung.lastOrNull()
                        if (t != null && x[0] <= t[1] + lepas) t[1] = maxOf(t[1], x[1]) else gabung.add(x)
                    }
                    for (m in gabung) {
                        if (batal) throw Dibatalkan()
                        val cs = m[0]; val ce = m[1]
                        var k = maxOf(0L, cs - atak)
                        val e0 = minOf(frame.toLong(), ce + lepas)
                        while (k < e0) {
                            val gain = when {
                                k < cs -> 1.0 - (1.0 - g) * (k - (cs - atak)).toDouble() / atak
                                k <= ce -> g
                                else -> g + (1.0 - g) * (k - ce).toDouble() / lepas
                            }
                            val p = (k * 2L).toInt()
                            pcm[p] = (pcm[p] * gain).toInt().toShort()
                            pcm[p + 1] = (pcm[p + 1] * gain).toInt().toShort()
                            k++
                        }
                    }
                }
                var dipakai = 0
                var dilewati = 0
                for ((k, b) in rencana.withIndex()) {
                    if (batal) throw Dibatalkan()
                    val mulai = Math.round(b.detik * SR)
                    if (mulai >= frame) { dilewati++; continue }
                    val sfx = efek(b.id)
                    val g = b.persen / 100.0
                    val n = minOf(sfx.size.toLong(), frame - mulai).toInt()
                    for (j in 0 until n) {
                        val p = ((mulai + j) * 2L).toInt()
                        pcm[p] = batasiLembut(pcm[p] + sfx[j] * g)
                        pcm[p + 1] = batasiLembut(pcm[p + 1] + sfx[j] * g)
                    }
                    dipakai++
                    progres(40 + (k + 1) * 30 / rencana.size)
                }
                if (dipakai == 0) {
                    pesan = "Semua waktu efek melewati akhir video. Panjang video ${TambahSfxActivity.tampilWaktu(frame.toDouble() / SR)}."
                    return@Thread
                }
                if (dilewati > 0) catatan += " $dilewati efek dilewati karena waktunya melewati akhir video."

                status("Memasang suara ke video...", true)
                progres(75)
                PenulisWav(tmpWav, SR, 2).use { it.tulis(pcm, frame * 2) }
                if (batal) throw Dibatalkan()

                val masuk = FFmpegKitConfig.getSafParameterForRead(this, src)
                fun pasang(tujuan: File): Boolean {
                    val a = arrayOf("-y", "-nostdin", "-i", masuk, "-i", tmpWav.absolutePath,
                        "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                        "-shortest") + (if (tujuan.extension == "mp4") arrayOf("-movflags", "+faststart") else emptyArray()) +
                        arrayOf(tujuan.absolutePath)
                    val s = FFmpegKit.executeWithArguments(a)
                    return ReturnCode.isSuccess(s.returnCode) && tujuan.length() > 0
                }
                var hasil = tmpMp4
                if (!pasang(tmpMp4)) {
                    if (batal) throw Dibatalkan()
                    tmpMp4.delete()
                    hasil = tmpMkv
                    mimeHasil = "video/x-matroska"
                    if (!pasang(tmpMkv)) { pesan = "Gagal memasang suara ke video ini."; return@Thread }
                    catatan += " Hasil berformat MKV karena video asli tidak cocok dengan MP4."
                }
                progres(95)
                namaHasil = dasarNama + "_sfx." + hasil.extension
                uriHasil = simpanVideo(hasil, namaHasil, mimeHasil)
            } catch (e: Dibatalkan) {
                pesan = "Dibatalkan."
            } catch (e: OutOfMemoryError) {
                pesan = "Memori HP tidak cukup. Coba video yang lebih pendek."
            } catch (e: Throwable) {
                pesan = "Gagal: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                tmpWav.delete(); tmpMp4.delete(); tmpMkv.delete()
                val u = uriHasil; val n = namaHasil; val p = pesan; val ket = catatan; val mm = mimeHasil
                runOnUiThread { selesai(u, n, p, mm, ket) }
            }
        }.start()
    }

    private fun simpanVideo(f: File, nama: String, mime: String): Uri {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, nama)
                put(MediaStore.Video.Media.MIME_TYPE, mime)
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AudioLab Novan/$SUBFOLDER")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val koleksi = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val u = contentResolver.insert(koleksi, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
            try {
                Converter.copyTo(this, f, u)
                contentResolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) {
                try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
                throw e
            }
            return u
        }
        val dasar = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val dir = File(dasar, "AudioLab Novan/$SUBFOLDER")
        dir.mkdirs()
        val t = File(dir, nama)
        f.copyTo(t, overwrite = true)
        return Uri.fromFile(t)
    }

    private fun selesai(uri: Uri?, nama: String, pesan: String?, mime: String, catatan: String) {
        sibuk = false
        tombolPilih.isEnabled = true
        tombolProses.isEnabled = true
        tombolBatal.isEnabled = false
        bar.visibility = View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (uri != null) {
            status("Selesai. Tersimpan di folder Film, AudioLab Novan, Video SFX, dengan nama $nama.$catatan", true)
            dialogHasil.tampilkan(uri, nama, mime)
        } else {
            status(pesan ?: "Gagal.", true)
        }
    }

    override fun onStop() {
        hentikanContoh()
        super.onStop()
    }

    override fun onDestroy() {
        batal = true
        hentikanContoh()
        try { dialogHasil.lepas() } catch (_: Throwable) { }
        super.onDestroy()
    }
}
