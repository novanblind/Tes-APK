package com.novan.audiolabnovan.kunci

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.novan.audiolabnovan.karaoke.PenguraiLagu
import java.util.Locale

/**
 * Tahap 88: Pencari Key dan BPM. Pilih satu berkas audio atau video; hasilnya tempo (BPM), kunci nada,
 * dan notasi Camelot untuk mencampur lagu. Semua dihitung di HP tanpa internet dan tanpa AI
 * (lihat [PencariKeyBpm]).
 */
class KeyBpmActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "uri_key_bpm"
        const val EXTRA_NAMA = "nama_key_bpm"
    }

    private lateinit var tombolPilih: Button
    private lateinit var tombolBatal: Button
    private lateinit var tombolSalin: Button
    private lateinit var hasil: TextView

    @Volatile private var batal = false
    @Volatile private var sibuk = false
    private var teksHasil = ""

    private val pilih = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) analisis(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Pencari Key dan BPM"

        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val judul = TextView(this).apply {
            text = title
            textSize = 24f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(14))
            ViewCompat.setAccessibilityHeading(this, true)
        }
        akar.addView(judul, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun margin() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(16), 0, dp(16), dp(8)) }

        tombolPilih = Button(this).apply {
            text = "Pilih berkas audio atau video"
            setOnClickListener { pilih.launch(arrayOf("audio/*", "video/*")) }
        }
        akar.addView(tombolPilih, margin())

        tombolBatal = Button(this).apply {
            text = "Batalkan analisis"
            isEnabled = false
            setOnClickListener { batal = true }
        }
        akar.addView(tombolBatal, margin())

        tombolSalin = Button(this).apply {
            text = "Salin hasil"
            isEnabled = false
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("key dan bpm", teksHasil))
                Toast.makeText(this@KeyBpmActivity, "Hasil disalin.", Toast.LENGTH_SHORT).show()
            }
        }
        akar.addView(tombolSalin, margin())

        hasil = TextView(this).apply {
            text = "Belum ada berkas dipilih. Hasil berupa perkiraan tempo dan kunci nada; paling cocok untuk lagu dengan ketukan jelas."
            textSize = 16f
            setTextIsSelectable(true)
            setPadding(dp(20), dp(8), dp(20), dp(16))
        }
        akar.addView(ScrollView(this).apply { addView(hasil) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        ViewCompat.setOnApplyWindowInsetsListener(akar) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }
        setContentView(akar)

        // Berkas dari menu Bagikan langsung dianalisis.
        val kiriman = intent.getStringExtra(EXTRA_URI)
        if (kiriman != null) analisis(Uri.parse(kiriman))
    }

    private fun status(teks: String, umumkan: Boolean = false) {
        runOnUiThread {
            hasil.text = teks
            if (umumkan) hasil.announceForAccessibility(teks)
        }
    }

    private fun analisis(uri: Uri) {
        if (sibuk) {
            Toast.makeText(this, "Masih menganalisis. Tunggu atau batalkan dulu.", Toast.LENGTH_SHORT).show()
            return
        }
        sibuk = true
        batal = false
        tombolPilih.isEnabled = false
        tombolBatal.isEnabled = true
        tombolSalin.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status("Membaca berkas...", true)

        Thread {
            var akhir: String? = null
            try {
                var terakhir = -1
                val lagu = PenguraiLagu.urai(this, uri, { batal }) { p ->
                    if (p / 10 != terakhir / 10) {
                        terakhir = p
                        status("Membaca berkas $p persen...")
                    }
                }
                if (batal) {
                    akhir = "Analisis dibatalkan."
                } else if (lagu == null) {
                    akhir = "Berkas ini tidak bisa dibaca sebagai audio."
                } else {
                    status("Menghitung tempo...", true)
                    val bpm = PencariKeyBpm.hitungBpm(lagu) { batal }
                    if (batal) {
                        akhir = "Analisis dibatalkan."
                    } else {
                        status("Menghitung kunci nada...", true)
                        val key = PencariKeyBpm.hitungKey(lagu) { batal }
                        akhir = if (batal) "Analisis dibatalkan." else susunHasil(lagu.nama, lagu.durasiMs, bpm, key)
                    }
                }
            } catch (e: Throwable) {
                akhir = "Analisis gagal: ${e.message ?: e.javaClass.simpleName}"
            }
            val teks = akhir ?: "Analisis gagal."
            runOnUiThread {
                sibuk = false
                tombolPilih.isEnabled = true
                tombolBatal.isEnabled = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                hasil.text = teks
                hasil.announceForAccessibility("Analisis selesai. $teks")
                val berhasil = teks.contains("BPM") || teks.contains("Kunci nada")
                if (berhasil) teksHasil = teks
                tombolSalin.isEnabled = berhasil
            }
        }.start()
    }

    private fun angka(d: Double): String = String.format(Locale("id"), "%.1f", d)

    private fun susunHasil(nama: String, durasiMs: Long, bpm: PencariKeyBpm.HasilBpm?, key: PencariKeyBpm.HasilKey?): String {
        val sb = StringBuilder()
        sb.append("Berkas: ").append(nama).append('\n')
        val dt = durasiMs / 1000
        sb.append("Durasi dianalisis: ").append(dt / 60).append(':').append(String.format(Locale("id"), "%02d", dt % 60)).append('\n')
        sb.append('\n')
        if (bpm != null) {
            sb.append("Tempo: ").append(angka(bpm.bpm)).append(" BPM\n")
            sb.append("Keyakinan tempo: ").append(bpm.yakin).append(" dari 100\n")
            sb.append("Bila terasa terlalu cepat atau lambat, coba ")
                .append(angka(bpm.setengah)).append(" atau ").append(angka(bpm.dua)).append(" BPM.\n")
        } else {
            sb.append("Tempo: tidak terdeteksi (lagu terlalu pendek atau ketukan tidak jelas).\n")
        }
        sb.append('\n')
        if (key != null) {
            sb.append("Kunci nada: ").append(key.nama).append('\n')
            sb.append("Notasi Camelot: ").append(key.camelot).append('\n')
            sb.append("Kunci setara: ").append(key.setara).append(" (Camelot ").append(key.camelotSetara).append(")\n")
            sb.append("Keyakinan kunci: ").append(key.tingkat).append('\n')
            if (key.tingkat != "tinggi") sb.append("Kemungkinan lain: ").append(key.namaKedua).append('\n')
        } else {
            sb.append("Kunci nada: tidak terdeteksi (lagu terlalu pendek atau tanpa nada yang jelas).\n")
        }
        if (durasiMs >= PenguraiLagu.MAKS_MS - 2000) {
            sb.append("\nCatatan: berkas panjang, yang dianalisis hanya 12 menit pertama.\n")
        }
        return sb.toString().trim()
    }

    override fun onDestroy() {
        batal = true
        super.onDestroy()
    }
}
