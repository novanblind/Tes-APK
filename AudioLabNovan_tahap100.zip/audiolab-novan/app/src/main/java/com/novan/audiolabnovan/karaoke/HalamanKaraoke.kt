package com.novan.audiolabnovan.karaoke

import com.novan.audiolabnovan.R

import android.app.Activity
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Dasar semua halaman: tampilan sederhana satu kolom, tombol besar, judul yang dikenali pembaca layar. */
abstract class HalamanKaraoke : Activity() {

    internal lateinit var prefs: KaraokePrefs
    protected lateinit var root: LinearLayout
    protected lateinit var header: LinearLayout

    /** Wadah tempat pembangun tampilan menambahkan isi; bawaannya root, bisa dialihkan ke wadah lain. */
    internal lateinit var induk: LinearLayout

    protected abstract val judulHalaman: Int
    protected abstract fun bangun()
    protected open val tampilkanJudul: Boolean = true
    protected open fun bangunHeader(h: LinearLayout) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = KaraokePrefs(this)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(8), dp(16), dp(24))
        induk = root
        val scroll = ScrollView(this)
        scroll.clipToPadding = false
        scroll.addView(root)

        header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(16), dp(8), dp(16), 0)

        val luar = LinearLayout(this)
        luar.orientation = LinearLayout.VERTICAL
        luar.addView(
            header,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        luar.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        luar.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            }
            insets
        }
        setContentView(luar)
        setTitle(judulHalaman)
        bangunHeader(header)
        if (tampilkanJudul) bagian(getString(judulHalaman), 26f)
        bangun()
    }

    // ---------- Pembangun tampilan ----------

    internal fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    internal fun larik(id: Int): List<String> = resources.getStringArray(id).toList()

    internal fun bagian(teks: String, ukuran: Float = 20f) {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = ukuran
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setPadding(0, dp(24), 0, dp(4))
        if (Build.VERSION.SDK_INT >= 28) tv.isAccessibilityHeading = true
        induk.addView(tv)
    }

    internal fun info(teks: String): TextView {
        val tv = TextView(this)
        tv.text = teks
        tv.textSize = 17f
        tv.setPadding(0, dp(4), 0, dp(4))
        induk.addView(tv)
        return tv
    }

    internal fun saklar(teks: String, nilai: Boolean, onUbah: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = teks
        s.textSize = 17f
        s.isChecked = nilai
        s.setPadding(0, dp(12), 0, dp(12))
        s.setOnCheckedChangeListener { _, c -> onUbah(c) }
        induk.addView(s)
        return s
    }

    /** Tombol besar (tinggi minimal 56 dp) tanpa huruf kapital semua, mudah disentuh dan dibaca. */
    internal fun buatTombol(teks: String, aksi: () -> Unit): Button {
        val b = Button(this)
        b.text = teks
        b.isAllCaps = false
        b.textSize = 18f
        b.minHeight = dp(56)
        b.setOnClickListener { aksi() }
        return b
    }

    internal fun tombol(teks: String, aksi: () -> Unit): Button {
        val b = buatTombol(teks, aksi)
        induk.addView(b)
        return b
    }

    internal fun pilihan(judul: String, items: List<String>, terpilih: Int, onPilih: (Int) -> Unit): Spinner {
        val tv = TextView(this)
        tv.text = judul
        tv.textSize = 17f
        tv.setPadding(0, dp(12), 0, 0)
        val sp = Spinner(this)
        sp.id = View.generateViewId()
        tv.labelFor = sp.id
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adapter
        sp.setSelection(terpilih, false)
        var terakhir = terpilih
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != terakhir) {
                    terakhir = pos
                    onPilih(pos)
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        induk.addView(tv)
        induk.addView(sp)
        return sp
    }

    /**
     * Penggeser volume 0 sampai 200 persen, langkah 10. TalkBack membacakan nilainya sebagai "N persen"
     * (nilai volume sebenarnya, bukan persen dari panjang penggeser).
     */
    internal fun penggeser(wadah: LinearLayout, judul: String, persen: Int, onUbah: (Int) -> Unit): SeekBar {
        val tv = TextView(this)
        tv.textSize = 17f
        tv.setPadding(0, dp(12), 0, 0)
        val sb = SeekBar(this)
        sb.id = View.generateViewId()
        sb.max = 20
        sb.progress = (persen / 10).coerceIn(0, 20)
        sb.minimumHeight = dp(56)
        if (Build.VERSION.SDK_INT >= 30) {
            // Teks di atas hanya untuk mata; pembaca layar memakai nama dan keterangan nilai milik penggeser.
            tv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            sb.contentDescription = judul
        } else {
            // Android 10: teks di atas menjadi label penggeser dan nilai baru diumumkan setiap berubah.
            tv.labelFor = sb.id
        }
        fun tampil(nilai: Int) {
            tv.text = getString(R.string.penggeser_nilai, judul, nilai)
            if (Build.VERSION.SDK_INT >= 30) sb.stateDescription = getString(R.string.persen_nilai, nilai)
        }
        tampil(sb.progress * 10)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, dariPengguna: Boolean) {
                val nilai = p * 10
                tampil(nilai)
                if (dariPengguna) {
                    onUbah(nilai)
                    if (Build.VERSION.SDK_INT < 30) {
                        s.announceForAccessibility(getString(R.string.persen_nilai, nilai))
                    }
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {}

            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        wadah.addView(tv)
        wadah.addView(sb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return sb
    }

    internal fun toast(id: Int) = Toast.makeText(this, id, Toast.LENGTH_LONG).show()

    internal fun toast(teks: String) = Toast.makeText(this, teks, Toast.LENGTH_LONG).show()
}
