package com.novan.audiolabnovan.kunci

import com.novan.audiolabnovan.karaoke.ChromaLagu
import com.novan.audiolabnovan.karaoke.Lagu
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Tahap 88: pencari tempo (BPM) dan kunci nada (key) dari sebuah lagu, murni hitungan sinyal tanpa AI.
 *
 * Tempo: lagu diturunkan ke mono 11.025 Hz, lalu dibuat kurva "awal ketukan" (kenaikan energi dua pita:
 * pita dasar dan pita tinggi). Kurva itu diautokorelasi; tiap kandidat tempo 60 sampai 200 BPM (langkah 0,1)
 * diberi nilai dari kelipatan jaraknya, lalu dikalikan pilihan lembut yang condong ke sekitar 120 BPM supaya
 * tidak salah oktaf (setengah atau dua kali).
 *
 * Kunci nada: peta nada [ChromaLagu] (sudah dipakai penilaian karaoke) dirata-ratakan seluruh lagu, lalu
 * dicocokkan dengan 24 profil kunci Krumhansl-Schmuckler (12 mayor, 12 minor) lewat korelasi Pearson.
 */
object PencariKeyBpm {

    class HasilBpm(val bpm: Double, val yakin: Int, val setengah: Double, val dua: Double)

    class HasilKey(
        val tonik: Int,
        val mayor: Boolean,
        val korelasi: Double,
        val tonikKedua: Int,
        val mayorKedua: Boolean,
        val tingkat: String
    ) {
        val nama: String get() = namaKey(tonik, mayor)
        val namaKedua: String get() = namaKey(tonikKedua, mayorKedua)
        val camelot: String get() = camelot(tonik, mayor)
        /** Kunci setara (mayor relatif untuk minor, minor relatif untuk mayor). */
        val setara: String get() = if (mayor) namaKey((tonik + 9) % 12, false) else namaKey((tonik + 3) % 12, true)
        val camelotSetara: String get() = if (mayor) camelot((tonik + 9) % 12, false) else camelot((tonik + 3) % 12, true)
    }

    private val NAMA = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    fun namaKey(tonik: Int, mayor: Boolean): String = NAMA[((tonik % 12) + 12) % 12] + if (mayor) " mayor" else " minor"

    /** Notasi roda Camelot (1A..12B) yang dipakai DJ untuk mencampur lagu yang cocok. */
    fun camelot(tonik: Int, mayor: Boolean): String {
        val t = ((tonik % 12) + 12) % 12
        val mayorPc = if (mayor) t else (t + 3) % 12
        val nomor = ((mayorPc * 7 + 7) % 12) + 1
        return nomor.toString() + if (mayor) "B" else "A"
    }

    // ---------------------------------------------------------------- tempo

    private const val SR_RENDAH = 11_025
    private const val JENDELA = 256
    private const val LANGKAH = 128
    private const val BPM_MIN = 60.0
    private const val BPM_MAKS = 200.0

    /** Mengembalikan null bila dibatalkan, lagu terlalu pendek (di bawah sekitar 6 detik), atau nyaris senyap. */
    fun hitungBpm(lagu: Lagu, batal: () -> Boolean): HasilBpm? {
        val pcm = lagu.pcm
        val panjang = lagu.frame / 4
        val n = (panjang - JENDELA) / LANGKAH + 1
        if (n < 512) return null

        // Mono 11.025 Hz: rata-rata empat frame stereo (sekaligus penyaring lolos-rendah sederhana).
        val mono = FloatArray(panjang)
        for (i in 0 until panjang) {
            val j = i * 8
            var s = 0
            for (k in 0 until 8) s += pcm[j + k].toInt()
            mono[i] = s / (8f * 32768f)
        }
        if (batal()) return null

        // Kurva awal ketukan: kenaikan log-energi pita dasar (sinyal asli) dan pita tinggi (selisih antarcontoh).
        val onset = DoubleArray(n)
        var cLamaDasar = 0.0
        var cLamaTinggi = 0.0
        var adaSuara = false
        for (f in 0 until n) {
            if (f % 4096 == 0 && batal()) return null
            val a = f * LANGKAH
            var eDasar = 0.0
            var eTinggi = 0.0
            for (k in 0 until JENDELA) {
                val x = mono[a + k].toDouble()
                eDasar += x * x
                if (k > 0) {
                    val d = x - mono[a + k - 1]
                    eTinggi += d * d
                }
            }
            eDasar /= JENDELA
            eTinggi /= JENDELA
            if (eDasar > 1e-7) adaSuara = true
            val cDasar = ln(1.0 + 1000.0 * eDasar)
            val cTinggi = ln(1.0 + 4000.0 * eTinggi)
            if (f > 0) onset[f] = max(0.0, cDasar - cLamaDasar) + max(0.0, cTinggi - cLamaTinggi)
            cLamaDasar = cDasar
            cLamaTinggi = cTinggi
        }
        if (!adaSuara) return null

        // Kurangi rata-rata geser (sekitar 0,6 detik) supaya yang tersisa hanya lonjakan ketukan.
        val lebar = 25
        val awal = DoubleArray(n + 1)
        for (i in 0 until n) awal[i + 1] = awal[i] + onset[i]
        val tegas = DoubleArray(n)
        for (i in 0 until n) {
            val a = max(0, i - lebar)
            val b = minOf(n - 1, i + lebar)
            val rata = (awal[b + 1] - awal[a]) / (b - a + 1)
            tegas[i] = max(0.0, onset[i] - rata)
        }

        // Autokorelasi sampai empat kali jarak ketukan terpanjang (60 BPM).
        val laju = SR_RENDAH.toDouble() / LANGKAH
        val lagMaks = (4.0 * 60.0 / BPM_MIN * laju).toInt() + 2
        if (lagMaks >= n / 2) return null
        val r = DoubleArray(lagMaks + 1)
        for (l in 0..lagMaks) {
            if (l % 64 == 0 && batal()) return null
            var s = 0.0
            for (i in 0 until n - l) s += tegas[i] * tegas[i + l]
            r[l] = s / (n - l)
        }
        if (r[0] <= 1e-12) return null
        for (l in lagMaks downTo 0) r[l] /= r[0]

        fun antar(x: Double): Double {
            val i = x.toInt()
            if (i < 0 || i >= lagMaks) return 0.0
            val t = x - i
            return r[i] * (1 - t) + r[i + 1] * t
        }

        val bobot = doubleArrayOf(1.0, 0.7, 0.5, 0.35)
        val jumlah = ((BPM_MAKS - BPM_MIN) * 10).toInt() + 1
        val nilai = DoubleArray(jumlah)
        var terbaik = 0
        for (g in 0 until jumlah) {
            val bpm = BPM_MIN + g / 10.0
            val periode = 60.0 / bpm * laju
            var s = 0.0
            for (k in 1..4) s += bobot[k - 1] * antar(k * periode)
            val oktaf = ln(bpm / 120.0) / ln(2.0)
            nilai[g] = s * exp(-0.5 * (oktaf / 0.9) * (oktaf / 0.9))
            if (nilai[g] > nilai[terbaik]) terbaik = g
        }
        if (nilai[terbaik] <= 0.0) return null
        var rata = 0.0
        for (v in nilai) rata += v
        rata /= jumlah
        val yakin = (100.0 * (nilai[terbaik] - rata) / nilai[terbaik]).coerceIn(0.0, 100.0).toInt()

        val bpm = Math.round((BPM_MIN + terbaik / 10.0) * 10.0) / 10.0
        return HasilBpm(bpm, yakin, bpm / 2.0, bpm * 2.0)
    }

    // ---------------------------------------------------------------- kunci nada

    private val PROFIL_MAYOR = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val PROFIL_MINOR = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)

    private fun korelasi(a: DoubleArray, b: DoubleArray, geser: Int): Double {
        // b diputar sehingga nada dasarnya jatuh di kelas nada [geser].
        var ma = 0.0
        var mb = 0.0
        for (i in 0 until 12) { ma += a[i]; mb += b[i] }
        ma /= 12.0
        mb /= 12.0
        var sab = 0.0
        var saa = 0.0
        var sbb = 0.0
        for (i in 0 until 12) {
            val x = a[i] - ma
            val y = b[((i - geser) % 12 + 12) % 12] - mb
            sab += x * y
            saa += x * x
            sbb += y * y
        }
        val d = sqrt(saa * sbb)
        return if (d < 1e-12) 0.0 else sab / d
    }

    /** Mengembalikan null bila dibatalkan, lagu terlalu pendek, atau tidak ada nada yang terdengar. */
    fun hitungKey(lagu: Lagu, batal: () -> Boolean): HasilKey? {
        val chroma = ChromaLagu.hitung(lagu, batal) ?: return null
        val profil = DoubleArray(12)
        var ada = false
        for (pc in 0 until 12) {
            val v = chroma.kecocokan(pc, 0L, lagu.durasiMs)
            if (v >= 0f) {
                profil[pc] = v.toDouble()
                ada = true
            }
        }
        if (!ada) return null

        var bTonik = 0
        var bMayor = true
        var bNilai = -2.0
        var kTonik = 0
        var kMayor = true
        var kNilai = -2.0
        for (t in 0 until 12) {
            for (mayor in booleanArrayOf(true, false)) {
                val c = korelasi(profil, if (mayor) PROFIL_MAYOR else PROFIL_MINOR, t)
                if (c > bNilai) {
                    kTonik = bTonik; kMayor = bMayor; kNilai = bNilai
                    bTonik = t; bMayor = mayor; bNilai = c
                } else if (c > kNilai) {
                    kTonik = t; kMayor = mayor; kNilai = c
                }
            }
        }
        val selisih = bNilai - kNilai
        val tingkat = when {
            bNilai >= 0.75 && selisih >= 0.05 -> "tinggi"
            bNilai >= 0.6 && selisih >= 0.02 -> "sedang"
            else -> "rendah"
        }
        return HasilKey(bTonik, bMayor, abs(bNilai).coerceAtMost(1.0), kTonik, kMayor, tingkat)
    }
}
