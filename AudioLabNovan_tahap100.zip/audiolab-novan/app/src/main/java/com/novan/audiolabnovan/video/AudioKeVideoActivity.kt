package com.novan.audiolabnovan.video

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import com.novan.audiolabnovan.Converter
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.R
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Tahap 67: Audio ke Video.
 *
 * Pengguna memilih satu berkas audio (atau memakai berkas yang sudah dipilih di layar utama), boleh memilih
 * banyak foto sekaligus (bila tidak memilih foto, dipakai gambar lambang Android), memilih kualitas resolusi
 * video dan kualitas audio, lalu menyimpan hasilnya sebagai video MP4.
 *
 * Cara kerja: tiap foto lebih dulu diubah oleh Android sendiri (putaran EXIF dibetulkan, diskalakan, diberi
 * latar hitam atau dipotong) menjadi satu gambar JPEG berukuran persis sama dengan video; lalu FFmpeg menyambung
 * gambar-gambar itu menurut urutan (daftar concat) bersama audionya. Audio bawaan mengikuti aslinya: bila
 * sumbernya AAC, aliran audio disalin apa adanya tanpa encode ulang; format lain disandi ke AAC dengan
 * bitrate sedekat mungkin dengan aslinya.
 */
class AudioKeVideoActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_NAMA = "nama"
        private const val FPS = 5                      // bingkai per detik; foto diam jadi tidak perlu banyak
        private val CODEC_TANPA_SUSUT = setOf("flac", "alac", "wavpack", "ape", "tta", "mlp", "truehd")
    }

    private class Foto(val uri: Uri, val nama: String)

    private class InfoAudio(val codec: String, val kbps: Int, val durMs: Long)

    private val daftarBentuk = listOf("Lebar 16:9 (bawaan)", "Tegak 9:16", "Persegi 1:1")
    private val daftarResolusi = listOf(
        144 to "144p (paling ringan)",
        240 to "240p",
        360 to "360p",
        480 to "480p (standar)",
        720 to "720p HD (bawaan)",
        1080 to "1080p Full HD"
    )
    private val daftarMuat = listOf("Muat utuh, sisa ruang hitam (bawaan)", "Penuhi layar, tepi foto terpotong")
    private val daftarLama = listOf(0, 3, 5, 10, 15, 30)
    private val daftarKbps = listOf(0, 64, 96, 128, 160, 192, 256, 320)   // 0 = ikut aslinya

    private val pref by lazy { getSharedPreferences("audio_video", MODE_PRIVATE) }

    private var sumber: Uri? = null
    private var namaSumber = ""
    private val foto = ArrayList<Foto>()
    @Volatile private var sibuk = false
    @Volatile private var batal = false
    @Volatile private var sesi: FFmpegSession? = null
    private var hasilFile: File? = null
    private var hasilUri: Uri? = null
    private var hasilMime = "video/mp4"
    private var hasilExt = "mp4"
    private var hasilNama = ""
    private var terakhirUmum = -1
    private val dialogHasil by lazy { DialogHasil(this) }

    private lateinit var tvBerkas: TextView
    private lateinit var tvFoto: TextView
    private lateinit var panelFoto: LinearLayout
    private lateinit var spFoto: Spinner
    private lateinit var spBentuk: Spinner
    private lateinit var spResolusi: Spinner
    private lateinit var spMuat: Spinner
    private lateinit var spLama: Spinner
    private lateinit var spKbps: Spinner
    private lateinit var btnPilihAudio: Button
    private lateinit var btnPilihFoto: Button
    private lateinit var btnKosongkan: Button
    private lateinit var btnBuat: Button
    private lateinit var btnBatal: Button
    private lateinit var progress: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvStatus: TextView
    private lateinit var panelHasil: LinearLayout
    private lateinit var tvHasil: TextView
    private lateinit var btnMenuHasil: Button
    private lateinit var btnBagikan: Button
    private lateinit var btnSimpan: Button

    private val pilihAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) setSumber(uri, namaDari(uri))
    }

    private val pilihFoto = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) { status("Tidak ada foto dipilih."); return@registerForActivityResult }
        for (u in uris) foto += Foto(u, namaDari(u))
        segarkanFoto(foto.size - 1)
        status("${uris.size} foto ditambahkan. Sekarang ada ${foto.size} foto, urutannya sesuai daftar di bawah.")
    }

    private val simpanSebagai = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data
        val f = hasilFile
        if (r.resultCode == RESULT_OK && uri != null && f != null && f.exists()) {
            thread {
                val err = try { Converter.copyTo(this, f, uri); null } catch (e: Exception) { e.message ?: "galat" }
                runOnUiThread {
                    if (err == null) { hasilUri = uri; btnBagikan.isEnabled = true; status("Berkas tersimpan.") }
                    else status("Gagal menyimpan: $err")
                }
            }
        } else status("Penyimpanan dibatalkan.")
    }

    // =====================================================================================
    //  Tampilan
    // =====================================================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun LinearLayout.tambah(v: View) {
        addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun judul(teks: String, untuk: View? = null) = TextView(this).apply {
        text = teks
        textSize = 16f
        setPadding(0, dp(14), 0, dp(2))
        if (untuk != null) {
            if (untuk.id == View.NO_ID) untuk.id = View.generateViewId()
            labelFor = untuk.id
        }
    }

    private fun subjudul(teks: String) = TextView(this).apply {
        text = teks
        textSize = 20f
        setPadding(0, dp(22), 0, dp(4))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        ViewCompat.setAccessibilityHeading(this, true)
    }

    private fun tombol(teks: String, aksi: () -> Unit) = Button(this).apply {
        text = teks
        minHeight = dp(52)
        isAllCaps = false
        setOnClickListener { aksi() }
    }

    private fun spinner(items: List<String>, awal: Int = 0, saatPilih: (Int) -> Unit = {}): Spinner {
        val sp = Spinner(this)
        sp.minimumHeight = dp(48)
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        if (items.isNotEmpty()) sp.setSelection(awal.coerceIn(0, items.size - 1), false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { saatPilih(position) }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    private fun labelKbps(k: Int) = if (k == 0) "Ikut aslinya (bawaan)" else "$k kbps (AAC)"
    private fun labelLama(d: Int) = if (d == 0) "Bagi rata sepanjang audio (bawaan)" else "$d detik per foto, diulang bergantian"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.judul_audio_video)

        val akar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(akar) })

        akar.tambah(subjudul("Berkas audio"))
        tvBerkas = TextView(this).apply { textSize = 16f; text = "Belum ada audio dipilih." }
        akar.tambah(tvBerkas)
        btnPilihAudio = tombol("Pilih berkas audio") { pilihAudio.launch(arrayOf("audio/*", "video/*")) }
        akar.tambah(btnPilihAudio)

        akar.tambah(subjudul("Foto"))
        tvFoto = TextView(this).apply { textSize = 16f }
        akar.tambah(tvFoto)
        btnPilihFoto = tombol("Pilih foto (boleh banyak sekaligus)") { pilihFoto.launch(arrayOf("image/*")) }
        akar.tambah(btnPilihFoto)
        panelFoto = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        spFoto = spinner(listOf("-"))
        panelFoto.tambah(judul("Foto terpilih (urutan tampil)", spFoto))
        panelFoto.tambah(spFoto)
        panelFoto.tambah(tombol("Naikkan foto ini") { geserFoto(-1) })
        panelFoto.tambah(tombol("Turunkan foto ini") { geserFoto(1) })
        panelFoto.tambah(tombol("Hapus foto ini dari daftar") { hapusFoto() })
        btnKosongkan = tombol("Kosongkan semua foto (kembali ke lambang Android)") { kosongkanFoto() }
        panelFoto.tambah(btnKosongkan)
        akar.tambah(panelFoto)
        spLama = spinner(daftarLama.map { labelLama(it) }, pref.getInt("lama", 0)) { pref.edit().putInt("lama", it).apply() }
        akar.tambah(judul("Lama tiap foto tampil", spLama))
        akar.tambah(spLama)
        spMuat = spinner(daftarMuat, pref.getInt("muat", 0)) { pref.edit().putInt("muat", it).apply() }
        akar.tambah(judul("Penyesuaian foto ke layar video", spMuat))
        akar.tambah(spMuat)

        akar.tambah(subjudul("Video"))
        spBentuk = spinner(daftarBentuk, pref.getInt("bentuk", 0)) { pref.edit().putInt("bentuk", it).apply() }
        akar.tambah(judul("Bentuk layar video", spBentuk))
        akar.tambah(spBentuk)
        spResolusi = spinner(daftarResolusi.map { it.second }, pref.getInt("resolusi", 4)) { pref.edit().putInt("resolusi", it).apply() }
        akar.tambah(judul("Kualitas resolusi video", spResolusi))
        akar.tambah(spResolusi)

        akar.tambah(subjudul("Audio"))
        spKbps = spinner(daftarKbps.map { labelKbps(it) }, pref.getInt("kbps", 0)) { pref.edit().putInt("kbps", it).apply() }
        akar.tambah(judul("Kualitas audio", spKbps))
        akar.tambah(spKbps)

        akar.tambah(subjudul("Buat video"))
        btnBuat = tombol("Buat video dan simpan") { jalankan() }
        akar.tambah(btnBuat)
        btnBatal = tombol("Batalkan") { batalkan() }
        akar.tambah(btnBatal)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        akar.tambah(progress)
        tvProgress = TextView(this).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(0, dp(4), 0, 0)
        }
        akar.tambah(tvProgress)
        tvStatus = TextView(this).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            textSize = 16f
            setPadding(0, dp(8), 0, 0)
        }
        akar.tambah(tvStatus)

        panelHasil = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        panelHasil.tambah(subjudul("Hasil"))
        tvHasil = TextView(this).apply { textSize = 16f }
        panelHasil.tambah(tvHasil)
        btnMenuHasil = tombol("Buka menu hasil: putar, jeda, bagikan, ubah nama, hapus") { bukaMenuHasil() }
        panelHasil.tambah(btnMenuHasil)
        btnBagikan = tombol("Bagikan") { bagikan() }
        panelHasil.tambah(btnBagikan)
        btnSimpan = tombol("Simpan sebagai…") { simpanKeLokasi() }
        panelHasil.tambah(btnSimpan)
        akar.tambah(panelHasil)

        val u = intent.getStringExtra(EXTRA_URI)?.let { Uri.parse(it) }
        if (u != null) setSumber(u, intent.getStringExtra(EXTRA_NAMA).orEmpty().ifBlank { namaDari(u) })
        else status("Pilih berkas audio dulu. Foto boleh dikosongkan, nanti dipakai lambang Android.")
        segarkanFoto(0)
        segarkanTombol()
    }

    private fun namaDari(uri: Uri): String {
        var nama = uri.lastPathSegment ?: "berkas"
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { nama = it }
            }
        } catch (_: Exception) { }
        return nama
    }

    private fun setSumber(uri: Uri, nama: String) {
        sumber = uri
        namaSumber = nama
        tvBerkas.text = "Audio: $nama"
        hapusHasil()
        status("Audio dipilih. Pilih foto bila mau, atur resolusi dan kualitas, lalu tekan Buat video dan simpan.")
        segarkanTombol()
    }

    // =====================================================================================
    //  Daftar foto
    // =====================================================================================

    private fun segarkanFoto(pilih: Int) {
        if (!::spFoto.isInitialized) return
        if (foto.isEmpty()) {
            panelFoto.visibility = View.GONE
            tvFoto.text = "Belum ada foto dipilih. Bila dibiarkan kosong, video memakai gambar lambang Android."
            return
        }
        panelFoto.visibility = View.VISIBLE
        tvFoto.text = "${foto.size} foto dipilih."
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, foto.mapIndexed { i, f -> "${i + 1}. ${f.nama}" })
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spFoto.adapter = ad
        spFoto.setSelection(pilih.coerceIn(0, foto.size - 1), false)
    }

    private fun geserFoto(arah: Int) {
        if (foto.isEmpty() || sibuk) return
        val i = spFoto.selectedItemPosition
        val j = i + arah
        if (i < 0 || j < 0 || j >= foto.size) {
            status(if (arah < 0) "Sudah paling atas." else "Sudah paling bawah.")
            return
        }
        val f = foto.removeAt(i)
        foto.add(j, f)
        segarkanFoto(j)
        status("${f.nama} dipindah ke urutan ${j + 1} dari ${foto.size}.")
    }

    private fun hapusFoto() {
        if (foto.isEmpty() || sibuk) return
        val i = spFoto.selectedItemPosition.coerceIn(0, foto.size - 1)
        val f = foto.removeAt(i)
        segarkanFoto(i)
        status("${f.nama} dihapus dari daftar. " + if (foto.isEmpty()) "Daftar kosong, dipakai lambang Android." else "Tersisa ${foto.size} foto.")
    }

    private fun kosongkanFoto() {
        if (sibuk) return
        foto.clear()
        segarkanFoto(0)
        status("Semua foto dikosongkan. Video akan memakai gambar lambang Android.")
    }

    // =====================================================================================
    //  Ukuran video, audio, foto
    // =====================================================================================

    /** Lebar dan tinggi video (selalu genap). Resolusi dihitung dari sisi pendek. */
    private fun ukuran(): Pair<Int, Int> {
        val pendek = daftarResolusi[spResolusi.selectedItemPosition.coerceIn(0, daftarResolusi.size - 1)].first
        val panjang = ((pendek * 16 / 9) / 2) * 2
        return when (spBentuk.selectedItemPosition) {
            1 -> pendek to panjang
            2 -> pendek to pendek
            else -> panjang to pendek
        }
    }

    private fun bacaAudio(path: String): InfoAudio {
        var codec = ""
        var kbps = 0
        var dur = 0L
        try {
            val mi = FFprobeKit.getMediaInformation(path).mediaInformation
            if (mi != null) {
                dur = ((mi.duration?.toDoubleOrNull() ?: 0.0) * 1000).toLong()
                val a = mi.streams?.firstOrNull { it.type == "audio" }
                codec = (a?.codec ?: "").lowercase(Locale.US)
                val b = a?.bitrate?.toLongOrNull() ?: mi.bitrate?.toLongOrNull() ?: 0L
                kbps = (b / 1000).toInt()
            }
        } catch (_: Throwable) { }
        return InfoAudio(codec, kbps, dur)
    }

    /** Argumen audio. Bawaan (0) = ikut aslinya. */
    private fun argAudio(kbps: Int, info: InfoAudio): Pair<List<String>, String> {
        if (kbps > 0) return listOf("-c:a", "aac", "-b:a", "${kbps}k") to "AAC $kbps kbps"
        if (info.codec == "aac") return listOf("-c:a", "copy") to "audio asli disalin tanpa diubah"
        val tujuan = when {
            info.codec in CODEC_TANPA_SUSUT || info.codec.startsWith("pcm") -> 320
            info.kbps <= 0 -> 192
            else -> (((info.kbps + 8) / 16) * 16).coerceIn(96, 320)
        }
        return listOf("-c:a", "aac", "-b:a", "${tujuan}k") to "AAC $tujuan kbps (sedekat mungkin dengan aslinya)"
    }

    private fun bacaBitmap(uri: Uri, w: Int, h: Int): Bitmap? {
        val batas = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, batas) }
        if (batas.outWidth <= 0 || batas.outHeight <= 0) return null
        var s = 1
        while (batas.outWidth / (s * 2) >= w && batas.outHeight / (s * 2) >= h) s *= 2
        val opt = BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt) } ?: return null
        val orientasi = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Throwable) { ExifInterface.ORIENTATION_NORMAL }
        val m = Matrix()
        when (orientasi) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return bmp
        }
        val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (r !== bmp) bmp.recycle()
        return r
    }

    /** Letakkan foto di kanvas berukuran video. */
    private fun susunFrame(src: Bitmap, w: Int, h: Int, penuh: Boolean): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.BLACK)
        val sk = if (penuh) maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        else minOf(w / src.width.toFloat(), h / src.height.toFloat())
        val lw = src.width * sk
        val lh = src.height * sk
        val tujuan = RectF((w - lw) / 2f, (h - lh) / 2f, (w + lw) / 2f, (h + lh) / 2f)
        c.drawBitmap(src, null, tujuan, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        return out
    }

    private fun tulisJpeg(b: Bitmap, f: File) {
        f.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }

    private fun f3(d: Double) = String.format(Locale.US, "%.3f", d)

    /** Daftar concat: tiap baris foto dan lamanya. Baris terakhir diulang tanpa durasi (kebiasaan demuxer concat). */
    private fun tulisDaftar(dir: File, jumlah: Int, durSec: Double, perFoto: Int): File {
        val daftar = File(dir, "daftar.txt")
        val sb = StringBuilder("ffconcat version 1.0\n")
        var terakhir = 0
        fun baris(i: Int, d: Double) {
            sb.append("file '").append(File(dir, "f%04d.jpg".format(i)).absolutePath).append("'\n")
            sb.append("duration ").append(f3(d)).append('\n')
            terakhir = i
        }
        val total = durSec + 0.1          // sedikit lebih panjang; -t memotong tepat di panjang audio
        if (perFoto <= 0) {
            val tiap = total / jumlah
            for (i in 0 until jumlah) baris(i, tiap)
        } else {
            var t = 0.0
            var i = 0
            while (t < total - 0.0005) {
                val d = minOf(perFoto.toDouble(), total - t)
                baris(i % jumlah, d)
                t += d
                i++
            }
        }
        sb.append("file '").append(File(dir, "f%04d.jpg".format(terakhir)).absolutePath).append("'\n")
        daftar.writeText(sb.toString())
        return daftar
    }

    // =====================================================================================
    //  Proses
    // =====================================================================================

    private fun jalankan() {
        val src = sumber
        if (src == null) { status("Pilih berkas audio dulu."); return }
        if (sibuk) return
        hapusHasil()

        val (w, h) = ukuran()
        val penuh = spMuat.selectedItemPosition == 1
        val perFoto = daftarLama[spLama.selectedItemPosition.coerceIn(0, daftarLama.size - 1)]
        val kbpsPilih = daftarKbps[spKbps.selectedItemPosition.coerceIn(0, daftarKbps.size - 1)]
        val ext = "mp4"
        val mime = "video/mp4"
        val daftarFoto = ArrayList(foto)
        val judulBerkas = namaSumber.substringBeforeLast('.', namaSumber).take(60)
        val dirKerja = File(cacheDir, "avid_" + System.currentTimeMillis())
        val dest = File(cacheDir, "avid_" + System.currentTimeMillis() + "." + ext)

        batal = false
        setSibuk(true)
        progres(0, "Menyiapkan")
        status("Menyiapkan video ${w} kali ${h}. Biarkan layar menyala sampai selesai.")

        thread {
            try {
                val pathAudio = try { FFmpegKitConfig.getSafParameterForRead(this, src) } catch (e: Throwable) { null }
                if (pathAudio == null) { runOnUiThread { selesaiGagal("Audio tidak bisa dibuka.", dirKerja) }; return@thread }
                val info = bacaAudio(pathAudio)
                if (info.durMs <= 0 && daftarFoto.size > 1) {
                    runOnUiThread { selesaiGagal("Lama audio tidak terbaca, jadi foto tidak bisa dibagi. Pakai satu foto saja atau pilih audio lain.", dirKerja) }
                    return@thread
                }
                dirKerja.mkdirs()

                // 1. Siapkan gambar tiap foto (atau lambang Android).
                var jumlah = 0
                val dilewati = ArrayList<String>()
                for ((i, f) in daftarFoto.withIndex()) {
                    if (batal) { runOnUiThread { selesaiGagal("Dibatalkan.", dirKerja) }; return@thread }
                    runOnUiThread { progres(i * 10 / daftarFoto.size, "Menyiapkan foto ${i + 1} dari ${daftarFoto.size}") }
                    try {
                        val b = bacaBitmap(f.uri, w, h)
                        if (b == null) { dilewati += f.nama; continue }
                        val frame = susunFrame(b, w, h, penuh)
                        b.recycle()
                        tulisJpeg(frame, File(dirKerja, "f%04d.jpg".format(jumlah)))
                        frame.recycle()
                        jumlah++
                    } catch (e: OutOfMemoryError) {
                        dilewati += f.nama
                    } catch (e: Exception) {
                        dilewati += f.nama
                    }
                }
                var pakaiLogo = false
                if (jumlah == 0) {
                    val logo = LogoAndroid.buat(w, h)
                    tulisJpeg(logo, File(dirKerja, "f0000.jpg"))
                    logo.recycle()
                    jumlah = 1
                    pakaiLogo = true
                }
                if (batal) { runOnUiThread { selesaiGagal("Dibatalkan.", dirKerja) }; return@thread }

                val durSec = info.durMs / 1000.0
                val (argA, ketAudio) = argAudio(kbpsPilih, info)
                val ketFoto = when {
                    pakaiLogo && daftarFoto.isEmpty() -> "gambar lambang Android"
                    pakaiLogo -> "lambang Android (tidak ada foto yang bisa dibaca)"
                    else -> "$jumlah foto"
                }
                val ketLewat = if (dilewati.isEmpty()) "" else " Foto yang tidak bisa dibaca dan dilewati: ${dilewati.take(5).joinToString(", ")}" +
                    (if (dilewati.size > 5) " dan ${dilewati.size - 5} lainnya" else "") + "."
                runOnUiThread {
                    progres(10, "Foto siap")
                    status("Membuat video ${w} kali ${h} dari $ketFoto, lama ${Converter.durasiTeks(durSec)}, audio: $ketAudio.$ketLewat")
                }

                // 2. FFmpeg: sambung gambar + audio.
                fun encode(pakaiX264: Boolean) {
                    val args = ArrayList<String>()
                    args += listOf("-y", "-nostdin")
                    val modeUlang = info.durMs <= 0     // lama tak diketahui: satu gambar diulang sampai audio habis
                    if (modeUlang) {
                        args += listOf("-loop", "1", "-framerate", FPS.toString(), "-i", File(dirKerja, "f0000.jpg").absolutePath)
                    } else {
                        val daftar = tulisDaftar(dirKerja, jumlah, durSec, perFoto)
                        args += listOf("-f", "concat", "-safe", "0", "-i", daftar.absolutePath)
                    }
                    args += listOf("-i", pathAudio)
                    args += listOf("-map", "0:v:0", "-map", "1:a:0")
                    args += listOf("-vf", "fps=$FPS,format=yuv420p")
                    if (pakaiX264) args += listOf("-c:v", "libx264", "-preset", "ultrafast", "-tune", "stillimage", "-crf", "26", "-g", (FPS * 2).toString())
                    else args += listOf("-c:v", "mpeg4", "-q:v", "4", "-g", (FPS * 2).toString())
                    args += argA
                    if (modeUlang) args += "-shortest" else args += listOf("-t", f3(durSec))
                    args += listOf("-movflags", "+faststart")
                    args += listOf("-metadata", "title=$judulBerkas", "-metadata", "artist=AudioLab novan")
                    args += dest.absolutePath

                    val sebut = if (info.durMs > 0) info.durMs else 0L
                    sesi = FFmpegKit.executeWithArgumentsAsync(
                        args.toTypedArray(),
                        { s ->
                            when {
                                ReturnCode.isCancel(s.returnCode) -> { dest.delete(); runOnUiThread { selesaiGagal("Dibatalkan.", dirKerja) } }
                                ReturnCode.isSuccess(s.returnCode) && dest.length() > 0 -> simpanDanTampilkan(dest, dirKerja, ext, mime, w, h)
                                else -> {
                                    dest.delete()
                                    val log = (s.allLogsAsString ?: "")
                                    val tanpaX264 = pakaiX264 && (log.contains("Unknown encoder", true) || log.contains("Encoder not found", true) || log.contains("libx264", true) && log.contains("not", true))
                                    if (tanpaX264) {
                                        runOnUiThread { status("Mesin H.264 tidak ada di pustaka ini, memakai MPEG-4 sebagai cadangan.") }
                                        thread { encode(false) }
                                    } else {
                                        val ringkas = log.takeLast(300).replace('\n', ' ')
                                        runOnUiThread { selesaiGagal("Gagal membuat video (kode ${s.returnCode}): $ringkas", dirKerja) }
                                    }
                                }
                            }
                        },
                        null,
                        { st ->
                            if (sebut > 0) {
                                val p = 10 + (st.time.toLong() * 89L / sebut).toInt()
                                runOnUiThread { progres(p.coerceIn(10, 99), "Membuat video") }
                            }
                        }
                    )
                }
                encode(true)
            } catch (e: Throwable) {
                runOnUiThread { selesaiGagal("Gagal menyiapkan video: ${e.message ?: e.javaClass.simpleName}", dirKerja) }
            }
        }
    }

    private fun batalkan() {
        if (!sibuk) return
        batal = true
        try { sesi?.cancel() } catch (_: Exception) { }
        status("Membatalkan…")
    }

    private fun selesaiGagal(pesan: String, dirKerja: File?) {
        dirKerja?.deleteRecursively()
        setSibuk(false)
        progres(0, "")
        status(pesan)
    }

    private fun simpanDanTampilkan(f: File, dirKerja: File, ext: String, mime: String, w: Int, h: Int) {
        dirKerja.deleteRecursively()
        val stempel = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
        val nama = "AudioKeVideo_$stempel.$ext"
        var uri: Uri? = null
        var galat: String? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try { uri = simpanOtomatis(f, nama, mime) } catch (e: Exception) { galat = e.message ?: "galat" }
        }
        val u = uri
        val g = galat
        val lama = try {
            val d = FFprobeKit.getMediaInformation(f.absolutePath).mediaInformation?.duration
            Converter.durasiTeks(d?.toDoubleOrNull() ?: 0.0)
        } catch (_: Throwable) { "tidak diketahui" }
        runOnUiThread {
            hasilFile = f
            hasilUri = u
            hasilMime = mime
            hasilExt = ext
            setSibuk(false)
            progres(100, "Selesai")
            panelHasil.visibility = View.VISIBLE
            tvHasil.text = when {
                u != null -> "Selesai, video $w kali $h, lama $lama. Tersimpan di folder Film, AudioLab Novan, Audio ke Video, dengan nama $nama."
                g != null -> "Selesai, lama $lama, tetapi tidak bisa disimpan otomatis ($g). Tekan Simpan sebagai."
                else -> "Selesai, lama $lama. Tekan Simpan sebagai untuk memilih lokasi simpan."
            }
            status(tvHasil.text.toString())
            btnBagikan.isEnabled = u != null
            hasilNama = if (u != null) nama else f.name
            segarkanTombol()
            bukaMenuHasil()
        }
    }

    @android.annotation.TargetApi(Build.VERSION_CODES.Q)
    private fun simpanOtomatis(src: File, nama: String, mime: String): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, nama)
            put(MediaStore.Video.Media.MIME_TYPE, mime)
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AudioLab Novan/Audio ke Video")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val koleksi = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val u = contentResolver.insert(koleksi, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
        try {
            Converter.copyTo(this, src, u)
            contentResolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
            throw e
        }
        return u
    }

    // =====================================================================================
    //  Hasil: menu, bagikan, simpan
    // =====================================================================================

    /** Dialog menu hasil: putar (suaranya), jeda, lanjutkan, bagikan, ubah nama, hapus. Muncul otomatis saat selesai. */
    private fun bukaMenuHasil() {
        val f = hasilFile
        val u = hasilUri ?: f?.takeIf { it.exists() }?.let { Uri.fromFile(it) }
        if (u == null) { status("Belum ada hasil."); return }
        dialogHasil.saatDiubah = { h ->
            if (h.uri.scheme == "file") hasilFile = File(h.uri.path ?: "") else hasilUri = h.uri
            hasilNama = h.nama
            tvHasil.text = "Nama berkas sekarang ${h.nama}."
        }
        dialogHasil.saatDihapus = {
            hasilUri = null
            hasilFile?.delete()
            hasilFile = null
            panelHasil.visibility = View.GONE
            btnBagikan.isEnabled = false
            status("Hasil sudah dihapus.")
        }
        dialogHasil.tampilkan(u, hasilNama.ifEmpty { u.lastPathSegment ?: "hasil" }, hasilMime)
    }

    private fun hapusHasil() {
        dialogHasil.hentikanSuara()
        hasilFile?.delete()
        hasilFile = null
        hasilUri = null
        panelHasil.visibility = View.GONE
    }

    private fun bagikan() {
        val u = hasilUri
        if (u == null) { status("Simpan dulu hasilnya dengan tombol Simpan sebagai."); return }
        try {
            val kirim = Intent(Intent.ACTION_SEND).apply {
                type = hasilMime
                putExtra(Intent.EXTRA_STREAM, u)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(kirim, "Bagikan video").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            status("Menu Bagikan tidak bisa dibuka: ${e.message}")
        }
    }

    private fun simpanKeLokasi() {
        val f = hasilFile
        if (f == null || !f.exists()) { status("Belum ada hasil untuk disimpan."); return }
        val stempel = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
        simpanSebagai.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = hasilMime
            putExtra(Intent.EXTRA_TITLE, "AudioKeVideo_$stempel.$hasilExt")
        })
    }

    // =====================================================================================
    //  Status, progres, tombol
    // =====================================================================================

    private fun status(t: String) { tvStatus.text = t }

    private fun progres(p: Int, teks: String) {
        progress.progress = p
        tvProgress.text = if (teks.isEmpty()) "" else "$teks, $p persen."
        val kelompok = p / 10
        tvProgress.accessibilityLiveRegion =
            if (kelompok == terakhirUmum) View.ACCESSIBILITY_LIVE_REGION_NONE else View.ACCESSIBILITY_LIVE_REGION_POLITE
        terakhirUmum = kelompok
    }

    private fun setSibuk(s: Boolean) {
        sibuk = s
        if (s) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        segarkanTombol()
    }

    private fun segarkanTombol() {
        if (!::btnBuat.isInitialized) return
        btnBuat.isEnabled = sumber != null && !sibuk
        btnBatal.isEnabled = sibuk
        btnPilihAudio.isEnabled = !sibuk
        btnPilihFoto.isEnabled = !sibuk
        listOf(spBentuk, spResolusi, spMuat, spLama, spKbps, spFoto).forEach { it.isEnabled = !sibuk }
        btnSimpan.isEnabled = !sibuk
    }

    override fun onStop() {
        super.onStop()
        if (!sibuk) dialogHasil.hentikanSuara()
    }

    override fun onDestroy() {
        batal = true
        try { sesi?.cancel() } catch (_: Exception) { }
        dialogHasil.lepas()
        if (!isChangingConfigurations) {
            hasilFile?.delete()
            cacheDir.listFiles { f -> f.name.startsWith("avid_") }?.forEach { it.deleteRecursively() }
        }
        super.onDestroy()
    }
}
