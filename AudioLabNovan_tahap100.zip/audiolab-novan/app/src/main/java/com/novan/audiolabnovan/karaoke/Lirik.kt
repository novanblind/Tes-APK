package com.novan.audiolabnovan.karaoke

/** Satu baris lirik yang mulai tampil pada [ms] (milidetik dari awal lagu). Teks kosong = jeda musik. */
class BarisLirik(val ms: Long, val teks: String)

/**
 * Pembaca lirik berformat LRC ("[01:23.45]teks lirik"). Murni hitungan, tanpa kelas Android.
 * Mendukung beberapa penanda waktu dalam satu baris, penanda [offset:], dan membuang penanda per kata <00:12.30>.
 * Bila berkas tidak punya penanda waktu sama sekali, barisnya dibagi rata sepanjang lagu ([ratakan]).
 */
object Lirik {

    private val WAKTU = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val OFFSET = Regex("""^\s*\[offset:\s*([+-]?\d+)\s*]\s*$""", RegexOption.IGNORE_CASE)
    private val KATA = Regex("""<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>""")

    private fun pecahan(s: String?): Long {
        if (s.isNullOrEmpty()) return 0L
        return when (s.length) {
            1 -> s.toLong() * 100
            2 -> s.toLong() * 10
            else -> s.substring(0, 3).toLong()
        }
    }

    /** Mengurai isi berkas LRC. Hasil terurut menurut waktu; kosong bila tidak ada penanda waktu. */
    fun urai(isi: String): List<BarisLirik> {
        var geser = 0L
        val hasil = ArrayList<BarisLirik>()
        for (mentah in isi.removePrefix("﻿").lineSequence()) {
            val baris = mentah.trimEnd('\r')
            val off = OFFSET.matchEntire(baris)
            if (off != null) {
                geser = off.groupValues[1].toLongOrNull() ?: 0L
                continue
            }
            val cocok = WAKTU.findAll(baris).toList()
            if (cocok.isEmpty()) continue
            // Teks = bagian setelah penanda waktu terakhir yang berada di awal baris.
            var akhir = 0
            for (m in cocok) {
                if (m.range.first == akhir) akhir = m.range.last + 1 else break
            }
            val teks = KATA.replace(baris.substring(akhir), "").trim()
            for (m in cocok) {
                if (m.range.last >= akhir) break
                val menit = m.groupValues[1].toLong()
                val detik = m.groupValues[2].toLong()
                val ms = menit * 60_000 + detik * 1000 + pecahan(m.groupValues[3].ifEmpty { null })
                hasil.add(BarisLirik(ms, teks))
            }
        }
        // Offset positif = lirik tampil lebih cepat (aturan LRC); berlaku untuk semua baris, di mana pun penandanya.
        return hasil.map { BarisLirik((it.ms - geser).coerceAtLeast(0L), it.teks) }.sortedBy { it.ms }
    }

    /** Lirik tanpa waktu: tiap baris yang berisi dibagi rata sepanjang [durasiMs], dengan jeda awal 2 detik. */
    fun ratakan(isi: String, durasiMs: Long): List<BarisLirik> {
        val baris = isi.removePrefix("﻿").lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (baris.isEmpty() || durasiMs <= 0) return emptyList()
        val awal = minOf(2_000L, durasiMs / 10)
        val jatah = (durasiMs - awal) / baris.size
        return baris.mapIndexed { i, t -> BarisLirik(awal + i * jatah, t) }
    }

    /** Membaca isi lirik apa adanya: berpenanda waktu bila ada, jika tidak dibagi rata. */
    fun baca(isi: String, durasiMs: Long): List<BarisLirik> {
        val berwaktu = urai(isi)
        return if (berwaktu.isNotEmpty()) berwaktu else ratakan(isi, durasiMs)
    }

    /** Nomor baris yang sedang dinyanyikan pada [ms]: baris terakhir yang waktunya sudah lewat; -1 bila belum mulai. */
    fun indeks(baris: List<BarisLirik>, ms: Long): Int {
        var lo = 0
        var hi = baris.size - 1
        var hasil = -1
        while (lo <= hi) {
            val tengah = (lo + hi) ushr 1
            if (baris[tengah].ms <= ms) {
                hasil = tengah
                lo = tengah + 1
            } else {
                hi = tengah - 1
            }
        }
        return hasil
    }
}
