package com.novan.audiolabnovan.karaoke

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

/**
 * Pantauan suara sendiri: suara mikrofon yang sudah diberi echo dan gema diputar langsung ke headset,
 * seperti memakai headphone di studio. Hanya suara mikrofon yang diputar; musik tetap dari pemutarnya sendiri.
 *
 * Memakai jalur latensi rendah dan penulisan tanpa menunggu, jadi tidak pernah menghambat pembacaan mikrofon.
 *
 * Supaya tidak putus-putus tetapi tetap cepat, pantauan menjaga "bantalan" kecil di pemutar (awalnya sekitar
 * 20 milidetik). Bila pemutar sempat kehabisan data (underrun), bantalan dinaikkan sedikit demi sedikit sampai
 * suara stabil, dengan batas atas sekitar 120 milidetik. Bila bantalan terlalu penuh (jam mikrofon sedikit lebih
 * cepat dari jam pemutar), satu blok utuh dibuang, bukan sebagian blok, jadi tidak ada klik di tengah suara
 * dan suara tidak makin tertinggal.
 *
 * Penggunaan "asisten" dipilih supaya suara pantauan tidak ikut tertangkap lagi oleh penangkap audio internal
 * (yang hanya mengambil penggunaan media, permainan, dan tak dikenal); volumenya mengikuti volume media.
 */
class PantauSuara private constructor(
    private val trek: AudioTrack,
    private val kanal: Int,
    sr: Int
) {
    private val langkah = maxOf(1, sr / 200)          // 5 milidetik
    private val bantalanMaks = maxOf(2, sr * 120 / 1000) // 120 milidetik
    private var bantalan = maxOf(1, sr / 50)           // 20 milidetik
    private var tertulis = 0L
    private var garisUnderrun = -1
    private var awal = true

    private fun tulisSenyap(frame: Int) {
        if (frame <= 0) return
        val nol = ShortArray(frame * kanal)
        val w = trek.write(nol, 0, nol.size, AudioTrack.WRITE_NON_BLOCKING)
        if (w > 0) tertulis += w / kanal
    }

    /** [jumlah] = banyaknya nilai sampel (semua saluran) di [b]. */
    fun tulis(b: ShortArray, jumlah: Int) {
        try {
            val n = jumlah - jumlah % kanal
            if (n <= 0) return
            val frame = n / kanal
            if (awal) {
                awal = false
                garisUnderrun = trek.underrunCount
                tulisSenyap(bantalan)
            } else {
                val u = trek.underrunCount
                if (u > garisUnderrun) {
                    garisUnderrun = u
                    if (bantalan < bantalanMaks) {
                        bantalan = minOf(bantalanMaks, bantalan + langkah)
                        tulisSenyap(langkah)
                    }
                }
            }
            val kepala = trek.playbackHeadPosition.toLong() and 0xFFFFFFFFL
            val isi = tertulis - kepala
            // Terlalu penuh: buang satu blok utuh supaya tidak makin tertinggal.
            if (isi > bantalan + frame * 6) return
            val w = trek.write(b, 0, n, AudioTrack.WRITE_NON_BLOCKING)
            if (w > 0) tertulis += w / kanal
        } catch (e: Exception) { }
    }

    fun lepas() {
        try { trek.stop() } catch (e: Exception) { }
        try { trek.release() } catch (e: Exception) { }
    }

    companion object {
        /** Membuat pemutar pantauan, atau null bila HP tidak mendukung formatnya. */
        fun buat(sr: Int, kanal: Int): PantauSuara? {
            return try {
                val cfg = if (kanal == 2) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
                val min = AudioTrack.getMinBufferSize(sr, cfg, AudioFormat.ENCODING_PCM_16BIT)
                if (min <= 0) return null
                val t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr)
                            .setChannelMask(cfg)
                            .build()
                    )
                    // Kapasitas besar sebagai cadangan; isi sebenarnya dijaga kecil oleh bantalan di atas.
                    .setBufferSizeInBytes(min * 6)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .build()
                if (t.state != AudioTrack.STATE_INITIALIZED) {
                    t.release()
                    return null
                }
                t.play()
                PantauSuara(t, kanal, sr)
            } catch (e: Exception) {
                null
            }
        }
    }
}
