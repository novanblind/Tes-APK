package com.novan.audiolabnovan.videolab;

import android.graphics.Bitmap;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.BitmapOverlay;
import androidx.media3.effect.OverlaySettings;

/** Gambar tempel yang tampil pada rentang waktu tertentu, dengan animasi masuk. */
@UnstableApi
public final class TimedImageOverlay extends BitmapOverlay {
    private static final long ANIM_US = 400_000L;
    private static final OverlaySettings IDLE =
            new OverlaySettings.Builder().setAlphaScale(0f).build();

    private final Bitmap bitmap;
    private final long startUs, endUs;
    private final float bgX, bgY, ovX, ovY, scale, opacity;
    private final int anim;

    public TimedImageOverlay(Bitmap bitmap, long startUs, long endUs, float bgX, float bgY,
                             float ovX, float ovY, float scale, float opacity, int anim) {
        this.bitmap = bitmap;
        this.startUs = startUs;
        this.endUs = endUs;
        this.bgX = bgX;
        this.bgY = bgY;
        this.ovX = ovX;
        this.ovY = ovY;
        this.scale = scale;
        this.opacity = opacity;
        this.anim = anim;
    }

    @Override
    public Bitmap getBitmap(long presentationTimeUs) {
        return bitmap;
    }

    @Override
    public OverlaySettings getOverlaySettings(long t) {
        if (t < startUs || t >= endUs) return IDLE;
        float inP = Math.min(1f, (t - startUs) / (float) ANIM_US);
        float alpha = opacity;
        float sc = scale;
        float y = bgY;
        if (anim == 1) {
            float outP = Math.min(1f, (endUs - t) / (float) ANIM_US);
            alpha = opacity * Math.max(0f, Math.min(inP, outP));
        } else if (anim == 2) {
            alpha = opacity * inP;
            y = bgY - (1f - inP) * 0.3f;
        } else if (anim == 3) {
            alpha = opacity * inP;
            sc = scale * (0.3f + 0.7f * inP);
        }
        return new OverlaySettings.Builder()
                .setBackgroundFrameAnchor(bgX, y)
                .setOverlayFrameAnchor(ovX, ovY)
                .setScale(sc, sc)
                .setAlphaScale(alpha)
                .build();
    }
}
