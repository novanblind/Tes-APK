package com.novan.audiolabnovan.wa;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.widget.Toast;

/** Mengumumkan pesan: lewat pembaca layar jika aktif, kalau tidak lewat Toast. */
public final class Say {
    private Say() {}

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    @SuppressWarnings("deprecation")
    public static void say(Context context, final String msg) {
        final Context app = context.getApplicationContext();
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                try {
                    AccessibilityManager am = (AccessibilityManager) app.getSystemService(Context.ACCESSIBILITY_SERVICE);
                    if (am != null && am.isEnabled() && am.isTouchExplorationEnabled()) {
                        AccessibilityEvent e = AccessibilityEvent.obtain(AccessibilityEvent.TYPE_ANNOUNCEMENT);
                        e.setPackageName(app.getPackageName());
                        e.setClassName(Say.class.getName());
                        e.getText().add(msg);
                        am.sendAccessibilityEvent(e);
                    } else {
                        Toast.makeText(app, msg, Toast.LENGTH_LONG).show();
                    }
                } catch (Exception ignored) {
                    try { Toast.makeText(app, msg, Toast.LENGTH_LONG).show(); } catch (Exception ignored2) { }
                }
            }
        });
    }
}
