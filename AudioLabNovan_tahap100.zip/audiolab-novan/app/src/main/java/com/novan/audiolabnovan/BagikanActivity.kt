package com.novan.audiolabnovan

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.IntentCompat
import androidx.core.view.ViewCompat

/**
 * Tahap 81: halaman yang terbuka saat berkas audio/video dibagikan dari pengelola berkas (atau "Buka dengan"),
 * meniru AudioLab asli: judul berkas di bilah atas, tombol "Putar Audio", lalu kisi semua fitur yang bisa digulir.
 * Mengetuk satu fitur membuka fitur itu dengan berkas yang dibagikan sudah terpilih.
 */
class BagikanActivity : BerandaActivity() {

    private val uris: List<Uri> by lazy { ambilUri(intent) }
    private val namaBerkas: List<String> by lazy { uris.map { namaDari(it) } }

    /** Tahap 86: bila yang dibagikan video, kisi yang tampil adalah kisi Alat Video. */
    private val adalahVideo: Boolean by lazy {
        uris.isNotEmpty() && uris.all { u ->
            val t = try { contentResolver.getType(u) } catch (_: Exception) { null } ?: intent.type
            t?.startsWith("video/") == true
        }
    }

    private var pemutar: MediaPlayer? = null
    private var tombolPutar: Button? = null

    private fun ambilUri(i: Intent?): List<Uri> {
        if (i == null) return emptyList()
        return when (i.action) {
            Intent.ACTION_SEND ->
                listOfNotNull(IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList<Uri>()
            Intent.ACTION_VIEW -> listOfNotNull(i.data)
            else -> emptyList()
        }
    }

    private fun namaDari(uri: Uri): String {
        var nama = uri.lastPathSegment ?: "berkas"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (k >= 0) nama = c.getString(k) ?: nama
                }
            }
        } catch (_: Exception) {
        }
        return nama
    }

    /** Rekam dan Riwayat tidak berguna untuk berkas yang dibagikan, jadi tidak ditampilkan. */
    override fun daftarTampil(): List<Fitur.Def> =
        if (adalahVideo) com.novan.audiolabnovan.video.VideoFitur.daftar
        else Fitur.daftar.filter { !it.rekam && !it.tanpaBerkas }

    override fun tambahHeader(akar: LinearLayout) {
        val judul = when {
            uris.isEmpty() -> getString(R.string.app_name)
            uris.size == 1 -> namaBerkas[0]
            else -> "${uris.size} berkas: ${namaBerkas[0]}"
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(warna(R.color.bar_bg))
            setPadding(dp(8), dp(10), dp(16), dp(10))
        }
        val kembali = TextView(this).apply {
            text = "←"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(warna(R.color.bar_teks))
            contentDescription = "Kembali"
            isClickable = true
            isFocusable = true
            setOnClickListener { finish() }
        }
        bar.addView(kembali, LinearLayout.LayoutParams(dp(48), dp(48)))
        val tvJudul = TextView(this).apply {
            text = judul
            textSize = 20f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(warna(R.color.bar_teks))
            ViewCompat.setAccessibilityHeading(this, true)
        }
        bar.addView(tvJudul, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        akar.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val putar = Button(this).apply {
            text = "Putar Audio"
            textSize = 20f
            isAllCaps = false
            setTextColor(warna(R.color.tile_simbol))
            background = GradientDrawable().apply {
                setColor(warna(R.color.tile_bg))
                cornerRadius = dp(8).toFloat()
            }
            isEnabled = uris.isNotEmpty()
            setOnClickListener { gantiPutar() }
        }
        tombolPutar = putar
        akar.addView(putar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply {
            setMargins(dp(12), dp(12), dp(12), dp(4))
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = if (uris.size == 1) namaBerkas[0] else getString(R.string.app_name)
    }

    /** Putar atau hentikan berkas pertama untuk didengarkan sebelum memilih fitur. */
    private fun gantiPutar() {
        if (pemutar != null) { hentikanPutar(); return }
        val uri = uris.firstOrNull() ?: return
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.setOnCompletionListener { hentikanPutar() }
            mp.setOnErrorListener { _, _, _ ->
                hentikanPutar()
                Toast.makeText(this, "Berkas ini tidak bisa diputar.", Toast.LENGTH_SHORT).show()
                true
            }
            mp.prepare()
            mp.start()
            pemutar = mp
            tombolPutar?.text = "Hentikan Putar"
        } catch (e: Exception) {
            hentikanPutar()
            Toast.makeText(this, "Berkas ini tidak bisa diputar.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hentikanPutar() {
        try { pemutar?.release() } catch (_: Exception) {}
        pemutar = null
        tombolPutar?.text = "Putar Audio"
    }

    /** Buka fitur yang diketuk dengan berkas yang dibagikan sudah terpilih. */
    override fun buka(d: Fitur.Def) {
        hentikanPutar()
        if (uris.isEmpty()) { super.buka(d); return }
        if (adalahVideo) {
            val tujuanV = d.tujuan ?: com.novan.audiolabnovan.video.AlatVideoActivity::class.java
            startActivity(
                Intent(this, tujuanV)
                    .putExtra(com.novan.audiolabnovan.video.VideoFitur.EXTRA, d.id)
                    .putExtra(com.novan.audiolabnovan.video.VideoFitur.EXTRA_JUDUL, d.judul)
                    .putExtra(com.novan.audiolabnovan.video.VideoFitur.EXTRA_URI, uris[0].toString())
                    .apply {
                        clipData = android.content.ClipData.newRawUri("berkas", uris[0])
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
            )
            return
        }
        val tujuan = d.tujuan
        if (tujuan == null) {
            // Fitur berbasis layar utama: oper berkas sebagai Bagikan; MainActivity sudah tahu cara menerimanya.
            val i = Intent(this, MainActivity::class.java).putExtra(Fitur.EXTRA, d.id)
            if (uris.size == 1) {
                i.action = Intent.ACTION_SEND
                i.putExtra(Intent.EXTRA_STREAM, uris[0])
                i.clipData = android.content.ClipData.newRawUri("berkas", uris[0])
            } else {
                i.action = Intent.ACTION_SEND_MULTIPLE
                i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                val cd = android.content.ClipData.newRawUri("berkas", uris[0])
                uris.drop(1).forEach { cd.addItem(android.content.ClipData.Item(it)) }
                i.clipData = cd
            }
            i.type = "audio/*"
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
            return
        }
        when (tujuan) {
            com.novan.audiolabnovan.ubah.PengubahSuaraActivity::class.java ->
                startActivity(bawaSatu(tujuan, uris[0], namaBerkas[0],
                    com.novan.audiolabnovan.ubah.PengubahSuaraActivity.EXTRA_URI,
                    com.novan.audiolabnovan.ubah.PengubahSuaraActivity.EXTRA_NAMA))
            com.novan.audiolabnovan.autotune.VocalAutoTunerActivity::class.java ->
                startActivity(bawaSatu(tujuan, uris[0], namaBerkas[0],
                    com.novan.audiolabnovan.autotune.VocalAutoTunerActivity.EXTRA_URI,
                    com.novan.audiolabnovan.autotune.VocalAutoTunerActivity.EXTRA_NAMA))
            com.novan.audiolabnovan.sfx.TambahSfxActivity::class.java ->
                startActivity(bawaSatu(tujuan, uris[0], namaBerkas[0],
                    com.novan.audiolabnovan.sfx.TambahSfxActivity.EXTRA_URI,
                    com.novan.audiolabnovan.sfx.TambahSfxActivity.EXTRA_NAMA))
            com.novan.audiolabnovan.kunci.KeyBpmActivity::class.java ->
                startActivity(bawaSatu(tujuan, uris[0], namaBerkas[0],
                    com.novan.audiolabnovan.kunci.KeyBpmActivity.EXTRA_URI,
                    com.novan.audiolabnovan.kunci.KeyBpmActivity.EXTRA_NAMA))
            com.novan.audiolabnovan.video.AudioKeVideoActivity::class.java ->
                startActivity(bawaSatu(tujuan, uris[0], namaBerkas[0],
                    com.novan.audiolabnovan.video.AudioKeVideoActivity.EXTRA_URI,
                    com.novan.audiolabnovan.video.AudioKeVideoActivity.EXTRA_NAMA))
            else -> super.buka(d)
        }
    }

    private fun bawaSatu(tujuan: Class<*>, uri: Uri, nama: String, kunciUri: String, kunciNama: String): Intent {
        // Berkas diteruskan sebagai teks URI; izin baca ikut lewat ClipData.
        return Intent(this, tujuan).apply {
            putExtra(kunciUri, uri.toString())
            putExtra(kunciNama, nama)
            clipData = android.content.ClipData.newRawUri("berkas", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    override fun onStop() {
        super.onStop()
        hentikanPutar()
    }

    override fun onDestroy() {
        hentikanPutar()
        super.onDestroy()
    }
}
