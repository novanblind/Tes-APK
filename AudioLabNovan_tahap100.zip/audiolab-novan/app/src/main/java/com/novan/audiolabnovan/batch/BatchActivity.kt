package com.novan.audiolabnovan.batch

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.ffmpegkit.FFmpegKit
import com.novan.audiolabnovan.Converter
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.OutFmt
import com.novan.audiolabnovan.Opts
import com.novan.audiolabnovan.pengolah.AlatUi
import com.novan.audiolabnovan.pengolah.PenyimpanHasil
import java.io.File
import java.util.concurrent.CountDownLatch

/**
 * Tahap 93: pemrosesan batch. Satu kerangka untuk empat fitur: Multi Konversi, Multi Video Ke Audio,
 * Multi Volume Booster, dan Multi Mix Audio. Berkas diproses satu per satu dengan mesin yang sama dengan
 * fitur tunggalnya ([Converter.convert] dan [Converter.merge]); satu berkas gagal tidak menghentikan yang lain.
 * Tanpa AI dan tanpa internet.
 */
abstract class BatchActivity : AppCompatActivity() {

    enum class Mode { KONVERSI, VIDEO_AUDIO, BOOSTER, MIX }

    protected abstract val mode: Mode

    private class Item(val uri: Uri, val nama: String)

    private val judul get() = when (mode) {
        Mode.KONVERSI -> "Multi Konversi"
        Mode.VIDEO_AUDIO -> "Multi Video Ke Audio"
        Mode.BOOSTER -> "Multi Volume Booster"
        Mode.MIX -> "Multi Mix Audio"
    }
    private val petunjuk get() = when (mode) {
        Mode.KONVERSI -> "Ubah banyak berkas sekaligus ke satu format."
        Mode.VIDEO_AUDIO -> "Ambil suara dari banyak video sekaligus."
        Mode.BOOSTER -> "Keraskan banyak berkas sekaligus tanpa pecah."
        Mode.MIX -> "Campur satu musik latar ke banyak suara. Hasilnya satu berkas per suara."
    }
    private val subfolder get() = judul
    private val suffix get() = when (mode) {
        Mode.KONVERSI -> ""
        Mode.VIDEO_AUDIO -> ""
        Mode.BOOSTER -> "_keras"
        Mode.MIX -> "_mix"
    }

    private val formatList = listOf(OutFmt.MP3, OutFmt.AAC, OutFmt.FLAC, OutFmt.WAV)
    private val kbpsList = listOf(64, 96, 128, 160, 192, 256, 320)
    private val boosterList = listOf(150, 200, 250, 300, 400)
    private val bgList = listOf(10, 20, 35, 50, 75)

    private val daftar = ArrayList<Item>()
    private var latar: Item? = null

    private lateinit var tvDaftar: TextView
    private lateinit var tvLatar: TextView
    private lateinit var spFormat: Spinner
    private lateinit var spKbps: Spinner
    private var spExtra: Spinner? = null
    private lateinit var tombolMulai: Button
    private lateinit var tombolBatal: Button
    private lateinit var tvStatus: TextView
    private lateinit var bar: ProgressBar

    @Volatile private var batal = false
    @Volatile private var sibuk = false
    private val dialogHasil by lazy { DialogHasil(this) }

    private val pilihBanyak = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        var baru = 0
        for (u in uris) if (daftar.none { it.uri == u }) { daftar.add(Item(u, namaDari(u))); baru++ }
        segarkan()
        status("$baru berkas ditambahkan. Jumlah ${daftar.size}.", true)
    }

    private val pilihLatar = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u == null) return@registerForActivityResult
        latar = Item(u, namaDari(u))
        segarkan()
        status("Musik latar: ${latar!!.nama}.", true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = judul
        val c = this
        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(AlatUi.judul(c, judul))
        akar.addView(AlatUi.label(c, petunjuk))

        if (mode == Mode.MIX) {
            akar.addView(AlatUi.tombol(c, "Pilih musik latar") { if (!sibuk) pilihLatar.launch(arrayOf("audio/*")) }, AlatUi.margin(c))
            tvLatar = AlatUi.label(c, "")
            akar.addView(tvLatar)
        }
        val tipe = if (mode == Mode.VIDEO_AUDIO) arrayOf("video/*") else arrayOf("audio/*", "video/*")
        val teksPilih = if (mode == Mode.MIX) "Pilih suara" else "Pilih berkas"
        akar.addView(AlatUi.tombol(c, teksPilih) { if (!sibuk) { daftar.clear(); pilihBanyak.launch(tipe) } }, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Tambah berkas lagi") { if (!sibuk) pilihBanyak.launch(tipe) }, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Kosongkan daftar") {
            if (!sibuk) { daftar.clear(); segarkan(); status("Daftar dikosongkan.", true) }
        }, AlatUi.margin(c))
        tvDaftar = AlatUi.label(c, "")
        akar.addView(tvDaftar)

        when (mode) {
            Mode.BOOSTER -> {
                val sp = AlatUi.spinner(c, boosterList.map { "$it persen" }).also { it.setSelection(1) }
                akar.addView(AlatUi.label(c, "Volume jadi", sp)); akar.addView(sp, AlatUi.margin(c)); spExtra = sp
            }
            Mode.MIX -> {
                val sp = AlatUi.spinner(c, bgList.map { "$it persen" }).also { it.setSelection(2) }
                akar.addView(AlatUi.label(c, "Volume musik latar", sp)); akar.addView(sp, AlatUi.margin(c)); spExtra = sp
            }
            else -> { }
        }
        spFormat = AlatUi.spinner(c, formatList.map { it.label })
        akar.addView(AlatUi.label(c, "Format hasil", spFormat)); akar.addView(spFormat, AlatUi.margin(c))
        spKbps = AlatUi.spinner(c, kbpsList.map { "$it kbps" }).also { it.setSelection(4) }
        akar.addView(AlatUi.label(c, "Kualitas (MP3 dan M4A)", spKbps)); akar.addView(spKbps, AlatUi.margin(c))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        akar.addView(bar, AlatUi.margin(c))
        tombolMulai = AlatUi.tombol(c, "Mulai proses") { mulai() }
        akar.addView(tombolMulai, AlatUi.margin(c))
        tombolBatal = AlatUi.tombol(c, "Batalkan") { batal = true; try { FFmpegKit.cancel() } catch (_: Throwable) { } }
        tombolBatal.isEnabled = false
        akar.addView(tombolBatal, AlatUi.margin(c))

        tvStatus = TextView(this).apply {
            textSize = 16f
            setTextIsSelectable(true)
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(AlatUi.dp(c, 20), AlatUi.dp(c, 8), AlatUi.dp(c, 20), AlatUi.dp(c, 16))
        }
        akar.addView(tvStatus, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlatUi.pasang(this, akar)
        segarkan()
    }

    private fun namaDari(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { q ->
                if (q.moveToFirst()) q.getString(0)?.let { return it }
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment ?: "berkas"
    }

    private fun segarkan() {
        tvDaftar.text = if (daftar.isEmpty()) "Belum ada berkas." else
            "Daftar (${daftar.size}):\n" + daftar.withIndex().joinToString("\n") { (i, d) -> "${i + 1}. ${d.nama}" }
        if (mode == Mode.MIX) tvLatar.text = latar?.let { "Musik latar: ${it.nama}" } ?: "Belum ada musik latar."
    }

    private fun status(t: String, umumkan: Boolean = false) {
        runOnUiThread {
            tvStatus.text = t
            if (umumkan) tvStatus.announceForAccessibility(t)
        }
    }

    private fun progres(p: Int) = runOnUiThread { bar.progress = p.coerceIn(0, 100) }

    private fun mulai() {
        if (sibuk) return
        if (daftar.isEmpty()) { status("Pilih berkas dulu.", true); return }
        val bg = latar
        if (mode == Mode.MIX && bg == null) { status("Pilih musik latar dulu.", true); return }
        val fmt = formatList[spFormat.selectedItemPosition.coerceIn(0, formatList.size - 1)]
        val kbps = kbpsList[spKbps.selectedItemPosition.coerceIn(0, kbpsList.size - 1)]
        val extra = spExtra?.selectedItemPosition ?: 0
        val rencana = ArrayList(daftar)

        sibuk = true
        batal = false
        tombolMulai.isEnabled = false
        tombolBatal.isEnabled = true
        bar.progress = 0
        bar.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status("Mulai. Biarkan layar menyala sampai selesai.", true)

        Thread {
            val hasil = ArrayList<DialogHasil.Hasil>()
            val gagal = ArrayList<String>()
            val dipakai = HashSet<String>()
            val n = rencana.size
            try {
                for ((i, item) in rencana.withIndex()) {
                    if (batal) break
                    status("Berkas ${i + 1} dari $n: ${item.nama}")
                    val tmp = File(cacheDir, "batch_${System.currentTimeMillis()}_$i.${fmt.ext}")
                    var galat: String? = null
                    try {
                        val dur = Converter.probeDurationMs(this, item.uri)
                        val latch = CountDownLatch(1)
                        val onProg = { p: Int -> progres((i * 100 + p) / n) }
                        val onDone = { e: String? -> galat = e; latch.countDown() }
                        when (mode) {
                            Mode.MIX -> Converter.merge(this, listOf(item.uri, bg!!.uri), tmp, fmt, kbps, dur,
                                Opts(mixFollowFirst = true, loopBg = true), onProg, onDone,
                                mix = true, bgVolume = bgList[extra.coerceIn(0, bgList.size - 1)] / 100.0)
                            Mode.BOOSTER -> Converter.convert(this, item.uri, tmp, fmt, kbps, dur,
                                Opts(loudPct = boosterList[extra.coerceIn(0, boosterList.size - 1)]), onProg, onDone)
                            else -> Converter.convert(this, item.uri, tmp, fmt, kbps, dur, Opts(), onProg, onDone)
                        }
                        latch.await()
                        if (galat == null && !batal) {
                            var dasar = item.nama.substringBeforeLast('.', item.nama) + suffix
                            var nama = "$dasar.${fmt.ext}"
                            var k = 2
                            while (!dipakai.add(nama)) { nama = "${dasar}_$k.${fmt.ext}"; k++ }
                            val u = PenyimpanHasil.simpan(this, tmp, nama, fmt, subfolder)
                            hasil.add(DialogHasil.Hasil(u, nama, fmt.mime))
                        } else if (galat != null && !batal) {
                            gagal.add("${item.nama}: ${galat!!.take(120)}")
                        }
                    } catch (e: Throwable) {
                        gagal.add("${item.nama}: ${e.message ?: e.javaClass.simpleName}")
                    } finally {
                        tmp.delete()
                    }
                    progres((i + 1) * 100 / n)
                }
            } finally {
                val dibatalkan = batal
                runOnUiThread { selesai(hasil, gagal, n, dibatalkan) }
            }
        }.start()
    }

    private fun selesai(hasil: List<DialogHasil.Hasil>, gagal: List<String>, total: Int, dibatalkan: Boolean) {
        sibuk = false
        tombolMulai.isEnabled = true
        tombolBatal.isEnabled = false
        bar.visibility = View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val sb = StringBuilder()
        sb.append(if (dibatalkan) "Dibatalkan. " else "Selesai. ")
        sb.append("${hasil.size} dari $total berhasil.")
        if (hasil.isNotEmpty()) sb.append(" Tersimpan di Musik, AudioLab Novan, $subfolder.")
        if (gagal.isNotEmpty()) sb.append("\nGagal ${gagal.size}:\n").append(gagal.joinToString("\n"))
        status(sb.toString(), true)
        if (hasil.isNotEmpty()) dialogHasil.tampilkan(hasil, "Hasil")
    }

    override fun onDestroy() {
        batal = true
        try { dialogHasil.lepas() } catch (_: Throwable) { }
        super.onDestroy()
    }
}

class MultiKonversiActivity : BatchActivity() { override val mode = Mode.KONVERSI }
class MultiVideoKeAudioActivity : BatchActivity() { override val mode = Mode.VIDEO_AUDIO }
class MultiBoosterActivity : BatchActivity() { override val mode = Mode.BOOSTER }
class MultiMixActivity : BatchActivity() { override val mode = Mode.MIX }
