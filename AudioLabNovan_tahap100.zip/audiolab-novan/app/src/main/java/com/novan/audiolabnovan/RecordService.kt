package com.novan.audiolabnovan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import androidx.core.content.IntentCompat
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import java.io.File
import com.novan.audiolabnovan.karaoke.EfekRekamPrefs
import com.novan.audiolabnovan.karaoke.RekamEfek

/** Hasil rekaman yang menunggu diambil layar (file atau pesan galat). */
data class RecResult(val file: File?, val sec: Double, val error: String?)

/** Tahap 30: keadaan perekam yang dipakai bersama antara layanan dan layar. */
object RecState {
    @Volatile var recording = false
    /** Tahap 36: rekaman sedang dijeda. */
    @Volatile var paused = false
    @Volatile var startMs = 0L
    /** Catatan dari layanan (misalnya pilihan yang tidak didukung dan diganti), ditambahkan ke status akhir. */
    @Volatile var note = ""
    @Volatile private var pending: RecResult? = null
    /** Dipanggil di thread utama saat ada hasil baru; null bila layar tidak sedang tampil. */
    @Volatile var listener: (() -> Unit)? = null

    fun post(r: RecResult) {
        pending = r
        Handler(Looper.getMainLooper()).post { listener?.invoke() }
    }

    /** Tahap 36: beri tahu layar bahwa keadaan jeda berubah (tanpa hasil baru). */
    fun notifyState() {
        Handler(Looper.getMainLooper()).post { listener?.invoke() }
    }

    fun consume(): RecResult? {
        val r = pending
        pending = null
        return r
    }
}

/**
 * Tahap 30: layanan latar depan untuk merekam suara. Rekaman tetap berjalan saat layar mati atau
 * aplikasi ditinggalkan; notifikasi punya tombol Berhenti. Hasil M4A (AAC) disimpan di cache.
 */
class RecordService : Service() {
    private var recorder: MediaRecorder? = null
    private var file: File? = null

    // Tahap 33: perekaman suara internal (AudioPlaybackCapture lewat MediaProjection), hasil WAV 16-bit stereo 44,1 kHz.
    private var ar: AudioRecord? = null
    private var projection: MediaProjection? = null
    private var projCallback: MediaProjection.Callback? = null
    private var capThread: Thread? = null
    @Volatile private var capRunning = false
    @Volatile private var capPeak = 0
    // Tahap 36: pencatat waktu jeda agar durasi hasil tidak menghitung bagian yang dijeda.
    private var pausedAt = 0L
    private var pausedTotal = 0L
    // Tahap 47: perekam mikrofon dengan efek langsung (gema, pengolah vokal, bass, penjernih, pantauan headset).
    private var fx: RekamEfek? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> finish()
            ACTION_PAUSE -> setPaused(true)
            ACTION_RESUME -> setPaused(false)
            else -> begin(intent)
        }
        return START_NOT_STICKY
    }

    private fun begin(intent: Intent?) {
        if (recorder != null || ar != null || fx != null) return
        if (intent?.getBooleanExtra(EXTRA_INTERNAL, false) == true) { beginInternal(intent); return }
        if (intent?.getBooleanExtra(EXTRA_FX, false) == true) { beginFx(); return }
        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            RecState.post(RecResult(null, 0.0, "Layanan rekam tidak bisa dimulai: ${e.message}"))
            stopSelf()
            return
        }
        // Bersihkan rekaman lama (lebih dari sehari) di cache agar tidak menumpuk.
        val old = System.currentTimeMillis() - 24L * 3600 * 1000
        cacheDir.listFiles { f -> f.name.startsWith("Rekaman_") && f.lastModified() < old }?.forEach { it.delete() }
        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
        val f = File(cacheDir, "Rekaman_$stamp.m4a")
        val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
        // Tahap 32: sumber rekaman, mikrofon pilihan, jumlah kanal, dan arah mikrofon.
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val notes = StringBuilder()
        var src = intent?.getIntExtra(EXTRA_SOURCE, MediaRecorder.AudioSource.MIC) ?: MediaRecorder.AudioSource.MIC
        if (src == MediaRecorder.AudioSource.UNPROCESSED &&
            am.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) != "true") {
            src = MediaRecorder.AudioSource.MIC
            notes.append("Sumber mentah tidak didukung perangkat ini, dipakai mikrofon standar. ")
        }
        val deviceId = intent?.getIntExtra(EXTRA_DEVICE, -1) ?: -1
        val dir = intent?.getIntExtra(EXTRA_DIR, -1) ?: -1
        val ch = (intent?.getIntExtra(EXTRA_CH, 1) ?: 1).coerceIn(1, 2)
        try {
            r.setAudioSource(src)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(if (ch == 2) 192000 else 128000)
            r.setAudioSamplingRate(44100)
            r.setAudioChannels(ch)
            r.setOutputFile(f.absolutePath)
            if (deviceId >= 0) {
                val dev = am.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.id == deviceId }
                if (dev == null || !r.setPreferredDevice(dev)) {
                    notes.append("Mikrofon pilihan tidak bisa dipakai, sistem memilih otomatis. ")
                }
            }
            r.prepare()
            r.start()
            if (dir >= 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    if (!r.setPreferredMicrophoneDirection(dir)) notes.append("Arah mikrofon tidak didukung perangkat ini. ")
                } catch (_: Exception) {
                    notes.append("Arah mikrofon tidak didukung perangkat ini. ")
                }
            }
        } catch (e: Exception) {
            try { r.release() } catch (_: Exception) { }
            f.delete()
            stopForeground(STOP_FOREGROUND_REMOVE)
            RecState.post(RecResult(null, 0.0, "Gagal mulai merekam: ${e.message}. Coba sumber rekaman atau kanal lain."))
            stopSelf()
            return
        }
        recorder = r
        file = f
        RecState.note = notes.toString().trim()
        RecState.startMs = SystemClock.elapsedRealtime()
        pausedTotal = 0L
        pausedAt = 0L
        RecState.paused = false
        RecState.recording = true
    }

    /** Tahap 36: lama rekaman tanpa bagian yang dijeda. */
    private fun elapsedSec(): Double {
        val now = SystemClock.elapsedRealtime()
        val extra = if (RecState.paused) now - pausedAt else 0L
        return maxOf(0L, now - RecState.startMs - pausedTotal - extra) / 1000.0
    }

    /** Tahap 36: jeda atau lanjutkan rekaman (mikrofon lewat MediaRecorder, suara internal lewat penanda). */
    private fun setPaused(p: Boolean) {
        if (recorder == null && ar == null && fx == null) { stopSelf(); return }
        if (RecState.paused == p) return
        val now = SystemClock.elapsedRealtime()
        fx?.jeda = p
        val r = recorder
        if (r != null) {
            try {
                if (p) r.pause() else r.resume()
            } catch (e: Exception) {
                RecState.note = (RecState.note + " Jeda tidak berhasil: ${e.message}.").trim()
                RecState.notifyState()
                return
            }
        }
        if (p) pausedAt = now else pausedTotal += now - pausedAt
        RecState.paused = p
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) { }
        RecState.notifyState()
    }

    private fun finish() {
        val r = recorder
        if (r == null) {
            if (fx != null) finishFx() else if (ar != null) finishInternal() else stopSelf()
            return
        }
        val f = file
        val sec = elapsedSec()
        var ok = true
        try { r.stop() } catch (e: RuntimeException) { ok = false }
        try { r.release() } catch (_: Exception) { }
        recorder = null
        file = null
        RecState.recording = false
        RecState.paused = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (ok && f != null && f.length() > 0) {
            RecState.post(RecResult(f, sec, null))
        } else {
            f?.delete()
            RecState.post(RecResult(null, sec, "Rekaman terlalu singkat atau gagal, jadi tidak disimpan."))
        }
        stopSelf()
    }


    private fun failInternal(msg: String) {
        try { ar?.release() } catch (_: Exception) { }
        ar = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        RecState.post(RecResult(null, 0.0, msg))
        stopSelf()
    }

    /** Tahap 47: mulai merekam mikrofon dengan efek langsung; setelannya dibaca dari [EfekRekamPrefs]. */
    private fun beginFx() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
        } catch (e: Exception) {
            RecState.post(RecResult(null, 0.0, "Layanan rekam tidak bisa dimulai: ${e.message}"))
            stopSelf()
            return
        }
        val old = System.currentTimeMillis() - 24L * 3600 * 1000
        cacheDir.listFiles { f -> f.name.startsWith("Rekaman_") && f.lastModified() < old }?.forEach { it.delete() }
        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
        val f = File(cacheDir, "Rekaman_efek_$stamp.wav")
        val e = RekamEfek(this, EfekRekamPrefs(this))
        val err = e.mulai(f)
        if (err != null) {
            f.delete()
            stopForeground(STOP_FOREGROUND_REMOVE)
            RecState.post(RecResult(null, 0.0, "Gagal mulai merekam dengan efek: $err"))
            stopSelf()
            return
        }
        fx = e
        RecState.note = e.catatan.trim()
        RecState.startMs = SystemClock.elapsedRealtime()
        pausedTotal = 0L
        pausedAt = 0L
        RecState.paused = false
        RecState.recording = true
    }

    /** Tahap 47: hentikan rekaman dengan efek dan serahkan berkas WAV-nya. */
    private fun finishFx() {
        val e = fx ?: run { stopSelf(); return }
        val sec = elapsedSec()
        val f = e.berhenti()
        val puncak = e.puncak
        fx = null
        RecState.recording = false
        RecState.paused = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (f != null) {
            if (puncak < 200) {
                RecState.note = (RecState.note + " Rekaman tampak hening. Periksa izin dan posisi mikrofon.").trim()
            }
            RecState.post(RecResult(f, sec, null))
        } else {
            RecState.post(RecResult(null, sec, "Rekaman terlalu singkat atau gagal, jadi tidak disimpan."))
        }
        stopSelf()
    }

    /** Tahap 33: mulai merekam suara yang diputar aplikasi lain (Android 10 ke atas, butuh izin rekam layar dari pengguna). */
    private fun beginInternal(intent: Intent) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            RecState.post(RecResult(null, 0.0, "Suara internal butuh Android 10 ke atas."))
            stopSelf()
            return
        }
        try {
            startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } catch (e: Exception) {
            RecState.post(RecResult(null, 0.0, "Layanan rekam tidak bisa dimulai: ${e.message}"))
            stopSelf()
            return
        }
        val code = intent.getIntExtra(EXTRA_PROJ_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_PROJ_DATA, Intent::class.java)
        if (data == null) { failInternal("Izin rekam suara internal tidak sampai ke layanan. Coba lagi."); return }
        val mp = try {
            (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code, data)
        } catch (e: Exception) { null }
        if (mp == null) { failInternal("Izin rekam suara internal ditolak sistem. Coba lagi."); return }
        projection = mp
        val cb = object : MediaProjection.Callback() {
            override fun onStop() { if (ar != null) finishInternal() }
        }
        projCallback = cb
        mp.registerCallback(cb, Handler(Looper.getMainLooper()))
        val old = System.currentTimeMillis() - 24L * 3600 * 1000
        cacheDir.listFiles { f -> f.name.startsWith("Rekaman_") && f.lastModified() < old }?.forEach { it.delete() }
        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
        val f = File(cacheDir, "Rekaman_internal_$stamp.wav")
        val rate = 44100
        val rec: AudioRecord
        val out: FileOutputStream
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minBuf, 4096) * 4)
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            rec.startRecording()
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                rec.release()
                failInternal("Perekaman suara internal tidak bisa dimulai di perangkat ini.")
                return
            }
            out = FileOutputStream(f)
            out.write(ByteArray(44))   // tempat kepala WAV, diisi setelah selesai
        } catch (e: Exception) {
            f.delete()
            failInternal("Gagal mulai merekam suara internal: ${e.message}")
            return
        }
        ar = rec
        file = f
        capPeak = 0
        capRunning = true
        RecState.note = ""
        RecState.startMs = SystemClock.elapsedRealtime()
        pausedTotal = 0L
        pausedAt = 0L
        RecState.paused = false
        RecState.recording = true
        capThread = Thread {
            val sbuf = ShortArray(4096)
            val bb = ByteBuffer.allocate(sbuf.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            var total = 0L
            try {
                while (capRunning) {
                    val n = rec.read(sbuf, 0, sbuf.size)
                    if (n <= 0) continue
                    if (RecState.paused) continue   // tahap 36: saat dijeda, data dibaca lalu dibuang
                    bb.clear()
                    var peak = capPeak
                    for (i in 0 until n) {
                        val v = sbuf[i].toInt()
                        val a = if (v < 0) -v else v
                        if (a > peak) peak = a
                        bb.putShort(sbuf[i])
                    }
                    capPeak = peak
                    out.write(bb.array(), 0, n * 2)
                    total += n * 2L
                }
            } catch (_: Exception) {
            }
            try { out.flush(); out.close() } catch (_: Exception) { }
            try {
                RandomAccessFile(f, "rw").use { raf ->
                    fun intLE(v: Long): ByteArray = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())
                    fun shortLE(v: Int): ByteArray = byteArrayOf(v.toByte(), (v shr 8).toByte())
                    raf.seek(0)
                    raf.write("RIFF".toByteArray()); raf.write(intLE(36 + total)); raf.write("WAVE".toByteArray())
                    raf.write("fmt ".toByteArray()); raf.write(intLE(16)); raf.write(shortLE(1)); raf.write(shortLE(2))
                    raf.write(intLE(rate.toLong())); raf.write(intLE(rate * 4L)); raf.write(shortLE(4)); raf.write(shortLE(16))
                    raf.write("data".toByteArray()); raf.write(intLE(total))
                }
            } catch (_: Exception) {
            }
        }.also { it.start() }
    }

    /** Tahap 33: hentikan perekaman suara internal dan serahkan berkas WAV-nya. */
    private fun finishInternal() {
        val a = ar ?: run { stopSelf(); return }
        val f = file
        val sec = elapsedSec()
        capRunning = false
        try { a.stop() } catch (_: Exception) { }
        try { capThread?.join(3000) } catch (_: Exception) { }
        try { a.release() } catch (_: Exception) { }
        ar = null
        file = null
        capThread = null
        projCallback?.let { try { projection?.unregisterCallback(it) } catch (_: Exception) { } }
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        projCallback = null
        RecState.recording = false
        RecState.paused = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (f != null && f.length() > 44) {
            if (capPeak < 200) {
                RecState.note = "Rekaman tampak hening. Aplikasi sumber mungkin memblokir perekaman suara internal " +
                    "(panggilan telepon dan sebagian aplikasi musik atau streaming memang tidak bisa direkam)."
            }
            RecState.post(RecResult(f, sec, null))
        } else {
            f?.delete()
            RecState.post(RecResult(null, sec, "Rekaman terlalu singkat atau gagal, jadi tidak disimpan."))
        }
        stopSelf()
    }

    /** Bila sistem menghentikan layanan, rekaman yang sudah ada tetap diselamatkan. */
    override fun onDestroy() {
        if (recorder != null || ar != null || fx != null) finish()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Perekam suara", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, RecordService::class.java).setAction(ACTION_STOP), flags)
        val paused = RecState.paused
        val pause = PendingIntent.getService(this, 2,
            Intent(this, RecordService::class.java).setAction(if (paused) ACTION_RESUME else ACTION_PAUSE), flags)
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (paused) "AudioLab novan: rekaman dijeda" else "AudioLab novan sedang merekam")
            .setContentText(if (paused) "Tekan Lanjutkan untuk meneruskan, atau Berhenti untuk menyelesaikan rekaman."
                else "Ketuk untuk membuka, tekan Jeda untuk menjeda, atau Berhenti untuk menyelesaikan rekaman.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, if (paused) "Lanjutkan" else "Jeda", pause).build())
            .addAction(Notification.Action.Builder(null, "Berhenti", stop).build())
            .build()
    }

    companion object {
        const val ACTION_START = "com.novan.audiolabnovan.REKAM_MULAI"
        const val ACTION_STOP = "com.novan.audiolabnovan.REKAM_BERHENTI"
        const val ACTION_PAUSE = "com.novan.audiolabnovan.REKAM_JEDA"
        const val ACTION_RESUME = "com.novan.audiolabnovan.REKAM_LANJUT"
        const val EXTRA_INTERNAL = "internal"
        const val EXTRA_FX = "efek_langsung"
        const val EXTRA_PROJ_CODE = "proj_kode"
        const val EXTRA_PROJ_DATA = "proj_data"
        const val EXTRA_SOURCE = "sumber"
        const val EXTRA_DEVICE = "mikrofon"
        const val EXTRA_DIR = "arah"
        const val EXTRA_CH = "kanal"
        private const val CHANNEL = "rekam"
        private const val NOTIF_ID = 28
    }
}
