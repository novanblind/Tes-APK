package com.novan.audiolabnovan.karaoke

import android.content.Context

/**
 * Pengaturan Studio Karaoke (tahap 46). Disimpan di berkas "karaoke" sendiri, terpisah dari pengaturan konverter.
 * Nilai pilihan disimpan sebagai nomor urut (indeks) dari daftar pilihannya.
 */
class KaraokePrefs(context: Context) {

    private val sp = context.applicationContext.getSharedPreferences("karaoke", Context.MODE_PRIVATE)

    private fun idx(k: String, def: Int, n: Int) = sp.getInt(k, def).coerceIn(0, n - 1)
    private fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun bool(k: String, def: Boolean) = sp.getBoolean(k, def)
    private fun putB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    /** Pilihan cepat efek: nomor urut dari EFEK_PRESET (bawaan 2 = karaoke klasik). */
    var kEfek: Int
        get() = idx("k_efek", 2, EFEK_PRESET.size)
        set(v) = put("k_efek", v)

    /** Sinkron vokal: nomor urut dari SELARAS_MS; diingat supaya cukup dicari sekali per headset. */
    var kSelaras: Int
        get() = idx("k_selaras", SELARAS_BAWAAN, SELARAS_MS.size)
        set(v) = put("k_selaras", v)

    /** True bila pengguna sendiri pernah mengubah sinkron vokal; selama false, nilainya dipilih otomatis menurut headset. */
    var kSelarasManual: Boolean
        get() = if (sp.contains("k_selaras_manual")) bool("k_selaras_manual", false) else sp.contains("k_selaras")
        set(v) = putB("k_selaras_manual", v)

    /** Memilih sinkron vokal menurut headset (Bluetooth jauh lebih lambat dari kabel) bila pengguna belum menentukannya sendiri. */
    fun selarasOtomatis(bluetooth: Boolean) {
        if (!kSelarasManual) {
            put("k_selaras", if (bluetooth) SELARAS_BLUETOOTH else SELARAS_BAWAAN)
            putB("k_selaras_manual", false)
        }
    }

    /** Mengembalikan semua pengaturan Studio Karaoke ke bawaan (kunci dihapus, jadi nilai bawaan di kelas ini yang berlaku). */
    fun setelBawaanStudioKaraoke() {
        val e = sp.edit()
        for (k in arrayOf(
            "k_efek", "k_selaras", "k_selaras_manual", "k_rapikan", "k_pantau", "k_skor", "k_vol_vokal", "k_vol_musik",
            "k_filter", "k_auto", "k_kromatik", "k_harmoni", "k_ganda", "k_bass", "k_jernih", "k_kurangi", "k_nada", "k_hitung", "k_runduk", "k_keras"
        )) e.remove(k)
        e.apply()
    }

    /** Rapikan vokal otomatis (penyaring dengung, gerbang, kompresor, penghilang desis, pembatas). */
    var kRapikan: Boolean
        get() = bool("k_rapikan", true)
        set(v) = putB("k_rapikan", v)

    /** Nada dasar lagu: nomor urut 0..12 (6 = tidak diubah, 0 = turun 6 setengah nada, 12 = naik 6 setengah nada). */
    var kNada: Int
        get() = idx("k_nada", 6, 13)
        set(v) = put("k_nada", v)

    /** Hitung mundur sebelum lagu mulai: nomor urut 0..2 (0 mati, 1 = 3 detik, 2 = 5 detik); bawaan 3 detik. */
    var kHitung: Int
        get() = idx("k_hitung", 1, 3)
        set(v) = put("k_hitung", v)

    /** Lama hitung mundur dalam detik (0 = mati). */
    val detikHitung: Int get() = intArrayOf(0, 3, 5)[kHitung]

    /** Jumlah setengah nada yang digeser, -6 sampai +6. */
    val setengahNada: Int get() = kNada - 6

    /** Kurangi suara penyanyi asli: nomor urut dari PengurangVokal.KEKUATAN (0 mati, 1 sedang, 2 kuat). */
    var kKurangi: Int
        get() = idx("k_kurangi", 1, PengurangVokal.KEKUATAN.size)
        set(v) = put("k_kurangi", v)

    var kPantau: Boolean
        get() = bool("k_pantau", true)
        set(v) = putB("k_pantau", v)

    /** Menilai nyanyian (skor, bintang, peringkat, baris yang perlu dilatih). */
    var kSkor: Boolean
        get() = bool("k_skor", true)
        set(v) = putB("k_skor", v)

    /** Volume vokal dan musik pada campuran akhir, persen 0..200. */
    var kVolVokal: Int
        get() = sp.getInt("k_vol_vokal", 110).coerceIn(0, 200)
        set(v) = put("k_vol_vokal", v)

    var kVolMusik: Int
        get() = sp.getInt("k_vol_musik", 85).coerceIn(0, 200)
        set(v) = put("k_vol_musik", v)

    /** Musik merunduk saat menyanyi: nomor urut 0..3 (mati, 3, 6, 9 dB); bawaan 1 (ringan). */
    var kRunduk: Int
        get() = idx("k_runduk", 1, 4)
        set(v) = put("k_runduk", v)

    val rundukDb: Double get() = doubleArrayOf(0.0, 3.0, 6.0, 9.0)[kRunduk]

    /** Penyama kekerasan hasil akhir: nomor urut 0..2 (mati, sedang, keras); bawaan 1 (sedang). */
    var kKeras: Int
        get() = idx("k_keras", 1, 3)
        set(v) = put("k_keras", v)

    // ----- Filter suara (ala StarMaker dan Smule) -----

    /** Pilihan cepat dari FILTER_PRESET; [FILTER_MANUAL] berarti atur sendiri. */
    var kFilter: Int
        get() = idx("k_filter", 1, FILTER_PRESET.size + 1)
        set(v) = put("k_filter", v)

    /** Penyetel nada otomatis: 0 mati, 1 lembut, 2 sedang, 3 kuat, 4 robot. */
    var kAuto: Int
        get() = idx("k_auto", 1, 5)
        set(v) = put("k_auto", v)

    var kKromatik: Boolean
        get() = bool("k_kromatik", false)
        set(v) = putB("k_kromatik", v)

    /** Harmoni: 0 mati, 1 terts di atas, 2 kuint di atas, 3 oktaf di bawah. */
    var kHarmoni: Int
        get() = idx("k_harmoni", 0, 4)
        set(v) = put("k_harmoni", v)

    var kGanda: Boolean
        get() = bool("k_ganda", false)
        set(v) = putB("k_ganda", v)

    var kBass: Int
        get() = idx("k_bass", 0, BASS_DB.size)
        set(v) = put("k_bass", v)

    var kJernih: Int
        get() = idx("k_jernih", 1, JERNIH_DB.size)
        set(v) = put("k_jernih", v)

    fun konfigFilter() = KonfigFilter(kAuto, kKromatik, kHarmoni, kGanda, BASS_DB[kBass], JERNIH_DB[kJernih])

    /** Mengisi semua pengaturan filter (dan efek gema bila preset menentukannya) dari pilihan cepat [i]. */
    fun terapkanFilterPreset(i: Int) {
        if (i !in FILTER_PRESET.indices) return
        val r = FILTER_PRESET[i]
        kAuto = r[0]
        kKromatik = r[1] == 1
        kHarmoni = r[2]
        kGanda = r[3] == 1
        kBass = r[4]
        kJernih = r[5]
        if (r[6] >= 0) kEfek = r[6]
    }

    /** Efek dari pilihan cepat nomor [i] (0 = mati). */
    fun efekPreset(i: Int): KonfigEfek = Companion.efekPreset(i)

    companion object {
        /** Lama gema (reverb) turun 60 dB, dalam detik; 0 = mati. Urutan: mati, ruang kecil, studio, aula, katedral. */
        val GAUNG_RT60 = floatArrayOf(0f, 0.45f, 0.9f, 1.8f, 3.2f)
        /** Kekerasan gema dibanding suara asli (1,0 = sama keras). */
        val GAUNG_LEVEL = floatArrayOf(0.15f, 0.28f, 0.42f, 0.6f)
        /** Jarak pengulangan echo (milidetik); 0 = mati. */
        val ECHO_MS = intArrayOf(0, 120, 250, 375, 500)
        /** Kekerasan echo dibanding suara asli, dan seberapa banyak echo diulang lagi (tipis, sedang, kuat). */
        val ECHO_CAMPUR = floatArrayOf(0.22f, 0.32f, 0.45f)
        val ECHO_UMPAN = floatArrayOf(0.25f, 0.4f, 0.55f)
        /**
         * Pilihan cepat efek karaoke; tiap baris = ukuran gema, kekuatan gema, jarak echo, kekuatan echo
         * (nomor urut ke larik di atas). Urutannya harus sama dengan larik k_efek_preset di arrays_karaoke.xml.
         */
        val EFEK_PRESET = arrayOf(
            intArrayOf(0, 0, 0, 0), // mati
            intArrayOf(2, 1, 0, 0), // studio vokal
            intArrayOf(2, 2, 2, 0), // karaoke klasik
            intArrayOf(3, 1, 3, 1), // panggung konser
            intArrayOf(4, 1, 4, 0), // aula besar
            intArrayOf(0, 0, 3, 2)  // echo panjang
        )
        /**
         * Filter suara siap pakai; tiap baris = penyetel nada otomatis, kromatik (1 = ya), harmoni, suara ganda (1 = ya),
         * nomor bass, nomor jernih, dan efek gema (-1 = jangan ubah). Urutan harus sama dengan larik k_filter_preset.
         */
        val FILTER_PRESET = arrayOf(
            intArrayOf(0, 0, 0, 0, 0, 0, -1), // asli
            intArrayOf(1, 0, 0, 0, 0, 1, 1),  // natural plus
            intArrayOf(2, 0, 0, 1, 0, 2, 1),  // pop cerah
            intArrayOf(1, 0, 1, 0, 2, 0, 4),  // balada hangat
            intArrayOf(1, 0, 0, 1, 1, 1, 3),  // panggung konser
            intArrayOf(2, 0, 2, 0, 0, 1, 2),  // duet harmoni
            intArrayOf(1, 0, 3, 0, 3, 0, 1),  // suara dalam
            intArrayOf(4, 1, 0, 0, 0, 2, 1)   // robot pop
        )
        val FILTER_MANUAL = FILTER_PRESET.size
        /** Seberapa awal (milidetik) vokal digeser terhadap musik; 0 = mati. Urutan sama dengan larik k_selaras_suara. */
        val SELARAS_MS = intArrayOf(0, 40, 80, 120, 160, 200, 250, 300)
        const val SELARAS_BAWAAN = 3
        /** Nomor urut 250 milidetik pada SELARAS_MS, awal yang masuk akal untuk headset Bluetooth. */
        const val SELARAS_BLUETOOTH = 6
        val BASS_DB = intArrayOf(0, 3, 6, 9, 12)
        val JERNIH_DB = intArrayOf(0, 2, 4, 6)

        fun efekPreset(i: Int): KonfigEfek {
            val p = EFEK_PRESET[i.coerceIn(0, EFEK_PRESET.size - 1)]
            return KonfigEfek(GAUNG_RT60[p[0]], GAUNG_LEVEL[p[1]], ECHO_MS[p[2]], ECHO_CAMPUR[p[3]], ECHO_UMPAN[p[3]])
        }
    }
}
