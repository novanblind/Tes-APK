package com.novan.audiolabnovan.karaoke

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Pembatas lembut: nilai di bawah ambang tidak diubah, di atasnya dilengkungkan mulus ke batas 16 bit.
 * Ini mencegah suara pecah (terpotong keras) saat penguatan atau penyetel nada membuat puncak melewati batas.
 */
internal fun batasiLembut(v: Double): Short {
    val ambang = 22_000.0
    val sisa = 32_767.0 - ambang
    val a = if (v < 0) -v else v
    val h = if (a <= ambang) a else ambang + sisa * tanh((a - ambang) / sisa)
    return (if (v < 0) -h else h).toInt().toShort()
}

/**
 * Penyetel nada ringan untuk suara mikrofon: penguat bass (rak rendah di 120 Hz) dan penjernih (puncak di 3,5 kHz).
 * Memakai tapis biquad rumus RBJ, jadi murah dan tidak menambah jeda. Kedua nilai 0 dB berarti tidak ada proses.
 */
class PenyetelSuara(sr: Int, private val kanal: Int, bassDb: Int, jernihDb: Int) {

    private class Biquad(val b0: Double, val b1: Double, val b2: Double, val a1: Double, val a2: Double, kanal: Int) {
        val x1 = DoubleArray(kanal)
        val x2 = DoubleArray(kanal)
        val y1 = DoubleArray(kanal)
        val y2 = DoubleArray(kanal)
    }

    private val tahap = ArrayList<Biquad>()

    val aktif: Boolean get() = tahap.isNotEmpty()

    init {
        if (bassDb != 0) tahap.add(rakRendah(sr, 120.0, bassDb.toDouble()))
        if (jernihDb != 0) tahap.add(puncak(sr, 3_500.0, 0.8, jernihDb.toDouble()))
    }

    private fun rakRendah(sr: Int, f0: Double, db: Double): Biquad {
        val a = 10.0.pow(db / 40.0)
        val w = 2.0 * PI * f0 / sr
        val c = cos(w)
        val alfa = sin(w) / 2.0 * sqrt(2.0)
        val r = 2.0 * sqrt(a) * alfa
        val b0 = a * ((a + 1) - (a - 1) * c + r)
        val b1 = 2 * a * ((a - 1) - (a + 1) * c)
        val b2 = a * ((a + 1) - (a - 1) * c - r)
        val a0 = (a + 1) + (a - 1) * c + r
        val a1 = -2 * ((a - 1) + (a + 1) * c)
        val a2 = (a + 1) + (a - 1) * c - r
        return Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0, kanal)
    }

    private fun puncak(sr: Int, f0: Double, q: Double, db: Double): Biquad {
        val a = 10.0.pow(db / 40.0)
        val w = 2.0 * PI * f0 / sr
        val c = cos(w)
        val alfa = sin(w) / (2.0 * q)
        val b0 = 1 + alfa * a
        val b1 = -2 * c
        val b2 = 1 - alfa * a
        val a0 = 1 + alfa / a
        val a1 = -2 * c
        val a2 = 1 - alfa / a
        return Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0, kanal)
    }

    /** Memproses [n] nilai sampel (bergantian antar saluran) di tempat. */
    fun proses(b: ShortArray, n: Int) {
        if (tahap.isEmpty()) return
        for (i in 0 until n) {
            val ch = i % kanal
            var x = b[i].toDouble()
            for (t in tahap) {
                val y = t.b0 * x + t.b1 * t.x1[ch] + t.b2 * t.x2[ch] - t.a1 * t.y1[ch] - t.a2 * t.y2[ch]
                t.x2[ch] = t.x1[ch]
                t.x1[ch] = x
                t.y2[ch] = t.y1[ch]
                t.y1[ch] = y
                x = y
            }
            b[i] = batasiLembut(x)
        }
    }
}
