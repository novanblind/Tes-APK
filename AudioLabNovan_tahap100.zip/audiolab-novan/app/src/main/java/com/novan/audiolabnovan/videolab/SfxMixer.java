package com.novan.audiolabnovan.videolab;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Menyatukan semua efek suara tambahan menjadi satu berkas WAV mono selama durasi hasil akhir. */
final class SfxMixer {
    static final int RATE = 44100;
    private static final long MAX_DECODE_MS = 30000;

    private SfxMixer() { }

    private static final class Dec {
        short[] pcm;
        long start;
        float gain;
    }

    /** Mengembalikan null jika tidak ada efek suara yang jatuh di dalam durasi hasil akhir. */
    static File buildBed(Context ctx, List<SfxItem> items, long totalMs, File out) throws Exception {
        long usable = totalMs - 30;
        if (usable <= 0) return null;
        long totalFrames = usable * RATE / 1000;
        List<Dec> decs = new ArrayList<>();
        for (SfxItem it : items) {
            long startFrame = it.atMs * RATE / 1000;
            if (startFrame >= totalFrames) continue;
            Dec d = new Dec();
            d.pcm = decode(ctx, it.uri, MAX_DECODE_MS);
            if (d.pcm.length == 0) continue;
            d.start = startFrame;
            d.gain = it.volume;
            decs.add(d);
        }
        if (decs.isEmpty()) return null;

        try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
            writeHeader(os, totalFrames);
            final int block = RATE;
            byte[] buf = new byte[block * 2];
            for (long pos = 0; pos < totalFrames; pos += block) {
                int n = (int) Math.min(block, totalFrames - pos);
                boolean any = false;
                for (Dec d : decs) {
                    if (d.start < pos + n && d.start + d.pcm.length > pos) { any = true; break; }
                }
                if (!any) {
                    Arrays.fill(buf, (byte) 0);
                    os.write(buf, 0, n * 2);
                    continue;
                }
                for (int i = 0; i < n; i++) {
                    float sum = 0f;
                    long fr = pos + i;
                    for (Dec d : decs) {
                        long idx = fr - d.start;
                        if (idx >= 0 && idx < d.pcm.length) sum += d.pcm[(int) idx] * d.gain;
                    }
                    float xs = sum / 32768f;
                    float as = Math.abs(xs);
                    if (as > 0.6f) {
                        float yy = 0.6f + 0.4f * (float) Math.tanh((as - 0.6f) / 0.4f);
                        xs = xs < 0 ? -yy : yy;
                    }
                    int v = Math.round(xs * 32767f);
                    if (v > Short.MAX_VALUE) v = Short.MAX_VALUE;
                    if (v < Short.MIN_VALUE) v = Short.MIN_VALUE;
                    buf[i * 2] = (byte) (v & 0xff);
                    buf[i * 2 + 1] = (byte) ((v >> 8) & 0xff);
                }
                os.write(buf, 0, n * 2);
            }
        }
        return out;
    }

    private static void writeHeader(OutputStream os, long frames) throws IOException {
        long dataBytes = frames * 2;
        ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        h.put(new byte[]{'R', 'I', 'F', 'F'});
        h.putInt((int) (36 + dataBytes));
        h.put(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
        h.putInt(16);
        h.putShort((short) 1);
        h.putShort((short) 1);
        h.putInt(RATE);
        h.putInt(RATE * 2);
        h.putShort((short) 2);
        h.putShort((short) 16);
        h.put(new byte[]{'d', 'a', 't', 'a'});
        h.putInt((int) dataBytes);
        os.write(h.array());
    }

    /** Mengurai berkas audio apa pun yang didukung HP menjadi sampel mono 16 bit pada 44100 Hz. */
    static short[] decode(Context ctx, Uri uri, long maxMs) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        try {
            ex.setDataSource(ctx, uri, null);
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) { track = i; fmt = f; break; }
            }
            if (track < 0) throw new IllegalStateException("tidak ada suara di berkas");
            ex.selectTrack(track);
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            codec.configure(fmt, null, null, 0);
            codec.start();

            int srcRate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                    ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : RATE;
            int ch = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                    ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
            boolean isFloat = false;
            short[] mono = new short[RATE * 4];
            int len = 0;

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inDone = false;
            boolean outDone = false;
            long t0 = System.currentTimeMillis();
            while (!outDone && System.currentTimeMillis() - t0 < 20000) {
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        int n = ex.readSampleData(ib, 0);
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi >= 0) {
                    ByteBuffer ob = codec.getOutputBuffer(oi);
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        ob.order(ByteOrder.LITTLE_ENDIAN);
                        if (isFloat) {
                            FloatBuffer fb = ob.asFloatBuffer();
                            while (fb.remaining() >= ch) {
                                float s = 0f;
                                for (int c = 0; c < ch; c++) s += fb.get();
                                int v = Math.round(s / ch * 32767f);
                                if (v > Short.MAX_VALUE) v = Short.MAX_VALUE;
                                if (v < Short.MIN_VALUE) v = Short.MIN_VALUE;
                                if (len == mono.length) mono = Arrays.copyOf(mono, len * 2);
                                mono[len++] = (short) v;
                            }
                        } else {
                            ShortBuffer sb = ob.asShortBuffer();
                            while (sb.remaining() >= ch) {
                                int s = 0;
                                for (int c = 0; c < ch; c++) s += sb.get();
                                if (len == mono.length) mono = Arrays.copyOf(mono, len * 2);
                                mono[len++] = (short) (s / ch);
                            }
                        }
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                    if (len >= (long) srcRate * maxMs / 1000) outDone = true;
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    isFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING)
                            && of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT;
                }
            }
            short[] raw = Arrays.copyOf(mono, len);
            return srcRate == RATE ? raw : resample(raw, srcRate);
        } finally {
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignored) { }
                try { codec.release(); } catch (Exception ignored) { }
            }
            ex.release();
        }
    }

    private static short[] resample(short[] in, int srcRate) {
        if (in.length == 0) return in;
        int outLen = (int) ((long) in.length * RATE / srcRate);
        short[] out = new short[outLen];
        double ratio = (double) srcRate / RATE;
        for (int i = 0; i < outLen; i++) {
            double p = i * ratio;
            int i0 = (int) p;
            double f = p - i0;
            int i1 = Math.min(i0 + 1, in.length - 1);
            out[i] = (short) Math.round(in[i0] * (1 - f) + in[i1] * f);
        }
        return out;
    }
}
