package com.novan.audiolabnovan.wa

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import java.util.Locale

/**
 * Tahap 57: kirim hasil audio ke WhatsApp atau WhatsApp Business sebagai PESAN SUARA, otomatis.
 * Alur (meniru proyek Voice note Suara Gemini): pilih aplikasi, aplikasi dibuka, pengguna membuka obrolan tujuan,
 * lalu layanan aksesibilitas menekan tombol rekam, memutar audio lewat speaker, dan menekan tombol kirim.
 */
object WaKirim {

    private const val PREFS = "wa_kirim"
    private const val K_URI = "uri_terakhir"
    private const val K_NAMA = "nama_terakhir"
    /** Kunci yang sama dibaca WaAccessibilityService.onRecording(). Satuan milidetik. */
    private const val K_JEDA = "wa_gap_ms"
    private const val JEDA_BAWAAN_MS = 500
    private const val JEDA_MAKS_MS = 10000
    private const val PKG_WA = "com.whatsapp"
    private const val PKG_WAB = "com.whatsapp.w4b"

    /** Berkas yang akan diputar layanan. Disimpan supaya tetap ada walau aplikasi sempat ditutup. */
    fun simpanUri(c: Context, u: Uri, nama: String) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(K_URI, u.toString()).putString(K_NAMA, nama).apply()
    }

    @JvmStatic
    fun uriTerakhir(c: Context): Uri? {
        val s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_URI, null) ?: return null
        return try { Uri.parse(s) } catch (_: Exception) { null }
    }

    @JvmStatic
    fun namaTerakhir(c: Context): String =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_NAMA, null) ?: ""

    /** Jeda (md) antara perekaman WhatsApp mulai dan audio mulai diputar. */
    @JvmStatic
    fun jedaMs(c: Context): Int =
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(K_JEDA, JEDA_BAWAAN_MS).coerceIn(0, JEDA_MAKS_MS)

    @JvmStatic
    fun simpanJedaMs(c: Context, ms: Int) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(K_JEDA, ms.coerceIn(0, JEDA_MAKS_MS)).apply()
    }

    /** Teks jeda untuk dibacakan, misalnya "1,5 detik" atau "tanpa jeda". */
    fun teksJeda(ms: Int): String {
        if (ms <= 0) return "tanpa jeda"
        val d = ms / 1000.0
        val t = if (ms % 1000 == 0) (ms / 1000).toString() else String.format(Locale("id"), "%.1f", d)
        return "$t detik"
    }

    /** Dialog untuk mengatur jeda dalam detik (0 sampai 10, boleh pecahan seperti 1,5). */
    fun aturJeda(act: Activity, umumkan: (String) -> Unit, saatTersimpan: () -> Unit = {}) {
        val et = EditText(act).apply {
            val sekarang = jedaMs(act)
            setText(if (sekarang % 1000 == 0) (sekarang / 1000).toString() else String.format(Locale.US, "%.1f", sekarang / 1000.0))
            setSelectAllOnFocus(true)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            contentDescription = "Jeda dalam detik, dari 0 sampai 10"
        }
        val pad = LinearLayout(act).apply {
            val p = (20 * act.resources.displayMetrics.density).toInt()
            setPadding(p, 4, p, 0)
            addView(et, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val dlg = AlertDialog.Builder(act)
            .setTitle("Atur jeda sebelum audio diputar")
            .setMessage(
                "Setelah WhatsApp mulai merekam pesan suara, aplikasi menunggu sebanyak detik ini, baru memutar audionya. " +
                "Isi 0 sampai 10 detik, boleh pecahan seperti 1,5. Saat ini: ${teksJeda(jedaMs(act))}."
            )
            .setView(pad)
            .setPositiveButton("Simpan", null)
            .setNeutralButton("Bawaan (0,5 detik)") { _, _ ->
                simpanJedaMs(act, JEDA_BAWAAN_MS)
                umumkan("Jeda dikembalikan ke bawaan: ${teksJeda(JEDA_BAWAAN_MS)}.")
                saatTersimpan()
            }
            .setNegativeButton("Batal", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val v = et.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (v == null || v < 0.0 || v > 10.0) {
                    et.error = "Isi angka 0 sampai 10"
                    umumkan("Jeda tidak valid. Isi angka 0 sampai 10 detik.")
                } else {
                    val ms = Math.round(v * 1000.0).toInt()
                    simpanJedaMs(act, ms)
                    umumkan("Jeda disimpan: ${teksJeda(ms)}.")
                    saatTersimpan()
                    dlg.dismiss()
                }
            }
        }
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dlg.show()
    }

    private fun terpasang(c: Context, pkg: String) = c.packageManager.getLaunchIntentForPackage(pkg) != null

    /** Titik masuk: dipanggil dari tombol "Kirim ke WhatsApp sebagai pesan suara". */
    fun mulai(act: Activity, uri: Uri, nama: String, umumkan: (String) -> Unit) = mulaiMode(act, uri, nama, false, umumkan)

    /** Tahap 62: titik masuk tombol "Bagikan ke status WhatsApp (pesan suara)". */
    fun mulaiStatus(act: Activity, uri: Uri, nama: String, umumkan: (String) -> Unit) = mulaiMode(act, uri, nama, true, umumkan)

    private fun mulaiMode(act: Activity, uri: Uri, nama: String, status: Boolean, umumkan: (String) -> Unit) {
        if (!WaAccessibilityService.isRunning()) {
            AlertDialog.Builder(act)
                .setTitle("Layanan aksesibilitas belum aktif")
                .setMessage(
                    "Aktifkan layanan \"Pengirim pesan suara WhatsApp\" (AudioLab novan) di pengaturan aksesibilitas " +
                    "agar pesan suara bisa dikirim otomatis ke WhatsApp.\n\n" +
                    "Di Android 13 ke atas, jika pilihannya abu-abu, buka Info aplikasi, tekan menu titik tiga, " +
                    "lalu pilih Izinkan pengaturan terbatas."
                )
                .setPositiveButton("Buka Pengaturan") { _, _ ->
                    try {
                        act.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    } catch (_: Exception) {
                        umumkan("Tidak bisa membuka pengaturan aksesibilitas.")
                    }
                }
                .setNegativeButton("Batal", null)
                .show()
            return
        }
        pilihAplikasi(act, uri, nama, status, umumkan)
    }

    private fun pilihAplikasi(act: Activity, uri: Uri, nama: String, status: Boolean, umumkan: (String) -> Unit) {
        val adaWa = terpasang(act, PKG_WA)
        val adaWab = terpasang(act, PKG_WAB)
        if (!adaWa && !adaWab) {
            umumkan("WhatsApp maupun WhatsApp Business tidak ditemukan di perangkat ini.")
            return
        }
        val nama2 = arrayOf(
            if (adaWa) "WhatsApp" else "WhatsApp (tidak terpasang)",
            if (adaWab) "WhatsApp Business" else "WhatsApp Business (tidak terpasang)"
        )
        AlertDialog.Builder(act)
            .setTitle(if (status) "Bagikan status lewat aplikasi mana?" else "Kirim lewat aplikasi mana?")
            .setItems(nama2) { _, which ->
                val pkg = if (which == 0) PKG_WA else PKG_WAB
                val ada = if (which == 0) adaWa else adaWab
                if (!ada) {
                    umumkan(nama2[which] + ".")
                } else {
                    buka(act, pkg, if (which == 0) "WhatsApp" else "WhatsApp Business", uri, nama, status, umumkan)
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun buka(act: Activity, pkg: String, label: String, uri: Uri, nama: String, status: Boolean, umumkan: (String) -> Unit) {
        val launch = act.packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            umumkan("$label tidak bisa dibuka.")
            return
        }
        simpanUri(act, uri, nama)
        val siaga = if (status) WaAccessibilityService.armStatus(act, pkg) else WaAccessibilityService.arm(act, pkg)
        if (!siaga) {
            umumkan("Layanan aksesibilitas belum aktif.")
            return
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pesan = if (status) {
            "$label dibuka. Buka tab Pembaruan atau Status, lalu tekan ikon pensil sampai halaman status dengan tab Foto, Teks, dan Suara terbuka. " +
            "Aplikasi memilih tab Suara sendiri, lalu menahan tombol mikrofon di kanan bawah, memutar audio, dan mengirim status. Volume media harus cukup keras. " +
            "Status suara WhatsApp mungkin punya batas durasi, jadi audio yang terlalu panjang bisa terpotong."
        } else "$label dibuka. Cari dan buka obrolan tujuan. Begitu obrolan terbuka, pesan suara direkam, " +
            "audio diputar, lalu dikirim otomatis. Pastikan kolom ketik pesan kosong dan volume media cukup keras."
        umumkan(pesan)
        Say.say(act, pesan)
        try {
            act.startActivity(launch)
        } catch (e: Exception) {
            umumkan("Gagal membuka $label: ${e.message ?: "galat"}")
        }
    }
}
