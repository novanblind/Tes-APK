package com.novan.audiolabnovan.karaoke

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Filter suara ala StarMaker dan Smule untuk hasil karaoke.
 * [auto] = penyetel nada otomatis: 0 mati, 1 lembut, 2 sedang, 3 kuat, 4 robot (cepat dan penuh).
 * [kromatik] = true: nada ditarik ke semiton terdekat (efek robot); false: ke tangga nada kunci lagu yang terdeteksi.
 * [harmoni] = suara tambahan: 0 mati, 1 terts di atas, 2 kuint di atas, 3 satu oktaf di bawah.
 * [ganda] = suara ganda (chorus) supaya vokal terdengar tebal.
 * [bassDb] dan [jernihDb] = penguat bass dan penjernih (dB, 0 = mati).
 */
class KonfigFilter(
    val auto: Int,
    val kromatik: Boolean,
    val harmoni: Int,
    val ganda: Boolean,
    val bassDb: Int,
    val jernihDb: Int
) {
    /** Butuh deretan nada hasil [PemantauNada] (penyetel nada otomatis dan harmoni terts atau kuint). */
    val perluNada: Boolean get() = auto > 0 || harmoni == 1 || harmoni == 2
    val adaSuara: Boolean get() = auto > 0 || harmoni > 0 || ganda
    val aktif: Boolean get() = adaSuara || bassDb != 0 || jernihDb != 0

    companion object {
        val MATI = KonfigFilter(0, false, 0, false, 0, 0)
    }
}

/**
 * Pergeseran nada dengan laju berubah-ubah: dua kepala baca bertunda dengan peralihan berbentuk Hann
 * (sama dengan [PenggeserNada] tetapi semitonnya boleh berbeda tiap sampel). Jedanya rata-rata setengah jendela.
 */
class PenggeserVariabel(sr: Int) {
    val tunda: Int = max(64, (sr * 0.03).roundToInt()) / 2
    private val lebar = max(64, (sr * 0.03).roundToInt()).toDouble()
    private val ukuran = lebar.toInt() * 2 + 4
    private val buf = DoubleArray(ukuran)
    private var tulis = 0
    private var d1 = 0.0

    fun proses(x: Double, semiton: Double): Double {
        buf[tulis] = x
        var d2 = d1 + lebar / 2.0
        if (d2 >= lebar) d2 -= lebar
        val g1 = 0.5 * (1.0 - cos(2.0 * PI * d1 / lebar))
        val g2 = 0.5 * (1.0 - cos(2.0 * PI * d2 / lebar))
        val y = (baca(d1) * g1 + baca(d2) * g2) * (1.0 + 0.2 * min(1.0, abs(semiton)))
        tulis = if (tulis + 1 == ukuran) 0 else tulis + 1
        d1 += 1.0 - 2.0.pow(semiton / 12.0)
        if (d1 >= lebar) d1 -= lebar else if (d1 < 0.0) d1 += lebar
        return y
    }

    private fun baca(d: Double): Double {
        var pos = tulis - d
        if (pos < 0) pos += ukuran
        val i0 = floor(pos).toInt()
        val t = pos - i0
        val a = buf[if (i0 >= ukuran) i0 - ukuran else i0]
        val i1 = if (i0 + 1 >= ukuran) i0 + 1 - ukuran else i0 + 1
        return a * (1.0 - t) + buf[i1] * t
    }
}

/** Suara ganda (chorus): dua salinan bertunda 17 dan 26 milidetik yang tundanya bergoyang pelan. */
class Penggandaan(private val sr: Int) {
    private val ukuran = (sr * 0.06).roundToInt()
    private val buf = DoubleArray(ukuran)
    private var tulis = 0
    private var fase = 0.0

    fun proses(x: Double): Double {
        buf[tulis] = x
        fase += 1.0 / sr
        val t1 = (0.017 + 0.0025 * sin(2.0 * PI * 0.6 * fase)) * sr
        val t2 = (0.026 + 0.003 * sin(2.0 * PI * 0.45 * fase + 2.0)) * sr
        val y = 0.35 * (baca(t1) + baca(t2))
        tulis = if (tulis + 1 == ukuran) 0 else tulis + 1
        return y
    }

    private fun baca(d: Double): Double {
        var pos = tulis - d
        while (pos < 0) pos += ukuran
        val i0 = floor(pos).toInt()
        val t = pos - i0
        val a = buf[i0 % ukuran]
        val b = buf[(i0 + 1) % ukuran]
        return a * (1.0 - t) + b * t
    }
}

/**
 * Menyiapkan, dari deretan nada suara, berapa semiton nada harus digeser di tiap saat: [kMain] untuk menarik nada
 * ke not terdekat (penyetel nada otomatis), [kHarm] untuk suara harmoni, dan [kSuara] (0..1) penanda ada suara
 * bernada (supaya harmoni tidak ikut menebalkan napas dan keheningan). Nilai antar pengukuran dihaluskan.
 *
 * Acuan penyetelan adalah A = 440 Hz. Tangga nada diambil dari kunci lagu yang ditaksir dari nada yang dinyanyikan.
 */
class JalurKoreksi(sal: PemantauNada.Salinan, kf: KonfigFilter, skalaPaksa: BooleanArray? = null) {

    private val n = sal.jumlah
    private val pusat = sal.pusat
    private val main = FloatArray(n)
    private val harm = FloatArray(n)
    private val suara = FloatArray(n)

    var kMain = 0.0
        private set
    var kHarm = 0.0
        private set
    var kSuara = 0.0
        private set

    private var p = 0

    init {
        val m = DoubleArray(n) { if (sal.hz[it] > 0f) PemantauNada.midi(sal.hz[it].toDouble()) else 0.0 }
        val s = SkorNyanyi.saring(m, n)
        val off = SkorNyanyi.taksirPenyetelan(s, n)
        val kunci = skalaPaksa ?: deteksiKunci(s, n, off)
        val semua = BooleanArray(12) { true }
        val skalaKunci = kunci ?: semua
        val skalaAuto = if (kf.kromatik || kunci == null) semua else skalaKunci
        val kekuatan = when (kf.auto) { 1 -> 0.5; 2 -> 0.8; else -> 1.0 }
        val langkahHarm = if (kf.harmoni == 2) 4 else 2
        for (i in 0 until n) {
            if (s[i] <= 0.0) continue
            suara[i] = 1f
            val y = s[i]
            val tujuan = terdekat(y, skalaAuto)
            main[i] = ((tujuan - y) * kekuatan).coerceIn(-1.5, 1.5).toFloat()
            if (kunci != null && (kf.harmoni == 1 || kf.harmoni == 2)) {
                val nada = terdekat(y, skalaKunci)
                val atas = naikTangga(nada, skalaKunci, langkahHarm)
                harm[i] = (atas - y).coerceIn(-14.0, 14.0).toFloat()
            } else {
                suara[i] = if (kf.harmoni == 1 || kf.harmoni == 2) 0f else 1f
            }
        }
    }

    /** Menetapkan [kMain], [kHarm], dan [kSuara] untuk sampel nomor [idx] (naik terus saat dipanggil berurutan). */
    fun ambil(idx: Long) {
        if (n == 0) return
        if (idx < pusat[p]) p = 0
        while (p + 1 < n && pusat[p + 1] <= idx) p++
        if (idx <= pusat[0]) {
            kMain = main[0].toDouble(); kHarm = harm[0].toDouble(); kSuara = suara[0].toDouble()
            return
        }
        if (p + 1 >= n) {
            kMain = main[p].toDouble(); kHarm = harm[p].toDouble(); kSuara = suara[p].toDouble()
            return
        }
        val t = (idx - pusat[p]).toDouble() / max(1L, pusat[p + 1] - pusat[p]).toDouble()
        kMain = main[p] + (main[p + 1] - main[p]) * t
        kHarm = harm[p] + (harm[p + 1] - harm[p]) * t
        kSuara = suara[p] + (suara[p + 1] - suara[p]) * t
    }

    companion object {
        private val MAYOR = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
        private val MINOR = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)
        private val TANGGA_MAYOR = intArrayOf(0, 2, 4, 5, 7, 9, 11)
        private val TANGGA_MINOR = intArrayOf(0, 2, 3, 5, 7, 8, 10)

        /**
         * Menaksir kunci lagu (profil Krumhansl) dari nada yang dinyanyikan; mengembalikan himpunan 12 kelas nada
         * tangga itu, atau null bila nada terlalu sedikit.
         */
        fun deteksiKunci(s: DoubleArray, n: Int, off: Double): BooleanArray? {
            val h = DoubleArray(12)
            var c = 0
            for (i in 0 until n) {
                if (s[i] <= 0.0) continue
                val pc = Math.floorMod(Math.round(s[i] - off).toInt(), 12)
                h[pc] += 1.0
                c++
            }
            if (c < 40) return null
            var terbaik = -1.0
            var tonik = 0
            var minor = false
            for (t in 0 until 12) {
                for (jenis in 0..1) {
                    val prof = if (jenis == 0) MAYOR else MINOR
                    val r = korelasi(h) { pc -> prof[Math.floorMod(pc - t, 12)] }
                    if (r > terbaik) {
                        terbaik = r; tonik = t; minor = jenis == 1
                    }
                }
            }
            val tangga = if (minor) TANGGA_MINOR else TANGGA_MAYOR
            val ada = BooleanArray(12)
            for (d in tangga) ada[(tonik + d) % 12] = true
            return ada
        }

        private inline fun korelasi(h: DoubleArray, prof: (Int) -> Double): Double {
            var mh = 0.0
            var mp = 0.0
            for (i in 0 until 12) { mh += h[i]; mp += prof(i) }
            mh /= 12.0; mp /= 12.0
            var a = 0.0
            var b = 0.0
            var d = 0.0
            for (i in 0 until 12) {
                val x = h[i] - mh
                val y = prof(i) - mp
                a += x * y; b += x * x; d += y * y
            }
            return if (b <= 0.0 || d <= 0.0) 0.0 else a / sqrt(b * d)
        }

        /** Not (bilangan bulat) terdekat dari [y] yang kelas notnya ada di [skala]. */
        fun terdekat(y: Double, skala: BooleanArray): Double {
            val dasar = Math.round(y).toInt()
            var terbaik = dasar
            var jarak = Double.MAX_VALUE
            for (d in 0..6) {
                for (c in intArrayOf(dasar - d, dasar + d)) {
                    if (skala[Math.floorMod(c, 12)] && abs(y - c) < jarak) {
                        jarak = abs(y - c)
                        terbaik = c
                    }
                }
                if (jarak < Double.MAX_VALUE) break
            }
            return terbaik.toDouble()
        }

        /** Naik [langkah] anak tangga dalam [skala] dari not [nada]; hasilnya not (bilangan bulat). */
        fun naikTangga(nada: Double, skala: BooleanArray, langkah: Int): Double {
            var c = nada.roundToInt()
            var sisa = langkah
            var jaga = 0
            while (sisa > 0 && jaga++ < 48) {
                c++
                if (skala[Math.floorMod(c, 12)]) sisa--
            }
            return c.toDouble()
        }
    }
}

/**
 * Rantai filter per sampel untuk vokal mono: penyetel nada otomatis, harmoni, dan suara ganda.
 * [lookahead] = berapa sampel ke depan vokal harus dibaca supaya hasilnya tidak terlambat dari musik
 * (pergeseran nada selalu menunda setengah jendela).
 */
class FilterVokal(private val sr: Int, private val k: KonfigFilter, private val jalur: JalurKoreksi?) {
    private val geser = k.auto > 0 || k.harmoni > 0
    private val utama = if (geser) PenggeserVariabel(sr) else null
    private val tambahan = if (k.harmoni > 0) PenggeserVariabel(sr) else null
    private val gandaan = if (k.ganda) Penggandaan(sr) else null
    private val aMain = exp(-1.0 / (max(1.0, kecepatanMs()) * sr / 1000.0))
    private val aHarm = exp(-1.0 / (0.025 * sr))
    private var hMain = 0.0
    private var hHarm = 0.0
    private var hSuara = 0.0
    private val bobotHarm = when (k.harmoni) { 1 -> 0.5; 2 -> 0.45; else -> 0.5 }

    val lookahead: Int get() = utama?.tunda ?: 0

    private fun kecepatanMs(): Double = when (k.auto) { 1 -> 90.0; 2 -> 45.0; 3 -> 20.0; else -> 3.0 }

    /** [idx] = nomor sampel vokal saat ini (untuk jalur nada); [x] = sampel vokal [lookahead] sampel ke depan. */
    fun proses(idx: Long, x: Double): Double {
        val j = jalur
        j?.ambil(idx)
        var hasil = x
        if (utama != null) {
            val sasaranMain = if (k.auto > 0 && j != null) j.kMain else 0.0
            hMain = sasaranMain + aMain * (hMain - sasaranMain)
            hasil = utama.proses(x, hMain)
        }
        if (tambahan != null) {
            val sasaranHarm = when (k.harmoni) {
                3 -> -12.0
                else -> if (j != null) j.kHarm else 0.0
            }
            hHarm = sasaranHarm + aHarm * (hHarm - sasaranHarm)
            val sasaranSuara = if (j != null) j.kSuara else if (k.harmoni == 3) 1.0 else 0.0
            hSuara = sasaranSuara + aHarm * (hSuara - sasaranSuara)
            hasil += tambahan.proses(x, hHarm) * bobotHarm * hSuara
        }
        if (gandaan != null) hasil += gandaan.proses(hasil)
        return hasil
    }
}
