package com.novan.audiolabnovan.videolab;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Baca dan tulis file subtitle format SRT. */
public final class SrtUtil {
    private static final Pattern TIME = Pattern.compile(
            "(\\d{1,2}):(\\d{2}):(\\d{2})[,.](\\d{1,3})\\s*-->\\s*(\\d{1,2}):(\\d{2}):(\\d{2})[,.](\\d{1,3})");

    private SrtUtil() { }

    private static long toMs(String h, String m, String s, String frac) {
        String f = (frac + "00").substring(0, 3);
        return ((Long.parseLong(h) * 60 + Long.parseLong(m)) * 60 + Long.parseLong(s)) * 1000
                + Long.parseLong(f);
    }

    public static List<SubtitleItem> parse(String text) {
        List<SubtitleItem> out = new ArrayList<>();
        if (text == null) return out;
        text = text.replace("﻿", "").replace("\r\n", "\n").replace('\r', '\n');
        String[] blocks = text.split("\\n\\s*\\n");
        for (String block : blocks) {
            String[] lines = block.split("\\n");
            int timeLine = -1;
            Matcher m = null;
            for (int i = 0; i < lines.length; i++) {
                Matcher mm = TIME.matcher(lines[i]);
                if (mm.find()) { timeLine = i; m = mm; break; }
            }
            if (timeLine < 0) continue;
            long st = toMs(m.group(1), m.group(2), m.group(3), m.group(4));
            long en = toMs(m.group(5), m.group(6), m.group(7), m.group(8));
            StringBuilder sb = new StringBuilder();
            for (int i = timeLine + 1; i < lines.length; i++) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(lines[i]);
            }
            String t = sb.toString().trim();
            if (t.isEmpty() || en <= st) continue;
            out.add(new SubtitleItem(st, en, t));
        }
        return out;
    }

    private static String fmt(long ms) {
        long h = ms / 3600000;
        long m = (ms / 60000) % 60;
        long s = (ms / 1000) % 60;
        long r = ms % 1000;
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, r);
    }

    public static String format(List<SubtitleItem> subs) {
        StringBuilder sb = new StringBuilder();
        int n = 1;
        for (SubtitleItem s : subs) {
            sb.append(n++).append('\n')
                    .append(fmt(s.startMs)).append(" --> ").append(fmt(s.endMs)).append('\n')
                    .append(s.text).append("\n\n");
        }
        return sb.toString();
    }
}
