package com.novan.audiolabnovan.codec

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.novan.audiolabnovan.pengolah.AlatUi

/**
 * Tahap 92: Codec Perangkat. Daftar codec audio dan video yang ada di HP (pengubah sandi dan pembaca sandi),
 * dengan saringan jenis dan tombol salin.
 */
class CodecPerangkatActivity : AppCompatActivity() {

    private val SARINGAN = listOf("Audio decoder", "Audio encoder", "Video decoder", "Video encoder", "Semua")

    private lateinit var tvHasil: TextView
    private var teks = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Codec Perangkat"
        val c = this
        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(AlatUi.judul(c, "Codec Perangkat"))
        akar.addView(AlatUi.label(c, "Codec audio dan video yang didukung HP ini."))

        val sp = AlatUi.spinner(c, SARINGAN)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { tampil(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) { }
        }
        akar.addView(AlatUi.label(c, "Tampilkan", sp))
        akar.addView(sp, AlatUi.margin(c))
        akar.addView(AlatUi.tombol(c, "Salin daftar") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Codec", teks))
            Toast.makeText(this, "Daftar disalin.", Toast.LENGTH_SHORT).show()
        }, AlatUi.margin(c))

        tvHasil = TextView(this).apply {
            textSize = 16f
            setTextIsSelectable(true)
            setPadding(AlatUi.dp(c, 20), AlatUi.dp(c, 8), AlatUi.dp(c, 20), AlatUi.dp(c, 16))
        }
        akar.addView(tvHasil, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlatUi.pasang(this, akar)
    }

    private fun tampil(saringan: Int) {
        val semua = try { MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.toList() } catch (e: Throwable) { emptyList() }
        val dipilih = semua.filter { info ->
            val audio = info.supportedTypes.any { it.startsWith("audio/") }
            val video = info.supportedTypes.any { it.startsWith("video/") }
            when (saringan) {
                0 -> audio && !info.isEncoder
                1 -> audio && info.isEncoder
                2 -> video && !info.isEncoder
                3 -> video && info.isEncoder
                else -> true
            }
        }.sortedBy { it.name.lowercase() }
        val sb = StringBuilder()
        sb.append("${SARINGAN[saringan]}: ${dipilih.size} codec.\n")
        for (info in dipilih) {
            sb.append('\n').append(info.name).append('\n')
            sb.append(if (info.isEncoder) "Encoder" else "Decoder")
            sb.append(", ").append(jenisMesin(info)).append('\n')
            sb.append("Format: ").append(info.supportedTypes.joinToString(", ")).append('\n')
            for (tipe in info.supportedTypes) {
                try {
                    val cap = info.getCapabilitiesForType(tipe)
                    cap.audioCapabilities?.let { a ->
                        sb.append("$tipe: sampai ${a.maxInputChannelCount} kanal")
                        val laju = a.supportedSampleRates
                        if (laju != null && laju.isNotEmpty()) sb.append(", laju ${laju.first()} sampai ${laju.last()} Hz")
                        val br = a.bitrateRange
                        if (br != null) sb.append(", bitrate ${br.lower / 1000} sampai ${br.upper / 1000} kbps")
                        sb.append('\n')
                    }
                    cap.videoCapabilities?.let { v ->
                        sb.append("$tipe: sampai ${v.supportedWidths.upper} x ${v.supportedHeights.upper}\n")
                    }
                } catch (_: Throwable) { }
            }
        }
        teks = sb.toString()
        tvHasil.text = teks
    }

    private fun jenisMesin(info: MediaCodecInfo): String {
        if (Build.VERSION.SDK_INT >= 29) {
            return when {
                info.isHardwareAccelerated -> "perangkat keras"
                info.isSoftwareOnly -> "perangkat lunak"
                else -> "campuran"
            }
        }
        val n = info.name.lowercase()
        return if (n.startsWith("omx.google.") || n.startsWith("c2.android.")) "perangkat lunak" else "perangkat keras"
    }
}
