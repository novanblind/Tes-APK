package com.novan.audiolabnovan.generator

import android.widget.LinearLayout
import android.widget.Spinner
import com.novan.audiolabnovan.karaoke.batasiLembut
import com.novan.audiolabnovan.pengolah.AlatUi

/**
 * Tahap 91: Noise Generator. Membuat noise putih, pink, cokelat, biru, atau ungu dari rumus (tanpa AI, tanpa internet).
 * Berguna untuk menutupi suara sekitar, membantu tidur atau fokus, atau menguji perangkat audio.
 * Tingkat kekerasan diukur sebagai RMS (kekerasan rata-rata), jadi semua jenis noise terdengar sama keras.
 */
class NoiseGeneratorActivity : GeneratorDasarActivity() {

    private class Jenis(val kode: String, val nama: String, val penjelasan: String, val norm: Double)

    companion object {
        /** [norm] = 1 / RMS hasil algoritma, supaya tiap jenis berkekerasan sama (diukur lewat simulasi 20 sampai 60 detik). */
        private val JENIS = listOf(
            Jenis("putih", "Putih (white)", "desis rata dan tajam", 1.7320),
            Jenis("pink", "Pink", "lembut, seperti hujan deras", 0.5669),
            Jenis("coklat", "Cokelat (brown)", "dalam, seperti gemuruh", 48.7),
            Jenis("biru", "Biru (blue)", "tipis dan tinggi", 0.9550),
            Jenis("ungu", "Ungu (violet)", "sangat tipis dan tinggi", 1.2257)
        )
        private val TINGKAT_DB = listOf(-30, -24, -18, -14)
        private val TINGKAT_NAMA = listOf("Sangat pelan", "Pelan", "Sedang", "Keras")
    }

    private lateinit var spJenis: Spinner
    private lateinit var spKanal: Spinner
    private lateinit var spTingkat: Spinner

    override val judulLayar = "Noise Generator"
    override val keterangan = "Buat noise untuk menutupi suara sekitar atau membantu tidur. Mulai dari volume HP yang pelan."
    override val subfolder = "Noise Generator"

    override fun tambahKolom(akar: LinearLayout) {
        val c = this
        spJenis = AlatUi.spinner(c, JENIS.map { "${it.nama}: ${it.penjelasan}" })
        akar.addView(AlatUi.label(c, "Jenis noise", spJenis))
        akar.addView(spJenis, AlatUi.margin(c))

        spKanal = AlatUi.spinner(c, listOf("Stereo (terasa lebar)", "Mono"))
        akar.addView(AlatUi.label(c, "Kanal", spKanal))
        akar.addView(spKanal, AlatUi.margin(c))

        spTingkat = AlatUi.spinner(c, TINGKAT_NAMA.indices.map { "${TINGKAT_NAMA[it]} (${TINGKAT_DB[it]} dB)" }).also { it.setSelection(1) }
        akar.addView(AlatUi.label(c, "Tingkat kekerasan", spTingkat))
        akar.addView(spTingkat, AlatUi.margin(c))
    }

    override fun siapkan(durasiDetik: Double): GeneratorDasarActivity.Rencana? {
        val j = JENIS[spJenis.selectedItemPosition.coerceIn(0, JENIS.size - 1)]
        val kanal = if (spKanal.selectedItemPosition == 1) 1 else 2
        val db = TINGKAT_DB[spTingkat.selectedItemPosition.coerceIn(0, TINGKAT_DB.size - 1)]
        val skala = j.norm * Math.pow(10.0, db / 20.0) * 32767.0
        val ph = PenghasilNoise(j.kode, kanal, skala)
        return GeneratorDasarActivity.Rencana(ph, "Noise_" + j.kode.replaceFirstChar { it.uppercase() },
            "Noise ${j.nama}, ${if (kanal == 1) "mono" else "stereo"}, tingkat $db dB.")
    }

    /** Satu aliran noise per kanal; kanal kiri dan kanan memakai benih acak berbeda sehingga tidak sama persis. */
    private class PenghasilNoise(private val kode: String, override val kanal: Int, private val skala: Double) : GeneratorDasarActivity.Penghasil {
        private class Saluran(benih: Int, private val kode: String) {
            private var x = if (benih == 0) 0x2545F491 else benih
            private var b0 = 0.0; private var b1 = 0.0; private var b2 = 0.0; private var b3 = 0.0
            private var b4 = 0.0; private var b5 = 0.0; private var b6 = 0.0
            private var coklat = 0.0
            private var pinkLalu = 0.0
            private var putihLalu = 0.0

            /** Acak seragam di [-1, 1) (xorshift32). */
            private fun acak(): Double {
                var v = x
                v = v xor (v shl 13)
                v = v xor (v ushr 17)
                v = v xor (v shl 5)
                x = v
                return (v ushr 8) / 8388608.0 - 1.0
            }

            private fun pink(w: Double): Double {
                b0 = 0.99886 * b0 + w * 0.0555179
                b1 = 0.99332 * b1 + w * 0.0750759
                b2 = 0.96900 * b2 + w * 0.1538520
                b3 = 0.86650 * b3 + w * 0.3104856
                b4 = 0.55000 * b4 + w * 0.5329522
                b5 = -0.7616 * b5 - w * 0.0168980
                val p = b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362
                b6 = w * 0.115926
                return p
            }

            fun berikut(): Double {
                val w = acak()
                return when (kode) {
                    "pink" -> pink(w)
                    "biru" -> { val p = pink(w); val d = p - pinkLalu; pinkLalu = p; d }
                    "coklat" -> { coklat = (coklat + 0.0025 * w) / 1.0025; coklat }
                    "ungu" -> { val d = w - putihLalu; putihLalu = w; d }
                    else -> w
                }
            }
        }

        private val saluran = Array(kanal) { k ->
            Saluran((System.nanoTime().toInt() * 31 + 0x9E3779B9.toInt() * (k + 1)), kode)
        }

        override fun isi(buf: ShortArray, frame: Int) {
            var p = 0
            for (i in 0 until frame) {
                for (k in 0 until kanal) {
                    buf[p++] = batasiLembut(saluran[k].berikut() * skala)
                }
            }
        }
    }
}
