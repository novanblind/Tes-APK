package com.novan.audiolabnovan.karaoke

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Process
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Hasil satu kali menyanyi: vokal mentah (mono) yang terpisah dari musik, [vokalAwal] = nomor sampel vokal yang
 * terekam tepat saat musik mulai, dan [frameMusik] = berapa frame lagu yang sempat terputar.
 */
class HasilNyanyi(val vokal: ShortArray, val vokalAwal: Int, val frameMusik: Int, val nada: PemantauNada? = null)

/**
 * Satu sesi karaoke: lagu diputar lewat AudioTrack sendiri sambil mikrofon direkam di utas lain. Karena musik tidak
 * ikut terekam (bukan lewat audio internal), vokal tetap bersih dan bisa diolah dan dicampur ulang kemudian.
 * Jam putar lagu diambil dari AudioTrack, jadi lirik bergulir tepat dengan musik yang terdengar.
 *
 * Bila [pantau] menyala, suara sendiri (dengan efek [efekPantau] dan [vokalPantau]) diputar ke headset.
 * Bila [nilai] menyala, nada suara diukur terus ([PemantauNada]) untuk penilaian nyanyian.
 */
class KaraokeMesin(
    private val lagu: Lagu,
    private val pantau: Boolean,
    private val efekPantau: KonfigEfek,
    private val vokalPantau: KonfigVokal,
    nilai: Boolean = true
) {
    private val sr = PenguraiLagu.SR
    private val vokal = PenampungShort(sr * 60)

    /** Pengukur nada suara untuk penilaian; null bila penilaian dimatikan. */
    val nada: PemantauNada? = if (nilai) PemantauNada(sr) else null

    /** Nomor sampel vokal saat musik mulai (-1 sebelum musik mulai), untuk mengaitkan nada dengan waktu musik. */
    val awalVokalSekarang: Int get() = vokalAwal

    /** Laju baca mikrofon; sama dengan [sr] kecuali jalur cepat pantauan memakai laju asli HP. */
    @Volatile private var srMik = PenguraiLagu.SR

    /** Laju sampel mikrofon yang dipakai (untuk uji dan keterangan). */
    val lajuMikrofon: Int get() = srMik

    private fun bukaMik(laju: Int, sumber: Int): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(laju, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        return try {
            val r = AudioRecord(
                sumber, laju, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(min * 4, laju / 5 * 2)
            )
            if (r.state == AudioRecord.STATE_INITIALIZED) {
                r
            } else {
                r.release()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    @Volatile private var jalan = false
    @Volatile private var vokalAwal = -1
    @Volatile private var frameAkhir = -1

    /** Lagu sudah terputar sampai habis. */
    @Volatile var selesaiAlami = false
        private set

    /** Pesan kegagalan di tengah jalan (mikrofon macet dan sebagainya); null bila baik-baik saja. */
    @Volatile var gagal: String? = null
        private set

    /** Puncak suara mikrofon pada blok terakhir (0..32767), untuk penunjuk kerasnya suara. */
    @Volatile var puncakMik = 0
        private set

    // ---- Ulangi bagian lagu (tahap 49): penulis lagu melompat dari akhir bagian ke awalnya selama dihidupkan ----
    @Volatile private var ulangDari = -1
    @Volatile private var ulangSampai = -1

    /** True bila bagian lagu pernah diulang di sesi ini: sesi jadi latihan, vokal tidak lagi disimpan dan hasil tidak dibuat. */
    @Volatile var dipakaiUlang = false
        private set

    /** Jumlah frame yang sudah ditulis ke pemutar sejak play (bertambah terus walau lagu diulang). */
    @Volatile private var ditulis = 0L
    private val lompatan = ArrayList<LongArray>() // pasangan [frame tertulis saat lompat, selisih posisi lagu]
    private var dasarLompat = 0L

    /**
     * Mulai mengulang bagian [dariMs]..[sampaiMs] terus-menerus sampai [hentikanUlang]. Bagian minimal 1,5 detik
     * dan harus berada di dalam lagu. Mengembalikan false bila tidak sah. Sesudah ini sesi menjadi latihan.
     */
    fun ulangi(dariMs: Long, sampaiMs: Long): Boolean {
        val dari = (dariMs * sr / 1000L).toInt()
        val sampai = (sampaiMs * sr / 1000L).toInt()
        if (!jalan || dari < 0 || sampai > lagu.frame || sampai - dari < sr * 3 / 2) return false
        dipakaiUlang = true
        ulangSampai = -1
        ulangDari = dari
        ulangSampai = sampai
        return true
    }

    /** Berhenti mengulang; lagu berlanjut ke depan dari titik putar sekarang. */
    fun hentikanUlang() {
        ulangSampai = -1
        ulangDari = -1
    }

    /** True selama sebuah bagian sedang diulang. */
    val mengulang: Boolean get() = ulangSampai > 0 && ulangDari >= 0

    /** Mengubah posisi kepala pemutar (frame sejak play) menjadi posisi di lagu, dengan memperhitungkan lompatan ulang. */
    private fun posisiLagu(kepala: Long): Long {
        synchronized(lompatan) {
            while (lompatan.isNotEmpty() && lompatan[0][0] <= kepala) {
                dasarLompat += lompatan.removeAt(0)[1]
            }
            return max(0L, kepala + dasarLompat)
        }
    }

    private var trek: AudioTrack? = null
    private var rekam: AudioRecord? = null
    private var tMik: Thread? = null
    private var tPutar: Thread? = null
    private var pantauan: PantauSuara? = null
    private val mikSiap = CountDownLatch(1)

    /** Posisi lagu sekarang (milidetik) menurut jam pemutar. */
    fun posisiMs(): Long {
        val t = trek ?: return if (frameAkhir >= 0) frameAkhir.toLong() * 1000L / sr else 0L
        if (!jalan) return if (frameAkhir >= 0) frameAkhir.toLong() * 1000L / sr else 0L
        return try {
            min(posisiLagu(t.playbackHeadPosition.toLong() and 0xFFFFFFFFL), lagu.frame.toLong()) * 1000L / sr
        } catch (e: Exception) {
            0L
        }
    }

    /** Memulai memutar dan merekam. Mengembalikan false bila mikrofon atau pemutar tidak bisa dibuka. */
    fun mulai(): Boolean {
        // Jalur cepat: saat pantauan headset menyala, mikrofon dibaca dengan sumber VOICE_PERFORMANCE (dirancang untuk
        // karaoke dan pertunjukan langsung, tanpa pengolahan suara tambahan) dan dengan laju asli HP (biasanya
        // 48 kHz) supaya Android tidak mengubah laju di tengah jalan. Bila gagal, kembali ke jalur lama.
        var rPilih: AudioRecord? = null
        var lajuPilih = sr
        if (pantau) {
            val asli = try { AudioTrack.getNativeOutputSampleRate(AudioManager.STREAM_MUSIC) } catch (e: Exception) { sr }
            if (asli in 16_000..96_000 && asli != sr) {
                rPilih = bukaMik(asli, SUMBER_PERFORMA)
                    ?: bukaMik(asli, MediaRecorder.AudioSource.MIC)
                if (rPilih != null) lajuPilih = asli
            }
            if (rPilih == null) rPilih = bukaMik(sr, SUMBER_PERFORMA)
        }
        if (rPilih == null) rPilih = bukaMik(sr, MediaRecorder.AudioSource.MIC)
        val r: AudioRecord = rPilih ?: return false
        srMik = lajuPilih
        val minTrek = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        if (minTrek <= 0) {
            r.release()
            return false
        }
        val t = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(max(minTrek * 2, sr / 10 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
        } catch (e: Exception) {
            r.release()
            return false
        }
        if (t.state != AudioTrack.STATE_INITIALIZED) {
            t.release()
            r.release()
            return false
        }
        rekam = r
        trek = t
        pantauan = if (pantau) PantauSuara.buat(srMik, 2) else null
        jalan = true

        tMik = Thread({ putarMik(r) }, "karaoke-mik").also { it.start() }
        tPutar = Thread({ putarLagu(t) }, "karaoke-lagu").also { it.start() }
        return true
    }

    private fun putarMik(r: AudioRecord) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val lajuBaca = srMik
        val olah = if (vokalPantau.awalAktif) PengolahVokal(lajuBaca, 1, vokalPantau) else null
        val gema = if (efekPantau.aktif) EfekKaraoke(lajuBaca, efekPantau) else null
        val batas = if (vokalPantau.pembatas) Pembatas(lajuBaca, 2) else null
        val blok = ShortArray(lajuBaca / 100) // 10 milidetik
        // Vokal disimpan dan dinilai pada 44,1 kHz; bila mikrofon dibaca pada laju lain, diubah dulu.
        val sampel = if (lajuBaca != sr) PenyampelMik(lajuBaca, sr) else null
        val simpan = ShortArray(sampel?.ukuranKeluar(blok.size) ?: 0)
        val mono = ShortArray(blok.size)
        val stereo = ShortArray(blok.size * 2)
        try {
            r.startRecording()
            if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                gagal = "Mikrofon tidak bisa dipakai. Mungkin sedang dipakai aplikasi lain."
                return
            }
        } catch (e: Exception) {
            gagal = "Mikrofon tidak bisa dipakai."
            return
        } finally {
            mikSiap.countDown()
        }
        while (jalan) {
            val n = r.read(blok, 0, blok.size)
            if (n < 0) {
                gagal = "Rekaman mikrofon terhenti."
                break
            }
            if (n == 0) continue
            if (sampel == null) {
                if (!dipakaiUlang) vokal.tambah(blok, 0, n)
                nada?.proses(blok, n)
            } else {
                val k = sampel.proses(blok, n, simpan)
                if (!dipakaiUlang) vokal.tambah(simpan, 0, k)
                nada?.proses(simpan, k)
            }
            var p = 0
            for (i in 0 until n) p = max(p, abs(blok[i].toInt()))
            puncakMik = p
            val pt = pantauan ?: continue
            System.arraycopy(blok, 0, mono, 0, n)
            olah?.proses(mono, n)
            if (gema != null) {
                gema.proses(mono, n, 1, stereo, 2)
            } else {
                for (i in 0 until n) {
                    stereo[2 * i] = mono[i]
                    stereo[2 * i + 1] = mono[i]
                }
            }
            batas?.proses(stereo, n * 2)
            pt.tulis(stereo, n * 2)
        }
    }

    private fun putarLagu(t: AudioTrack) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        // Mikrofon dinyalakan lebih dulu supaya titik awal vokal terukur tepat saat musik mulai.
        try { mikSiap.await(1500, TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { }
        val pcm = lagu.pcm
        val total = lagu.frame
        val potong = 1024
        var pos = 0
        try {
            // Isi sedikit sebelum play() supaya musik langsung terdengar; jumlahnya lebih kecil dari penyangga.
            val awal = min(total, potong * 2)
            t.write(pcm, 0, awal * 2)
            pos = awal
            ditulis = awal.toLong()
            vokalAwal = vokal.ukuran
            t.play()
            while (jalan && pos < total) {
                val us = ulangSampai
                val ud = ulangDari
                val ulang = us > 0 && ud in 0 until us
                if (ulang && pos >= us) {
                    // Akhir bagian terlewati: catat lompatan (untuk jam posisi) lalu tulis ulang dari awal bagian.
                    synchronized(lompatan) { lompatan.add(longArrayOf(ditulis, (ud - pos).toLong())) }
                    pos = ud
                    continue
                }
                var b = min(potong, total - pos)
                if (ulang) b = min(b, us - pos)
                val w = t.write(pcm, pos * 2, b * 2)
                if (w < 0) break
                pos += w / 2
                ditulis += (w / 2).toLong()
            }
            if (jalan && pos >= total) {
                // Tunggu sisa penyangga habis diputar.
                var tunggu = 0
                while (jalan && tunggu++ < 300) {
                    val kepala = t.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                    if (kepala >= ditulis) break
                    Thread.sleep(10)
                }
                if (jalan) selesaiAlami = true
            }
        } catch (e: Exception) {
            if (jalan) gagal = "Pemutar lagu terhenti."
        }
    }

    /** Menghentikan semuanya dan mengembalikan hasil nyanyi. Aman dipanggil lebih dari sekali (kedua kali: null). */
    fun berhenti(): HasilNyanyi? {
        val t = trek ?: return null
        val r = rekam ?: return null
        val kepala = try { posisiLagu(t.playbackHeadPosition.toLong() and 0xFFFFFFFFL).toInt() } catch (e: Exception) { 0 }
        frameAkhir = if (selesaiAlami) lagu.frame else min(kepala, lagu.frame)
        jalan = false
        try { t.pause() } catch (e: Exception) { }
        try { t.flush() } catch (e: Exception) { }
        try { r.stop() } catch (e: Exception) { }
        try { tPutar?.join(1000) } catch (e: Exception) { }
        try { tMik?.join(1000) } catch (e: Exception) { }
        try { t.release() } catch (e: Exception) { }
        try { r.release() } catch (e: Exception) { }
        pantauan?.lepas()
        pantauan = null
        trek = null
        rekam = null
        val awal = if (vokalAwal >= 0) vokalAwal else 0
        return HasilNyanyi(vokal.keLarik(), awal, frameAkhir, nada)
    }

    companion object {
        /** VOICE_PERFORMANCE baru ada di Android 10; di bawahnya dipakai mikrofon biasa. */
        private val SUMBER_PERFORMA: Int =
            if (Build.VERSION.SDK_INT >= 29) MediaRecorder.AudioSource.VOICE_PERFORMANCE else MediaRecorder.AudioSource.MIC

        /** Headset yang terpasang hanya Bluetooth (tanpa kabel atau USB)? Bluetooth menambah jeda ratusan milidetik. */
        fun headsetBluetooth(ctx: Context): Boolean {
            return try {
                val am = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                var bt = false
                var kabel = false
                for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                    when (d.type) {
                        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                        AudioDeviceInfo.TYPE_WIRED_HEADSET,
                        AudioDeviceInfo.TYPE_USB_HEADSET -> kabel = true
                        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> bt = true
                        else -> if (Build.VERSION.SDK_INT >= 31 && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET) bt = true
                    }
                }
                bt && !kabel
            } catch (e: Exception) {
                false
            }
        }

        /** Ada headset (kabel, USB, atau Bluetooth) yang terpasang? Tanpa itu, mikrofon menangkap musik dari speaker. */
        fun adaHeadset(ctx: Context): Boolean {
            return try {
                val am = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
                    when (it.type) {
                        AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                        AudioDeviceInfo.TYPE_WIRED_HEADSET,
                        AudioDeviceInfo.TYPE_USB_HEADSET,
                        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                        AudioDeviceInfo.TYPE_HEARING_AID -> true
                        else -> Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                    }
                }
            } catch (e: Exception) {
                false
            }
        }
    }
}
