package com.novan.audiolabnovan.videolab;

import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.BaseAudioProcessor;
import androidx.media3.common.util.UnstableApi;

import java.nio.ByteBuffer;

/** Mengatur volume dan fade masuk/keluar pada audio PCM 16 bit. */
@UnstableApi
public final class GainFadeProcessor extends BaseAudioProcessor {
    private final float volume;
    private final long fadeInMs;
    private final long fadeOutMs;
    private final long totalMs;
    private long framePos = 0;

    public GainFadeProcessor(float volume, long fadeInMs, long fadeOutMs, long totalMs) {
        this.volume = volume;
        this.fadeInMs = fadeInMs;
        this.fadeOutMs = fadeOutMs;
        this.totalMs = totalMs;
    }

    @Override
    protected AudioProcessor.AudioFormat onConfigure(AudioProcessor.AudioFormat inputAudioFormat)
            throws AudioProcessor.UnhandledAudioFormatException {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT
                && inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            // Format lain dilewatkan apa adanya supaya ekspor tidak gagal.
            return AudioProcessor.AudioFormat.NOT_SET;
        }
        return inputAudioFormat;
    }

    @Override
    protected void onFlush() {
        framePos = 0;
    }

    @Override
    public void queueInput(ByteBuffer inputBuffer) {
        int remaining = inputBuffer.remaining();
        if (remaining == 0) return;
        ByteBuffer out = replaceOutputBuffer(remaining);
        int channels = inputAudioFormat.channelCount;
        int rate = inputAudioFormat.sampleRate;
        final boolean isFloat = inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT;
        final int frameBytes = channels * (isFloat ? 4 : 2);
        while (inputBuffer.remaining() >= frameBytes) {
            double tMs = framePos * 1000.0 / rate;
            float g = volume;
            if (fadeInMs > 0 && tMs < fadeInMs) {
                g *= (float) (tMs / fadeInMs);
            }
            if (fadeOutMs > 0 && totalMs > 0) {
                double left = totalMs - tMs;
                if (left < fadeOutMs) g *= (float) Math.max(0, left / fadeOutMs);
            }
            for (int ch = 0; ch < channels; ch++) {
                float x = (isFloat ? inputBuffer.getFloat() : inputBuffer.getShort() / 32768f) * g;
                if (volume > 1f) x = softClip(x);
                if (isFloat) {
                    out.putFloat(Math.max(-1f, Math.min(1f, x)));
                } else {
                    int v = Math.round(x * 32767f);
                    if (v > Short.MAX_VALUE) v = Short.MAX_VALUE;
                    if (v < Short.MIN_VALUE) v = Short.MIN_VALUE;
                    out.putShort((short) v);
                }
            }
            framePos++;
        }
        out.flip();
    }

    /** Pembatas lembut: linear sampai 0,6, setelah itu dilengkungkan mulus agar tidak terpotong keras (tidak pecah). */
    private static float softClip(float x) {
        final float knee = 0.6f;
        float a = Math.abs(x);
        if (a <= knee) return x;
        float room = 1f - knee;
        float y = knee + room * (float) Math.tanh((a - knee) / room);
        return x < 0 ? -y : y;
    }
}
