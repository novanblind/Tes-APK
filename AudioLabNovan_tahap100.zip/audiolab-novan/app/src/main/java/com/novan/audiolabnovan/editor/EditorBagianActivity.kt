package com.novan.audiolabnovan.editor

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.OutFmt
import com.novan.audiolabnovan.RecState
import com.novan.audiolabnovan.pengolah.AlatUi
import com.novan.audiolabnovan.pengolah.PenyimpanHasil
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Tahap 95-98: Editor Salin Tempel, fitur dari Lexis Audio Editor.
 *
 * Satu berkas kerja (WAV 44,1 kHz stereo) disunting dengan waktu yang diketik: salin, hapus, pangkas, tempel,
 * sisipkan hening, senyapkan bagian, bungkam kanal kiri atau kanan. Setiap perubahan bisa dibatalkan (Undo, sampai 8 langkah).
 * Semua dikerjakan FFmpeg, tanpa gambar gelombang, supaya mudah dipakai dengan pembaca layar.
 * Waktu boleh ditulis 90, 1:30, 1:30,5, atau 1:02:03.
 */
class EditorBagianActivity : AppCompatActivity() {

    private val maksUndo = 8
    private val handler = Handler(Looper.getMainLooper())
    private val dir by lazy { File(cacheDir, "editor_bagian").also { it.mkdirs() } }
    private var nomor = 0
    private val durMap = HashMap<File, Double>()

    private var kerja: File? = null
    private var klip: File? = null
    private val riwayat = ArrayList<File>()
    private var namaSumber = ""
    @Volatile private var sibuk = false
    private var player: MediaPlayer? = null
    private val hentiPutar = Runnable { hentikan() }

    private lateinit var tvInfo: TextView
    private lateinit var tvStatus: TextView
    private lateinit var etMulai: EditText
    private lateinit var etSelesai: EditText
    private lateinit var etPosisi: EditText
    private lateinit var etDurHening: EditText
    private lateinit var spFormat: Spinner
    private lateinit var spKbps: Spinner
    private lateinit var spPreset: Spinner
    private lateinit var progress: ProgressBar
    private val tombolKerja = ArrayList<View>()
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var merekam = false

    private val kbps = listOf(96, 128, 192, 256, 320)

    /** Preset penyetelan siap pakai, seperti menu Presets di Lexis. Pasangan: nama dan rantai filter FFmpeg. */
    private val preset = listOf(
        "Bass diperkuat" to "bass=g=8:f=100",
        "Treble diperkuat" to "treble=g=6:f=4000",
        "Vokal lebih jelas" to "highpass=f=100,equalizer=f=3000:t=q:w=1:g=4,acompressor=threshold=-20dB:ratio=3:makeup=2",
        "Suara telepon" to "highpass=f=300,lowpass=f=3400",
        "Buang dengung rendah" to "highpass=f=80",
        "Kurangi desis latar" to "afftdn=nr=12:nf=-40",
        "Ratakan volume (kompresor)" to "acompressor=threshold=-18dB:ratio=4:attack=20:release=250:makeup=3",
        "Samakan kenyaringan" to "loudnorm=I=-16:TP=-1.5:LRA=11",
        "Redam bagian tinggi (hangat)" to "lowpass=f=6000,bass=g=3:f=150"
    )

    private val pilihBerkas = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) buka(uri)
    }

    private val izinMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) mulaiRekam() else status("Izin mikrofon ditolak, jadi tidak bisa merekam.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Editor Salin Tempel"
        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(AlatUi.judul(this, "Editor Salin Tempel"))
        akar.addView(AlatUi.label(this, "Buka satu berkas audio atau video, lalu sunting bagiannya dengan mengetik waktu. Waktu boleh ditulis 90, 1:30, atau 1:30,5."))

        akar.addView(AlatUi.tombol(this, "Buka berkas audio") {
            if (!sibuk) pilihBerkas.launch(arrayOf("audio/*", "video/*"))
        }, AlatUi.margin(this))

        tvInfo = AlatUi.label(this, "Belum ada berkas dibuka.")
        akar.addView(tvInfo)

        etMulai = kolom("mis. 0:10")
        akar.addView(AlatUi.label(this, "Mulai bagian (waktu)", etMulai))
        akar.addView(etMulai, AlatUi.margin(this))
        etSelesai = kolom("kosong = sampai akhir")
        akar.addView(AlatUi.label(this, "Sampai bagian (waktu)", etSelesai))
        akar.addView(etSelesai, AlatUi.margin(this))

        akar.addView(AlatUi.judul(this, "Bagian terpilih").apply { textSize = 20f })
        kerjaTombol(akar, "Dengarkan dari waktu mulai") { putar() }
        kerjaTombol(akar, "Berhenti mendengarkan") { hentikan(); status("Berhenti.") }
        kerjaTombol(akar, "Salin bagian") { salin() }
        kerjaTombol(akar, "Hapus bagian (sisanya disambung)") { hapus() }
        kerjaTombol(akar, "Pangkas (simpan hanya bagian ini)") { pangkas() }
        kerjaTombol(akar, "Senyapkan bagian (durasi tetap)") { senyapkan() }

        akar.addView(AlatUi.judul(this, "Tempel dan sisipkan").apply { textSize = 20f })
        etPosisi = kolom("mis. 0:30")
        akar.addView(AlatUi.label(this, "Posisi tempel atau sisip (waktu)", etPosisi))
        akar.addView(etPosisi, AlatUi.margin(this))
        kerjaTombol(akar, "Tempel salinan di posisi ini") { tempel() }
        etDurHening = kolom("mis. 2")
        akar.addView(AlatUi.label(this, "Lama hening yang disisipkan (detik)", etDurHening))
        akar.addView(etDurHening, AlatUi.margin(this))
        kerjaTombol(akar, "Sisipkan hening di posisi ini") { sisipHening() }

        akar.addView(AlatUi.judul(this, "Rekam ke dalam berkas").apply { textSize = 20f })
        akar.addView(AlatUi.label(this, "Isi posisi di atas, tekan Mulai rekam, lalu Berhenti rekam: rekaman disisipkan di posisi itu. Posisi kosong = ditambah di akhir. Bila belum ada berkas, rekaman jadi berkas baru."))
        akar.addView(AlatUi.tombol(this, "Mulai rekam dari mikrofon") { if (!sibuk && !merekam) mulaiRekam() }, AlatUi.margin(this))
        akar.addView(AlatUi.tombol(this, "Berhenti rekam dan sisipkan") { if (!sibuk) berhentiRekam() }, AlatUi.margin(this))

        akar.addView(AlatUi.judul(this, "Preset penyetelan").apply { textSize = 20f })
        spPreset = AlatUi.spinner(this, preset.map { it.first })
        akar.addView(AlatUi.label(this, "Pilih preset", spPreset))
        akar.addView(spPreset, AlatUi.margin(this))
        kerjaTombol(akar, "Terapkan preset ke seluruh berkas") { terapkanPreset() }

        akar.addView(AlatUi.judul(this, "Kanal").apply { textSize = 20f })
        kerjaTombol(akar, "Bungkam kanal kiri") { bungkam(true) }
        kerjaTombol(akar, "Bungkam kanal kanan") { bungkam(false) }

        akar.addView(AlatUi.judul(this, "Batalkan").apply { textSize = 20f })
        kerjaTombol(akar, "Undo (batalkan perubahan terakhir)") { undo() }

        akar.addView(AlatUi.judul(this, "Simpan").apply { textSize = 20f })
        spFormat = AlatUi.spinner(this, OutFmt.values().map { it.label })
        akar.addView(AlatUi.label(this, "Format hasil", spFormat))
        akar.addView(spFormat, AlatUi.margin(this))
        spKbps = AlatUi.spinner(this, kbps.map { "$it kbps" }).apply { setSelection(2) }
        akar.addView(AlatUi.label(this, "Kualitas (untuk MP3 dan M4A)", spKbps))
        akar.addView(spKbps, AlatUi.margin(this))
        kerjaTombol(akar, "Simpan hasil") { simpan() }

        progress = ProgressBar(this).apply { isIndeterminate = true; visibility = View.GONE }
        akar.addView(progress)
        tvStatus = AlatUi.label(this, "").apply { accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }
        akar.addView(tvStatus)

        AlatUi.pasang(this, akar)
        segarkan()
    }

    private fun kolom(petunjuk: String) = EditText(this).apply {
        hint = petunjuk
        inputType = InputType.TYPE_CLASS_TEXT
        setSingleLine()
    }

    private fun kerjaTombol(akar: LinearLayout, teks: String, aksi: () -> Unit) {
        val b = AlatUi.tombol(this, teks) { if (merekam) status("Sedang merekam. Tekan Berhenti rekam dulu.") else if (!sibuk) aksi() }
        tombolKerja += b
        akar.addView(b, AlatUi.margin(this))
    }

    // ---------------------------------------------------------------- waktu

    private fun parseWaktu(t: String): Double? {
        val s = t.trim().replace(',', '.')
        if (s.isEmpty()) return null
        return try {
            val p = s.split(':')
            when (p.size) {
                1 -> p[0].toDouble()
                2 -> p[0].toDouble() * 60 + p[1].toDouble()
                3 -> p[0].toDouble() * 3600 + p[1].toDouble() * 60 + p[2].toDouble()
                else -> null
            }
        } catch (e: NumberFormatException) { null }
    }

    private fun fmtWaktu(d: Double): String {
        val total = Math.round(d * 10).toLong()
        val dec = total % 10
        val det = total / 10
        val m = det / 60
        val s = det % 60
        return String.format(Locale.US, "%d:%02d,%d", m, s, dec)
    }

    private fun fmtDet(d: Double) = String.format(Locale.US, "%.3f", d)

    private fun durKe(f: File): Double = durMap[f] ?: durasi(f).also { durMap[f] = it }

    private fun durasi(f: File): Double =
        FFprobeKit.getMediaInformation(f.absolutePath).mediaInformation?.duration?.toDoubleOrNull() ?: 0.0

    /** Membaca kolom mulai dan sampai; mengembalikan null (dengan pesan) bila tidak sah. */
    private fun rentang(d: Double): Pair<Double, Double>? {
        val s = if (etMulai.text.isBlank()) 0.0 else parseWaktu(etMulai.text.toString())
        if (s == null || s < 0) { status("Waktu mulai tidak dikenali. Contoh: 0:10 atau 10,5."); return null }
        val e = if (etSelesai.text.isBlank()) d else parseWaktu(etSelesai.text.toString())
        if (e == null) { status("Waktu sampai tidak dikenali. Contoh: 0:40."); return null }
        val akhir = Math.min(e, d)
        if (s >= d) { status("Waktu mulai melewati akhir berkas (${fmtWaktu(d)})."); return null }
        if (akhir - s < 0.01) { status("Bagian terpilih terlalu pendek. Periksa waktu mulai dan sampai."); return null }
        return Pair(s, akhir)
    }

    private fun posisi(d: Double): Double? {
        val p = parseWaktu(etPosisi.text.toString())
        if (p == null || p < 0) { status("Posisi tidak dikenali. Contoh: 0:30."); return null }
        if (p > d) { status("Posisi melewati akhir berkas (${fmtWaktu(d)})."); return null }
        return p
    }

    // ---------------------------------------------------------------- buka

    private fun namaDari(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "audio"
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment ?: "audio"
    }

    private fun baru(awalan: String) = File(dir, "${awalan}_${++nomor}.wav")

    private fun buka(uri: Uri) {
        if (sibuk) return
        hentikan()
        setSibuk(true)
        status("Membuka berkas...")
        val nama = namaDari(uri)
        thread {
            var pesan: String? = null
            val masuk = File(dir, "masuk.tmp")
            val wav = baru("kerja")
            try {
                contentResolver.openInputStream(uri)!!.use { i -> masuk.outputStream().use { o -> i.copyTo(o) } }
                val s = FFmpegKit.executeWithArguments(arrayOf("-y", "-nostdin", "-i", masuk.absolutePath, "-vn",
                    "-ac", "2", "-ar", "44100", "-c:a", "pcm_s16le", wav.absolutePath))
                if (!ReturnCode.isSuccess(s.returnCode) || wav.length() < 100) pesan = "Berkas tidak bisa dibaca sebagai audio."
            } catch (e: Exception) {
                pesan = "Gagal membuka: ${e.message ?: "galat"}"
            } finally {
                masuk.delete()
            }
            val durwav = if (pesan == null) durasi(wav) else 0.0
            runOnUiThread {
                if (pesan == null) {
                    bersihkanRiwayat()
                    durMap[wav] = durwav
                    kerja?.delete()
                    kerja = wav
                    namaSumber = nama
                    status("Berkas dibuka: $nama.")
                } else {
                    wav.delete()
                    status(pesan ?: "Galat.")
                }
                setSibuk(false)
            }
        }
    }

    // ---------------------------------------------------------------- operasi

    private class Pot(val inp: Int, val mulai: Double?, val akhir: Double?)

    private fun susunConcat(pot: List<Pot>): String {
        val sb = StringBuilder()
        pot.forEachIndexed { i, p ->
            sb.append("[${p.inp}:a]")
            val bagian = ArrayList<String>()
            if (p.mulai != null) bagian += "start=${fmtDet(p.mulai)}"
            if (p.akhir != null) bagian += "end=${fmtDet(p.akhir)}"
            if (bagian.isNotEmpty()) sb.append("atrim=").append(bagian.joinToString(":")).append(",")
            sb.append("asetpts=PTS-STARTPTS,aformat=sample_fmts=s16:sample_rates=44100:channel_layouts=stereo[s$i];")
        }
        pot.indices.forEach { sb.append("[s$it]") }
        sb.append("concat=n=${pot.size}:v=0:a=1[o]")
        return sb.toString()
    }

    private fun argsConcat(inputs: List<String>, pot: List<Pot>, out: File): List<String> =
        listOf("-y", "-nostdin") + inputs +
            listOf("-filter_complex", susunConcat(pot), "-map", "[o]", "-c:a", "pcm_s16le", out.absolutePath)

    /** Menjalankan FFmpeg di utas latar; bila [ubahKerja] berhasil, [out] jadi berkas kerja dan yang lama masuk riwayat Undo. */
    private fun jalankan(ket: String, args: List<String>, out: File, ubahKerja: Boolean, berhasil: String) {
        setSibuk(true)
        status("$ket...")
        thread {
            val s = FFmpegKit.executeWithArguments(args.toTypedArray())
            val ok = ReturnCode.isSuccess(s.returnCode) && out.length() > 100
            val d = if (ok) durasi(out) else 0.0
            if (ok) durMap[out] = d
            runOnUiThread {
                if (ok) {
                    if (ubahKerja) {
                        kerja?.let { riwayat.add(it) }
                        while (riwayat.size > maksUndo) riwayat.removeAt(0).delete()
                        kerja = out
                        status("$berhasil Panjang sekarang ${fmtWaktu(d)}.")
                    } else {
                        klip?.delete()
                        klip = out
                        status("$berhasil Panjang salinan ${fmtWaktu(d)}.")
                    }
                } else {
                    out.delete()
                    status("Gagal: " + (s.allLogsAsString ?: "").takeLast(200).replace('\n', ' '))
                }
                setSibuk(false)
            }
        }
    }

    private fun perluBerkas(): File? {
        val f = kerja
        if (f == null) status("Buka berkas dulu.")
        return f
    }

    private fun salin() {
        val f = perluBerkas() ?: return
        val d = durKe(f)
        val (s, e) = rentang(d) ?: return
        val out = baru("klip")
        val args = listOf("-y", "-nostdin", "-i", f.absolutePath,
            "-af", "atrim=start=${fmtDet(s)}:end=${fmtDet(e)},asetpts=PTS-STARTPTS", "-c:a", "pcm_s16le", out.absolutePath)
        jalankan("Menyalin", args, out, false, "Bagian ${fmtWaktu(s)} sampai ${fmtWaktu(e)} disalin.")
    }

    private fun hapus() {
        val f = perluBerkas() ?: return
        val d = durKe(f)
        val (s, e) = rentang(d) ?: return
        val pot = ArrayList<Pot>()
        if (s > 0.001) pot += Pot(0, 0.0, s)
        if (e < d - 0.001) pot += Pot(0, e, null)
        if (pot.isEmpty()) { status("Seluruh berkas akan terhapus. Pilih bagian yang lebih pendek."); return }
        val out = baru("kerja")
        jalankan("Menghapus", argsConcat(listOf("-i", f.absolutePath), pot, out), out, true,
            "Bagian ${fmtWaktu(s)} sampai ${fmtWaktu(e)} dihapus.")
    }

    private fun pangkas() {
        val f = perluBerkas() ?: return
        val d = durKe(f)
        val (s, e) = rentang(d) ?: return
        val out = baru("kerja")
        val args = listOf("-y", "-nostdin", "-i", f.absolutePath,
            "-af", "atrim=start=${fmtDet(s)}:end=${fmtDet(e)},asetpts=PTS-STARTPTS", "-c:a", "pcm_s16le", out.absolutePath)
        jalankan("Memangkas", args, out, true, "Hanya bagian ${fmtWaktu(s)} sampai ${fmtWaktu(e)} yang disimpan.")
    }

    private fun senyapkan() {
        val f = perluBerkas() ?: return
        val d = durKe(f)
        val (s, e) = rentang(d) ?: return
        val out = baru("kerja")
        val args = listOf("-y", "-nostdin", "-i", f.absolutePath,
            "-af", "volume=0:enable='between(t,${fmtDet(s)},${fmtDet(e)})'", "-c:a", "pcm_s16le", out.absolutePath)
        jalankan("Menyenyapkan", args, out, true, "Bagian ${fmtWaktu(s)} sampai ${fmtWaktu(e)} disenyapkan.")
    }

    private fun tempel() {
        val f = perluBerkas() ?: return
        val k = klip
        if (k == null || !k.exists()) { status("Belum ada salinan. Tekan Salin bagian dulu."); return }
        val d = durKe(f)
        val p = posisi(d) ?: return
        val pot = ArrayList<Pot>()
        if (p > 0.001) pot += Pot(0, 0.0, p)
        pot += Pot(1, null, null)
        if (p < d - 0.001) pot += Pot(0, p, null)
        val out = baru("kerja")
        jalankan("Menempel", argsConcat(listOf("-i", f.absolutePath, "-i", k.absolutePath), pot, out), out, true,
            "Salinan ditempel di ${fmtWaktu(p)}.")
    }

    private fun sisipHening() {
        val f = perluBerkas() ?: return
        val d = durKe(f)
        val p = posisi(d) ?: return
        val t = parseWaktu(etDurHening.text.toString())
        if (t == null || t <= 0 || t > 600) { status("Lama hening harus antara 0,1 dan 600 detik."); return }
        val pot = ArrayList<Pot>()
        if (p > 0.001) pot += Pot(0, 0.0, p)
        pot += Pot(1, null, null)
        if (p < d - 0.001) pot += Pot(0, p, null)
        val out = baru("kerja")
        val inputs = listOf("-i", f.absolutePath, "-f", "lavfi", "-t", fmtDet(t), "-i", "anullsrc=r=44100:cl=stereo")
        jalankan("Menyisipkan hening", argsConcat(inputs, pot, out), out, true,
            "Hening ${fmtWaktu(t)} disisipkan di ${fmtWaktu(p)}.")
    }

    private fun terapkanPreset() {
        val f = perluBerkas() ?: return
        val (nama, filter) = preset[spPreset.selectedItemPosition.coerceIn(0, preset.size - 1)]
        val out = baru("kerja")
        val args = listOf("-y", "-nostdin", "-i", f.absolutePath,
            "-af", "$filter,aresample=44100,aformat=sample_fmts=s16:channel_layouts=stereo", "-c:a", "pcm_s16le", out.absolutePath)
        jalankan("Menerapkan preset $nama", args, out, true, "Preset \"$nama\" diterapkan.")
    }

    private fun bungkam(kiri: Boolean) {
        val f = perluBerkas() ?: return
        val out = baru("kerja")
        val pan = if (kiri) "pan=stereo|c0=0*c0|c1=1*c1" else "pan=stereo|c0=1*c0|c1=0*c1"
        val args = listOf("-y", "-nostdin", "-i", f.absolutePath, "-af", pan, "-c:a", "pcm_s16le", out.absolutePath)
        jalankan("Membungkam kanal", args, out, true, if (kiri) "Kanal kiri dibungkam." else "Kanal kanan dibungkam.")
    }

    private fun undo() {
        if (riwayat.isEmpty()) { status("Tidak ada perubahan yang bisa dibatalkan."); return }
        hentikan()
        kerja?.delete()
        kerja = riwayat.removeAt(riwayat.size - 1)
        status("Perubahan terakhir dibatalkan.")
        segarkan()
    }

    // ---------------------------------------------------------------- rekam

    private fun mulaiRekam() {
        if (RecState.recording) { status("Perekam suara lain sedang berjalan. Hentikan dulu."); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            izinMic.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        hentikan()
        val f = File(dir, "rekam_${++nomor}.m4a")
        try {
            val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(128000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            recFile = f
            merekam = true
            status("Merekam. Tekan Berhenti rekam dan sisipkan bila selesai.")
        } catch (e: Exception) {
            recorder?.release()
            recorder = null
            status("Tidak bisa merekam: ${e.message ?: "galat"}")
        }
    }

    private fun batalRekam() {
        if (!merekam) return
        try { recorder?.stop() } catch (_: Exception) { }
        recorder?.release()
        recorder = null
        merekam = false
        recFile?.delete()
    }

    private fun berhentiRekam() {
        val r = recorder
        val m4a = recFile
        if (!merekam || r == null || m4a == null) { status("Tidak sedang merekam."); return }
        try { r.stop() } catch (_: Exception) { }
        r.release()
        recorder = null
        merekam = false
        setSibuk(true)
        status("Memproses rekaman...")
        thread {
            val wav = baru("rek")
            val s = FFmpegKit.executeWithArguments(arrayOf("-y", "-nostdin", "-i", m4a.absolutePath,
                "-ac", "2", "-ar", "44100", "-c:a", "pcm_s16le", wav.absolutePath))
            m4a.delete()
            val ok = ReturnCode.isSuccess(s.returnCode) && wav.length() > 100
            val d = if (ok) durasi(wav) else 0.0
            runOnUiThread {
                setSibuk(false)
                if (!ok) { wav.delete(); status("Rekaman gagal diproses, mungkin terlalu pendek."); return@runOnUiThread }
                sisipRekaman(wav, d)
            }
        }
    }

    private fun sisipRekaman(wav: File, d: Double) {
        val f = kerja
        if (f == null) {
            durMap[wav] = d
            kerja = wav
            namaSumber = "rekaman"
            status("Rekaman baru dibuat, panjang ${fmtWaktu(d)}.")
            return
        }
        val dk = durKe(f)
        val p = if (etPosisi.text.isBlank()) dk else posisi(dk)
        if (p == null) { wav.delete(); return }
        val pot = ArrayList<Pot>()
        if (p > 0.001) pot += Pot(0, 0.0, p)
        pot += Pot(1, null, null)
        if (p < dk - 0.001) pot += Pot(0, p, null)
        val out = baru("kerja")
        jalankan("Menyisipkan rekaman", argsConcat(listOf("-i", f.absolutePath, "-i", wav.absolutePath), pot, out), out, true,
            "Rekaman ${fmtWaktu(d)} disisipkan di ${fmtWaktu(p)}.")
    }

    // ---------------------------------------------------------------- putar

    private fun putar() {
        val f = perluBerkas() ?: return
        hentikan()
        val s = if (etMulai.text.isBlank()) 0.0 else parseWaktu(etMulai.text.toString())
        if (s == null || s < 0) { status("Waktu mulai tidak dikenali."); return }
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            mp.seekTo((s * 1000).toInt())
            mp.setOnCompletionListener { hentikan() }
            mp.start()
            player = mp
            val e = parseWaktu(etSelesai.text.toString())
            if (e != null && e > s) handler.postDelayed(hentiPutar, ((e - s) * 1000).toLong())
            status("Memutar dari ${fmtWaktu(s)}.")
        } catch (ex: Exception) {
            status("Tidak bisa memutar: ${ex.message ?: "galat"}")
        }
    }

    private fun hentikan() {
        handler.removeCallbacks(hentiPutar)
        player?.let { try { it.stop() } catch (_: Exception) { }; it.release() }
        player = null
    }

    // ---------------------------------------------------------------- simpan

    private fun simpan() {
        val f = perluBerkas() ?: return
        hentikan()
        val fmt = OutFmt.values()[spFormat.selectedItemPosition]
        val kb = kbps[spKbps.selectedItemPosition]
        val judul = PenyimpanHasil.judulDari(namaSumber)
        val nama = "${judul}_edit_${PenyimpanHasil.stempel()}.${fmt.ext}"
        setSibuk(true)
        status("Menyimpan...")
        thread {
            val tujuan = File(dir, "hasil.${fmt.ext}")
            var uri: Uri? = null
            var err = PenyimpanHasil.sandi(f, tujuan, fmt, kb, judul, "Editor Salin Tempel")
            if (err == null) {
                try { uri = PenyimpanHasil.simpan(this, tujuan, nama, fmt, "Editor") }
                catch (e: Exception) { err = "Gagal menyimpan: ${e.message ?: "galat"}" }
            }
            tujuan.delete()
            val uAkhir = uri
            val eAkhir = err
            runOnUiThread {
                setSibuk(false)
                if (uAkhir != null) {
                    status("Tersimpan: $nama")
                    DialogHasil(this).tampilkan(uAkhir, nama, fmt.mime)
                } else status(eAkhir ?: "Gagal menyimpan.")
            }
        }
    }

    // ---------------------------------------------------------------- tampilan

    private fun status(t: String) {
        tvStatus.text = t
        segarkan()
    }

    private fun segarkan() {
        val f = kerja
        tvInfo.text = if (f == null) "Belum ada berkas dibuka." else
            "Berkas kerja: $namaSumber, panjang ${fmtWaktu(durKe(f))}. Salinan: ${if (klip?.exists() == true) "ada" else "kosong"}. " +
                "Undo tersedia: ${riwayat.size} langkah."
    }

    private fun setSibuk(s: Boolean) {
        sibuk = s
        progress.visibility = if (s) View.VISIBLE else View.GONE
        tombolKerja.forEach { it.isEnabled = !s }
    }

    private fun bersihkanRiwayat() {
        riwayat.forEach { it.delete() }
        riwayat.clear()
    }

    override fun onStop() {
        super.onStop()
        if (merekam) { batalRekam(); status("Rekaman dibatalkan karena layar ditinggalkan.") }
        hentikan()
    }

    override fun onDestroy() {
        batalRekam()
        hentikan()
        bersihkanRiwayat()
        kerja?.delete()
        klip?.delete()
        super.onDestroy()
    }
}
