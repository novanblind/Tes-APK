package com.novan.audiolabnovan.keluaran

import android.content.ContentUris
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.pengolah.AlatUi
import java.io.File
import java.util.Locale

/**
 * Tahap 92: Output Audio dan Output Video. Daftar hasil yang sudah disimpan aplikasi (terbaru di atas).
 * Ketuk satu berkas untuk memutar, bagikan, ubah nama, atau hapus (memakai menu hasil yang sama).
 */
open class HasilTersimpanActivity : AppCompatActivity() {

    companion object {
        private const val MAKS = 150
    }

    private class Butir(val uri: Uri, val nama: String, val ukuran: Long, val mime: String)

    protected open val adalahVideo: Boolean get() = false
    private val dialogHasil by lazy { DialogHasil(this) }
    private lateinit var tvStatus: TextView
    private lateinit var daftarView: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val judul = if (adalahVideo) "Output Video" else "Output Audio"
        title = judul
        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(AlatUi.judul(this, judul))
        tvStatus = AlatUi.label(this, "")
        tvStatus.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        akar.addView(tvStatus)
        akar.addView(AlatUi.tombol(this, "Segarkan daftar") { muat() }, AlatUi.margin(this))
        daftarView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(daftarView)
        AlatUi.pasang(this, akar)
    }

    override fun onResume() {
        super.onResume()
        muat()
    }

    private fun muat() {
        tvStatus.text = "Membaca daftar..."
        Thread {
            val hasil = try { baca() } catch (e: Throwable) { emptyList() }
            runOnUiThread { tampil(hasil) }
        }.start()
    }

    private fun baca(): List<Butir> {
        val out = ArrayList<Butir>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val koleksi = if (adalahVideo) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE)
            contentResolver.query(koleksi, proj, "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("%AudioLab Novan%"),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { q ->
                while (q.moveToNext() && out.size < MAKS) {
                    val id = q.getLong(0)
                    out.add(Butir(ContentUris.withAppendedId(koleksi, id), q.getString(1) ?: "berkas", q.getLong(2),
                        q.getString(3) ?: if (adalahVideo) "video/*" else "audio/*"))
                }
            }
        } else if (!adalahVideo) {
            val dasar = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir, "AudioLab Novan")
            dasar.walkTopDown().filter { it.isFile }.sortedByDescending { it.lastModified() }.take(MAKS).forEach {
                out.add(Butir(Uri.fromFile(it), it.name, it.length(), "audio/*"))
            }
        }
        return out
    }

    private fun tampil(hasil: List<Butir>) {
        daftarView.removeAllViews()
        if (hasil.isEmpty()) {
            tvStatus.text = "Belum ada hasil."
            return
        }
        tvStatus.text = "${hasil.size} berkas, terbaru di atas. Ketuk untuk membuka menunya."
        for (b in hasil) {
            val mb = b.ukuran / 1_000_000.0
            val ukuran = if (mb >= 1) String.format(Locale("id"), "%.1f MB", mb) else "${b.ukuran / 1000} KB"
            daftarView.addView(AlatUi.tombol(this, "${b.nama}, $ukuran") {
                dialogHasil.tampilkan(b.uri, b.nama, b.mime)
            }, AlatUi.margin(this))
        }
    }

    override fun onDestroy() {
        try { dialogHasil.lepas() } catch (_: Throwable) { }
        super.onDestroy()
    }
}

/** Tahap 92: Output Video (daftar video hasil). */
class HasilVideoActivity : HasilTersimpanActivity() {
    override val adalahVideo: Boolean get() = true
}
