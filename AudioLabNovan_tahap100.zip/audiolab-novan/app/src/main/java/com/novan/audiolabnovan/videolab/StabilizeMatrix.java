package com.novan.audiolabnovan.videolab;

import android.graphics.Matrix;

import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.MatrixTransformation;

/**
 * Menggeser dan memperbesar bingkai sedikit untuk meredam goyang kamera.
 * Jejak gerak dihaluskan sesuai tingkat, selisihnya dipakai sebagai koreksi per bingkai.
 */
@UnstableApi
public final class StabilizeMatrix implements MatrixTransformation {
    private static final int[] HALF_WINDOW = {0, 4, 8, 15};
    private static final float[] ZOOM = {1f, 1.06f, 1.10f, 1.15f};

    private final float[] corr;
    private final int n;
    private final long anaStartMs;
    private final long stepMs;
    private final long clipStartMs;
    private final float speed;
    private final float zoom;

    public StabilizeMatrix(float[] path, long anaStartMs, long stepMs, long clipStartMs, float speed, int level) {
        int lv = Math.max(1, Math.min(3, level));
        this.n = path.length / 2;
        this.anaStartMs = anaStartMs;
        this.stepMs = Math.max(1, stepMs);
        this.clipStartMs = clipStartMs;
        this.speed = speed;
        this.zoom = ZOOM[lv];
        this.corr = new float[n * 2];
        int hw = HALF_WINDOW[lv];
        float limit = (zoom - 1f) * 0.45f; // pecahan lebar atau tinggi, setara 90 persen ruang aman
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - hw), b = Math.min(n - 1, i + hw);
            float sx = 0, sy = 0;
            for (int k = a; k <= b; k++) { sx += path[k * 2]; sy += path[k * 2 + 1]; }
            int cnt = b - a + 1;
            float cx = sx / cnt - path[i * 2];
            float cy = sy / cnt - path[i * 2 + 1];
            corr[i * 2] = Math.max(-limit, Math.min(limit, cx));
            corr[i * 2 + 1] = Math.max(-limit, Math.min(limit, cy));
        }
    }

    @Override
    public Matrix getMatrix(long presentationTimeUs) {
        double srcMs = clipStartMs + presentationTimeUs / 1000.0 * speed;
        double pos = (srcMs - anaStartMs) / stepMs;
        float cx = 0, cy = 0;
        if (n > 0) {
            if (pos <= 0) { cx = corr[0]; cy = corr[1]; }
            else if (pos >= n - 1) { cx = corr[(n - 1) * 2]; cy = corr[(n - 1) * 2 + 1]; }
            else {
                int i = (int) pos;
                float f = (float) (pos - i);
                cx = corr[i * 2] * (1 - f) + corr[(i + 1) * 2] * f;
                cy = corr[i * 2 + 1] * (1 - f) + corr[(i + 1) * 2 + 1] * f;
            }
        }
        Matrix m = new Matrix();
        m.postScale(zoom, zoom);
        m.postTranslate(2f * cx, -2f * cy);
        return m;
    }
}
