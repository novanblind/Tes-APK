package com.novan.audiolabnovan.pengolah

import android.app.Activity
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Tahap 89: komponen tampilan sederhana (dibuat lewat kode, ramah pembaca layar) untuk layar Vocal AutoTuner dan Tambah SFX. */
object AlatUi {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun margin(c: Context) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { setMargins(dp(c, 16), 0, dp(c, 16), dp(c, 8)) }

    fun judul(c: Context, teks: String) = TextView(c).apply {
        text = teks
        textSize = 24f
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(c, 20), dp(c, 14), dp(c, 20), dp(c, 14))
        ViewCompat.setAccessibilityHeading(this, true)
    }

    /** Teks petunjuk; bila [untuk] diberi, label ini dibacakan sebagai nama kolom itu. */
    fun label(c: Context, teks: String, untuk: View? = null) = TextView(c).apply {
        text = teks
        textSize = 16f
        setPadding(dp(c, 20), dp(c, 8), dp(c, 20), dp(c, 2))
        if (untuk != null) {
            if (untuk.id == View.NO_ID) untuk.id = View.generateViewId()
            labelFor = untuk.id
        }
    }

    fun tombol(c: Context, teks: String, aksi: () -> Unit) = Button(c).apply {
        text = teks
        setOnClickListener { aksi() }
    }

    fun spinner(c: Context, items: List<String>) = Spinner(c).apply {
        adapter = ArrayAdapter(c, android.R.layout.simple_spinner_dropdown_item, items)
    }

    /** Membungkus [akar] dalam ScrollView, menghindari bilah sistem, lalu menampilkannya. */
    fun pasang(act: Activity, akar: LinearLayout) {
        val gulir = ScrollView(act).apply { addView(akar) }
        ViewCompat.setOnApplyWindowInsetsListener(gulir) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }
        act.setContentView(gulir)
    }
}
