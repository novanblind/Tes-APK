#define _GNU_SOURCE
#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <signal.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/wait.h>

static void set_size(int fd, int rows, int cols) {
    struct winsize w;
    memset(&w, 0, sizeof(w));
    w.ws_row = rows;
    w.ws_col = cols;
    ioctl(fd, TIOCSWINSZ, &w);
}

/* Mengembalikan {fd master, pid}; fd -1 jika gagal. */
JNIEXPORT jintArray JNICALL Java_novan_terminal_Pty_start(JNIEnv *env, jclass c, jstring jcmd, jstring jcwd,
        jobjectArray jenv, jint rows, jint cols) {
    jint res[2] = {-1, -1};
    const char *cmd = (*env)->GetStringUTFChars(env, jcmd, NULL);
    const char *cwd = (*env)->GetStringUTFChars(env, jcwd, NULL);
    int n = jenv ? (*env)->GetArrayLength(env, jenv) : 0;
    char **envp = calloc(n + 1, sizeof(char *));
    for (int i = 0; i < n; i++) {
        jstring s = (jstring)(*env)->GetObjectArrayElement(env, jenv, i);
        const char *u = (*env)->GetStringUTFChars(env, s, NULL);
        envp[i] = strdup(u);
        (*env)->ReleaseStringUTFChars(env, s, u);
    }
    int m = posix_openpt(O_RDWR | O_NOCTTY);
    char name[64];
    if (m >= 0 && grantpt(m) == 0 && unlockpt(m) == 0 && ptsname_r(m, name, sizeof(name)) == 0) {
        struct termios t;
        if (tcgetattr(m, &t) == 0) { t.c_iflag |= IUTF8; tcsetattr(m, TCSANOW, &t); }
        set_size(m, rows, cols);
        pid_t pid = fork();
        if (pid == 0) {
            setsid();
            int s = open(name, O_RDWR);
            if (s < 0) _exit(126);
            ioctl(s, TIOCSCTTY, 0);
            dup2(s, 0); dup2(s, 1); dup2(s, 2);
            for (int fd = 3; fd < 1024; fd++) close(fd);
            if (chdir(cwd) != 0) chdir("/");
            char *argv[] = {"/system/bin/sh", "-c", (char *)cmd, NULL};
            execve("/system/bin/sh", argv, envp);
            _exit(127);
        }
        if (pid > 0) { res[0] = m; res[1] = pid; }
        else close(m);
    } else if (m >= 0) close(m);
    for (int i = 0; i < n; i++) free(envp[i]);
    free(envp);
    (*env)->ReleaseStringUTFChars(env, jcmd, cmd);
    (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
    jintArray out = (*env)->NewIntArray(env, 2);
    (*env)->SetIntArrayRegion(env, out, 0, 2, res);
    return out;
}

JNIEXPORT void JNICALL Java_novan_terminal_Pty_setSize(JNIEnv *env, jclass c, jint fd, jint rows, jint cols) {
    set_size(fd, rows, cols);
}

JNIEXPORT jint JNICALL Java_novan_terminal_Pty_waitFor(JNIEnv *env, jclass c, jint pid) {
    int st = 0;
    while (waitpid(pid, &st, 0) < 0) { if (errno == EINTR) continue; return -1; }
    if (WIFEXITED(st)) return WEXITSTATUS(st);
    if (WIFSIGNALED(st)) return 128 + WTERMSIG(st);
    return -1;
}
