package novan.terminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

/**
 * Penjelajah folder sederhana: telusuri penyimpanan HP, naik ke folder atas, lompat lewat lokasi cepat
 * (Download, Dokumen, penyimpanan internal, kartu SD atau USB). Dipakai untuk memilih berkas APK atau zip,
 * dan bila bolehFolder, juga folder proyek. Folder terakhir diingat.
 */
class Jelajah {

    interface Hasil { void pilih(File f); }

    private static final String KUNCI = "jelajahTerakhir";

    static void buka(Activity a, String judul, String[] ekstensi, boolean bolehFolder, Hasil h) {
        File awal = null;
        try {
            String s = a.getSharedPreferences("term", Context.MODE_PRIVATE).getString(KUNCI, "");
            if (!s.isEmpty()) awal = new File(s);
        } catch (Exception e) { }
        if (awal == null || !awal.isDirectory() || !awal.canRead()) awal = new File("/sdcard/Download");
        if (!awal.isDirectory() || !awal.canRead()) awal = new File("/sdcard");
        if (!awal.isDirectory() || !awal.canRead()) awal = Env.home;
        tampil(a, judul, ekstensi, bolehFolder, h, awal);
    }

    private static boolean cocok(File f, String[] ekstensi) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        for (String e : ekstensi) if (n.endsWith(e)) return true;
        return false;
    }

    private static String ukuran(long b) {
        if (b >= 1048576) return (b / 1048576) + " MB";
        if (b >= 1024) return (b / 1024) + " KB";
        return b + " byte";
    }

    private static void ingat(Activity a, File d) {
        try { a.getSharedPreferences("term", Context.MODE_PRIVATE).edit().putString(KUNCI, d.getPath()).apply(); } catch (Exception e) { }
    }

    private static void tampil(final Activity a, final String judul, final String[] ekstensi, final boolean bolehFolder,
                               final Hasil h, final File dir) {
        File[] fs = dir.listFiles();
        if (fs == null) {
            MainActivity.add("Folder tidak bisa dibuka: " + dir.getPath() + ". Periksa izin penyimpanan.");
            MainActivity.say("Folder tidak bisa dibuka. Periksa izin penyimpanan");
            if (a instanceof MainActivity && !((MainActivity) a).storageOk()) ((MainActivity) a).askStorage();
            return;
        }
        ingat(a, dir);
        final ArrayList<File> folder = new ArrayList<>(), berkas = new ArrayList<>();
        for (File f : fs) {
            if (f.getName().startsWith(".")) continue;
            if (f.isDirectory()) folder.add(f);
            else if (f.isFile() && cocok(f, ekstensi)) berkas.add(f);
        }
        java.util.Collections.sort(folder, (x, y) -> x.getName().compareToIgnoreCase(y.getName()));
        java.util.Collections.sort(berkas, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));

        final ArrayList<String> nama = new ArrayList<>();
        final ArrayList<File> sasaran = new ArrayList<>();
        final File atas = dir.getParentFile();
        if (atas != null && atas.canRead()) {
            nama.add("Naik ke folder atas: " + (atas.getName().isEmpty() ? "/" : atas.getName()));
            sasaran.add(atas);
        }
        SimpleDateFormat tg = new SimpleDateFormat("dd MMM yyyy", new Locale("id"));
        for (File f : folder) { nama.add("Folder: " + f.getName()); sasaran.add(f); }
        for (File f : berkas) {
            nama.add(f.getName() + ", " + ukuran(f.length()) + ", " + tg.format(new Date(f.lastModified())));
            sasaran.add(f);
        }
        if (folder.isEmpty() && berkas.isEmpty()) { nama.add("(Tidak ada folder atau berkas yang cocok di sini)"); sasaran.add(null); }

        AlertDialog.Builder b = new AlertDialog.Builder(a)
            .setTitle(judul + "\n" + dir.getPath() + "\n" + folder.size() + " folder, " + berkas.size() + " berkas")
            .setItems(nama.toArray(new String[0]), (d, i) -> {
                File f = sasaran.get(i);
                if (f == null) { tampil(a, judul, ekstensi, bolehFolder, h, dir); return; }
                if (f.isDirectory()) { tampil(a, judul, ekstensi, bolehFolder, h, f); return; }
                h.pilih(f);
            })
            .setNeutralButton("Lokasi cepat", (d, w) -> lokasiCepat(a, judul, ekstensi, bolehFolder, h, dir))
            .setNegativeButton("Batal", (d, w) -> MainActivity.say("Dibatalkan"));
        if (bolehFolder) b.setPositiveButton("Pilih folder ini", (d, w) -> h.pilih(dir));
        b.show();
        MainActivity.say(dir.getName() + ", " + folder.size() + " folder, " + berkas.size() + " berkas");
    }

    private static void lokasiCepat(final Activity a, final String judul, final String[] ekstensi, final boolean bolehFolder,
                                    final Hasil h, final File dari) {
        final ArrayList<String> nama = new ArrayList<>();
        final ArrayList<File> tujuan = new ArrayList<>();
        tambah(nama, tujuan, "Download", new File("/sdcard/Download"));
        tambah(nama, tujuan, "Dokumen", new File("/sdcard/Documents"));
        tambah(nama, tujuan, "Penyimpanan internal (semua folder)", new File("/sdcard"));
        File[] vol = new File("/storage").listFiles();
        if (vol != null) {
            Arrays.sort(vol);
            for (File v : vol) {
                String n = v.getName();
                if (n.equals("emulated") || n.equals("self") || !v.isDirectory() || !v.canRead()) continue;
                tambah(nama, tujuan, "Kartu SD atau USB: " + n, v);
            }
        }
        tambah(nama, tujuan, "Folder rumah aplikasi (proyek, bongkar)", Env.home);
        new AlertDialog.Builder(a).setTitle("Lokasi cepat")
            .setItems(nama.toArray(new String[0]), (d, i) -> tampil(a, judul, ekstensi, bolehFolder, h, tujuan.get(i)))
            .setNegativeButton("Kembali", (d, w) -> tampil(a, judul, ekstensi, bolehFolder, h, dari))
            .show();
    }

    private static void tambah(ArrayList<String> nama, ArrayList<File> tujuan, String label, File f) {
        if (f.isDirectory()) { nama.add(label); tujuan.add(f); }
    }
}
