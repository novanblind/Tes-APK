package novan.terminal;

import android.os.ParcelFileDescriptor;
import android.system.Os;
import android.system.OsConstants;
import java.io.*;

/** Terminal semu (pty) lewat library native ptyterm. */
public class Pty {
    static boolean loaded;
    static {
        try { System.loadLibrary("ptyterm"); loaded = true; } catch (Throwable t) { loaded = false; }
    }

    static native int[] start(String cmd, String cwd, String[] env, int rows, int cols);
    static native void setSize(int fd, int rows, int cols);
    static native int waitFor(int pid);

    int pid;
    ParcelFileDescriptor pfd;
    InputStream in;
    OutputStream out;

    static Pty open(String cmd, String cwd, int rows, int cols) {
        if (!loaded) return null;
        String[] env = Env.vars(rows, cols);
        try {
            int[] r = start(cmd, cwd, env, rows, cols);
            if (r == null || r[0] < 0) return null;
            Pty p = new Pty();
            p.pid = r[1];
            p.pfd = ParcelFileDescriptor.adoptFd(r[0]);
            p.in = new FileInputStream(p.pfd.getFileDescriptor());
            p.out = new FileOutputStream(p.pfd.getFileDescriptor());
            return p;
        } catch (Throwable t) { return null; }
    }

    void resize(int rows, int cols) { try { setSize(pfd.getFd(), rows, cols); } catch (Throwable t) { } }

    void send(String s) {
        try { out.write(s.getBytes("UTF-8")); out.flush(); } catch (Exception e) { }
    }

    void hangup() {
        try { Os.kill(-pid, OsConstants.SIGHUP); } catch (Exception e) { }
        try { Os.kill(pid, OsConstants.SIGKILL); } catch (Exception e) { }
    }

    void close() { try { pfd.close(); } catch (Exception e) { } }
}
