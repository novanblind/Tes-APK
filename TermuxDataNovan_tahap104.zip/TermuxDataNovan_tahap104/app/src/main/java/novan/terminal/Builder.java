package novan.terminal;

import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import dalvik.system.DexClassLoader;
import java.io.*;
import java.lang.reflect.Method;

/** Membangun APK dari proyek sederhana: aapt2, ecj, d8, lalu tanda tangan. */
public class Builder {
    static volatile boolean busy;
    static DexClassLoader loader;

    static void out(String s) { MainActivity.H.post(() -> MainActivity.add(s)); }
    static void say(String s) { MainActivity.H.post(() -> MainActivity.say(s)); }
    static File share(String n) { return new File(Env.prefix, "share/novan/" + n); }

    /** Proyek sederhana: ada AndroidManifest.xml dan folder src di folder itu. */
    static boolean proyekSederhana(File p) {
        return new File(p, "AndroidManifest.xml").exists() && new File(p, "src").isDirectory();
    }

    static void buat(String nama) {
        String n = nama.replaceAll("[^A-Za-z0-9_-]", "");
        if (n.isEmpty()) { out("Tulis nama proyek. Contoh: buat-proyek halo"); say("Tulis nama proyek"); return; }
        File d = new File(MainActivity.cwd, n);
        if (d.exists()) { out("Folder sudah ada: " + d.getPath()); say("Folder sudah ada"); return; }
        String pk = n.toLowerCase().replaceAll("[^a-z0-9]", "");
        if (pk.isEmpty() || Character.isDigit(pk.charAt(0))) pk = "p" + pk;
        pk = "app." + pk;
        try {
            File src = new File(d, "src/" + pk.replace('.', '/'));
            src.mkdirs();
            new File(d, "res/values").mkdirs();
            write(new File(d, "AndroidManifest.xml"),
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                + "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\" package=\"" + pk + "\">\n"
                + "    <application android:label=\"@string/app_name\">\n"
                + "        <activity android:name=\".MainActivity\" android:exported=\"true\">\n"
                + "            <intent-filter>\n"
                + "                <action android:name=\"android.intent.action.MAIN\"/>\n"
                + "                <category android:name=\"android.intent.category.LAUNCHER\"/>\n"
                + "            </intent-filter>\n"
                + "        </activity>\n"
                + "    </application>\n"
                + "</manifest>\n");
            write(new File(d, "res/values/strings.xml"),
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n    <string name=\"app_name\">" + n + "</string>\n    <string name=\"halo\">Halo dari " + n + "</string>\n</resources>\n");
            write(new File(src, "MainActivity.java"),
                "package " + pk + ";\n\nimport android.app.Activity;\nimport android.os.Bundle;\nimport android.widget.TextView;\n\n"
                + "public class MainActivity extends Activity {\n    @Override protected void onCreate(Bundle b) {\n        super.onCreate(b);\n"
                + "        TextView t = new TextView(this);\n        t.setTextSize(24);\n        t.setText(R.string.halo);\n        setContentView(t);\n    }\n}\n");
            out("Proyek dibuat: " + d.getPath());
            out("Bangun dengan: cd " + n + " lalu tekan tombol Bangun APK");
            say("Proyek " + n + " dibuat");
        } catch (IOException e) { out("Gagal: " + e.getMessage()); }
    }

    static void write(File f, String s) throws IOException {
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(s.getBytes("UTF-8")); }
    }

    static void del(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) del(x);
        f.delete();
    }

    static int exec(File cwd, String... cmd) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(Env.wrap(cmd)).directory(cwd).redirectErrorStream(true);
        Env.apply(pb.environment());
        Process pr = pb.start();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(pr.getInputStream()))) {
            String l;
            while ((l = r.readLine()) != null) { if (!Progres.baris(l)) out(l); }
        }
        return pr.waitFor();
    }

    static int tool(String... a) throws Exception {
        if (loader == null) {
            File t = share("tools.jar");
            t.setReadOnly();
            File cache = new File(MainActivity.ctx.getCodeCacheDir(), "novan");
            cache.mkdirs();
            loader = new DexClassLoader(t.getPath(), cache.getPath(), null, Builder.class.getClassLoader());
        }
        Class<?> c = loader.loadClass("novan.build.Tool");
        Method m = c.getMethod("run", String[].class, PrintWriter.class);
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        int r;
        try { r = (Integer) m.invoke(null, new Object[]{a, pw}); }
        catch (java.lang.reflect.InvocationTargetException e) { throw new Exception(String.valueOf(e.getCause())); }
        pw.flush();
        for (String l : sw.toString().split("\n")) if (!l.trim().isEmpty()) out(l);
        return r;
    }

    static void build(String arg) {
        if (busy) { out("Masih ada proses bangun berjalan"); say("Masih ada proses bangun berjalan"); return; }
        busy = true;
        final File proj = arg.isEmpty() ? MainActivity.cwd : arg.startsWith("/") ? new File(arg) : new File(MainActivity.cwd, arg);
        android.content.Context c = MainActivity.ctx;
        KeepAliveService.begin(c);
        Progres.mulai("Membangun APK", "Memulai", () -> build(arg));
        new Thread(() -> {
            try { run(proj); }
            catch (Throwable e) {
                out("Gagal: " + e.getMessage()); say("Gagal membangun: " + e.getMessage());
                Progres.selesai(false, "Gagal: " + e.getMessage());
            }
            busy = false;
            KeepAliveService.end(c);
        }).start();
    }

    private static String cariPola(String t, String pola) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(pola, java.util.regex.Pattern.MULTILINE).matcher(t);
        return m.find() ? m.group(1) : "";
    }

    private static String bersih(String s) {
        return s.replaceAll("[^A-Za-z0-9._-]", "_").replaceAll("_+", "_").replaceAll("^_|_$", "");
    }

    /** Nama berkas dari isi APK: namaAplikasi_vVersi (tanpa .apk), atau null bila APK tidak terbaca. */
    static String namaApk(File apk) {
        try {
            File aapt2 = new File(Env.prefix, "bin/aapt2");
            if (!aapt2.exists()) return null;
            ProcessBuilder pb = new ProcessBuilder(Env.wrap(aapt2.getPath(), "dump", "badging", apk.getPath())).redirectErrorStream(true);
            Env.apply(pb.environment());
            Process pr = pb.start();
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(pr.getInputStream()))) {
                String l;
                while ((l = r.readLine()) != null) sb.append(l).append('\n');
            }
            pr.waitFor();
            String t = sb.toString();
            String pkg = cariPola(t, "^package: name='([^']*)'");
            String ver = bersih(cariPola(t, "versionName='([^']*)'"));
            String kode = cariPola(t, "versionCode='([^']*)'");
            String nama = bersih(cariPola(t, "^application-label:'(.*)'$"));
            if (nama.isEmpty()) nama = bersih(pkg);
            if (nama.isEmpty()) return null;
            return ver.isEmpty() ? (kode.isEmpty() ? nama : nama + "_kode" + kode) : nama + "_v" + ver;
        } catch (Throwable e) { return null; }
    }

    /** Setelah bangun selesai: pilih APK yang dibuka di dialog hasil (universal atau arm64 bila ada, kalau tidak yang terbesar). */
    static void pilihHasil() {
        java.util.List<File> fs = new java.util.ArrayList<>();
        for (String h : new java.util.ArrayList<>(Progres.semua)) {
            File f = new File(h);
            if (h.toLowerCase().endsWith(".apk") && f.isFile()) fs.add(f);
        }
        if (fs.isEmpty()) return;
        File pilih = null;
        for (File f : fs) if (f.getName().toLowerCase().contains("universal")) { pilih = f; break; }
        if (pilih == null) for (File f : fs) if (f.getName().toLowerCase().contains("arm64")) { pilih = f; break; }
        if (pilih == null) { pilih = fs.get(0); for (File f : fs) if (f.length() > pilih.length()) pilih = f; }
        Progres.hasil = pilih.getPath();
        if (fs.size() > 1) out("Ada " + fs.size() + " APK hasil, semuanya di folder Download. Yang dibuka: " + pilih.getName());
    }

    /**
     * Setelah Gradle selesai: tandatangani ulang semua APK hasil (proyek apa pun: beberapa flavor, pecahan ABI,
     * release tanpa tanda tangan) dengan tanda tangan pribadi yang dipilih. Yang dibuka di dialog hasil adalah
     * APK universal atau arm64 bila ada, kalau tidak yang terbesar.
     */
    static void tandatanganiGradle(String ttd) {
        try {
            java.util.List<String> daftar = new java.util.ArrayList<>(Progres.semua);
            if (daftar.isEmpty() && Progres.hasil != null && !Progres.hasil.isEmpty()) daftar.add(Progres.hasil);
            java.util.Properties pr = Ks.muat(ttd);
            java.util.List<File> berhasil = new java.util.ArrayList<>();
            for (String h : daftar) {
                if (!h.toLowerCase().endsWith(".apk") || !new File(h).isFile()) continue;
                File in = new File(h);
                File hasil = new File(in.getParentFile(), in.getName().replaceAll("(?i)\\.apk$", "") + "-" + ttd + ".apk");
                out("Menandatangani ulang " + in.getName() + " dengan tanda tangan pribadi " + ttd);
                int r = -1;
                // Alat bawaan aplikasi (tools.jar) hanya ada bila paket toolchain terpasang. Proyek Gradle tidak
                // membutuhkannya, jadi bila tidak ada atau gagal, pakai apksigner yang dipasang oleh "siap".
                if (share("tools.jar").exists()) {
                    try { r = tool("sign", Ks.p12(ttd).getPath(), pr.getProperty("sandi"), pr.getProperty("alias"), in.getPath(), hasil.getPath(), "24"); }
                    catch (Throwable e) { out("Alat tanda tangan bawaan tidak bisa dipakai: " + e.getMessage()); }
                }
                if (r != 0) {
                    out("Menandatangani dengan apksigner");
                    r = apksigner(in, hasil, Ks.p12(ttd).getPath(), pr.getProperty("sandi"), pr.getProperty("alias"));
                }
                new File(hasil.getPath() + ".idsig").delete();
                if (r != 0) { out("Tanda tangan ulang gagal untuk " + in.getName() + ". APK dengan tanda tangan proyek tetap ada di " + in.getPath()); continue; }
                out("Berhasil: " + hasil.getPath() + " (" + hasil.length() / 1024 + " KB)");
                berhasil.add(hasil);
            }
            if (berhasil.isEmpty()) { out("Tanda tangan ulang dilewati atau gagal: tidak ada APK yang berhasil ditandatangani."); return; }
            File pilih = null;
            for (File f : berhasil) if (f.getName().toLowerCase().contains("universal")) { pilih = f; break; }
            if (pilih == null) for (File f : berhasil) if (f.getName().toLowerCase().contains("arm64")) { pilih = f; break; }
            if (pilih == null) { pilih = berhasil.get(0); for (File f : berhasil) if (f.length() > pilih.length()) pilih = f; }
            Progres.hasil = pilih.getPath();
            if (berhasil.size() > 1) out("Ada " + berhasil.size() + " APK hasil, semuanya di folder Download. Yang dibuka: " + pilih.getName());
        } catch (Throwable e) {
            out("Tanda tangan ulang gagal: " + e.getMessage() + ". APK dengan tanda tangan proyek tetap ada.");
        }
    }

    /** Tandatangani APK memakai apksigner (paket Termux, dipasang oleh perintah siap). */
    static int apksigner(File in, File out, String p12, String sandi, String alias) throws Exception {
        String k = "pass:" + sandi;
        String cmd = "apksigner sign --ks " + MainActivity.kutip(p12) + " --ks-pass " + MainActivity.kutip(k)
            + " --key-pass " + MainActivity.kutip(k) + " --ks-key-alias " + MainActivity.kutip(alias)
            + " --out " + MainActivity.kutip(out.getPath()) + " " + MainActivity.kutip(in.getPath());
        return exec(Env.home, Env.shell(), "-c", cmd);
    }

    static void need(boolean ok, String msg) throws Exception { if (!ok) throw new Exception(msg); }

    static void run(File p) throws Exception {
        File man = new File(p, "AndroidManifest.xml"), src = new File(p, "src"), res = new File(p, "res");
        File aapt2 = new File(Env.prefix, "bin/aapt2"), aj = share("android.jar");
        need(man.exists(), "AndroidManifest.xml tidak ada di " + p.getPath());
        need(src.isDirectory(), "Folder src tidak ada di " + p.getPath());
        String ttd = Ks.aktif();
        File ks; String ksSandi, ksAlias;
        if (ttd.equals("bawaan")) {
            ks = share("debug.p12"); ksSandi = "android"; ksAlias = "novan";
        } else {
            ks = Ks.p12(ttd);
            java.util.Properties pr = Ks.muat(ttd);
            ksSandi = pr.getProperty("sandi"); ksAlias = pr.getProperty("alias");
        }
        need(aapt2.exists() && aj.exists() && share("tools.jar").exists() && ks.exists(),
            ttd.equals("bawaan") ? "Alat membangun APK belum lengkap. Ketik: siap, tunggu sampai selesai, lalu tekan Bangun APK lagi."
                : "Tanda tangan pribadi " + ttd + " tidak ditemukan. Ketik daftar-ttd.");
        out("Tanda tangan: " + (ttd.equals("bawaan") ? "bawaan (debug)" : ttd + " (pribadi)"));
        aapt2.setExecutable(true, false);
        File b = new File(p, "build");
        del(b);
        File gen = new File(b, "gen"), cls = new File(b, "classes"), dex = new File(b, "dex");
        gen.mkdirs(); cls.mkdirs(); dex.mkdirs();
        File manUse = man;
        boolean penjagaAktif = false;
        if (!ttd.equals("bawaan") && Penjaga.aktif()) {
            try {
                String manifestXml = Ks.readAll(man);
                String paket = Penjaga.paket(manifestXml);
                String sidikJari = Ks.muat(ttd).getProperty("sidikJari");
                if (paket == null) {
                    out("Penjaga tanda tangan dilewati: atribut package tidak ditemukan di AndroidManifest.xml.");
                } else if (sidikJari == null || sidikJari.isEmpty()) {
                    out("Penjaga tanda tangan dilewati: sidik jari tanda tangan " + ttd + " tidak ditemukan.");
                } else {
                    Penjaga.pasang(src, paket, sidikJari);
                    manUse = new File(b, "AndroidManifest.xml");
                    Ks.write(manUse, Penjaga.sisipkanManifest(manifestXml, paket));
                    penjagaAktif = true;
                }
            } catch (Throwable e) {
                out("Penjaga tanda tangan dilewati: " + e.getMessage());
            }
        }
        out("Penjaga tanda tangan: " + (penjagaAktif ? "aktif (paket terkunci ke sidik jari " + ttd + ")"
            : ttd.equals("bawaan") ? "nonaktif (hanya berlaku dengan tanda tangan pribadi)" : "nonaktif"));
        String base = new File(b, "base.apk").getPath();
        Progres.tahap(0, 15, "Langkah 1 dari 6: sumber daya");
        Progres.perkiraan(6);
        out("1 dari 6: sumber daya"); say("Langkah 1 dari 6, sumber daya");
        String[] link;
        if (res.isDirectory()) {
            need(exec(p, aapt2.getPath(), "compile", "--dir", res.getPath(), "-o", new File(b, "res.zip").getPath()) == 0, "aapt2 compile gagal");
            link = new String[]{aapt2.getPath(), "link", "-o", base, "-I", aj.getPath(), "--manifest", manUse.getPath(), "--java", gen.getPath(),
                "--min-sdk-version", "24", "--target-sdk-version", "34", "--auto-add-overlay", new File(b, "res.zip").getPath()};
        } else {
            link = new String[]{aapt2.getPath(), "link", "-o", base, "-I", aj.getPath(), "--manifest", manUse.getPath(), "--java", gen.getPath(),
                "--min-sdk-version", "24", "--target-sdk-version", "34"};
        }
        need(exec(p, link) == 0, "aapt2 link gagal");
        Progres.tahap(15, 55, "Langkah 2 dari 6: kompilasi Java");
        Progres.perkiraan(25);
        out("2 dari 6: kompilasi Java"); say("Langkah 2 dari 6, kompilasi Java");
        need(tool("javac", "-bootclasspath", aj.getPath(), "-source", "1.8", "-target", "1.8", "-proc:none", "-nowarn",
            "-d", cls.getPath(), src.getPath(), gen.getPath()) == 0, "Kompilasi Java gagal");
        Progres.tahap(55, 62, "Langkah 3 dari 6: membuat jar");
        Progres.perkiraan(3);
        out("3 dari 6: jar"); say("Langkah 3 dari 6");
        String jar = new File(b, "classes.jar").getPath();
        need(tool("jar", cls.getPath(), jar) == 0, "Membuat jar gagal");
        Progres.tahap(62, 80, "Langkah 4 dari 6: dex");
        Progres.perkiraan(12);
        out("4 dari 6: dex"); say("Langkah 4 dari 6, dex");
        need(tool("d8", aj.getPath(), jar, dex.getPath()) == 0, "d8 gagal");
        Progres.tahap(80, 90, "Langkah 5 dari 6: merakit APK");
        Progres.perkiraan(5);
        out("5 dari 6: rakit APK"); say("Langkah 5 dari 6, rakit");
        File assets = new File(p, "assets");
        String unsigned = new File(b, "unsigned.apk").getPath();
        need(tool("pack", base, dex.getPath(), assets.isDirectory() ? assets.getPath() : "-", unsigned) == 0, "Merakit APK gagal");
        Progres.tahap(90, 99, "Langkah 6 dari 6: tanda tangan");
        Progres.perkiraan(4);
        out("6 dari 6: tanda tangan"); say("Langkah 6 dari 6, tanda tangan");
        File fin = new File(b, p.getName() + ".apk");
        need(tool("sign", ks.getPath(), ksSandi, ksAlias, unsigned, fin.getPath(), "24") == 0, "Tanda tangan gagal");
        String nmApk = namaApk(fin);
        if (nmApk != null) { File fin2 = new File(b, nmApk + ".apk"); if (fin.renameTo(fin2)) fin = fin2; }
        out("Berhasil: " + fin.getPath() + " (" + fin.length() / 1024 + " KB)");
        Progres.hasil = fin.getPath();
        try {
            File dl = new File(Environment.getExternalStorageDirectory(), "Download");
            if (dl.isDirectory() && dl.canWrite()) {
                File cp = new File(dl, fin.getName());
                try (InputStream in = new FileInputStream(fin); OutputStream o = new FileOutputStream(cp)) { Pkg.copy(in, o); }
                out("Salinan: " + cp.getPath());
                Progres.hasil = cp.getPath();
            }
        } catch (Throwable e) { }
        final long kb = fin.length() / 1024;
        Bersih.sesudahSederhana(b, Progres.hasil);
        say("Berhasil membangun APK " + fin.getName());
        Progres.selesai(true, "APK berhasil dibuat: " + fin.getName() + ", " + kb + " KB."
            + (Progres.hasil.isEmpty() ? "" : " Salinan: " + Progres.hasil));
        KeepAliveService.selesai(MainActivity.ctx, "APK selesai: " + fin.getName());
    }
}
