package novan.terminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Bongkar APK jadi zip dengan format yang sama dengan Apktool M: zip rata bernama NAMA_vVERSI_src.zip (versi aplikasi dicantumkan) di folder Download,
 * berisi apktool.json, smali, res, assets, lib, original/ (termasuk original/signature.data). Zip itu bisa dibangun
 * lagi di sini (tombol Bangun APK atau Bagikan, alur proyek apktool) dan di Apktool M.
 */
class Bongkar {

    /** Opsi: tanpa kode (apktool -s) dan tanpa sumber daya (apktool -r). */
    static final String TANPA_KODE = "--tanpa-kode", TANPA_RES = "--tanpa-res";

    static final String SKRIP = """
#!/data/data/com.termux/files/usr/bin/bash
# bongkar-apk <berkas.apk> [--tanpa-kode] [--tanpa-res]
# Hasil: NAMA_vVERSI_src.zip di Download (versi aplikasi ikut dicantumkan), berformat sama dengan Apktool M (zip rata, apktool.json, original/signature.data).
APK=""
OPT=""
for a in "$@"; do
  case "$a" in
    --tanpa-kode) OPT="$OPT -s" ;;
    --tanpa-res) OPT="$OPT -r" ;;
    *) if [ -z "$APK" ]; then APK="$a"; fi ;;
  esac
done
if [ -n "$APK" ]; then
  case "$APK" in /*) ;; *) APK="$PWD/$APK" ;; esac
fi
cd "$HOME"
echo "@@P 0 3 Memeriksa berkas APK"
if [ -z "$APK" ]; then
  APK=$(ls -t /sdcard/Download/*.apk 2>/dev/null | head -1)
  if [ -z "$APK" ]; then echo "Tulis lokasi APK: bongkar-apk <berkas.apk>, atau taruh APK di folder Download"; exit 2; fi
  echo "Memakai APK terbaru di Download: $APK"
fi
if [ ! -f "$APK" ]; then echo "Berkas tidak ditemukan: $APK"; exit 2; fi
if ! unzip -l "$APK" 2>/dev/null | grep -q 'AndroidManifest.xml'; then
  echo "Bukan APK yang sah (tidak ada AndroidManifest.xml di dalamnya): $APK"; exit 2
fi
base=$(basename "$APK")
base="${base%.[aA][pP][kK]}"
if [ -z "$base" ]; then base="apk"; fi
nama=$(printf '%s' "$base" | tr -c 'A-Za-z0-9_.-' '_')
echo "@@P 3 10 Menyiapkan apktool"
if ! command -v apktool >/dev/null 2>&1; then
  pkg install -y apktool || { echo "Gagal memasang apktool"; exit 2; }
fi
if ! command -v zip >/dev/null 2>&1; then
  pkg install -y zip || { echo "Gagal memasang zip"; exit 2; }
fi
if ! command -v python3 >/dev/null 2>&1; then
  pkg install -y python || { echo "Gagal memasang python"; exit 2; }
fi
mkdir -p "$HOME/bongkar"
out="$HOME/bongkar/$nama"
rm -rf "$out"
echo "Membongkar $APK"
echo "@@P 10 15 Memulai apktool"
apktool d -f $OPT -o "$out" "$APK" 2>&1 | while IFS= read -r l; do
  case "$l" in
    *"Loading resource table"*) echo "@@P 15 25 Membaca tabel sumber daya" ;;
    *"Decoding AndroidManifest"*) echo "@@P 25 30 Membongkar AndroidManifest" ;;
    *"Decoding file-resources"*) echo "@@P 30 45 Membongkar sumber daya" ;;
    *"Decoding values"*) echo "@@P 45 55 Membongkar nilai sumber daya" ;;
    *"Baksmaling"*) echo "@@P 55 85 Membongkar kode (smali)" ;;
    *"Copying assets"*|*"Copying raw"*|*"Copying unknown"*|*"Copying original"*|*"Copying lib"*) echo "@@P 85 92 Menyalin berkas lain" ;;
  esac
  echo "$l"
done
rc=${PIPESTATUS[0]}
if [ "$rc" != "0" ]; then echo "apktool gagal membongkar, kode $rc. Periksa log di atas."; exit 1; fi
if [ ! -f "$out/apktool.yml" ]; then echo "Hasil bongkar tidak lengkap (apktool.yml tidak ada)"; exit 1; fi
echo "@@P 92 95 Mencantumkan versi aplikasi"
vn=$(sed -n "s/^ *versionName: *//p" "$out/apktool.yml" | head -1 | tr -d "'" | tr -d '"' | tr -d '[:cntrl:]')
vc=$(sed -n "s/^ *versionCode: *//p" "$out/apktool.yml" | head -1 | tr -d "'" | tr -d '"' | tr -d '[:cntrl:]')
vers=$(printf '%s' "$vn" | tr -c 'A-Za-z0-9_.-' '_')
vers="${vers#[vV]}"
if [ -z "$vers" ] && [ -n "$vc" ]; then vers="kode$(printf '%s' "$vc" | tr -c 'A-Za-z0-9_.-' '_')"; fi
if [ -n "$vers" ]; then
  versu=$(printf '%s' "$vers" | tr . _)
  case "$base" in
    *"$vers"*|*"$versu"*) echo "Nama berkas sudah memuat versi $vers" ;;
    *)
      case "$vers" in kode*) lbl="_$vers" ;; *) lbl="_v$vers" ;; esac
      base="${base}${lbl}"
      nama="${nama}${lbl}"
      out2="$HOME/bongkar/$nama"
      rm -rf "$out2"
      mv "$out" "$out2" && out="$out2"
      echo "Versi aplikasi: ${vn:-kode $vc} (versionCode ${vc:-tidak ada})" ;;
  esac
else
  echo "Peringatan: versi aplikasi tidak terbaca dari APK ini, nama hasil tanpa versi"
fi
echo "@@P 92 95 Menyusun format Apktool M"
python3 -I - "$out" "$APK" "$base" <<'PYEOF' || { echo "Gagal menyusun format Apktool M"; exit 1; }
import json, os, struct, sys

out, apk, base = sys.argv[1], sys.argv[2], sys.argv[3]
NL = chr(10)


def unq(v):
    v = v.strip()
    if v in ('null', '~', ''):
        return None
    if len(v) >= 2 and v[0] == "'" and v[-1] == "'":
        return v[1:-1].replace("''", "'")
    if len(v) >= 2 and v[0] == '"' and v[-1] == '"':
        return v[1:-1]
    return v


def kv(s):
    if s[0] == "'":
        j = 1
        while j < len(s):
            if s[j] == "'":
                if j + 1 < len(s) and s[j + 1] == "'":
                    j += 2
                    continue
                break
            j += 1
        return s[1:j].replace("''", "'"), s[j + 1:].partition(':')[2]
    k, _, v = s.partition(':')
    return k.strip(), v


top = {}
cur = None
sub = None
for raw in open(os.path.join(out, 'apktool.yml'), encoding='utf-8').read().split(NL):
    if not raw.strip() or raw.lstrip().startswith('#'):
        continue
    ind = len(raw) - len(raw.lstrip(' '))
    s = raw.strip()
    if s.startswith('- '):
        item = unq(s[2:])
        if cur is None:
            continue
        if sub is not None and isinstance(top[cur], dict):
            top[cur].setdefault(sub, []).append(item)
        else:
            if not isinstance(top[cur], list):
                top[cur] = []
            top[cur].append(item)
    elif ind == 0:
        k, v = kv(s)
        sub = None
        if v.strip() == '':
            top[k] = {}
            cur = k
        else:
            top[k] = unq(v)
            cur = None
    else:
        if cur is None or not isinstance(top[cur], dict):
            continue
        k, v = kv(s)
        if v.strip() == '':
            sub = k
        else:
            top[cur][k] = unq(v)
            sub = None


def blok(k):
    x = top.get(k)
    return x if isinstance(x, dict) else {}


def b(v):
    return str(v).lower() == 'true'


def teks(v):
    return None if v is None else str(v)


sdk, pk, vi, uf = blok('sdkInfo'), blok('packageInfo'), blok('versionInfo'), blok('usesFramework')
dnc = top.get('doNotCompress')
sdkj = {'minSdkVersion': teks(sdk.get('minSdkVersion')), 'targetSdkVersion': teks(sdk.get('targetSdkVersion'))}
if sdk.get('maxSdkVersion'):
    sdkj['maxSdkVersion'] = teks(sdk['maxSdkVersion'])
if sdkj['minSdkVersion'] is None:
    del sdkj['minSdkVersion']
if sdkj['targetSdkVersion'] is None:
    del sdkj['targetSdkVersion']
ids = []
for x in uf.get('ids') or ['1']:
    try:
        ids.append(int(x))
    except ValueError:
        pass
j = {
    'apkFileName': base + '_src.apk',
    'PackageInfo': {'forcedPackageId': teks(pk.get('forcedPackageId')) or '127',
                    'renameManifestPackage': pk.get('renameManifestPackage')},
    'doNotCompress': list(dnc) if isinstance(dnc, list) else [],
    'compressionType': b(top.get('compressionType', top.get('resourcesAreCompressed', 'false'))),
    'sparseResources': b(top.get('sparseResources')),
    'version': '2.4.0-261013',
    'sharedLibrary': b(top.get('sharedLibrary')),
    'VersionInfo': {'versionName': teks(vi.get('versionName')), 'versionCode': teks(vi.get('versionCode'))},
    'UsesFramework': {'ids': 'IDSPH', 'tag': uf.get('tag')},
    'unknownFiles': dict(blok('unknownFiles')),
    'apkFilePath': apk,
    'compactEntries': False,
    'isFrameworkApk': b(top.get('isFrameworkApk')),
    'sdkInfo': sdkj,
}
txt = json.dumps(j, indent=2, ensure_ascii=False).replace('"IDSPH"', '[' + ', '.join(str(i) for i in ids) + ']')
with open(os.path.join(out, 'apktool.json'), 'w', encoding='utf-8') as f:
    f.write(txt)
os.remove(os.path.join(out, 'apktool.yml'))


def blok_tanda_tangan(path):
    # APK Signing Block (v2/v3): terletak tepat sebelum central directory, diakhiri teks "APK Sig Block 42".
    try:
        with open(path, 'rb') as f:
            f.seek(0, 2)
            n = f.tell()
            f.seek(max(0, n - 70000))
            tail = f.read()
            i = tail.rfind(bytes([0x50, 0x4b, 5, 6]))
            if i < 0:
                return None
            cd = struct.unpack('<I', tail[i + 16:i + 20])[0]
            if cd < 32:
                return None
            f.seek(cd - 24)
            ujung = f.read(24)
            if ujung[8:] != b'APK Sig Block 42':
                return None
            size = struct.unpack('<Q', ujung[:8])[0]
            mulai = cd - size - 8
            if mulai < 0:
                return None
            f.seek(mulai)
            data = f.read(cd - mulai)
            if struct.unpack('<Q', data[:8])[0] != size:
                return None
            return data
    except Exception:
        return None


sig = blok_tanda_tangan(apk)
if sig:
    os.makedirs(os.path.join(out, 'original'), exist_ok=True)
    with open(os.path.join(out, 'original', 'signature.data'), 'wb') as f:
        f.write(sig)
    print('Blok tanda tangan asli disimpan: original/signature.data (' + str(len(sig)) + ' byte)')
else:
    print('APK ini tanpa blok tanda tangan v2/v3, original/signature.data dilewati')
PYEOF
if [ ! -f "$out/apktool.json" ]; then echo "apktool.json tidak terbentuk"; exit 1; fi
echo "@@P 95 97 Mengemas hasil jadi zip"
z="$TMPDIR/$nama-bongkar.zip"
rm -f "$z"
( cd "$out" && zip -qr "$z" . ) || { echo "Gagal membuat zip"; exit 1; }
echo "@@P 97 99 Menyalin zip ke folder Download"
mkdir -p /sdcard/Download
hasil="/sdcard/Download/${base}_src.zip"
rm -f "$hasil"
cp "$z" "$hasil" || { echo "Gagal menyalin ke Download. Periksa izin penyimpanan."; exit 1; }
rm -f "$z"
echo "Folder hasil bongkar juga ada di: $out"
echo "Salinan: $hasil"
echo "Selesai membongkar APK. Format sama dengan Apktool M, jadi zip ini bisa dibangun di sini (bagikan atau Bangun APK) dan di Apktool M."
exit 0
""";

    /** Menulis skrip bongkar-apk ke usr/bin bila belum ada atau isinya beda. Aman dipanggil berkali-kali. */
    static void pasang() {
        try {
            File bin = new File(Env.prefix, "bin");
            if (!bin.isDirectory()) return; // bootstrap belum ada; dipanggil lagi nanti
            File f = new File(bin, "bongkar-apk");
            if (f.exists()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                try (InputStream in = new FileInputStream(f)) { Pkg.copy(in, bo); }
                if (bo.toString("UTF-8").equals(SKRIP)) { f.setExecutable(true, false); return; }
            }
            Builder.write(f, SKRIP);
            f.setExecutable(true, false);
        } catch (Throwable e) { }
    }

    /** Perintah yang diketik: bongkar-apk [lokasi.apk] [--tanpa-kode] [--tanpa-res]. */
    static void perintah(Activity a, String arg) {
        String lokasi = "";
        StringBuilder opsi = new StringBuilder();
        for (String t : arg.trim().split("\\s+")) {
            if (t.isEmpty()) continue;
            if (t.equals(TANPA_KODE) || t.equals(TANPA_RES)) opsi.append(' ').append(t);
            else if (lokasi.isEmpty()) lokasi = t.replaceAll("^['\"]|['\"]$", "");
            else lokasi += " " + t.replaceAll("^['\"]|['\"]$", ""); // nama berkas yang berisi spasi
        }
        if (lokasi.isEmpty()) { pilih(a); return; }
        if (lokasi.startsWith("~")) lokasi = Env.home.getPath() + lokasi.substring(1);
        File f = lokasi.startsWith("/") ? new File(lokasi) : new File(MainActivity.cwd, lokasi);
        if (!f.isFile()) {
            MainActivity.add("Berkas tidak ditemukan: " + f.getPath());
            MainActivity.say("Berkas APK tidak ditemukan");
            return;
        }
        if (!f.getName().toLowerCase().endsWith(".apk")) {
            MainActivity.add("Harus berkas .apk: " + f.getName());
            MainActivity.say("Harus berkas APK");
            return;
        }
        jalankan(f, opsi.toString());
    }

    static void jalankan(File apk, String opsi) {
        MainActivity.say("Membongkar " + apk.getName());
        MainActivity.run("bongkar-apk " + MainActivity.kutip(apk.getPath()) + opsi);
    }

    /** Menu lainnya dan perintah tanpa lokasi: pilih sumber APK, yaitu folder Download atau aplikasi yang sudah terpasang. */
    static void pilih(final Activity a) {
        new AlertDialog.Builder(a).setTitle("Bongkar APK dari mana?")
            .setItems(new String[]{"Aplikasi yang sudah terpasang di HP", "Cari berkas APK di penyimpanan (semua folder)"}, (d, i) -> {
                if (i == 0) pilihTerpasang(a, false); else pilihBerkas(a);
            })
            .setNegativeButton("Batal", (d, w) -> MainActivity.say("Dibatalkan"))
            .show();
    }

    // ---------------------------------------------------------------- aplikasi terpasang

    private static class Aplikasi {
        String label, paket; File apk; boolean sistem, split;
        @Override public String toString() { return label + "\n" + paket + (split ? " (split APK, hanya base)" : ""); }
    }

    /** Daftar aplikasi berikon peluncur (cukup lewat queries di manifest, tanpa izin QUERY_ALL_PACKAGES). */
    private static List<Aplikasi> daftarTerpasang(Activity a) {
        PackageManager pm = a.getPackageManager();
        Intent mi = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ri = pm.queryIntentActivities(mi, 0);
        java.util.HashSet<String> lihat = new java.util.HashSet<>();
        ArrayList<Aplikasi> r = new ArrayList<>();
        for (ResolveInfo x : ri) {
            ApplicationInfo ai = x.activityInfo.applicationInfo;
            if (ai == null || ai.sourceDir == null || !lihat.add(ai.packageName)) continue;
            if (ai.packageName.equals(a.getPackageName())) continue;
            Aplikasi ap = new Aplikasi();
            ap.paket = ai.packageName;
            ap.label = String.valueOf(pm.getApplicationLabel(ai));
            ap.apk = new File(ai.sourceDir);
            ap.sistem = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
            ap.split = ai.splitSourceDirs != null && ai.splitSourceDirs.length > 0;
            r.add(ap);
        }
        java.util.Collections.sort(r, (p, q) -> p.label.compareToIgnoreCase(q.label));
        return r;
    }

    /** Dialog daftar aplikasi dengan kolom cari. Aplikasi sistem disembunyikan kecuali diminta. */
    static void pilihTerpasang(final Activity a, final boolean denganSistem) {
        final ArrayList<Aplikasi> semua = new ArrayList<>();
        for (Aplikasi x : daftarTerpasang(a)) if (denganSistem || !x.sistem) semua.add(x);
        if (semua.isEmpty()) {
            MainActivity.add("Tidak ada aplikasi yang bisa ditampilkan.");
            MainActivity.say("Tidak ada aplikasi yang bisa ditampilkan");
            return;
        }
        final ArrayAdapter<Aplikasi> ad = new ArrayAdapter<>(a, android.R.layout.simple_list_item_1, new ArrayList<>(semua));
        LinearLayout l = new LinearLayout(a);
        l.setOrientation(LinearLayout.VERTICAL);
        final EditText cari = new EditText(a);
        cari.setHint("Cari nama aplikasi");
        cari.setSingleLine(true);
        cari.setContentDescription("Cari nama aplikasi");
        final ListView lv = new ListView(a);
        lv.setAdapter(ad);
        l.addView(cari);
        l.addView(lv, new LinearLayout.LayoutParams(-1, (int) (a.getResources().getDisplayMetrics().heightPixels * 0.55)));
        cari.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int b, int c, int d) { }
            @Override public void onTextChanged(CharSequence s, int b, int c, int d) { }
            @Override public void afterTextChanged(Editable e) {
                String k = e.toString().trim().toLowerCase();
                ad.clear();
                for (Aplikasi x : semua) if (k.isEmpty() || x.label.toLowerCase().contains(k) || x.paket.toLowerCase().contains(k)) ad.add(x);
            }
        });
        final AlertDialog dlg = new AlertDialog.Builder(a)
            .setTitle((denganSistem ? "Semua aplikasi" : "Aplikasi terpasang") + " (" + semua.size() + ")")
            .setView(l)
            .setNeutralButton(denganSistem ? "Sembunyikan aplikasi sistem" : "Tampilkan aplikasi sistem", (d, w) -> pilihTerpasang(a, !denganSistem))
            .setNegativeButton("Kembali", (d, w) -> pilih(a))
            .create();
        lv.setOnItemClickListener((p, v, i, id) -> {
            Aplikasi x = ad.getItem(i);
            dlg.dismiss();
            if (x != null) salinLaluPilih(a, x);
        });
        dlg.show();
    }

    /** base.apk milik aplikasi lain disalin dulu ke folder masuk, bernama <paket>.apk, supaya hasil zip bernama jelas. */
    private static void salinLaluPilih(final Activity a, final Aplikasi x) {
        if (MainActivity.novanBusy || Pkg.busy) {
            MainActivity.add("Masih ada proses berjalan. Tunggu sampai selesai, lalu pilih lagi.");
            MainActivity.say("Masih ada proses berjalan. Tunggu sampai selesai");
            return;
        }
        MainActivity.add("Menyalin APK " + x.label + " (" + x.paket + ")");
        MainActivity.say("Menyalin APK " + x.label + ", mohon tunggu");
        new Thread(() -> {
            try {
                File dir = new File(Env.home, "masuk");
                Builder.del(dir);
                dir.mkdirs();
                String nm = x.label.replaceAll("[/\\\\:*?\"<>|]", "_").trim();
                if (nm.isEmpty()) nm = x.paket;
                final File z = new File(dir, nm + ".apk");
                try (InputStream in = new FileInputStream(x.apk); OutputStream o = new FileOutputStream(z)) { Pkg.copy(in, o); }
                MainActivity.H.post(() -> {
                    if (x.split) MainActivity.add("Catatan: " + x.label + " memakai split APK. Hanya base.apk yang dibongkar, jadi hasil rakitannya mungkin tidak lengkap.");
                    cara(a, z);
                });
            } catch (Exception e) {
                MainActivity.H.post(() -> { MainActivity.add("Gagal menyalin APK: " + e.getMessage()); MainActivity.say("Gagal menyalin APK"); });
            }
        }).start();
    }

    // ---------------------------------------------------------------- penyimpanan (semua folder)

    static void pilihBerkas(final Activity a) {
        Jelajah.buka(a, "Pilih APK yang dibongkar", new String[]{".apk"}, false, f -> cara(a, f));
    }

    /** Pilihan apa yang dibongkar. Bawaan: semua tercentang (kode smali dan sumber daya), jadi cukup tekan Bongkar. */
    static void cara(final Activity a, final File apk) {
        final String[] item = {
            "Kode program (smali)",
            "Sumber daya (res, AndroidManifest.xml, resources.arsc)"};
        final boolean[] pilih = {true, true};
        new AlertDialog.Builder(a).setTitle("Bongkar " + apk.getName())
            .setMultiChoiceItems(item, pilih, (d, i, cek) -> pilih[i] = cek)
            .setPositiveButton("Bongkar", (d, w) -> {
                if (!pilih[0] && !pilih[1]) {
                    MainActivity.say("Pilih minimal satu, kode atau sumber daya");
                    cara(a, apk);
                    return;
                }
                String opsi = (pilih[0] ? "" : " " + TANPA_KODE) + (pilih[1] ? "" : " " + TANPA_RES);
                MainActivity.add("$ bongkar-apk " + apk.getName() + opsi);
                jalankan(apk, opsi);
            })
            .setNegativeButton("Kembali", (d, w) -> pilih(a))
            .show();
        MainActivity.say("Semua sudah tercentang. Tekan Bongkar untuk membongkar semuanya");
    }
}
