package novan.terminal;

import java.util.ArrayList;

/** Emulator layar VT100/xterm sederhana: kursor, hapus, gulir, layar alternatif. Warna diabaikan. */
public class Screen {
    int rows, cols, cx, cy, top, bot, sx, sy;
    char[][] g;
    boolean alt, wrapPending;
    char[][] saved;
    final ArrayList<String> scroll = new ArrayList<>();
    private int st; // 0 normal, 1 ESC, 2 CSI, 3 OSC, 4 ESC + (, ), #
    private final StringBuilder par = new StringBuilder();

    Screen(int r, int c) { rows = r; cols = c; g = blank(r, c); top = 0; bot = r - 1; }

    static char[][] blank(int r, int c) {
        char[][] a = new char[r][c];
        for (char[] x : a) java.util.Arrays.fill(x, ' ');
        return a;
    }

    synchronized void write(String s) {
        for (int i = 0; i < s.length(); i++) ch(s.charAt(i));
    }

    private void ch(char c) {
        switch (st) {
            case 1:
                st = 0;
                if (c == '[') { st = 2; par.setLength(0); }
                else if (c == ']') { st = 3; }
                else if (c == '(' || c == ')' || c == '#' || c == '%') st = 4;
                else if (c == 'M') { if (cy == top) scrollDown(1); else cy = Math.max(0, cy - 1); }
                else if (c == 'D') lf();
                else if (c == 'E') { cx = 0; lf(); }
                else if (c == '7') { sx = cx; sy = cy; }
                else if (c == '8') { cx = sx; cy = sy; }
                else if (c == 'c') { clearAll(); cx = cy = 0; }
                return;
            case 2:
                if (c >= 0x40 && c <= 0x7e) { st = 0; csi(c, par.toString()); }
                else par.append(c);
                return;
            case 3:
                if (c == 7 || c == 27) st = c == 27 ? 1 : 0;
                return;
            case 4: st = 0; return;
        }
        if (c == 27) { st = 1; return; }
        if (c == '\n' || c == 0x0B || c == 0x0C) { lf(); return; }
        if (c == '\r') { cx = 0; wrapPending = false; return; }
        if (c == '\b') { if (cx > 0) cx--; wrapPending = false; return; }
        if (c == '\t') { cx = Math.min(cols - 1, (cx / 8 + 1) * 8); return; }
        if (c < 32 || c == 127) return;
        if (wrapPending) { cx = 0; lf(); wrapPending = false; }
        g[cy][cx] = c;
        if (cx < cols - 1) cx++; else wrapPending = true;
    }

    private void lf() {
        if (cy == bot) scrollUp(1); else if (cy < rows - 1) cy++;
    }

    private void scrollUp(int n) {
        for (int k = 0; k < n; k++) {
            if (!alt && top == 0) {
                scroll.add(rowText(g[0]));
                if (scroll.size() > 2000) scroll.subList(0, 500).clear();
            }
            for (int r = top; r < bot; r++) g[r] = g[r + 1];
            g[bot] = new char[cols];
            java.util.Arrays.fill(g[bot], ' ');
        }
    }

    private void scrollDown(int n) {
        for (int k = 0; k < n; k++) {
            for (int r = bot; r > top; r--) g[r] = g[r - 1];
            g[top] = new char[cols];
            java.util.Arrays.fill(g[top], ' ');
        }
    }

    private static int[] nums(String p, int def) {
        if (p.startsWith("?") || p.startsWith(">")) p = p.substring(1);
        String[] a = p.isEmpty() ? new String[0] : p.split(";", -1);
        int[] r = new int[Math.max(1, a.length)];
        for (int i = 0; i < r.length; i++) {
            try { r[i] = i < a.length && !a[i].isEmpty() ? Integer.parseInt(a[i]) : def; } catch (Exception e) { r[i] = def; }
        }
        return r;
    }

    private void clearAll() { g = blank(rows, cols); }

    private void eraseRow(int r, int a, int b) { for (int i = Math.max(0, a); i <= Math.min(cols - 1, b); i++) g[r][i] = ' '; }

    private void csi(char c, String p) {
        wrapPending = false;
        boolean priv = p.startsWith("?");
        int[] n = nums(p, 0);
        int a = n[0] <= 0 ? 1 : n[0];
        switch (c) {
            case 'A': cy = Math.max(top, cy - a); break;
            case 'B': cy = Math.min(bot, cy + a); break;
            case 'C': cx = Math.min(cols - 1, cx + a); break;
            case 'D': cx = Math.max(0, cx - a); break;
            case 'E': cy = Math.min(bot, cy + a); cx = 0; break;
            case 'F': cy = Math.max(top, cy - a); cx = 0; break;
            case 'G': case '`': cx = Math.max(0, Math.min(cols - 1, a - 1)); break;
            case 'd': cy = Math.max(0, Math.min(rows - 1, a - 1)); break;
            case 'H': case 'f': {
                int[] q = nums(p, 1);
                cy = Math.max(0, Math.min(rows - 1, (q[0] <= 0 ? 1 : q[0]) - 1));
                cx = Math.max(0, Math.min(cols - 1, (q.length > 1 ? (q[1] <= 0 ? 1 : q[1]) : 1) - 1));
                break;
            }
            case 'J':
                if (n[0] == 0) { eraseRow(cy, cx, cols - 1); for (int r = cy + 1; r < rows; r++) eraseRow(r, 0, cols - 1); }
                else if (n[0] == 1) { for (int r = 0; r < cy; r++) eraseRow(r, 0, cols - 1); eraseRow(cy, 0, cx); }
                else clearAll();
                break;
            case 'K':
                if (n[0] == 0) eraseRow(cy, cx, cols - 1);
                else if (n[0] == 1) eraseRow(cy, 0, cx);
                else eraseRow(cy, 0, cols - 1);
                break;
            case 'L': if (cy >= top && cy <= bot) { int t = top; top = cy; scrollDown(a); top = t; } break;
            case 'M': if (cy >= top && cy <= bot) { int t = top; top = cy; scrollUp(a); top = t; } break;
            case 'P': { char[] row = g[cy]; for (int i = cx; i < cols; i++) row[i] = i + a < cols ? row[i + a] : ' '; break; }
            case '@': { char[] row = g[cy]; for (int i = cols - 1; i >= cx; i--) row[i] = i - a >= cx ? row[i - a] : ' '; break; }
            case 'X': eraseRow(cy, cx, cx + a - 1); break;
            case 'S': scrollUp(a); break;
            case 'T': scrollDown(a); break;
            case 'r': {
                int[] q = nums(p, 0);
                int t = q[0] <= 0 ? 1 : q[0], b = q.length > 1 && q[1] > 0 ? q[1] : rows;
                if (t < b && b <= rows) { top = t - 1; bot = b - 1; cx = 0; cy = top; }
                break;
            }
            case 's': sx = cx; sy = cy; break;
            case 'u': cx = sx; cy = sy; break;
            case 'h': case 'l':
                if (priv) for (int v : n) if (v == 1049 || v == 1047 || v == 47) setAlt(c == 'h');
                break;
            default: break; // m (warna) dan lainnya diabaikan
        }
    }

    private void setAlt(boolean on) {
        if (on == alt) return;
        if (on) { saved = g; g = blank(rows, cols); alt = true; cx = cy = 0; top = 0; bot = rows - 1; }
        else { if (saved != null) g = saved; saved = null; alt = false; top = 0; bot = rows - 1; }
    }

    static String rowText(char[] r) {
        int e = r.length;
        while (e > 0 && r[e - 1] == ' ') e--;
        return new String(r, 0, e);
    }

    /** Isi layar saat ini tanpa baris kosong di ujung bawah. */
    synchronized ArrayList<String> snapshot() {
        ArrayList<String> l = new ArrayList<>();
        for (char[] r : g) l.add(rowText(r));
        while (!l.isEmpty() && l.get(l.size() - 1).isEmpty()) l.remove(l.size() - 1);
        return l;
    }

    synchronized String cursorLine() { return rowText(g[cy]); }
}
