package novan.terminal;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Membaca pertanyaan dari perintah yang menunggu jawaban, lalu menyusun pilihan jawaban
 * yang tinggal ditekan di dialog, supaya pengguna tidak perlu mengetik.
 * Dikenali: [y/N], (yes/no), [a/b/c], menu bernomor, "tekan Enter", dan permintaan sandi.
 * Kelas ini tidak memakai Android sehingga mudah diuji.
 */
class Tanya {
    static final String KETIK = "\u0001ketik";
    static final String TUTUP = "\u0001tutup";

    final List<String> label = new ArrayList<>();
    final List<String> kirim = new ArrayList<>();
    boolean sandi;

    // Kelompok pilihan di ujung baris, misalnya [y/N] atau (yes/no/all). Huruf pertama harus huruf, bukan angka.
    static final Pattern P_GRUP = Pattern.compile(
        "[\\[(]\\s*([A-Za-z][A-Za-z0-9]{0,5}(?:\\s*/\\s*[A-Za-z][A-Za-z0-9]{0,5}){1,5})\\s*[\\])]\\s*[?:>]?\\s*$");
    static final Pattern P_MENU = Pattern.compile("^\\s*[\\[(]?(\\d{1,2})[\\]).:]\\s+(\\S.*)$");
    static final Pattern P_SANDI = Pattern.compile("(?i)(password|passphrase|kata sandi|\\bsandi\\b)");
    static final Pattern P_TEKAN = Pattern.compile("(?i)(press\\s+(enter|return|any key)|hit enter|tekan\\s+(enter|sembarang|tombol apa))");
    static final Pattern P_NOMOR = Pattern.compile(
        "(?i)(choice|choose|select|enter (a |the )?(number|option)|pilih|nomor|[\\[(]\\d+\\s*-\\s*\\d+[\\])])");
    static final Pattern P_KATA = Pattern.compile(
        "(?i)(continue\\s*\\?|proceed\\s*\\?|are you sure|do you want to|would you like|overwrite|\\by/n\\b|yes/no|lanjutkan\\s*\\?|apakah)");

    static final java.util.Set<String> KATA_JAWAB = new java.util.HashSet<>(java.util.Arrays.asList(
        "skip", "quit", "cancel", "abort", "retry", "ignore", "none", "done", "next", "back"));

    /** Kelompok pilihan yang sah di ujung teks, atau null. Tiap pilihan pendek (maksimal 3 huruf) atau kata jawaban umum. */
    static Matcher grup(String s) {
        Matcher g = P_GRUP.matcher(s);
        if (!g.find()) return null;
        for (String x : g.group(1).split("\\s*/\\s*"))
            if (x.length() > 3 && !KATA_JAWAB.contains(x.toLowerCase())) return null;
        return g;
    }

    /** True bila teks (baris yang berhenti tanpa akhir baris) terlihat seperti pertanyaan yang menunggu jawaban. */
    static boolean mirip(String teks) {
        if (teks == null) return false;
        String s = teks.trim();
        if (s.isEmpty() || s.length() > 250) return false;
        if (grup(s) != null) return true;
        if (P_TEKAN.matcher(s).find()) return true;
        if (P_SANDI.matcher(s).find() && (s.endsWith(":") || s.endsWith("?"))) return true;
        if (P_NOMOR.matcher(s).find() && (s.endsWith(":") || s.endsWith("?") || s.endsWith(">"))) return true;
        if (P_KATA.matcher(s).find()) return true;
        return s.endsWith("?");
    }

    /** Baris terakhir yang tidak kosong. */
    static String barisAkhir(String teks) {
        if (teks == null) return "";
        String[] b = teks.split("\n");
        for (int i = b.length - 1; i >= 0; i--) if (!b[i].trim().isEmpty()) return b[i].trim();
        return "";
    }

    private static String nama(String tk) {
        switch (tk.toLowerCase()) {
            case "y": return "Ya (y)";
            case "yes": return "Ya (yes)";
            case "n": return "Tidak (n)";
            case "no": return "Tidak (no)";
            case "a": case "all": return "Semua (" + tk.toLowerCase() + ")";
            case "q": case "quit": return "Keluar (" + tk.toLowerCase() + ")";
            case "s": case "skip": return "Lewati (" + tk.toLowerCase() + ")";
            case "c": case "cancel": return "Batal (" + tk.toLowerCase() + ")";
            default: return tk;
        }
    }

    private void tambah(String l, String k) {
        for (String x : kirim) if (x.equals(k)) return;
        label.add(l);
        kirim.add(k);
    }

    /**
     * Susun pilihan jawaban.
     * @param pertanyaan baris pertanyaan (tanpa akhir baris)
     * @param konteks keluaran sebelumnya, dipakai untuk membaca menu bernomor
     */
    static Tanya susun(String pertanyaan, String konteks) {
        Tanya t = new Tanya();
        String p = pertanyaan == null ? "" : pertanyaan.trim();

        if (P_SANDI.matcher(p).find() && (p.endsWith(":") || p.endsWith("?"))) {
            t.sandi = true;
            t.label.add("Ketik jawaban");
            t.kirim.add(KETIK);
            t.label.add("Tutup, biarkan menunggu");
            t.kirim.add(TUTUP);
            return t;
        }

        Matcher g = grup(p);
        if (g != null) {
            String[] tk = g.group(1).split("\\s*/\\s*");
            boolean adaKecil = false;
            for (String x : tk) if (x.equals(x.toLowerCase())) adaKecil = true;
            for (String x : tk) {
                // Huruf besar di antara huruf kecil menandai jawaban bawaan, misalnya [y/N].
                boolean bawaan = adaKecil && !x.equals(x.toLowerCase()) && x.equals(x.toUpperCase());
                t.tambah(nama(x) + (bawaan ? ", bawaan" : ""), x.toLowerCase());
            }
        }

        if (t.kirim.isEmpty() && (P_NOMOR.matcher(p).find() || konteks != null)) {
            List<String> nomor = new ArrayList<>();
            List<String> isi = new ArrayList<>();
            String[] b = konteks == null ? new String[0] : konteks.split("\n");
            int lewat = 0;
            for (int i = b.length - 1; i >= 0 && nomor.size() < 15; i--) {
                Matcher m = P_MENU.matcher(b[i]);
                if (m.find()) {
                    nomor.add(0, m.group(1));
                    String s = m.group(2).trim();
                    isi.add(0, s.length() > 60 ? s.substring(0, 60) : s);
                    lewat = 0;
                } else if (!nomor.isEmpty()) {
                    break;
                } else if (++lewat > 3) {
                    break;
                }
            }
            if (nomor.size() >= 2 && (P_NOMOR.matcher(p).find() || nomor.size() >= 3)) {
                for (int i = 0; i < nomor.size(); i++) t.tambah(nomor.get(i) + ". " + isi.get(i), nomor.get(i));
            }
        }

        if (P_TEKAN.matcher(p).find()) t.tambah("Tekan Enter, lanjut", "");

        if (t.kirim.isEmpty()) {
            t.tambah("Jawab ya (y)", "y");
            t.tambah("Jawab tidak (n)", "n");
        }
        t.tambah("Tekan Enter saja", "");
        t.tambah("Ketik jawaban lain", KETIK);
        t.tambah("Tutup, biarkan menunggu", TUTUP);
        return t;
    }
}
