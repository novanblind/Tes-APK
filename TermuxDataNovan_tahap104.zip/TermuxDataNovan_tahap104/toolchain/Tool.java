package novan.build;

import com.android.apksig.ApkSigner;
import com.android.tools.r8.D8;
import com.android.tools.r8.D8Command;
import com.android.tools.r8.OutputMode;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.zip.*;

/** Alat build yang dijalankan di dalam aplikasi (ART) lewat DexClassLoader. */
public class Tool {
    public static int run(String[] a, PrintWriter out) {
        try {
            switch (a[0]) {
                case "javac": return javac(a, out);
                case "jar": return jar(a);
                case "d8": return d8(a);
                case "pack": return pack(a);
                case "sign": return sign(a);
                default: out.println("Perintah alat tidak dikenal: " + a[0]); return 2;
            }
        } catch (Throwable t) {
            Throwable c = t.getCause() != null ? t.getCause() : t;
            out.println("Galat " + a[0] + ": " + c);
            return 1;
        }
    }

    static int javac(String[] a, PrintWriter out) {
        String[] rest = Arrays.copyOfRange(a, 1, a.length);
        boolean ok = new org.eclipse.jdt.internal.compiler.batch.Main(out, out, false, null, null).compile(rest);
        out.flush();
        return ok ? 0 : 1;
    }

    static int d8(String[] a) throws Exception {
        new File(a[3]).mkdirs();
        D8.run(D8Command.builder()
            .addProgramFiles(Paths.get(a[2]))
            .addLibraryFiles(Paths.get(a[1]))
            .setMinApiLevel(24)
            .setOutput(Paths.get(a[3]), OutputMode.DexIndexed)
            .build());
        return 0;
    }

    static int jar(String[] a) throws IOException {
        File dir = new File(a[1]);
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(a[2]))) { walk(dir, "", z); }
        return 0;
    }

    static void walk(File d, String pre, ZipOutputStream z) throws IOException {
        File[] fs = d.listFiles();
        if (fs == null) return;
        Arrays.sort(fs);
        for (File f : fs) {
            if (f.isDirectory()) walk(f, pre + f.getName() + "/", z);
            else if (f.getName().endsWith(".class")) {
                z.putNextEntry(new ZipEntry(pre + f.getName()));
                z.write(Files.readAllBytes(f.toPath()));
                z.closeEntry();
            }
        }
    }

    static class CountOut extends FilterOutputStream {
        long n;
        CountOut(OutputStream o) { super(o); }
        @Override public void write(int b) throws IOException { out.write(b); n++; }
        @Override public void write(byte[] b, int o, int l) throws IOException { out.write(b, o, l); n += l; }
    }

    static void add(ZipOutputStream z, CountOut co, String name, byte[] d, boolean store) throws IOException {
        ZipEntry e = new ZipEntry(name);
        if (store) {
            e.setMethod(ZipEntry.STORED);
            e.setSize(d.length);
            e.setCompressedSize(d.length);
            CRC32 c = new CRC32();
            c.update(d);
            e.setCrc(c.getValue());
            int hdr = 30 + name.getBytes("UTF-8").length;
            int pad = (int) ((4 - ((co.n + hdr) % 4)) % 4);
            if (pad > 0) {
                byte[] x = new byte[4 + pad];
                x[0] = 0x35; x[1] = (byte) 0xD9; x[2] = (byte) pad; x[3] = 0;
                e.setExtra(x);
            }
        }
        z.putNextEntry(e);
        z.write(d);
        z.closeEntry();
    }

    /** a[1]=base.apk, a[2]=folder dex, a[3]=folder assets atau "-", a[4]=keluaran. resources.arsc disimpan rata 4 byte. */
    static int pack(String[] a) throws IOException {
        CountOut co = new CountOut(new BufferedOutputStream(new FileOutputStream(a[4])));
        try (ZipOutputStream z = new ZipOutputStream(co); ZipFile zf = new ZipFile(a[1])) {
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements();) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                byte[] d;
                try (InputStream in = zf.getInputStream(e)) { d = readAll(in); }
                add(z, co, e.getName(), d, e.getName().equals("resources.arsc"));
            }
            File[] dex = new File(a[2]).listFiles();
            if (dex != null) { Arrays.sort(dex); for (File f : dex) if (f.getName().endsWith(".dex")) add(z, co, f.getName(), Files.readAllBytes(f.toPath()), false); }
            if (!a[3].equals("-")) addDir(z, co, new File(a[3]), "assets/");
        }
        return 0;
    }

    static void addDir(ZipOutputStream z, CountOut co, File d, String pre) throws IOException {
        File[] fs = d.listFiles();
        if (fs == null) return;
        Arrays.sort(fs);
        for (File f : fs) {
            if (f.isDirectory()) addDir(z, co, f, pre + f.getName() + "/");
            else add(z, co, pre + f.getName(), Files.readAllBytes(f.toPath()), false);
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] t = new byte[16384];
        int n;
        while ((n = in.read(t)) > 0) b.write(t, 0, n);
        return b.toByteArray();
    }

    /** a[1]=keystore, a[2]=sandi, a[3]=alias, a[4]=masuk, a[5]=keluar, a[6]=minSdk */
    static int sign(String[] a) throws Exception {
        KeyStore ks = KeyStore.getInstance("PKCS12");
        try (InputStream in = new FileInputStream(a[1])) { ks.load(in, a[2].toCharArray()); }
        PrivateKey k = (PrivateKey) ks.getKey(a[3], a[2].toCharArray());
        List<X509Certificate> certs = new ArrayList<>();
        for (Certificate c : ks.getCertificateChain(a[3])) certs.add((X509Certificate) c);
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("novan", k, certs).build();
        new ApkSigner.Builder(Collections.singletonList(sc))
            .setInputApk(new File(a[4])).setOutputApk(new File(a[5]))
            .setMinSdkVersion(Integer.parseInt(a[6]))
            .setV1SigningEnabled(true).setV2SigningEnabled(true)
            .build().sign();
        return 0;
    }
}
