package com.novan.statusnovan;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;

import java.io.File;
import java.util.List;

/** Menjalankan pemotongan di latar belakang (layanan latar depan) supaya tetap jalan saat pindah aplikasi. */
public class PotongService extends Service {

    static final String AKSI_MULAI = "com.novan.statusnovan.MULAI";
    static final String AKSI_BATAL = "com.novan.statusnovan.BATAL";
    static final String EKSTRA_AWAL_MS = "awal_ms";
    static final String EKSTRA_AKHIR_MS = "akhir_ms";
    static final String EKSTRA_PANJANG_DETIK = "panjang_detik";
    static final String EKSTRA_FOLDER = "folder";
    static final String EKSTRA_AWALAN = "awalan";

    private static final String KANAL_PROSES = "proses";
    private static final String KANAL_HASIL = "hasil";
    private static final int ID_PROSES = 1;
    private static final int ID_HASIL = 2;

    private PowerManager.WakeLock kunci;
    private int persenNotif = -1;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String aksi = intent != null ? intent.getAction() : null;

        if (AKSI_BATAL.equals(aksi)) {
            ProsesPotong.batalkan();
            if (ProsesPotong.tugas == null) {
                stopSelf();
            }
            return START_NOT_STICKY;
        }

        buatKanal();
        // Wajib segera dipanggil karena layanan dimulai dengan startForegroundService.
        ServiceCompat.startForeground(this, ID_PROSES, notifProses(0),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);

        Uri uri = intent != null ? intent.getData() : null;
        if (!AKSI_MULAI.equals(aksi) || uri == null || ProsesPotong.tugas != null) {
            if (ProsesPotong.tugas == null) {
                akhir();
            }
            return START_NOT_STICKY;
        }

        long awalMs = intent.getLongExtra(EKSTRA_AWAL_MS, 0L);
        long akhirMs = intent.getLongExtra(EKSTRA_AKHIR_MS, 0L);
        long panjangUs = intent.getLongExtra(EKSTRA_PANJANG_DETIK, 90L) * 1_000_000L;
        File folder = new File(intent.getStringExtra(EKSTRA_FOLDER));
        String awalan = intent.getStringExtra(EKSTRA_AWALAN);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        kunci = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "statusnovan:potong");
        kunci.acquire(2 * 60 * 60 * 1000L);

        persenNotif = -1;
        ProsesPotong.tugas = PemotongVideo.mulai(this, uri, awalMs * 1000L, akhirMs * 1000L, folder, awalan,
                panjangUs, new PemotongVideo.Pendengar() {
                    @Override
                    public void kemajuan(int persen) {
                        ProsesPotong.setPersen(persen);
                        if (persen != persenNotif) {
                            persenNotif = persen;
                            manajer().notify(ID_PROSES, notifProses(persen));
                        }
                    }

                    @Override
                    public void selesai(List<File> berkas, boolean tanpaSuara) {
                        boolean terlihat = ProsesPotong.adaPantau();
                        ProsesPotong.selesai(berkas, tanpaSuara);
                        akhir();
                        if (!terlihat) {
                            notifHasil(getString(R.string.notif_selesai), getString(R.string.notif_ketuk));
                        }
                    }

                    @Override
                    public void gagal(String pesan) {
                        boolean terlihat = ProsesPotong.adaPantau();
                        ProsesPotong.gagal(pesan);
                        akhir();
                        if (!terlihat) {
                            notifHasil(getString(R.string.notif_gagal), pesan);
                        }
                    }

                    @Override
                    public void dibatalkan() {
                        ProsesPotong.batal();
                        akhir();
                    }
                });
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (ProsesPotong.tugas != null) {
            ProsesPotong.tugas.batalkan();
        }
        lepasKunci();
        super.onDestroy();
    }

    private void akhir() {
        ProsesPotong.tugas = null;
        lepasKunci();
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void lepasKunci() {
        if (kunci != null && kunci.isHeld()) {
            kunci.release();
        }
        kunci = null;
    }

    private NotificationManager manajer() {
        return (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    private void buatKanal() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = manajer();
            nm.createNotificationChannel(new NotificationChannel(KANAL_PROSES,
                    getString(R.string.kanal_proses), NotificationManager.IMPORTANCE_LOW));
            nm.createNotificationChannel(new NotificationChannel(KANAL_HASIL,
                    getString(R.string.kanal_hasil), NotificationManager.IMPORTANCE_DEFAULT));
        }
    }

    private PendingIntent bukaAplikasi() {
        Intent buka = new Intent(this, ProcessActivity.class);
        buka.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, buka,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private android.app.Notification notifProses(int persen) {
        Intent batal = new Intent(this, PotongService.class).setAction(AKSI_BATAL);
        PendingIntent pb = PendingIntent.getService(this, 1, batal,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, KANAL_PROSES)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(getString(R.string.notif_memotong))
                .setContentText(persen + "%")
                .setProgress(100, persen, false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(bukaAplikasi())
                .addAction(0, getString(R.string.batal), pb)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .build();
    }

    private void notifHasil(String judul, String teks) {
        android.app.Notification n = new NotificationCompat.Builder(this, KANAL_HASIL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(judul)
                .setContentText(teks)
                .setAutoCancel(true)
                .setContentIntent(bukaAplikasi())
                .build();
        manajer().notify(ID_HASIL, n);
    }
}
