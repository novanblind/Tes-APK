package com.novan.statusnovan;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.IntConsumer;

/**
 * Memotong video menjadi potongan berdurasi paling lama {@code panjangUs} TANPA encode ulang
 * (salin sampel langsung, jadi cepat dan kualitas tidak turun).
 * Setiap potongan dimulai tepat di bingkai kunci, sehingga potongan berurutan tanpa celah dan tanpa tumpang tindih.
 */
final class PemotongVideo {

    private static final int UKURAN_BUFFER_MIN = 4 * 1024 * 1024;

    interface Pendengar {
        void kemajuan(int persen);

        void selesai(List<File> berkas, boolean tanpaSuara);

        void gagal(String pesan);

        void dibatalkan();
    }

    static final class Tugas {
        private volatile boolean batal;

        void batalkan() {
            batal = true;
        }

        boolean dibatalkan() {
            return batal;
        }
    }

    private static final class Batal extends Exception {
    }

    private PemotongVideo() {
    }

    /** Dijalankan di thread latar; semua panggilan Pendengar tiba di thread utama. */
    static Tugas mulai(Context konteks, Uri uri, long awalUs, long akhirUs, File folder,
                       String awalan, long panjangUs, Pendengar pendengar) {
        final Context app = konteks.getApplicationContext();
        final Tugas tugas = new Tugas();
        final Handler utama = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            final List<File> hasil = new ArrayList<>();
            final boolean[] tanpaSuara = new boolean[1];
            try {
                potong(app, uri, awalUs, akhirUs, folder, awalan, panjangUs, tugas, hasil, tanpaSuara,
                        persen -> utama.post(() -> pendengar.kemajuan(persen)));
                utama.post(() -> pendengar.selesai(hasil, tanpaSuara[0]));
            } catch (Batal b) {
                hapus(hasil);
                utama.post(pendengar::dibatalkan);
            } catch (Exception e) {
                hapus(hasil);
                final String pesan = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                utama.post(() -> pendengar.gagal(pesan));
            }
        }, "PemotongVideo").start();
        return tugas;
    }

    private static void potong(Context konteks, Uri uri, long awalUs, long akhirUs, File folder,
                               String awalan, long panjangUs, Tugas tugas, List<File> hasil, boolean[] tanpaSuara,
                               IntConsumer kemajuan) throws Exception {
        ParcelFileDescriptor pfdV = null;
        ParcelFileDescriptor pfdA = null;
        MediaExtractor video = new MediaExtractor();
        MediaExtractor audio = null;
        try {
            pfdV = konteks.getContentResolver().openFileDescriptor(uri, "r");
            if (pfdV == null) {
                throw new Exception("Video tidak dapat dibuka");
            }
            video.setDataSource(pfdV.getFileDescriptor());

            int idxV = -1;
            int idxA = -1;
            for (int i = 0; i < video.getTrackCount(); i++) {
                String mime = video.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                if (mime == null) {
                    continue;
                }
                if (idxV < 0 && mime.startsWith("video/")) {
                    idxV = i;
                } else if (idxA < 0 && mime.startsWith("audio/")) {
                    idxA = i;
                }
            }
            if (idxV < 0) {
                throw new Exception("Berkas ini tidak berisi gambar video");
            }
            MediaFormat fmtV = video.getTrackFormat(idxV);

            MediaFormat fmtA = null;
            if (idxA >= 0) {
                MediaFormat f = video.getTrackFormat(idxA);
                String mimeA = f.getString(MediaFormat.KEY_MIME);
                if ("audio/mp4a-latm".equals(mimeA) || "audio/3gpp".equals(mimeA)
                        || "audio/amr-wb".equals(mimeA)) {
                    fmtA = f;
                } else {
                    tanpaSuara[0] = true;
                }
            }

            video.selectTrack(idxV);
            if (fmtA != null) {
                pfdA = konteks.getContentResolver().openFileDescriptor(uri, "r");
                if (pfdA == null) {
                    throw new Exception("Video tidak dapat dibuka");
                }
                audio = new MediaExtractor();
                audio.setDataSource(pfdA.getFileDescriptor());
                audio.selectTrack(idxA);
            }

            int rotasi = bacaRotasi(konteks, uri);
            int ukuranBuf = UKURAN_BUFFER_MIN;
            if (fmtV.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                ukuranBuf = Math.max(ukuranBuf, fmtV.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE));
            }
            ByteBuffer buf = ByteBuffer.allocate(ukuranBuf);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

            video.seekTo(awalUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            long mulai = video.getSampleTime();
            if (mulai < 0) {
                throw new Exception("Posisi awal di luar durasi video");
            }
            long totalUs = Math.max(1L, akhirUs - mulai);

            int nomor = 0;
            long awalSeg = mulai;
            while (awalSeg < akhirUs) {
                if (tugas.dibatalkan()) {
                    throw new Batal();
                }
                long akhirSeg = cariAkhirSegmen(video, awalSeg, akhirUs, panjangUs);
                nomor++;
                File out = new File(folder, String.format(Locale.US, "%s_%03d.mp4", awalan, nomor));
                hasil.add(out);
                tulisSegmen(video, audio, fmtV, fmtA, rotasi, out, awalSeg, akhirSeg, buf, info,
                        tugas, mulai, totalUs, kemajuan);
                if (akhirSeg <= awalSeg) {
                    break; // pengaman agar tidak berputar tanpa akhir
                }
                awalSeg = akhirSeg;
            }
            if (hasil.isEmpty()) {
                throw new Exception("Tidak ada bagian video yang dipotong");
            }
            kemajuan.accept(100);
        } finally {
            video.release();
            if (audio != null) {
                audio.release();
            }
            tutup(pfdV);
            tutup(pfdA);
        }
    }

    /**
     * Mencari titik akhir potongan yang dimulai di {@code awal}: bingkai kunci terakhir yang
     * tidak melewati awal + panjangUs. Jika tidak ada, bingkai kunci berikutnya.
     * Potongan terakhir berakhir di {@code akhirTotal}.
     */
    private static long cariAkhirSegmen(MediaExtractor video, long awal, long akhirTotal, long panjangUs) {
        long batas = awal + panjangUs;
        if (batas >= akhirTotal) {
            return akhirTotal;
        }
        video.seekTo(awal, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        long terbaik = -1;
        while (true) {
            long t = video.getSampleTime();
            if (t < 0) {
                break;
            }
            boolean sinkron = (video.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0;
            if (t > awal && sinkron) {
                if (t <= batas) {
                    terbaik = t;
                } else {
                    if (terbaik < 0) {
                        terbaik = t;
                    }
                    break;
                }
            }
            if (t > batas && terbaik >= 0) {
                break;
            }
            if (!video.advance()) {
                break;
            }
        }
        if (terbaik < 0 || terbaik >= akhirTotal) {
            return akhirTotal;
        }
        return terbaik;
    }

    private static void tulisSegmen(MediaExtractor video, MediaExtractor audio, MediaFormat fmtV,
                                    MediaFormat fmtA, int rotasi, File out, long awal, long akhir,
                                    ByteBuffer buf, MediaCodec.BufferInfo info, Tugas tugas,
                                    long mulaiTotal, long totalUs, IntConsumer kemajuan) throws Exception {
        video.seekTo(awal, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        if (audio != null) {
            audio.seekTo(awal, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
        }
        MediaMuxer muxer = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        try {
            muxer.setOrientationHint(rotasi);
            int jalurV = muxer.addTrack(fmtV);
            int jalurA = fmtA != null ? muxer.addTrack(fmtA) : -1;
            muxer.start();

            int persenTerakhir = -1;
            while (true) {
                if (tugas.dibatalkan()) {
                    throw new Batal();
                }
                long tv = video.getSampleTime();
                long ta = audio != null ? audio.getSampleTime() : -1;
                boolean adaV = tv >= 0 && tv < akhir;
                boolean adaA = audio != null && ta >= 0 && ta < akhir;
                if (!adaV && !adaA) {
                    break;
                }
                boolean pakaiV = adaV && (!adaA || tv <= ta);
                MediaExtractor sumber = pakaiV ? video : audio;
                long t = pakaiV ? tv : ta;
                if (!pakaiV && t < awal) {
                    audio.advance(); // suara sebelum titik awal dibuang
                    continue;
                }
                buf.clear();
                int ukuran = sumber.readSampleData(buf, 0);
                if (ukuran < 0) {
                    break;
                }
                int bendera = (sumber.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                        ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                info.set(0, ukuran, Math.max(0L, t - awal), bendera);
                muxer.writeSampleData(pakaiV ? jalurV : jalurA, buf, info);
                sumber.advance();

                if (pakaiV) {
                    int persen = (int) Math.min(99L, Math.max(0L, (t - mulaiTotal) * 100L / totalUs));
                    if (persen != persenTerakhir) {
                        persenTerakhir = persen;
                        kemajuan.accept(persen);
                    }
                }
            }
            muxer.stop();
        } finally {
            try {
                muxer.release();
            } catch (Exception ignored) {
                // sudah rusak karena galat sebelumnya; berkas akan dihapus
            }
        }
    }

    private static int bacaRotasi(Context konteks, Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(konteks, uri);
            String s = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            return s == null ? 0 : Integer.parseInt(s);
        } catch (Exception e) {
            return 0;
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
                // pada SDK baru release() bisa melempar IOException; abaikan
            }
        }
    }

    private static void tutup(ParcelFileDescriptor p) {
        if (p != null) {
            try {
                p.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static void hapus(List<File> berkas) {
        for (File f : berkas) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
        }
    }
}
