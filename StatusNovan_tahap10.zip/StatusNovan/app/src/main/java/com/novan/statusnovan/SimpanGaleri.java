package com.novan.statusnovan;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/** Menyalin potongan ke galeri (Movies/StatusCutterNovan). */
final class SimpanGaleri {

    static final String FOLDER = "StatusCutterNovan";

    interface Hasil {
        void selesai(int berhasil, int total);
    }

    private SimpanGaleri() {}

    static void simpan(Context konteks, List<File> berkas, Hasil hasil) {
        final Context app = konteks.getApplicationContext();
        final Handler utama = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            int ok = 0;
            for (File f : berkas) {
                try {
                    simpanSatu(app, f);
                    ok++;
                } catch (Exception ignored) {
                    // lanjut ke potongan berikutnya
                }
            }
            final int berhasil = ok;
            utama.post(() -> hasil.selesai(berhasil, berkas.size()));
        }, "SimpanGaleri").start();
    }

    private static void simpanSatu(Context konteks, File sumber) throws IOException {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver cr = konteks.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Video.Media.DISPLAY_NAME, sumber.getName());
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/" + FOLDER);
            v.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v);
            if (uri == null) {
                throw new IOException("Tidak dapat membuat berkas galeri");
            }
            boolean berhasil = false;
            try {
                OutputStream keluar = cr.openOutputStream(uri);
                if (keluar == null) {
                    throw new IOException("Tidak dapat menulis berkas galeri");
                }
                try (OutputStream o = keluar; InputStream masuk = new FileInputStream(sumber)) {
                    salin(masuk, o);
                }
                berhasil = true;
            } finally {
                if (!berhasil) {
                    cr.delete(uri, null, null);
                }
            }
            ContentValues selesai = new ContentValues();
            selesai.put(MediaStore.Video.Media.IS_PENDING, 0);
            cr.update(uri, selesai, null, null);
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), FOLDER);
            if (!dir.exists() && !dir.mkdirs()) {
                throw new IOException("Tidak dapat membuat folder galeri");
            }
            File tujuan = new File(dir, sumber.getName());
            try (OutputStream o = new FileOutputStream(tujuan); InputStream masuk = new FileInputStream(sumber)) {
                salin(masuk, o);
            }
            MediaScannerConnection.scanFile(konteks, new String[]{tujuan.getAbsolutePath()},
                    new String[]{"video/mp4"}, null);
        }
    }

    private static void salin(InputStream masuk, OutputStream keluar) throws IOException {
        byte[] buf = new byte[256 * 1024];
        int n;
        while ((n = masuk.read(buf)) > 0) {
            keluar.write(buf, 0, n);
        }
    }
}
