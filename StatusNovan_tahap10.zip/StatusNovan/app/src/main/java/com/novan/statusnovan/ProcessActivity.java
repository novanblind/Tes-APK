package com.novan.statusnovan;

import android.Manifest;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.StatFs;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ProcessActivity extends AppCompatActivity implements ProsesPotong.Pantau {

    private static final String KUNCI_POSISI = "posisi";
    private static final String KUNCI_PILIHAN = "pilihan_panjang";
    private static final String KUNCI_SENDIRI = "panjang_sendiri";
    private static final String KUNCI_AWAL = "awal_ms";
    private static final String KUNCI_AKHIR = "akhir_ms";

    private Uri uri;
    private boolean pemantau;          // hanya memantau proses yang sedang/sudah berjalan
    private String nama = "video";
    private long durasiMs;
    private long panjangDetik = 90;
    private long awalMs;
    private long akhirMs;

    private PlayerView tampilanPemain;
    private ExoPlayer pemain;
    private long posisi;

    private TextView txtInfo;
    private TextView txtRentang;
    private Button btnSimpan;
    private Button btnUlang;
    private View panelAtur;
    private View panelProses;
    private View panelHasil;
    private Button btnPanjang;
    private Button btnPotong;
    private int pilihanPanjang = 2;    // 0=30, 1=60, 2=90, 3=atur sendiri
    private long panjangSendiri = 0;
    private ProgressBar bar;
    private TextView txtStatus;
    private TextView txtHasil;
    private Button btnSatu;
    private int persenDiumumkan = -10;

    private final ActivityResultLauncher<String> izinSimpan = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), diberi -> {
                if (diberi) {
                    mulaiSimpan();
                } else {
                    Toast.makeText(this, R.string.izin_ditolak, Toast.LENGTH_SHORT).show();
                }
            });

    private final ActivityResultLauncher<String> izinNotifikasi = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), diberi -> mulaiLayanan());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        TepiLayar.aktifkan(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_process);
        TepiLayar.terapkan(findViewById(R.id.root));

        tampilanPemain = findViewById(R.id.pemutar);
        txtInfo = findViewById(R.id.txt_info);
        txtRentang = findViewById(R.id.txt_rentang);
        btnSimpan = findViewById(R.id.btn_simpan);
        btnUlang = findViewById(R.id.btn_ulang);
        panelAtur = findViewById(R.id.panel_atur);
        panelProses = findViewById(R.id.panel_proses);
        panelHasil = findViewById(R.id.panel_hasil);
        btnPanjang = findViewById(R.id.btn_panjang);
        btnPotong = findViewById(R.id.btn_potong);
        bar = findViewById(R.id.bar_proses);
        txtStatus = findViewById(R.id.txt_status);
        txtHasil = findViewById(R.id.txt_hasil);
        btnSatu = findViewById(R.id.btn_satu);

        uri = getIntent().getData();
        boolean baru = savedInstanceState == null;
        if (uri != null && baru && ProsesPotong.status != ProsesPotong.JALAN) {
            ProsesPotong.reset(); // video baru: hasil lama dilepas
        }
        pemantau = uri == null || ProsesPotong.status == ProsesPotong.JALAN;

        if (pemantau) {
            tampilanPemain.setVisibility(View.GONE);
            txtInfo.setText(ProsesPotong.nama);
        } else {
            if (!bacaDurasi()) {
                Toast.makeText(this, R.string.video_tidak_terbaca, Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            nama = bacaNama();
            awalMs = 0;
            akhirMs = durasiMs;
            if (savedInstanceState != null) {
                posisi = savedInstanceState.getLong(KUNCI_POSISI, 0L);
                pilihanPanjang = savedInstanceState.getInt(KUNCI_PILIHAN, 2);
                panjangSendiri = savedInstanceState.getLong(KUNCI_SENDIRI, 0L);
                awalMs = savedInstanceState.getLong(KUNCI_AWAL, 0L);
                akhirMs = savedInstanceState.getLong(KUNCI_AKHIR, durasiMs);
            }
            siapkanPilihan();
            perbaruiInfo();
        }

        btnPotong.setOnClickListener(v -> mulaiPotong());
        findViewById(R.id.btn_batal).setOnClickListener(v -> {
            ProsesPotong.batalkan();
            v.setEnabled(false);
        });
        findViewById(R.id.btn_semua).setOnClickListener(v -> kirim(ProsesPotong.berkas));
        btnSatu.setOnClickListener(v -> bagikanSatu());
        findViewById(R.id.btn_awal).setOnClickListener(v -> aturAwal());
        findViewById(R.id.btn_akhir).setOnClickListener(v -> aturAkhir());
        findViewById(R.id.btn_setel).setOnClickListener(v -> {
            awalMs = 0;
            akhirMs = durasiMs;
            perbaruiInfo();
        });
        btnSimpan.setOnClickListener(v -> simpanKeGaleri());
        btnUlang.setOnClickListener(v -> {
            ProsesPotong.reset();
            berubah();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        ProsesPotong.pasang(this);
        if (!pemantau && uri != null) {
            pemain = new ExoPlayer.Builder(this).build();
            pemain.addListener(new Player.Listener() {
                @Override
                public void onPlayerError(PlaybackException error) {
                    Toast.makeText(ProcessActivity.this, R.string.pratinjau_gagal, Toast.LENGTH_LONG).show();
                }
            });
            tampilanPemain.setPlayer(pemain);
            pemain.setMediaItem(MediaItem.fromUri(uri));
            pemain.seekTo(posisi);
            pemain.prepare();
        }
        berubah();
    }

    @Override
    protected void onStop() {
        super.onStop();
        ProsesPotong.pasang(null);
        if (pemain != null) {
            posisi = pemain.getCurrentPosition();
            tampilanPemain.setPlayer(null);
            pemain.release();
            pemain = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle keluar) {
        super.onSaveInstanceState(keluar);
        keluar.putLong(KUNCI_POSISI, posisi);
        keluar.putInt(KUNCI_PILIHAN, pilihanPanjang);
        keluar.putLong(KUNCI_SENDIRI, panjangSendiri);
        keluar.putLong(KUNCI_AWAL, awalMs);
        keluar.putLong(KUNCI_AKHIR, akhirMs);
    }

    // ------------------------------------------------------------------ tampilan

    @Override
    public void berubah() {
        if (isFinishing()) {
            return;
        }
        if (ProsesPotong.batalBaru) {
            ProsesPotong.batalBaru = false;
            Toast.makeText(this, R.string.dibatalkan, Toast.LENGTH_SHORT).show();
        }
        if (ProsesPotong.galatBaru != null) {
            String galat = ProsesPotong.galatBaru;
            ProsesPotong.galatBaru = null;
            new AlertDialog.Builder(this)
                    .setTitle(R.string.gagal_judul)
                    .setMessage(galat)
                    .setPositiveButton(R.string.ok, null)
                    .show();
        }

        int s = ProsesPotong.status;
        if (s == ProsesPotong.IDLE && uri == null) {
            finish();
            return;
        }
        if (s == ProsesPotong.IDLE && pemantau) {
            // proses yang dipantau berakhir tanpa hasil; kembali ke layar awal
            finish();
            return;
        }
        panelAtur.setVisibility(s == ProsesPotong.IDLE ? View.VISIBLE : View.GONE);
        btnPotong.setVisibility(s == ProsesPotong.IDLE ? View.VISIBLE : View.GONE);
        panelProses.setVisibility(s == ProsesPotong.JALAN ? View.VISIBLE : View.GONE);
        panelHasil.setVisibility(s == ProsesPotong.SELESAI ? View.VISIBLE : View.GONE);

        if (s == ProsesPotong.JALAN) {
            int p = ProsesPotong.persen;
            bar.setProgress(p);
            if (p != persenDiumumkan) {
                persenDiumumkan = p;
                txtStatus.setText(getString(R.string.status_memotong, p));
            } else if (txtStatus.getText().length() == 0) {
                txtStatus.setText(getString(R.string.status_memotong, p));
            }
            findViewById(R.id.btn_batal).setEnabled(true);
        } else if (s == ProsesPotong.SELESAI) {
            int n = ProsesPotong.berkas.size();
            String teks = getString(R.string.hasil_siap, n);
            if (ProsesPotong.tanpaSuara) {
                teks += " " + getString(R.string.tanpa_suara);
            }
            txtHasil.setText(teks);
            btnSatu.setText(getString(R.string.bagikan_satu,
                    (n == 0 ? 0 : ProsesPotong.indeksSatu % n) + 1, n));
            persenDiumumkan = -10;
            txtStatus.setText("");
            btnSimpan.setEnabled(!ProsesPotong.disimpan);
            btnSimpan.setText(ProsesPotong.disimpan ? R.string.sudah_tersimpan : R.string.simpan_galeri);
            btnUlang.setVisibility(pemantau ? View.GONE : View.VISIBLE);
        }
    }

    private void siapkanPilihan() {
        btnPanjang.setOnClickListener(v -> tampilkanPilihanPanjang());
    }

    private void tampilkanPilihanPanjang() {
        String[] daftar = {
                getString(R.string.detik_30),
                getString(R.string.detik_60),
                getString(R.string.detik_90),
                getString(R.string.atur_sendiri)
        };
        new AlertDialog.Builder(this)
                .setTitle(R.string.panjang_judul)
                .setSingleChoiceItems(daftar, pilihanPanjang, (d, which) -> {
                    d.dismiss();
                    if (which == 3) {
                        tampilkanAturSendiri();
                    } else {
                        pilihanPanjang = which;
                        perbaruiInfo();
                    }
                })
                .setNegativeButton(R.string.batal, null)
                .show();
    }

    private void tampilkanAturSendiri() {
        View isi = getLayoutInflater().inflate(R.layout.dialog_panjang, null);
        EditText etMenit = isi.findViewById(R.id.et_menit);
        EditText etDetik = isi.findViewById(R.id.et_detik);
        if (panjangSendiri > 0) {
            etMenit.setText(String.valueOf(panjangSendiri / 60));
            etDetik.setText(String.valueOf(panjangSendiri % 60));
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.atur_sendiri)
                .setView(isi)
                .setPositiveButton(R.string.ok_atur, (d, w) -> {
                    long detik = angka(etMenit) * 60 + angka(etDetik);
                    if (detik <= 0) {
                        Toast.makeText(this, R.string.isi_panjang, Toast.LENGTH_SHORT).show();
                    } else {
                        panjangSendiri = detik;
                        pilihanPanjang = 3;
                    }
                    perbaruiInfo();
                })
                .setNegativeButton(R.string.batal, null)
                .create();
        dialog.show();
        etMenit.requestFocus();
    }

    private long bacaPanjangDetik() {
        if (pilihanPanjang == 0) {
            return 30;
        } else if (pilihanPanjang == 1) {
            return 60;
        } else if (pilihanPanjang == 3) {
            return panjangSendiri;
        }
        return 90;
    }

    private static long angka(EditText e) {
        try {
            return Long.parseLong(e.getText().toString().trim());
        } catch (Exception x) {
            return 0;
        }
    }

    private String teksPanjang() {
        if (pilihanPanjang == 0) {
            return getString(R.string.detik_30);
        } else if (pilihanPanjang == 1) {
            return getString(R.string.detik_60);
        } else if (pilihanPanjang == 3) {
            return getString(R.string.menit_detik, panjangSendiri / 60, panjangSendiri % 60);
        }
        return getString(R.string.detik_90);
    }

    private void perbaruiInfo() {
        btnPanjang.setText(getString(R.string.panjang_tombol, teksPanjang()));
        long detik = bacaPanjangDetik();
        long lama = akhirMs - awalMs;
        long jumlah = detik <= 0 ? 0 : Math.max(1L, (lama + detik * 1000 - 1) / (detik * 1000));
        txtInfo.setText(getString(R.string.info_video, nama, formatWaktu(durasiMs)));
        txtRentang.setText(getString(R.string.info_rentang, formatWaktu(awalMs), formatWaktu(akhirMs), (int) jumlah));
    }

    private long posisiSekarang() {
        return pemain != null ? pemain.getCurrentPosition() : posisi;
    }

    private void aturAwal() {
        long p = Math.max(0L, posisiSekarang());
        if (p > akhirMs - 1000) {
            Toast.makeText(this, R.string.awal_sebelum_akhir, Toast.LENGTH_SHORT).show();
            return;
        }
        awalMs = p;
        perbaruiInfo();
    }

    private void aturAkhir() {
        long p = Math.min(durasiMs, posisiSekarang());
        if (p < awalMs + 1000) {
            Toast.makeText(this, R.string.awal_sebelum_akhir, Toast.LENGTH_SHORT).show();
            return;
        }
        akhirMs = p;
        perbaruiInfo();
    }

    // ------------------------------------------------------------------ memotong

    private void mulaiPotong() {
        panjangDetik = bacaPanjangDetik();
        if (panjangDetik <= 0) {
            Toast.makeText(this, R.string.isi_panjang, Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            izinNotifikasi.launch(Manifest.permission.POST_NOTIFICATIONS);
        } else {
            mulaiLayanan();
        }
    }

    private void mulaiLayanan() {
        if (uri == null || pemantau || ProsesPotong.status == ProsesPotong.JALAN) {
            return;
        }
        File folder = folderKeluaran();
        bersihkan(folder);
        if (!cukupRuang(folder)) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.penuh_judul)
                    .setMessage(R.string.penuh_pesan)
                    .setPositiveButton(R.string.ok, null)
                    .show();
            return;
        }
        if (pemain != null) {
            pemain.pause();
        }
        String awalan = "STS_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        ProsesPotong.mulaiBaru(uri, nama);

        Intent i = new Intent(this, PotongService.class)
                .setAction(PotongService.AKSI_MULAI)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .putExtra(PotongService.EKSTRA_AWAL_MS, awalMs)
                .putExtra(PotongService.EKSTRA_AKHIR_MS, akhirMs)
                .putExtra(PotongService.EKSTRA_PANJANG_DETIK, panjangDetik)
                .putExtra(PotongService.EKSTRA_FOLDER, folder.getAbsolutePath())
                .putExtra(PotongService.EKSTRA_AWALAN, awalan);
        try {
            ContextCompat.startForegroundService(this, i);
        } catch (Exception e) {
            ProsesPotong.tugas = null;
            ProsesPotong.gagal(e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName());
        }
    }

    // ------------------------------------------------------------------ galeri

    private void simpanKeGaleri() {
        if (Build.VERSION.SDK_INT <= 28 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            izinSimpan.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        } else {
            mulaiSimpan();
        }
    }

    private void mulaiSimpan() {
        if (ProsesPotong.berkas.isEmpty()) {
            return;
        }
        btnSimpan.setEnabled(false);
        final android.content.Context app = getApplicationContext();
        SimpanGaleri.simpan(this, new ArrayList<>(ProsesPotong.berkas), (berhasil, total) -> {
            if (berhasil == total && total > 0) {
                ProsesPotong.disimpan = true;
                Toast.makeText(app, app.getString(R.string.tersimpan, berhasil), Toast.LENGTH_LONG).show();
            } else if (berhasil > 0) {
                Toast.makeText(app, app.getString(R.string.tersimpan_sebagian, berhasil, total),
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(app, R.string.simpan_gagal, Toast.LENGTH_LONG).show();
            }
            berubah();
        });
    }

    // ------------------------------------------------------------------ berbagi

    private void bagikanSatu() {
        List<File> semua = ProsesPotong.berkas;
        if (semua.isEmpty()) {
            return;
        }
        int n = semua.size();
        int i = ProsesPotong.indeksSatu % n;
        ProsesPotong.indeksSatu = (i + 1) % n;
        berubah();
        kirim(Collections.singletonList(semua.get(i)));
    }

    private void kirim(List<File> daftarBerkas) {
        if (daftarBerkas.isEmpty()) {
            return;
        }
        ArrayList<Uri> daftar = new ArrayList<>();
        for (File f : daftarBerkas) {
            daftar.add(FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f));
        }
        Intent i;
        if (daftar.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, daftar.get(0));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, daftar);
        }
        i.setType("video/mp4");
        ClipData klip = ClipData.newRawUri(null, daftar.get(0));
        for (int k = 1; k < daftar.size(); k++) {
            klip.addItem(new ClipData.Item(daftar.get(k)));
        }
        i.setClipData(klip);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, getString(R.string.bagikan_judul)));
        } catch (Exception e) {
            Toast.makeText(this, R.string.tidak_ada_aplikasi, Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------ bantu

    private File folderKeluaran() {
        File dasar = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        if (dasar == null) {
            dasar = new File(getFilesDir(), "Movies");
        }
        File folder = new File(dasar, "Potongan");
        //noinspection ResultOfMethodCallIgnored
        folder.mkdirs();
        return folder;
    }

    /** Potongan lama hanya berkas sementara untuk dibagikan; dihapus sebelum pemotongan baru. */
    private void bersihkan(File folder) {
        File[] isi = folder.listFiles();
        if (isi != null) {
            for (File f : isi) {
                //noinspection ResultOfMethodCallIgnored
                f.delete();
            }
        }
    }

    private boolean cukupRuang(File folder) {
        try (ParcelFileDescriptor p = getContentResolver().openFileDescriptor(uri, "r")) {
            if (p == null) {
                return true;
            }
            long ukuran = p.getStatSize();
            if (ukuran <= 0) {
                return true;
            }
            double bagian = durasiMs > 0 ? Math.min(1.0, (double) (akhirMs - awalMs) / durasiMs) : 1.0;
            long butuh = (long) (ukuran * bagian * 1.15) + 8L * 1024 * 1024;
            return new StatFs(folder.getAbsolutePath()).getAvailableBytes() >= butuh;
        } catch (Exception e) {
            return true;
        }
    }

    private boolean bacaDurasi() {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, uri);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            durasiMs = d == null ? 0L : Long.parseLong(d);
            return durasiMs > 0;
        } catch (Exception e) {
            return false;
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
                // pada SDK baru release() bisa melempar IOException; abaikan
            }
        }
    }

    private String bacaNama() {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME},
                null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null) {
                    return n;
                }
            }
        } catch (Exception ignored) {
        }
        return "video";
    }

    private static String formatWaktu(long ms) {
        long total = ms / 1000;
        long j = total / 3600;
        long m = (total % 3600) / 60;
        long d = total % 60;
        if (j > 0) {
            return String.format(Locale.US, "%d:%02d:%02d", j, m, d);
        }
        return String.format(Locale.US, "%d:%02d", m, d);
    }
}
