package com.novan.statusnovan;

import android.graphics.Color;
import android.view.View;

import androidx.activity.ComponentActivity;
import androidx.activity.EdgeToEdge;
import androidx.activity.SystemBarStyle;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** Android 15 ke atas memaksa tampilan penuh layar; kelas ini menjaga isi tidak tertutup bilah sistem. */
final class TepiLayar {

    private TepiLayar() {}

    static void aktifkan(ComponentActivity aktivitas) {
        SystemBarStyle gaya = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT);
        EdgeToEdge.enable(aktivitas, gaya, gaya);
    }

    static void terapkan(View akar) {
        final int kiri = akar.getPaddingLeft();
        final int atas = akar.getPaddingTop();
        final int kanan = akar.getPaddingRight();
        final int bawah = akar.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(akar, (v, insets) -> {
            androidx.core.graphics.Insets bilah = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(kiri + bilah.left, atas + bilah.top, kanan + bilah.right, bawah + bilah.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
    }
}
