package com.novan.statusnovan;

import android.net.Uri;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Keadaan proses pemotongan yang bertahan selama aplikasi hidup (dipakai layanan dan layar). Hanya dari thread utama. */
final class ProsesPotong {

    static final int IDLE = 0;
    static final int JALAN = 1;
    static final int SELESAI = 2;

    interface Pantau {
        void berubah();
    }

    static int status = IDLE;
    static int persen;
    static List<File> berkas = new ArrayList<>();
    static boolean tanpaSuara;
    static int indeksSatu;
    static boolean disimpan;
    static Uri sumber;
    static String nama = "";
    static String galatBaru;
    static boolean batalBaru;
    static PemotongVideo.Tugas tugas;

    private static Pantau pantau;

    private ProsesPotong() {}

    static void pasang(Pantau p) {
        pantau = p;
    }

    static boolean adaPantau() {
        return pantau != null;
    }

    static void mulaiBaru(Uri uri, String namaVideo) {
        status = JALAN;
        persen = 0;
        berkas = new ArrayList<>();
        tanpaSuara = false;
        indeksSatu = 0;
        disimpan = false;
        sumber = uri;
        nama = namaVideo;
        galatBaru = null;
        batalBaru = false;
        beri();
    }

    static void setPersen(int p) {
        persen = p;
        beri();
    }

    static void selesai(List<File> hasil, boolean tanpaSuaraBaru) {
        berkas = hasil;
        tanpaSuara = tanpaSuaraBaru;
        indeksSatu = 0;
        disimpan = false;
        status = SELESAI;
        beri();
    }

    static void gagal(String pesan) {
        status = IDLE;
        galatBaru = pesan;
        beri();
    }

    static void batal() {
        status = IDLE;
        batalBaru = true;
        beri();
    }

    static void reset() {
        status = IDLE;
        berkas = new ArrayList<>();
        disimpan = false;
    }

    static void batalkan() {
        if (tugas != null) {
            tugas.batalkan();
        }
    }

    private static void beri() {
        if (pantau != null) {
            pantau.berubah();
        }
    }
}
