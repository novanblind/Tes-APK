package com.novan.statusnovan;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private final ActivityResultLauncher<String[]> pemilih = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) {
                    bukaProses(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        TepiLayar.aktifkan(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        TepiLayar.terapkan(findViewById(R.id.root));
        findViewById(R.id.btn_pilih).setOnClickListener(v -> pemilih.launch(new String[]{"video/*"}));
    }

    private void bukaProses(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Tidak semua penyedia berkas mengizinkan izin permanen; izin sementara cukup.
        }
        Intent i = new Intent(this, ProcessActivity.class);
        i.setData(uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
    }
}
