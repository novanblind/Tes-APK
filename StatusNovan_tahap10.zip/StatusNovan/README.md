# Status Cutter Novan (tahap 3)

Memotong video untuk status WhatsApp lalu membagikannya. Dasar fitur: Status Cutter 3.4.

## Fitur
- Pilih video (tombol +), pratinjau
- Pilih bagian yang dipotong: atur awal dan akhir di posisi pemutar
- Panjang potongan: 30 / 60 / 90 detik (bawaan 90) atau atur sendiri (menit + detik)
- Potong tanpa encode ulang; tetap jalan saat pindah aplikasi (notifikasi progres, bisa dibatalkan)
- Bagikan semua sekaligus, atau satu per satu (potongan 1, lalu 2, dst.)
- Simpan ke galeri (Movies/StatusCutterNovan)
- Tanpa iklan, tanpa internet

- Tema terang atau gelap mengikuti pengaturan sistem

## Catatan
- Potongan pertama dimulai di bingkai kunci terdekat sebelum awal yang dipilih (bisa beberapa detik lebih awal).
- versionCode tidak diubah; hanya versionName yang dinaikkan.

## Target
minSdk 24 (Android 7), targetSdk 36 (Android 16). Tanpa kode native: satu APK untuk 64-bit dan 32-bit.

## Bangun dengan tanda tangan pribadi
Ganti blok `signingConfigs.release` di app/build.gradle dengan keystore Anda, lalu jalankan workflow `Bangun APK`.
