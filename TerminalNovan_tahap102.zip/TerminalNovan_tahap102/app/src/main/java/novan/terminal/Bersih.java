package novan.terminal;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Pembersihan sisa bangun APK dan bongkar APK, serta laporan pemakaian ruang (tahap 102).
 * Setiap bangun atau bongkar berhasil (APK hasil sudah tersalin ke Download), semua sisanya dibuang: hasil ekstrak proyek,
 * folder build dan .gradle, hasil bongkar, salinan zip masuk, cache Gradle sementara, berkas sementara.
 * Yang TIDAK pernah disentuh otomatis: android-sdk, android-ndk, .gradle-dist, pustaka Gradle (modules-2), paket Termux,
 * dan kode sumber proyek buatan sendiri.
 */
class Bersih {
    /** Penanda di dalam folder proyek yang diekstrak atau disalin oleh aplikasi. Hanya folder bertanda yang dihapus otomatis. */
    static final String TANDA = ".novan-ekstrak";
    /** Folder proyek yang terakhir dibangun lewat bangun-apk atau bangun-gradle (bukan di folder proyek hasil ekstrak). */
    static volatile File terakhir;
    /** Folder alat bangun: tidak pernah dimasuki saat mencari sisa bangun. */
    private static final List<String> ALAT = Arrays.asList("android-sdk", "android-ndk", ".gradle-dist", "usr");

    static File proyek() { return new File(Env.home, "proyek"); }
    static File bongkar() { return new File(Env.home, "bongkar"); }
    static File masuk() { return new File(Env.home, "masuk"); }
    static File gradle() { return new File(Env.home, ".gradle"); }
    static File pustaka() { return new File(Env.home, ".gradle/caches/modules-2"); }
    static File arsipApt() { return new File(Env.prefix, "var/cache/apt/archives"); }

    // ---------- alat dasar ----------

    /** Tautan simbolik (termasuk ke folder lain): jangan diikuti saat menghitung atau menghapus. */
    static boolean tautan(File f) {
        try {
            File p = f.getParentFile();
            if (p == null) return false;
            return !f.getCanonicalPath().equals(new File(p.getCanonicalFile(), f.getName()).getPath());
        } catch (IOException e) {
            return true;
        }
    }

    static long ukuran(File f) {
        try {
            if (!f.exists() || tautan(f)) return 0;
            if (f.isFile()) return f.length();
            long s = 0;
            File[] c = f.listFiles();
            if (c != null) for (File x : c) s += ukuran(x);
            return s;
        } catch (Throwable e) {
            return 0;
        }
    }

    /** Hapus berkas atau folder. Tautan simbolik hanya dilepas, isi tujuannya tidak disentuh. */
    static void hapus(File f) {
        if (!tautan(f)) {
            File[] c = f.listFiles();
            if (c != null) for (File x : c) hapus(x);
        }
        f.delete();
    }

    /** Hapus dan kembalikan ukuran yang dibebaskan. */
    static long hapusHitung(File f) {
        if (!f.exists()) return 0;
        long s = ukuran(f);
        hapus(f);
        return s;
    }

    static String fmt(long b) {
        Locale id = new Locale("id", "ID");
        if (b >= 1024L * 1024 * 1024) return String.format(id, "%.2f GB", b / (1024.0 * 1024 * 1024));
        if (b >= 1024L * 1024) return String.format(id, "%d MB", b / (1024 * 1024));
        return String.format(id, "%d KB", b / 1024);
    }

    private static boolean ada(File d, String n) { return new File(d, n).isFile(); }

    // ---------- isi yang dibersihkan ----------

    /**
     * Hapus hasil bangun di dalam satu proyek: folder build, .cxx, dan .gradle di tiap modul Gradle.
     * Folder hanya dihapus bila induknya benar-benar berkas Gradle, supaya folder bernama build milik kode tidak ikut.
     */
    static long hapusHasilBangun(File d, int dalam) {
        if (dalam > 4 || tautan(d)) return 0;
        File[] c = d.listFiles();
        if (c == null) return 0;
        boolean mod = ada(d, "build.gradle") || ada(d, "build.gradle.kts") || ada(d, "settings.gradle") || ada(d, "settings.gradle.kts");
        long n = 0;
        for (File x : c) {
            if (!x.isDirectory()) continue;
            String nm = x.getName();
            if (mod && (nm.equals("build") || nm.equals(".cxx") || nm.equals(".gradle"))) { n += hapusHitung(x); continue; }
            if (nm.equals("build") || nm.equals("src") || nm.equals(".git") || nm.equals("node_modules") || ALAT.contains(nm)) continue;
            n += hapusHasilBangun(x, dalam + 1);
        }
        return n;
    }

    /** Cache Gradle yang dibuat ulang otomatis. Pustaka unduhan (modules-2) sengaja tidak termasuk. */
    static List<File> cacheSementara() {
        List<File> r = new ArrayList<>();
        File g = gradle();
        File[] c = new File(g, "caches").listFiles();
        if (c != null) for (File x : c) {
            String n = x.getName();
            if (n.startsWith("transforms-") || n.startsWith("build-cache-") || n.startsWith("jars-")) r.add(x);
        }
        r.add(new File(g, "daemon"));
        r.add(new File(g, "native"));
        r.add(new File(g, ".tmp"));
        return r;
    }

    static long ukuranDaftar(List<File> l) {
        long s = 0;
        for (File f : l) s += ukuran(f);
        return s;
    }

    static long hapusApt() {
        long n = 0;
        File[] c = arsipApt().listFiles();
        if (c != null) for (File f : c) if (f.isFile() && f.getName().endsWith(".deb")) { n += f.length(); f.delete(); }
        return n;
    }

    // ---------- pembersihan otomatis sesudah bangun atau bongkar berhasil ----------

    /** Isi sebuah folder dihapus, foldernya sendiri tetap ada. */
    static long kosongkan(File d) {
        long n = 0;
        File[] c = d.listFiles();
        if (c != null) for (File f : c) n += hapusHitung(f);
        return n;
    }

    /**
     * Dipanggil sesudah bangun APK atau bongkar APK berhasil, saat APK hasil sudah tersalin ke Download.
     * Folder proyek diekstrak ulang tiap bangun, jadi sisa bangun tidak pernah dipakai lagi. Semuanya dibuang:
     * proyek hasil ekstrak, hasil bongkar, salinan zip masuk, cache Gradle sementara, berkas sementara, arsip apt.
     */
    static void otomatis() {
        try {
            long b = 0;
            File[] ps = proyek().listFiles();
            if (ps != null) for (File p : ps) {
                if (tautan(p)) { p.delete(); continue; }
                if (p.isDirectory() && ada(p, TANDA)) b += hapusHitung(p);       // hasil ekstrak aplikasi: dibuang semua
                else if (p.isDirectory()) b += hapusHasilBangun(p, 0);          // buatan sendiri: hanya hasil bangunnya
            }
            File t = terakhir;
            terakhir = null;
            if (t != null && t.isDirectory() && !t.equals(Env.home) && !tautan(t)) b += hapusHasilBangun(t, 0);
            b += kosongkan(bongkar());
            b += kosongkan(masuk());
            for (File f : cacheSementara()) b += hapusHitung(f);
            if (!Pkg.busy) { b += kosongkan(Env.tmp); b += hapusApt(); }
            if (b > 1024 * 1024) {
                Builder.out("Pembersihan otomatis: " + fmt(b) + " sisa bangun dibuang. APK hasil tetap ada di folder Download.");
            }
        } catch (Throwable e) {
            Builder.out("Pembersihan otomatis dilewati: " + e.getMessage());
        }
    }

    /** Dipanggil sesudah proyek sederhana (AndroidManifest.xml + src) selesai dibangun di aplikasi dan APK sudah tersalin. */
    static void sesudahSederhana(File build, String hasil) {
        try {
            if (hasil == null || hasil.isEmpty() || hasil.startsWith(build.getPath())) return;   // salinan belum ada: jangan hapus
            long b = hapusHitung(build);
            b += kosongkan(masuk());
            if (b > 1024 * 1024) Builder.out("Pembersihan otomatis: " + fmt(b) + " sisa bangun dibuang. APK hasil tetap ada di folder Download.");
        } catch (Throwable e) {
            Builder.out("Pembersihan otomatis dilewati: " + e.getMessage());
        }
    }

    // ---------- perintah ukuran dan bersihkan ----------

    private static boolean sibuk() {
        return MainActivity.novanBusy || Builder.busy || Pkg.busy || Progres.aktif;
    }

    static void ukuranCmd() {
        new Thread(() -> {
            try {
                Builder.out("Menghitung pemakaian ruang, mohon tunggu.");
                long proyek = ukuran(proyek()), bongkar = ukuran(bongkar()), masuk = ukuran(masuk());
                long cache = ukuranDaftar(cacheSementara()), apt = 0;
                File[] ap = arsipApt().listFiles();
                if (ap != null) for (File f : ap) if (f.isFile() && f.getName().endsWith(".deb")) apt += f.length();
                long bisa = proyek + bongkar + masuk + cache + apt;
                long ndk = ukuran(new File(Env.home, "android-ndk"));
                long sdk = ukuran(new File(Env.home, "android-sdk"));
                long dist = ukuran(new File(Env.home, ".gradle-dist"));
                long pus = ukuran(pustaka());
                long total = ukuran(Env.home.getParentFile());
                Builder.out("Bisa dibersihkan (perintah bersihkan): " + fmt(bisa));
                Builder.out("  Proyek hasil ekstrak: " + fmt(proyek));
                Builder.out("  Hasil bongkar APK: " + fmt(bongkar));
                Builder.out("  Salinan zip masuk: " + fmt(masuk));
                Builder.out("  Cache Gradle sementara: " + fmt(cache));
                Builder.out("  Arsip paket apt: " + fmt(apt));
                Builder.out("Alat bangun (jangan dihapus): " + fmt(ndk + sdk + dist + pus));
                Builder.out("  Android NDK: " + fmt(ndk));
                Builder.out("  Android SDK: " + fmt(sdk));
                Builder.out("  Gradle (.gradle-dist): " + fmt(dist));
                Builder.out("  Pustaka Gradle (modules-2): " + fmt(pus) + ". Dihapus hanya oleh: bersihkan semua");
                Builder.out("Total data aplikasi: " + fmt(total));
                Builder.say("Total data aplikasi " + fmt(total) + ". Bisa dibersihkan " + fmt(bisa));
            } catch (Throwable e) {
                Builder.out("Gagal menghitung ukuran: " + e.getMessage());
            }
        }).start();
    }

    /** bersihkan: sisa bangun. bersihkan semua: ditambah proyek buatan sendiri di folder proyek dan pustaka Gradle. */
    static void bersihkanCmd(String arg) {
        final boolean semua = arg.equals("semua");
        if (!arg.isEmpty() && !semua) {
            Builder.out("Pemakaian: bersihkan, atau bersihkan semua");
            return;
        }
        if (sibuk()) {
            Builder.out("Masih ada proses berjalan. Tunggu sampai selesai, lalu ulangi.");
            Builder.say("Masih ada proses berjalan. Tunggu sampai selesai");
            return;
        }
        new Thread(() -> {
            try {
                Builder.out("Membersihkan, mohon tunggu.");
                Builder.say("Membersihkan, mohon tunggu");
                long b = 0;
                File[] ps = proyek().listFiles();
                if (ps != null) for (File p : ps) {
                    if (tautan(p)) { p.delete(); continue; }
                    if (p.isDirectory() && !ada(p, TANDA) && !semua) b += hapusHasilBangun(p, 0);
                    else b += hapusHitung(p);
                }
                File[] bs = bongkar().listFiles();
                if (bs != null) for (File f : bs) b += hapusHitung(f);
                File[] ms = masuk().listFiles();
                if (ms != null) for (File f : ms) b += hapusHitung(f);
                for (File f : cacheSementara()) b += hapusHitung(f);
                b += hapusApt();
                b += kosongkan(Env.tmp);
                if (semua) {
                    long p = hapusHitung(pustaka());
                    b += p;
                    if (p > 0) Builder.out("Pustaka Gradle dihapus. Bangun berikutnya mengunduh ulang pustaka, jadi butuh internet, atau jalankan impor-alat lagi untuk memulihkannya dari bundel.");
                }
                Builder.out("Selesai. Ruang yang dibebaskan: " + fmt(b));
                Builder.say("Selesai. Dibebaskan " + fmt(b));
            } catch (Throwable e) {
                Builder.out("Pembersihan gagal: " + e.getMessage());
            }
        }).start();
    }

    /** Tandai folder proyek sebagai hasil ekstrak atau salinan aplikasi, supaya boleh dihapus otomatis. */
    static void tandai(File dest) {
        try { new File(dest, TANDA).createNewFile(); } catch (IOException e) { }
    }
}
