package novan.terminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import java.io.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    static ArrayList<String> lines = new ArrayList<>(), hist = new ArrayList<>();
    ArrayAdapter<String> ad;
    ListView list;
    EditText input;
    SharedPreferences sp;
    int hi = 0;
    static int mode = 0;
    static File cwd;
    static MainActivity front;
    static Context ctx;
    static final Handler H = new Handler(Looper.getMainLooper());
    static volatile Process proc;
    static volatile OutputStream stdin;
    static int cmdPos = -1;
    static String lastOut = "";
    boolean pendingStorage;
    static int auto;
    static String lastCur = "";
    static volatile Pty pty;
    static volatile Screen scr;
    static volatile boolean ptyMode, refreshPending;
    static final ArrayList<String> scrLines = new ArrayList<>();
    ArrayAdapter<String> ad2;
    static final String[] MODES = {"semua", "baris terakhir", "diam"};

    @Override protected void onCreate(Bundle b) {
        Tema.pasang(this);
        super.onCreate(b);
        setContentView(R.layout.main);
        Tema.bilah(this);
        // Target SDK 35: tampilan penuh layar (edge-to-edge) dipaksa sistem, jadi beri ruang untuk bilah sistem dan keyboard.
        findViewById(android.R.id.content).setOnApplyWindowInsetsListener((v, w) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = w.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.ime());
                v.setPadding(i.left, i.top, i.right, i.bottom);
            } else {
                v.setPadding(w.getSystemWindowInsetLeft(), w.getSystemWindowInsetTop(), w.getSystemWindowInsetRight(), w.getSystemWindowInsetBottom());
            }
            return w;
        });
        front = this;
        sp = getSharedPreferences("term", MODE_PRIVATE);
        layarNyala(sp.getBoolean("layar", true));
        mode = 0;
        if (hist.isEmpty()) {
            String h = sp.getString("hist", "");
            if (!h.isEmpty()) for (String x : h.split("\n")) hist.add(x);
            hi = hist.size();
        }
        ctx = getApplicationContext();
        Env.init(ctx);
        if (cwd == null) cwd = Env.home;
        boolean first = !sp.getBoolean("askedPerm", false);
        if (first) sp.edit().putBoolean("askedPerm", true).apply();
        pendingStorage = first;
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        else if (first && !storageOk()) { pendingStorage = false; H.postDelayed(() -> askStorage(), 300); }
        H.postDelayed(() -> Pkg.otomatis(), 2500);
        H.postDelayed(() -> askBattery(), 6000);
        list = findViewById(R.id.list);
        input = findViewById(R.id.input);
        ad = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lines);
        ad2 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, scrLines);
        list.setAdapter(ptyMode ? ad2 : ad);
        if (lines.isEmpty()) {
            add("Termux Data Novan siap. Ketik perintah lalu tekan Jalankan. Untuk membuat aplikasi, tekan Bangun APK. Ketik bantuan untuk daftar perintah.");
            add("Folder kerja: " + cwd.getPath());
            if (!storageOk()) add("Penyimpanan HP belum diizinkan. Buka Menu lainnya lalu pilih Izin penyimpanan, atau ketik: izin");
        }
        input.setOnEditorActionListener((v, id, e) -> { submit(); return true; });
        findViewById(R.id.bRun).setOnClickListener(v -> submit());
        findViewById(R.id.bStop).setOnClickListener(v -> hentikan());
        findViewById(R.id.bRead).setOnClickListener(v -> salinHasil());
        findViewById(R.id.bClear).setOnClickListener(v -> bersihkanLayar());
        findViewById(R.id.bApk).setOnClickListener(v -> { add("$ bangun-apk"); pilihProyek(); });
        findViewById(R.id.bMore).setOnClickListener(v -> menuLainnya());
        terimaBerbagi(getIntent());
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        terimaBerbagi(i);
    }

    /**
     * Zip proyek yang dibagikan atau dibuka dengan aplikasi ini dari aplikasi lain (mis. file manager):
     * disalin ke folder masuk di home, diekstrak, lalu langsung dibangun dengan alur Bangun APK.
     * Bila zip itu bundel peralatan (TerminalNovan-bundel-....zip), langsung diimpor otomatis.
     */
    void terimaBerbagi(Intent it) {
        if (it == null) return;
        String act = it.getAction();
        boolean kirim = Intent.ACTION_SEND.equals(act);
        if (!kirim && !Intent.ACTION_VIEW.equals(act)) return;
        if ((it.getFlags() & Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return;
        final Uri uri = kirim ? (Uri) it.getParcelableExtra(Intent.EXTRA_STREAM) : it.getData();
        final String tipe = it.getType();
        final boolean apk = kirim && tipe != null && tipe.toLowerCase().contains("package-archive");
        setIntent(new Intent(this, MainActivity.class)); // tandai sudah diproses, tidak diulang saat layar berputar
        if (uri == null) {
            add(apk ? "Tidak ada berkas APK yang diterima." : "Tidak ada berkas zip yang diterima.");
            H.postDelayed(() -> say(apk ? "Tidak ada berkas APK yang diterima" : "Tidak ada berkas zip yang diterima"), 600);
            return;
        }
        if (apk) {
            if (novanBusy || Pkg.busy || proc != null) {
                add("Masih ada proses berjalan. Tunggu sampai selesai, lalu bagikan APK lagi.");
                H.postDelayed(() -> say("Masih ada proses berjalan. Tunggu sampai selesai"), 600);
                return;
            }
            add("Menerima APK dari aplikasi lain, akan dibongkar jadi zip");
            H.postDelayed(() -> say("Menerima APK, mohon tunggu"), 600);
            new Thread(() -> {
                try {
                    File dir = new File(Env.home, "masuk");
                    Builder.del(dir);
                    dir.mkdirs();
                    final File z = new File(dir, namaBerkas(uri));
                    try (InputStream in = getContentResolver().openInputStream(uri); OutputStream o = new FileOutputStream(z)) {
                        if (in == null) throw new IOException("berkas tidak bisa dibuka");
                        Pkg.copy(in, o);
                    }
                    H.post(() -> { add("$ bongkar-apk " + z.getName()); Bongkar.jalankan(z, ""); });
                } catch (Exception e) {
                    H.post(() -> { add("Gagal menerima APK: " + e.getMessage()); say("Gagal menerima APK"); });
                }
            }).start();
            return;
        }
        if (Builder.busy) {
            add("Masih ada proses bangun berjalan. Tunggu sampai selesai, lalu bagikan zip lagi.");
            H.postDelayed(() -> say("Masih ada proses bangun berjalan. Tunggu sampai selesai"), 600);
            return;
        }
        add("Menerima zip dari aplikasi lain");
        H.postDelayed(() -> say("Menerima zip, mohon tunggu"), 600);
        new Thread(() -> {
            try {
                // Bundel peralatan (hasil ekspor-alat): otomatis diimpor, bukan dibangun sebagai proyek.
                boolean bundel;
                try (InputStream cek = getContentResolver().openInputStream(uri)) {
                    bundel = cek != null && Bundel.adalahBundel(cek);
                }
                if (bundel) {
                    if (Pkg.busy) {
                        H.post(() -> { add("Masih ada proses pkg berjalan. Tunggu sampai selesai, lalu bagikan bundel lagi."); say("Masih ada proses berjalan. Tunggu sampai selesai"); });
                        return;
                    }
                    H.post(() -> { add("Bundel peralatan terdeteksi. Menyalin bundel, bisa agak lama karena ukurannya besar."); say("Bundel peralatan terdeteksi. Menyalin, mohon tunggu"); });
                    File dir = Bundel.salinan();
                    Builder.del(dir);
                    dir.mkdirs();
                    final File z = new File(dir, namaBerkas(uri));
                    try (InputStream in = getContentResolver().openInputStream(uri); OutputStream o = new FileOutputStream(z)) {
                        if (in == null) throw new IOException("berkas tidak bisa dibuka");
                        Pkg.copy(in, o);
                    } catch (IOException e) {
                        Builder.del(dir);
                        throw new IOException(e.getMessage() + ". Pastikan ruang kosong di HP cukup (sekitar 3 GB)");
                    }
                    H.post(() -> { add("$ impor-alat " + z.getName()); Pkg.handle("impor " + z.getPath()); });
                    return;
                }
                File dir = new File(Env.home, "masuk");
                Builder.del(dir);
                dir.mkdirs();
                final File z = new File(dir, namaBerkas(uri));
                try (InputStream in = getContentResolver().openInputStream(uri); OutputStream o = new FileOutputStream(z)) {
                    if (in == null) throw new IOException("berkas tidak bisa dibuka");
                    Pkg.copy(in, o);
                }
                H.post(() -> ekstrakLaluBangun(z, null));
            } catch (Exception e) {
                H.post(() -> { add("Gagal menerima zip: " + e.getMessage()); say("Gagal menerima zip"); });
            }
        }).start();
    }

    String namaBerkas(Uri u) {
        String n = null;
        if ("content".equals(u.getScheme())) {
            try (android.database.Cursor c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) n = c.getString(0);
            } catch (Exception e) { }
        }
        if (n == null || n.isEmpty()) n = u.getLastPathSegment();
        if (n == null || n.isEmpty()) n = "proyek.zip";
        n = n.substring(n.lastIndexOf('/') + 1).replaceAll("[^A-Za-z0-9_.-]", "_");
        if (!n.toLowerCase().endsWith(".zip") && !n.toLowerCase().endsWith(".apk")) n += ".zip";
        return n;
    }

    /** Layar tetap menyala selama Termux Data Novan terbuka. */
    void layarNyala(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /** Muncul saat perintah gagal: tampilkan ujung keluaran dan tombol salin error. */
    void dialogError(final String cmd, final int code, final String keluaran) {
        String[] bs = keluaran.trim().split("\n");
        StringBuilder ujung = new StringBuilder();
        for (int i = Math.max(0, bs.length - 12); i < bs.length; i++) ujung.append(bs[i]).append('\n');
        final String semua = "$ " + cmd + "\n" + (keluaran.length() > 50000 ? keluaran.substring(keluaran.length() - 50000) : keluaran) + "\n[kode " + code + "]";
        new AlertDialog.Builder(this).setTitle("Perintah gagal, kode " + code).setMessage(ujung.toString())
            .setPositiveButton("Salin error", (d, w) -> {
                ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("error", semua));
                say("Error disalin");
            }).setNegativeButton("Tutup", null).show();
    }

    void hentikan() {
        if (pty != null) { pty.send("\u0003"); say("Perintah dihentikan"); }
        else if (proc != null) { proc.destroy(); say("Perintah dihentikan"); }
        else if (Builder.busy) say("Pembangunan APK sedang berjalan dan tidak bisa dihentikan. Tunggu sampai selesai");
        else say("Tidak ada perintah yang berjalan");
    }

    /** Tombol Salin hasil: menyalin hasil perintah terakhir, atau isi layar bila program interaktif berjalan. */
    void salinHasil() {
        String t;
        if (pty != null && scr != null) {
            StringBuilder b = new StringBuilder();
            for (String l : scr.snapshot()) if (!l.trim().isEmpty()) b.append(l.trim()).append('\n');
            t = b.toString();
        } else t = lastOut;
        if (t.trim().isEmpty()) { say("Belum ada hasil untuk disalin"); return; }
        ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("hasil", t));
        say(pty != null && scr != null ? "Isi layar disalin" : "Hasil terakhir disalin");
    }

    /** Membaca: isi layar bila program interaktif berjalan, bila tidak hasil perintah terakhir. */
    void bacakanHasil() {
        if (pty != null && scr != null) { readScreen(); return; }
        if (lastOut.trim().isEmpty()) { say("Belum ada hasil untuk dibacakan"); return; }
        String t = lastOut.trim().replace('\n', ' ');
        say(t.length() > 1500 ? t.substring(0, 1500) + ". Dipotong. Tekan tombol Salin hasil untuk hasil lengkap" : t);
    }

    void bersihkanLayar() {
        lines.clear(); cmdPos = -1; ad.notifyDataSetChanged(); say("Layar dibersihkan");
    }

    void menuLainnya() {
        final String[] n = {
            "Bongkar APK jadi zip",
            "Pengaturan tanda tangan dan keamanan APK",
            "Lihat kemajuan proses",
            "Izin penyimpanan",
            "Layar tetap menyala saat Terminal terbuka: " + (sp.getBoolean("layar", true) ? "hidup" : "mati") + ". Ketuk untuk mengganti",
            "Tema tampilan: " + Tema.nama(this) + ". Ketuk untuk mengganti",
            "Bacakan hasil terakhir atau isi layar",
            "Ekspor alat",
            "Impor alat",
            "Bantuan: daftar perintah"};
        new AlertDialog.Builder(this).setTitle("Menu lainnya").setItems(n, (d, i) -> {
            switch (i) {
                case 0: add("$ bongkar-apk"); Bongkar.pilih(this); break;
                case 1: BangunDialog.kelola(this); break;
                case 2: Progres.buka(); break;
                case 3: askStorage(); break;
                case 4: {
                    boolean on = !sp.getBoolean("layar", true);
                    sp.edit().putBoolean("layar", on).apply();
                    layarNyala(on);
                    say("Layar tetap menyala " + (on ? "hidup" : "mati"));
                    break;
                }
                case 5: Tema.pilih(this); break;
                case 6: bacakanHasil(); break;
                case 7: add("$ ekspor-alat"); Pkg.handle("ekspor"); break;
                case 8: Bundel.pilihImpor(this); break;
                default: bantuan(); break;
            }
        }).setNegativeButton("Tutup", null).show();
    }

    void bantuan() {
        add("Daftar perintah:");
        add("bangun-apk [folder]  : bangun APK, tanda tangan dan keamanan otomatis");
        add("buat-proyek <nama>   : buat proyek aplikasi contoh");
        add("buat-ttd <nama>      : buat tanda tangan pribadi baru");
        add("daftar-ttd           : lihat tanda tangan tersimpan");
        add("cari-ttd, impor-ttd  : cari dan masukkan berkas .p12");
        add("jelajah-ttd         : cari berkas .p12 di folder mana saja");
        add("pilih-ttd <nama>     : pilih tanda tangan, hapus-ttd, ekspor-ttd <nama>");
        add("penjaga-apk aktif / mati : atur penjaga tanda tangan");
        add("bangun-gradle [lokasi] : bangun proyek Gradle (.zip atau folder)");
        add("ekspor-alat [lokasi] [--tanpa-pustaka] : kumpulkan semua unduhan alat jadi satu zip bundel offline");
        add("impor-alat [lokasi] : pasang alat dari bundel offline tanpa internet");
        add("bongkar-apk [apk] [--tanpa-kode] [--tanpa-res] : bongkar APK (dari Download atau aplikasi terpasang) jadi zip di Download");
        add("Dari file manager     : tekan tahan zip proyek, pilih Bagikan atau Buka dengan, lalu pilih aplikasi ini. Langsung dibangun");
        add("./gradlew assembleDebug : ditempel lalu Jalankan, otomatis memakai alur Bangun APK");
        add("siap                 : siapkan alat membangun APK");
        add("ukuran               : lihat pemakaian ruang: yang bisa dibersihkan dan alat bangun");
        add("bersihkan [semua]    : buang sisa bangun lama. Dengan semua: juga proyek buatan sendiri di folder proyek dan pustaka Gradle");
        add("cd <folder>          : pindah folder. izin: izinkan penyimpanan");
        add("nano, vim, top, less : program interaktif, pakai tombol Tombol khusus dan Salin hasil (atau Menu lainnya, Bacakan)");
        say("Daftar perintah ditampilkan di layar");
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 1 && pendingStorage) {
            pendingStorage = false;
            if (!storageOk()) H.postDelayed(() -> askStorage(), 300);
        } else if (code == 2) {
            say(storageOk() ? "Izin penyimpanan aktif" : "Izin penyimpanan ditolak");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        front = this;
        visible = true;
        Progres.pulihkan();
        if (tundaTanya != null) { String q = tundaTanya, k = tundaKonteks == null ? "" : tundaKonteks; tundaTanya = null; tundaKonteks = null; dialogJawab(q, proc, k, false); }
        list.setAdapter(ptyMode ? ad2 : ad);
        if (ptyMode) refreshScreen();
        if (front != null) { front.ad.notifyDataSetChanged(); front.list.setSelection(lines.size() - 1); }
    }

    @Override protected void onPause() {
        visible = false;
        super.onPause();
    }

    void askBattery() {
        if (sp.getBoolean("askedBatt", false)) return;
        android.os.PowerManager pm = getSystemService(android.os.PowerManager.class);
        if (pm.isIgnoringBatteryOptimizations(getPackageName())) return;
        sp.edit().putBoolean("askedBatt", true).apply();
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
            say("Pilih Izinkan, supaya Termux Data Novan tetap berjalan di latar belakang");
        } catch (Exception e) { }
    }

    @Override protected void onDestroy() {
        if (front == this) front = null;
        Progres.lepas();
        super.onDestroy();
    }

    static volatile boolean visible, novanBusy, tungguBangun;
    /** Perintah bangun-gradle lengkap (lokasi proyek dan tugas) yang menunggu alat selesai disiapkan. */
    static volatile String perintahTunggu = "";
    static volatile String ttdSetelah;
    /** Tugas Gradle dari perintah yang ditempel (mis. assembleRelease); null berarti bawaan assembleDebug. */
    static String tugasKhusus;

    static void say(String s) { if (front != null && visible) front.list.announceForAccessibility(s); }

    static void add(String s) {
        if (Progres.aktif || Progres.usai) Progres.catat(s);
        if (lines.size() > 3000) { lines.subList(0, 500).clear(); cmdPos = -1; }
        lines.add(s);
        KeepAliveService.progress(ctx, s);
        MainActivity f = front;
        if (f != null) {
            f.ad.notifyDataSetChanged();
            f.list.setSelection(lines.size() - 1);
        }
    }

    void ins(String t, String nama) {
        int a = Math.max(0, input.getSelectionStart()), b = Math.max(0, input.getSelectionEnd());
        input.getText().replace(Math.min(a, b), Math.max(a, b), t);
        say(nama);
    }

    static void addMatches(ArrayList<String> c, File dir, String prefix, boolean mark) {
        String[] names = dir.list();
        if (names == null) return;
        java.util.Arrays.sort(names);
        for (String n : names) {
            if (!n.startsWith(prefix) || (n.startsWith(".") && !prefix.startsWith("."))) continue;
            String e = mark && new File(dir, n).isDirectory() ? n + "/" : n;
            if (!c.contains(e)) c.add(e);
        }
    }

    void ctrlD() {
        if (pty != null) { pty.send("\u0004"); say("Ctrl+D dikirim"); return; }
        if (proc != null && stdin != null) {
            try { stdin.close(); say("Ctrl+D: akhir input dikirim"); } catch (Exception e) { say("Gagal menutup input"); }
        } else say("Tidak ada perintah berjalan");
    }

    void ctrlDialog() {
        if (pty == null) { say("Ctrl+huruf hanya untuk program interaktif seperti nano dan top"); return; }
        String[] it = new String[26];
        for (int i = 0; i < 26; i++) it[i] = "Ctrl+" + (char) ('A' + i);
        new AlertDialog.Builder(this).setTitle("Kirim Ctrl+huruf").setItems(it, (d, i) -> {
            if (pty != null) { pty.send(String.valueOf((char) (i + 1))); say(it[i] + " dikirim"); }
        }).show();
    }

    void readScreen() {
        Screen sc = scr;
        if (pty == null || sc == null) { say("Tidak ada program interaktif"); return; }
        StringBuilder b = new StringBuilder();
        for (String l : sc.snapshot()) if (!l.trim().isEmpty()) b.append(l.trim()).append(". ");
        String t = b.toString();
        say(t.isEmpty() ? "Layar kosong" : t.length() > 1500 ? t.substring(0, 1500) + ". Dipotong" : t);
    }

    static void refreshScreen() {
        if (refreshPending) return;
        refreshPending = true;
        H.postDelayed(() -> {
            refreshPending = false;
            Screen sc = scr;
            MainActivity f = front;
            if (sc == null || f == null || !ptyMode) return;
            scrLines.clear();
            scrLines.addAll(sc.snapshot());
            f.ad2.notifyDataSetChanged();
            if (auto == 1) {
                String t = sc.cursorLine();
                if (!t.equals(lastCur)) { lastCur = t; say(t.isEmpty() ? "Baris kosong" : t); }
            }
        }, 120);
    }

    static boolean wantsPty(String cmd) {
        String c = cmd.trim();
        if (c.startsWith("pty ")) return true;
        String[] t = c.split("\\s+");
        String w = t[0].substring(t[0].lastIndexOf('/') + 1);
        if (w.equals("top")) { for (String x : t) if (x.equals("-b") || x.startsWith("-b")) return false; return true; }
        for (String x : new String[]{"nano", "vi", "vim", "less", "more", "man", "htop", "watch", "tmux", "ncdu", "mc", "emacs"})
            if (w.equals(x)) return true;
        return false;
    }

    static boolean runPty(String cmd) {
        if (cmd.trim().startsWith("pty ")) cmd = cmd.trim().substring(4);
        Pty p = Pty.open(cmd, cwd.getPath(), 24, 80);
        if (p == null) return false;
        KeepAliveService.begin(ctx);
        final Screen sc = new Screen(24, 80);
        scr = sc; pty = p; ptyMode = true;
        scrLines.clear();
        lastCur = "";
        if (front != null) front.list.setAdapter(front.ad2);
        say("Program interaktif berjalan. Gunakan Salin hasil, Menu lainnya untuk membacakan layar, Kirim tombol, dan Ctrl+huruf");
        new Thread(() -> {
            try {
                InputStreamReader r = new InputStreamReader(p.in, "UTF-8");
                char[] buf = new char[4096];
                int n;
                while ((n = r.read(buf)) > 0) { sc.write(new String(buf, 0, n)); refreshScreen(); }
            } catch (Exception e) { }
            int code = Pty.waitFor(p.pid);
            p.close();
            KeepAliveService.end(ctx);
            final int fc = code;
            H.post(() -> {
                ptyMode = false; pty = null; scr = null;
                if (front != null) { front.list.setAdapter(front.ad); }
                StringBuilder o = new StringBuilder();
                ArrayList<String> all = new ArrayList<>(sc.scroll);
                if (!sc.alt) all.addAll(sc.snapshot());
                for (String l : all) if (!l.trim().isEmpty()) { add(l); o.append(l).append('\n'); }
                lastOut = o.toString();
                add("[selesai, kode " + fc + "]");
                say("Program interaktif selesai, kode " + fc);
            });
        }).start();
        return true;
    }

    void tab() {
        if (pty != null) { pty.send("\t"); say("Tab dikirim"); return; }
        String t = input.getText().toString();
        int cur = input.getSelectionStart();
        if (cur < 0) cur = t.length();
        String head = t.substring(0, cur), tail = t.substring(cur);
        int st = head.lastIndexOf(' ') + 1;
        String tok = head.substring(st), dirPart = "", prefix;
        ArrayList<String> c = new ArrayList<>();
        if (head.substring(0, st).trim().isEmpty() && tok.indexOf('/') < 0) {
            prefix = tok;
            addMatches(c, new File("/system/bin"), prefix, false);
            addMatches(c, new File("/system/xbin"), prefix, false);
        } else {
            int sl = tok.lastIndexOf('/');
            dirPart = sl >= 0 ? tok.substring(0, sl + 1) : "";
            prefix = tok.substring(sl + 1);
            File dir = dirPart.isEmpty() ? cwd : dirPart.startsWith("/") ? new File(dirPart) : new File(cwd, dirPart);
            addMatches(c, dir, prefix, true);
        }
        if (c.isEmpty()) { say("Tidak ada kecocokan"); return; }
        String lcp = c.get(0);
        for (String x : c) while (!x.startsWith(lcp)) lcp = lcp.substring(0, lcp.length() - 1);
        String done = head.substring(0, st) + dirPart + lcp + (c.size() == 1 && !lcp.endsWith("/") ? " " : "");
        input.setText(done + tail);
        input.setSelection(done.length());
        if (c.size() == 1) { say(lcp); return; }
        StringBuilder b = new StringBuilder(c.size() + " pilihan: ");
        for (int i = 0; i < Math.min(8, c.size()); i++) b.append(i > 0 ? ", " : "").append(c.get(i));
        if (c.size() > 8) b.append(", dan lainnya");
        say(b.toString());
    }

    static boolean adaGradle(File p) {
        return new File(p, "gradlew").exists() || new File(p, "build.gradle").exists()
            || new File(p, "build.gradle.kts").exists() || new File(p, "settings.gradle").exists();
    }

    /** Proyek berbasis Node: React Native, Capacitor, Ionic (ada folder android) atau Cordova (ada config.xml). */
    static boolean adaNode(File p) {
        return new File(p, "package.json").exists()
            && (new File(p, "android").isDirectory() || new File(p, "config.xml").exists());
    }

    /** Folder hasil bongkar apktool (ada apktool.yml, atau apktool.json dari Apktool M). */
    static boolean adaApktool(File p) { return new File(p, "apktool.yml").exists() || new File(p, "apktool.json").exists(); }

    static String kutip(String s) { return "'" + s.replace("'", "'\\''") + "'"; }

    static File cariAkar(File d, int dalam) {
        if (Builder.proyekSederhana(d) || adaGradle(d) || adaApktool(d)) return d;
        if (adaNode(d)) { File a = new File(d, "android"); return a.isDirectory() && adaGradle(a) ? a : d; }
        File[] fs = d.listFiles();
        if (fs == null || dalam <= 0) return null;
        java.util.Arrays.sort(fs);
        for (File f : fs) if (f.isDirectory()) { File r = cariAkar(f, dalam - 1); if (r != null) return r; }
        return null;
    }

    /** Langkah awal Bangun APK: pilih proyek, yaitu folder kerja atau salah satu berkas .zip di folder Download. */
    /** Dipanggil setelah tanda tangan dan penjaga ditentukan (otomatis dari pengaturan): bangun proyek sederhana di aplikasi, atau proyek Gradle lewat bangun-gradle. */
    void mulaiBangun(String arg) {
        final String tg = tugasKhusus;
        tugasKhusus = null;
        File p = arg.isEmpty() ? cwd : arg.startsWith("/") ? new File(arg) : new File(cwd, arg);
        if (Builder.proyekSederhana(p)) { Builder.build(arg); return; }
        Bersih.terakhir = p;
        String ttd = Ks.aktif();
        boolean pribadi = !ttd.equals("bawaan");
        try {
            if (pribadi && Penjaga.aktif()) add(Penjaga.pasangGradle(p, Ks.muat(ttd).getProperty("sidikJari")));
            else Penjaga.lepasGradle(p);
        } catch (Throwable e) { add("Penjaga tanda tangan dilewati: " + e.getMessage()); }
        ttdSetelah = null;
        File berkasTtd = new File(Env.home, ".novan-ttd");
        berkasTtd.delete();
        if (pribadi) {
            try {
                java.util.Properties pr = Ks.muat(ttd);
                Ks.write(berkasTtd, "TTD_NAMA=" + kutip(ttd) + "\nTTD_P12=" + kutip(Ks.p12(ttd).getPath())
                    + "\nTTD_SANDI=" + kutip(String.valueOf(pr.getProperty("sandi"))) + "\nTTD_ALIAS=" + kutip(String.valueOf(pr.getProperty("alias")))
                    + "\nTTD_SIDIK=" + kutip(String.valueOf(pr.getProperty("sidikJari"))) + "\n");
                ttdSetelah = ttd;
            } catch (Throwable e) { add("Tanda tangan pribadi tidak bisa disiapkan: " + e.getMessage() + ". Memakai tanda tangan bawaan proyek."); }
        }
        add(ttdSetelah != null ? "Membangun dengan tanda tangan pribadi " + ttd + ", langsung ditandatangani tanpa tanda tangan ulang." : "Membangun dengan tanda tangan bawaan proyek.");
        say("Membangun proyek Gradle");
        run("bangun-gradle " + kutip(p.getPath()) + (tg != null ? " " + kutip(tg) : ""));
    }

    void pilihProyek() {
        final ArrayList<String> nama = new ArrayList<>();
        final ArrayList<File> zipList = new ArrayList<>();
        boolean adaFolder = Builder.proyekSederhana(cwd) || adaGradle(cwd) || adaNode(cwd) || adaApktool(cwd);
        if (adaFolder) nama.add("Folder kerja: " + cwd.getName());
        nama.add("Jelajahi folder lain (zip atau folder proyek di mana saja)...");
        File[] zs = new File("/sdcard/Download").listFiles((d, nm) -> nm.toLowerCase().endsWith(".zip"));
        if (zs != null) {
            java.util.Arrays.sort(zs, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
            for (int i = 0; i < zs.length && i < 15; i++) { zipList.add(zs[i]); nama.add("Download: " + zs[i].getName()); }
        }
        if (zipList.isEmpty() && !storageOk()) add("Izin penyimpanan belum aktif, jadi isi folder Download tidak terbaca. Buka Menu lainnya, Izin penyimpanan.");
        final int off = adaFolder ? 1 : 0;
        new AlertDialog.Builder(this).setTitle("Pilih proyek yang dibangun").setItems(nama.toArray(new String[0]), (d, i) -> {
            if (adaFolder && i == 0) { bangunApk(""); return; }
            if (i == off) {
                Jelajah.buka(this, "Pilih zip atau folder proyek", new String[]{".zip"}, true, f -> bangunDariPilihan(f));
                return;
            }
            bangunDariPilihan(zipList.get(i - off - 1));
        }).setNegativeButton("Batal", (d, w) -> say("Dibatalkan")).show();
    }

    /** Zip dari mana saja: diekstrak lalu dibangun. Folder proyek di penyimpanan: disalin dulu ke home, lalu dibangun. */
    void bangunDariPilihan(final File f) {
        if (f.isFile()) { ekstrakLaluBangun(f, null); return; }
        final File hp = Env.home;
        boolean didalamHome = false;
        try { didalamHome = f.getCanonicalPath().startsWith(hp.getCanonicalPath() + "/"); } catch (IOException e) { }
        if (didalamHome) {
            File root = cariAkar(f, 3);
            if (root == null) { add("Folder ini bukan proyek yang dikenali: " + f.getPath()); say("Folder ini bukan proyek yang dikenali"); return; }
            bangunApk(root.getPath());
            return;
        }
        add("Menyalin folder " + f.getName() + " ke folder proyek di home, supaya bisa dibangun. Mohon tunggu.");
        say("Menyalin folder proyek, mohon tunggu");
        new Thread(() -> {
            try {
                File dest = new File(hp, "proyek/" + f.getName().replaceAll("[^A-Za-z0-9_.-]", "_"));
                Builder.del(dest);
                dest.mkdirs();
                salinFolder(f, dest);
                Bersih.tandai(dest);
                final File root = cariAkar(dest, 3);
                H.post(() -> {
                    if (root == null) { add("Folder ini bukan proyek yang dikenali: " + f.getPath() + ". Harus ada AndroidManifest.xml dan src, berkas Gradle, atau apktool.yml / apktool.json."); say("Folder ini bukan proyek yang dikenali"); }
                    else bangunApk(root.getPath());
                });
            } catch (Exception e) {
                H.post(() -> { add("Gagal menyalin folder: " + e.getMessage()); say("Gagal menyalin folder"); });
            }
        }).start();
    }

    static void salinFolder(File src, File dst) throws IOException {
        File[] fs = src.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.getName().equals(".git")) continue;
            File t = new File(dst, f.getName());
            if (f.isDirectory()) {
                // lewati tautan simbolik supaya tidak berputar
                if (!f.getCanonicalPath().equals(new File(src.getCanonicalPath(), f.getName()).getPath())) continue;
                t.mkdirs();
                salinFolder(f, t);
            } else {
                try (InputStream in = new FileInputStream(f); OutputStream o = new FileOutputStream(t)) { Pkg.copy(in, o); }
                if (f.canExecute()) t.setExecutable(true, false);
            }
        }
    }

    /**
     * Satu pintu untuk tombol Bangun APK dan perintah bangun-apk. Proyek sederhana (AndroidManifest.xml + src)
     * dibangun di dalam aplikasi lewat otomatis: tanda tangan dan keamanan penjaga mengikuti pengaturan.
     * Proyek Gradle diteruskan ke bangun-gradle.
     */
    static final java.util.regex.Pattern P_BG = java.util.regex.Pattern.compile(
        "^bangun-gradle(?:\\s+('[^']*'|\"[^\"]*\"|\\S+))?(?:\\s+(\\S+))?$");

    /**
     * bangun-gradle yang diketik langsung memakai alur yang sama dengan tombol Bangun APK:
     * tanda tangan pribadi dan keamanan penjaga otomatis, dialog persen, salinan ke Download, pilihan Buka dengan.
     * Boleh berisi lokasi zip atau folder proyek, dan nama tugas. Tanpa lokasi: folder kerja, atau zip terbaru di Download.
     */
    boolean bangunGradleDariPerintah(String cmd) {
        java.util.regex.Matcher m = P_BG.matcher(cmd.trim());
        if (!m.matches()) return false;
        String a = m.group(1) == null ? "" : m.group(1).replaceAll("^['\"]|['\"]$", "");
        String tugas = m.group(2);
        if (a.startsWith("~")) a = Env.home.getPath() + a.substring(1);
        File f = null;
        if (a.isEmpty()) {
            if (adaGradle(cwd)) f = cwd;
            else {
                File[] zs = new File("/sdcard/Download").listFiles((d, nm) -> nm.toLowerCase().endsWith(".zip"));
                if (zs != null) for (File z : zs) if (f == null || z.lastModified() > f.lastModified()) f = z;
            }
        } else f = a.startsWith("/") ? new File(a) : new File(cwd, a);
        if (f == null) return false;
        if (f.isFile() && f.getName().toLowerCase().endsWith(".zip")) {
            add("bangun-gradle dikenali. Dijalankan dengan alur Bangun APK: tanda tangan pribadi dan keamanan penjaga otomatis.");
            say("Memakai alur Bangun APK");
            ekstrakLaluBangun(f, tugas);
            return true;
        }
        if (f.isDirectory()) {
            File root = cariAkar(f, 3);
            if (root == null) return false;
            add("bangun-gradle dikenali. Dijalankan dengan alur Bangun APK: tanda tangan pribadi dan keamanan penjaga otomatis.");
            say("Memakai alur Bangun APK");
            bangunApk(root.getPath(), tugas);
            return true;
        }
        return false;
    }

    /** Ekstrak zip proyek ke folder proyek di home, lalu bangun dengan alur Bangun APK. */
    void ekstrakLaluBangun(final File z, final String tugas) {
        say("Mengekstrak " + z.getName() + ", mohon tunggu");
        add("Mengekstrak " + z.getName());
        new Thread(() -> {
            try {
                File dest = new File(Env.home, "proyek/" + z.getName().replaceAll("(?i)\\.zip$", "").replaceAll("[^A-Za-z0-9_.-]", "_"));
                Builder.del(dest);
                dest.mkdirs();
                Pkg.extractZip(z, dest);
                Bersih.tandai(dest);
                final File root = cariAkar(dest, 3);
                H.post(() -> {
                    if (root == null) { add("Proyek tidak dikenali di dalam " + z.getName() + ". Harus ada AndroidManifest.xml dan folder src, atau berkas Gradle."); say("Proyek tidak dikenali di dalam zip"); }
                    else bangunApk(root.getPath(), tugas);
                });
            } catch (Exception e) {
                H.post(() -> { add("Gagal mengekstrak: " + e.getMessage()); say("Gagal mengekstrak zip"); });
            }
        }).start();
    }

    void bangunApk(String arg) { bangunApk(arg, null); }

    void bangunApk(String arg, String tugas) {
        tugasKhusus = tugas;
        File p = arg.isEmpty() ? cwd : arg.startsWith("/") ? new File(arg) : new File(cwd, arg);
        if (Builder.proyekSederhana(p)) { BangunDialog.mulai(this, arg); return; }
        if (adaGradle(p) || adaNode(p) || adaApktool(p)) { BangunDialog.mulai(this, arg); return; }
        add("Tidak ada proyek di " + p.getPath() + ". Pindah ke folder proyek dengan perintah cd, atau buat contoh dengan: buat-proyek nama");
        say("Tidak ada proyek di folder ini. Pindah dengan cd, atau ketik buat-proyek lalu nama");
    }

    void history(int d) {
        if (hist.isEmpty()) { say("Riwayat kosong"); return; }
        hi = Math.max(0, Math.min(hist.size() - 1, hi + d));
        input.setText(hist.get(hi));
        input.setSelection(input.length());
        say(hist.get(hi));
    }

    void submit() {
        if (pty != null) {
            String raw = input.getText().toString();
            input.setText("");
            pty.send(raw + "\r");
            say(raw.isEmpty() ? "Enter dikirim" : "Terkirim");
            return;
        }
        String cmd = input.getText().toString().trim();
        if (cmd.isEmpty()) return;
        input.setText("");
        hist.add(cmd);
        while (hist.size() > 100) hist.remove(0);
        sp.edit().putString("hist", TextUtils.join("\n", hist)).apply();
        hi = hist.size();
        if (proc != null) {
            add("> " + cmd);
            try { stdin.write((cmd + "\n").getBytes()); stdin.flush(); } catch (Exception e) { add("Gagal kirim input"); }
            return;
        }
        add("$ " + cmd);
        if (cmd.equals("izin")) { askStorage(); return; }
        if (cmd.equals("bangun-apk") || cmd.startsWith("bangun-apk ")) {
            String ar = cmd.substring(10).trim();
            if (ar.isEmpty()) pilihProyek(); else bangunApk(ar);
            return;
        }
        if (cmd.equals("bantuan") || cmd.equals("help")) { bantuan(); return; }
        if (cmd.equals("tanda-tangan")) { BangunDialog.kelola(this); return; }
        if (cmd.startsWith("buat-proyek ")) { Builder.buat(cmd.substring(12).trim()); return; }
        if (cmd.startsWith("buat-ttd ")) { Ks.buat(cmd.substring(9).trim()); return; }
        if (cmd.equals("cari-ttd")) { Ks.cariCmd(); return; }
        if (cmd.equals("jelajah-ttd")) { Ks.jelajahCmd(this); return; }
        if (cmd.startsWith("impor-ttd ")) { Ks.impor(cmd.substring(10).trim()); return; }
        if (cmd.equals("daftar-ttd")) { Ks.daftarCmd(); return; }
        if (cmd.startsWith("pilih-ttd ")) { Ks.pilih(cmd.substring(10).trim()); return; }
        if (cmd.startsWith("hapus-ttd ")) { Ks.hapus(cmd.substring(10).trim()); return; }
        if (cmd.startsWith("ekspor-ttd ")) { Ks.ekspor(cmd.substring(11).trim()); return; }
        if (cmd.equals("penjaga-apk")) {
            add(Penjaga.aktif() ? "Penjaga tanda tangan: aktif. Dipasang ke APK hasil bangun-apk bila memakai tanda tangan pribadi. Matikan: penjaga-apk mati"
                : "Penjaga tanda tangan: nonaktif. Nyalakan: penjaga-apk aktif");
            say(Penjaga.aktif() ? "Penjaga tanda tangan aktif" : "Penjaga tanda tangan nonaktif");
            return;
        }
        if (cmd.equals("penjaga-apk aktif") || cmd.equals("penjaga-apk mati")) {
            boolean on = cmd.endsWith("aktif");
            Penjaga.set(on);
            add("Penjaga tanda tangan sekarang: " + (on ? "aktif" : "nonaktif") + (on ? " (hanya berlaku saat bangun-apk memakai tanda tangan pribadi)" : ""));
            say("Penjaga tanda tangan " + (on ? "diaktifkan" : "dimatikan"));
            return;
        }
        if (cmd.equals("bongkar-apk") || cmd.startsWith("bongkar-apk ")) { Bongkar.perintah(this, cmd.substring(11).trim()); return; }
        if (cmd.equals("siap")) { Pkg.handle("siap"); return; }
        if (cmd.equals("ukuran")) { Bersih.ukuranCmd(); return; }
        if (cmd.equals("bersihkan") || cmd.startsWith("bersihkan ")) { Bersih.bersihkanCmd(cmd.substring(9).trim()); return; }
        if (cmd.equals("ekspor-alat") || cmd.startsWith("ekspor-alat ")) { Pkg.handle("ekspor " + cmd.substring(11).trim()); return; }
        if (cmd.equals("impor-alat") || cmd.startsWith("impor-alat ")) {
            String ar = cmd.substring(10).trim();
            if (ar.isEmpty()) Bundel.pilihImpor(this); else Pkg.handle("impor " + ar);
            return;
        }
        if (cmd.equals("pkg") || cmd.startsWith("pkg ")) {
            String a = cmd.substring(3).trim();
            if (a.startsWith("zip ")) { Pkg.handle("install " + a.substring(4).trim()); return; }
            if (a.equals("bootstrap") || !new File(Env.prefix, "bin/pkg").exists()) { Pkg.handle(a); return; }
            run(cmd); return;
        }
        if (cmd.equals("lingkungan")) { for (String l : Env.info().split("\n")) add(l); say("Info lingkungan ditampilkan"); return; }
        if (cmd.equals("uji-eksekusi")) { String r = Env.selfTest(); add(r); say(r); return; }
        if (cmd.equals("cd") || cmd.startsWith("cd ")) { cd(cmd.length() > 3 ? cmd.substring(3).trim() : ""); return; }
        if (bangunGradleDariPerintah(cmd)) return;
        if (bangunDariPerintah(cmd)) return;
        run(cmd);
    }

    static final java.util.regex.Pattern P_BANGUN = java.util.regex.Pattern.compile("(?i)(bangun|gradlew|assemble\\w*|build[\\w.-]*\\.sh)");
    static volatile long tanyaTerakhir, tanyaTutupWaktu;
    static volatile String tanyaTutup = "";
    static AlertDialog dlgTanya;
    static String tundaTanya, tundaKonteks;

    /** Dibaca dari thread utama sementara thread perintah masih menulis, jadi galat dianggap kosong. */
    private static String ekorAman(StringBuilder b) {
        try { return ekor(b.toString()); } catch (Throwable e) { return ""; }
    }

    private static String ekor(String konteks) {
        return konteks.length() > 3000 ? konteks.substring(konteks.length() - 3000) : konteks;
    }

    /** Baris tanpa akhir baris yang berhenti mengalir adalah pertanyaan yang menunggu jawaban. */
    static void cekTanya(final String t, final Process pp, StringBuilder keluaran) {
        if (!Tanya.mirip(t)) return;
        long now = System.currentTimeMillis();
        if (now - tanyaTerakhir < 3000) return;
        // Pertanyaan yang baru saja ditutup pengguna tidak ditampilkan lagi.
        if (t.trim().equals(tanyaTutup) && now - tanyaTutupWaktu < 60000) return;
        tanyaTerakhir = now;
        final String k = ekor(keluaran.toString());
        H.post(() -> dialogJawab(t.trim(), pp, k, false));
    }

    static void dialogJawab(String tanya, Process pp) { dialogJawab(tanya, pp, "", false); }

    /**
     * Dialog pilihan jawaban untuk perintah yang menunggu masukan, supaya pengguna tidak perlu mengetik.
     * Pilihan disusun dari pertanyaannya: y/n, huruf lain, menu bernomor, atau tekan Enter.
     * Bila diam (tanpa pertanyaan jelas), baris keluaran terakhir yang dibaca.
     */
    static void dialogJawab(final String tanya, final Process pp, final String konteks, final boolean diam) {
        if (proc == null || proc != pp) return;
        final MainActivity a = front;
        if (a == null || !visible) { tundaTanya = tanya; tundaKonteks = konteks; return; }
        if (dlgTanya != null && dlgTanya.isShowing()) return;
        final String soal = diam ? Tanya.barisAkhir(konteks) : tanya;
        final Tanya q = Tanya.susun(soal, konteks);
        final String judul = diam ? (tanya + (soal.isEmpty() ? "" : " " + soal)) : tanya;
        say("Perintah menunggu jawaban. " + judul);
        if (q.sandi) { ketikJawaban(a, judul, true); return; }
        final String[] n = q.label.toArray(new String[0]);
        final AlertDialog.Builder bd = new AlertDialog.Builder(a)
            .setTitle(judul.length() > 150 ? judul.substring(0, 150) : judul)
            .setItems(n, (d, i) -> {
                String k = q.kirim.get(i);
                if (k.equals(Tanya.KETIK)) ketikJawaban(a, judul, false);
                else if (k.equals(Tanya.TUTUP)) { tanyaTutup = soal.trim(); tanyaTutupWaktu = System.currentTimeMillis(); }
                else kirimJawaban(k);
            })
            .setOnCancelListener(d -> { tanyaTutup = soal.trim(); tanyaTutupWaktu = System.currentTimeMillis(); });
        dlgTanya = bd.show();
    }

    static void ketikJawaban(final MainActivity a, String judul, boolean sandi) {
        final EditText et = new EditText(a);
        et.setHint(sandi ? "Sandi" : "Jawaban");
        et.setSingleLine(true);
        // Sandi dibuat terlihat supaya pengguna pembaca layar bisa memeriksa yang diketik.
        if (sandi) et.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        et.setContentDescription(sandi ? "Kolom sandi" : "Kolom jawaban");
        new AlertDialog.Builder(a).setTitle(judul.length() > 150 ? judul.substring(0, 150) : judul).setView(et)
            .setPositiveButton("Kirim", (d, w) -> kirimJawaban(et.getText().toString(), sandi))
            .setNegativeButton("Batal", null).show();
    }

    static void kirimJawaban(String s) { kirimJawaban(s, false); }

    static void kirimJawaban(String s, boolean rahasia) {
        if (proc == null || stdin == null) { say("Perintah sudah selesai"); return; }
        add("> " + (s.isEmpty() ? "(Enter)" : rahasia ? "(sandi dikirim)" : s));
        try { stdin.write((s + "\n").getBytes()); stdin.flush(); } catch (Exception e) { add("Gagal mengirim jawaban"); }
    }

    /** Cari lokasi berkas .apk terakhir yang disebut di keluaran dan benar-benar ada. */
    static String cariApk(String keluaran) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(/[^\\s'\"]+\\.apk)").matcher(keluaran);
        String r = null;
        while (m.find()) if (new File(m.group(1)).isFile()) r = m.group(1);
        return r;
    }

    /** APK hasil Gradle yang baru dibuat (sejak waktu t0) di folder kerja, subfoldernya, atau modul di dalamnya. */
    static String apkTerbaru(File dasar, long t0) {
        File[] akar = dasar.listFiles();
        java.util.ArrayList<File> cari = new java.util.ArrayList<>();
        cari.add(dasar);
        if (akar != null) for (File f : akar) if (f.isDirectory()) cari.add(f);
        File terbaik = null;
        for (File r : cari) {
            java.util.ArrayList<File> hasil = new java.util.ArrayList<>();
            hasil.add(new File(r, "build/outputs/apk"));
            File[] modul = r.listFiles();
            if (modul != null) for (File m : modul) if (m.isDirectory()) hasil.add(new File(m, "build/outputs/apk"));
            for (File h : hasil) terbaik = apkDalam(h, t0, 0, terbaik);
        }
        return terbaik == null ? null : terbaik.getPath();
    }

    private static File apkDalam(File d, long t0, int dalam, File terbaik) {
        File[] l = d.listFiles();
        if (l == null || dalam > 4) return terbaik;
        for (File f : l) {
            if (f.isDirectory()) terbaik = apkDalam(f, t0, dalam + 1, terbaik);
            else if (f.getName().toLowerCase().endsWith(".apk") && f.lastModified() >= t0 - 5000
                     && (terbaik == null || f.lastModified() > terbaik.lastModified())) terbaik = f;
        }
        return terbaik;
    }

    static final java.util.regex.Pattern P_GRADLE = java.util.regex.Pattern.compile("^(?:sh\\s+|bash\\s+)?(?:\\S*/)?gradlew?(?:\\s+(.*))?$");
    static final java.util.regex.Pattern P_TUGAS = java.util.regex.Pattern.compile("^:?(?:[A-Za-z0-9_.-]+:)*(?:assemble|bundle|build)[A-Za-z0-9_]*$");

    /**
     * Perintah Gradle yang ditempel di kolom perintah (mis. ./gradlew assembleDebug, boleh didahului cd folder &&)
     * dijalankan lewat alur Bangun APK yang sama: tanda tangan dan keamanan otomatis, dialog persen,
     * salinan ke Download, lalu pilihan aplikasi pemasang. Mengembalikan false bila bukan perintah bangun
     * atau folder bukan proyek, sehingga perintah dijalankan biasa.
     */
    boolean bangunDariPerintah(String cmd) {
        String[] bag = cmd.split("\\s*&&\\s*");
        java.util.regex.Matcher m = P_GRADLE.matcher(bag[bag.length - 1].trim());
        if (!m.matches()) return false;
        String tugas = null;
        if (m.group(1) != null) {
            for (String t : m.group(1).trim().split("\\s+")) if (P_TUGAS.matcher(t).matches()) { tugas = t; break; }
        }
        if (tugas == null) return false;
        File cur = cwd;
        for (int i = 0; i < bag.length - 1; i++) {
            String c = bag[i].trim();
            if (!(c.equals("cd") || c.startsWith("cd "))) return false;
            String a = c.length() > 3 ? c.substring(3).trim().replaceAll("^['\"]|['\"]$", "") : "";
            File t = a.isEmpty() ? Env.home : a.startsWith("/") ? new File(a) : new File(cur, a);
            try { t = t.getCanonicalFile(); } catch (IOException e) { }
            if (!t.isDirectory()) return false;
            cur = t;
        }
        if (!(Builder.proyekSederhana(cur) || adaGradle(cur) || adaNode(cur) || adaApktool(cur))) return false;
        if (!cur.equals(cwd)) { cwd = cur; add("Folder kerja: " + cur.getPath()); }
        add("Perintah bangun dikenali (" + tugas + "). Dijalankan dengan alur Bangun APK: tanda tangan dan keamanan otomatis, persen, lalu pilihan aplikasi pemasang.");
        say("Perintah bangun dikenali. Memakai alur Bangun APK");
        bangunApk("", tugas);
        return true;
    }

    boolean storageOk() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    void askStorage() {
        if (storageOk()) { add("Izin penyimpanan sudah aktif"); say("Izin penyimpanan sudah aktif"); return; }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
            say("Nyalakan izin akses semua berkas untuk Termux Data Novan, lalu kembali ke aplikasi");
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
        }
    }

    static String clean(String s) {
        s = s.replaceAll("\u001B\\[[0-9;?]*[ -/]*[@-~]", "").replaceAll("\u001B\\][^\u0007]*\u0007", "");
        if (s.indexOf('\r') >= 0) {
            String[] seg = s.split("\r");
            s = "";
            for (int i = seg.length - 1; i >= 0; i--) if (!seg[i].isEmpty()) { s = seg[i]; break; }
        }
        return s.replaceAll("[\u0000-\u0008\u000B\u000C\u000E-\u001F]", "");
    }

    void cd(String p) {
        File t = p.isEmpty() ? Env.home : p.startsWith("/") ? new File(p) : new File(cwd, p);
        try { t = t.getCanonicalFile(); } catch (IOException e) { }
        if (t.isDirectory()) { cwd = t; add("Folder kerja: " + t.getPath()); say("Folder kerja " + t.getName()); }
        else { add("Folder tidak ditemukan: " + p); say("Folder tidak ditemukan"); }
    }

    static void run(String cmd) {
        final boolean bk = cmd.startsWith("bongkar-apk");
        final boolean nb = cmd.contains("bangun-gradle") || bk;
        // Perintah bangun lain (skrip bangun, gradlew, assemble...) juga tampil di dialog proses, bukan hanya di layar utama.
        final boolean dp = !nb && !Progres.aktif && !Pkg.busy && P_BANGUN.matcher(cmd).find();
        if (Pkg.busy && (nb || cmd.contains("pkg ") || cmd.contains("apt"))) {
            if (nb && !novanBusy) { tungguBangun = true; perintahTunggu = cmd; }
            add("Masih ada proses penyiapan atau pembangunan." + (nb ? " Alat sedang disiapkan, APK akan langsung " + (bk ? "dibongkar" : "dibangun") + " otomatis begitu selesai." : " Tunggu sampai selesai."));
            say(nb ? "Alat sedang disiapkan. Tunggu, APK akan langsung " + (bk ? "dibongkar" : "dibangun") + " otomatis" : "Masih ada proses berjalan. Tunggu sampai selesai");
            Progres.buka();
            return;
        }
        if (nb) {
            if (novanBusy) { add(bk ? "Proses bangun atau bongkar masih berjalan." : "Pembangunan Gradle masih berjalan."); say("Pembangunan masih berjalan"); Progres.buka(); return; }
            if (!Pkg.sudahSiap() && !new File(Env.prefix, "bin/java").exists()) {
                tungguBangun = true;
                perintahTunggu = cmd;
                add("Alat membangun APK belum siap. Menyiapkan otomatis sekarang, APK akan langsung " + (bk ? "dibongkar" : "dibangun") + " begitu selesai — tidak perlu mengetik apa pun.");
                say("Menyiapkan alat otomatis. Tunggu sampai selesai, APK akan langsung " + (bk ? "dibongkar" : "dibangun"));
                Pkg.mulaiSiap();
                Progres.buka();
                return;
            }
            novanBusy = true;
            if (bk) Bongkar.pasang();
            Progres.mulai(bk ? "Membongkar APK jadi zip" : "Membangun APK dengan Gradle", "Memulai", () -> run(cmd));
        }
        if (wantsPty(cmd) && runPty(cmd)) return;
        if (dp) {
            Progres.mulai("Menjalankan proses bangun", "Memulai", () -> run(cmd));
            Progres.tahap(0, 97, "Menjalankan perintah, persen perkiraan");
            Progres.perkiraan(300);
        }
        // termux-setup-storage menanyakan y/n bila ~/storage sudah ada, dan pertanyaannya tidak tampil tanpa terminal.
        // Izin penyimpanan sudah diatur aplikasi ini, jadi dijawab y otomatis supaya tidak perlu mengetik.
        final String jalan = cmd.contains("yes |") ? cmd
            : cmd.replaceAll("(?<![\\w-])termux-setup-storage(?![\\w-])", "yes | termux-setup-storage");
        KeepAliveService.begin(ctx);
        new Thread(() -> {
            final long t0 = System.currentTimeMillis();
            StringBuilder out = new StringBuilder();
            String last = "";
            int code = -1;
            try {
                ProcessBuilder pb = new ProcessBuilder(Env.wrap(Env.shell(), "-c", jalan)).directory(cwd).redirectErrorStream(true);
                Env.apply(pb.environment());
                proc = pb.start();
                stdin = proc.getOutputStream();
                // Perintah tanpa terminal (tty) tidak bisa menampilkan pertanyaan seperti "lanjutkan? (y/n)".
                // Bila diam cukup lama, tampilkan dialog pilihan jawaban supaya tidak perlu mengetik.
                final Process pp = proc;
                final long[] io = {System.currentTimeMillis()};
                final boolean[] petunjuk = {false};
                final long batas = dp ? 20000 : 8000;
                H.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (proc != pp || nb || petunjuk[0]) return;
                        if (System.currentTimeMillis() - io[0] > batas) {
                            petunjuk[0] = true;
                            dialogJawab("Tidak ada keluaran selama " + (batas / 1000) + " detik. Perintah mungkin menunggu jawaban.", pp, ekorAman(out), true);
                        } else H.postDelayed(this, 2000);
                    }
                }, batas);
                InputStreamReader r = new InputStreamReader(proc.getInputStream());
                char[] buf = new char[2048];
                StringBuilder cur = new StringBuilder();
                int n;
                while ((n = r.read(buf)) > 0) {
                    io[0] = System.currentTimeMillis();
                    cur.append(buf, 0, n);
                    String all = cur.toString();
                    int st = 0, nl;
                    while ((nl = all.indexOf('\n', st)) >= 0) {
                        String t = clean(all.substring(st, nl));
                        st = nl + 1;
                        if ((nb || dp) && Progres.baris(t)) continue;
                        out.append(t).append('\n');
                        last = t;
                        final String f = t;
                        H.post(() -> add(f));
                    }
                    cur.setLength(0);
                    cur.append(all.substring(st));
                    if (cur.length() > 0) {
                        int w = 0;
                        while (w < 300 && !r.ready()) { try { Thread.sleep(50); } catch (Exception e) { } w += 50; }
                        if (!r.ready()) {
                            String t = clean(cur.toString());
                            cur.setLength(0);
                            cekTanya(t, pp, out);
                            if ((nb || dp) && Progres.baris(t)) t = "";
                            if (!t.trim().isEmpty()) {
                                out.append(t).append('\n');
                                last = t;
                                final String f = t;
                                H.post(() -> { add(f); if (mode != 2) say(f); });
                            }
                        }
                    }
                }
                if (cur.length() > 0) {
                    String t = clean(cur.toString());
                    if (!t.trim().isEmpty()) {
                        out.append(t).append('\n');
                        last = t;
                        final String f = t;
                        H.post(() -> add(f));
                    }
                }
                code = proc.waitFor();
            } catch (Exception e) {
                out.append(e.getMessage());
                last = String.valueOf(e.getMessage());
                final String m = last;
                H.post(() -> add("Galat: " + m));
            }
            proc = null;
            stdin = null;
            if (nb) {
                if (code == 0) { H.post(() -> add("Membersihkan sisa bangun lama, mohon tunggu")); Bersih.otomatis(); }
                novanBusy = false;
                String ts = ttdSetelah;
                ttdSetelah = null;
                if (bk) {
                    if (code == 0) Progres.selesai(true, "APK selesai dibongkar." + (Progres.hasil.isEmpty() ? "" : " Zip: " + Progres.hasil));
                    else Progres.selesai(false, "Membongkar APK gagal atau dihentikan, kode " + code + ". Lihat keluaran di layar utama.");
                } else {
                    if (code == 0 && ts != null) Builder.pilihHasil();
                    new File(Env.home, ".novan-ttd").delete();
                    if (code == 0) Progres.selesai(true, "APK selesai dibangun." + (Progres.hasil.isEmpty() ? "" : " Salinan: " + Progres.hasil));
                    else Progres.selesai(false, "Pembangunan gagal atau dihentikan, kode " + code + ". Lihat keluaran di layar utama.");
                }
            }
            if (dp) {
                // Perintah dengan pipa (| tee) menutupi kegagalan Gradle: kode keluarnya milik tee, bukan Gradle.
                if (code == 0 && (out.indexOf("BUILD FAILED") >= 0 || out.indexOf("FAILURE: Build failed") >= 0)) {
                    code = 1;
                    H.post(() -> add("Gradle melaporkan BUILD FAILED, jadi proses dianggap gagal."));
                }
                if (code == 0 && Progres.hasil.isEmpty()) {
                    String apk = cariApk(out.toString());
                    if (apk == null && out.indexOf("BUILD SUCCESSFUL") >= 0) apk = apkTerbaru(cwd, t0);
                    if (apk != null) Progres.hasil = apk;
                }
                if (code == 0) Progres.selesai(true, "Proses selesai." + (Progres.hasil.isEmpty() ? "" : " Hasil: " + Progres.hasil));
                else Progres.selesai(false, "Proses gagal atau dihentikan, kode " + code + ". Lihat keluaran di layar utama.");
            }
            H.post(() -> { AlertDialog dq = dlgTanya; dlgTanya = null; if (dq != null) try { dq.dismiss(); } catch (Exception ex) { } });
            KeepAliveService.end(ctx);
            final String fo = out.toString(), fl = last;
            final int fc = code;
            H.post(() -> {
                if (System.currentTimeMillis() - t0 > 20000)
                    KeepAliveService.selesai(ctx, "Perintah selesai, kode " + fc + (fl.isEmpty() ? "" : ". " + fl));
                lastOut = fo;
                add("[selesai, kode " + fc + "]");
                if (fc != 0 && !nb && !dp && visible && front != null && !fo.trim().isEmpty()) front.dialogError(cmd, fc, fo);
                else if (mode == 0) {
                    if (fo.isEmpty()) say("Selesai tanpa keluaran");
                    else if (fo.length() > 600) {
                        int tot = 0;
                        for (int q = 0; q < fo.length(); q++) if (fo.charAt(q) == '\n') tot++;
                        say(fo.substring(0, 600) + ". Keluaran dipotong, total " + tot + " baris. Jelajahi daftar atau tekan tombol Salin hasil");
                    } else say(fo);
                }
                else if (mode == 1) say(fl.isEmpty() ? "Selesai" : fl);
            });
        }).start();
    }
}
