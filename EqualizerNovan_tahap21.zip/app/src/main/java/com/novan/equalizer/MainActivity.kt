package com.novan.equalizer

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onResume() {
        super.onResume()
        Bat.ok = isIgnoring(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        EqService.start(this)
        Bat.ok = isIgnoring(this)
        setContent {
            val dark = isSystemInDarkTheme()
            val scheme = when {
                Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(this) else dynamicLightColorScheme(this)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { EqScreen() }
            }
        }
    }
}

private object Bat {
    var ok by mutableStateOf(false)
}

private fun isIgnoring(ctx: Context): Boolean =
    ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

private fun openAppInfo(ctx: Context) {
    runCatching {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
    }
}

/** Minta pengecualian hemat baterai; bila layar sistemnya tidak ada, buka daftar pengecualian, lalu info aplikasi. */
private fun requestIgnore(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
    } catch (t: Throwable) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (t2: Throwable) {
            openAppInfo(ctx)
        }
    }
}

private fun appLabel(ctx: Context, pkg: String): String = runCatching {
    ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
}.getOrDefault(pkg)

private fun num(v: Float): String {
    val r = Math.round(v * 10) / 10f
    return if (r % 1f == 0f) r.toInt().toString() else r.toString().replace('.', ',')
}

private fun dbText(v: Float): String = (if (v > 0f) "+" else "") + num(v) + " dB"

private fun dbSpoken(v: Float): String = when {
    v > 0f -> "plus ${num(v).replace(",", " koma ")} desibel"
    v < 0f -> "minus ${num(-v).replace(",", " koma ")} desibel"
    else -> "nol desibel"
}

private fun msText(v: Float) = num(v) + " ms"
private fun msSpoken(v: Float) = num(v).replace(",", " koma ") + " milidetik"
private fun ratioText(v: Float) = num(v) + " : 1"
private fun ratioSpoken(v: Float) = num(v).replace(",", " koma ") + " banding satu"
private fun balText(v: Float) = when {
    v > 0f -> "kanan, kiri turun ${num(v)} dB"
    v < 0f -> "kiri, kanan turun ${num(-v)} dB"
    else -> "tengah"
}
private fun balSpoken(v: Float) = when {
    v > 0f -> "condong ke kanan, kiri turun ${num(v).replace(",", " koma ")} desibel"
    v < 0f -> "condong ke kiri, kanan turun ${num(-v).replace(",", " koma ")} desibel"
    else -> "tengah"
}

@Composable
private fun Head(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().toggleable(value = checked, role = Role.Switch, onValueChange = onChange).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        Switch(checked, null)
    }
}

/** Slider umum. Pembaca layar mendapat aksi naik/turun satu langkah dan lima langkah. */
@Composable
private fun ParamSlider(
    label: String, value: Float, min: Float, max: Float, step: Float,
    show: (Float) -> String, say: (Float) -> String, onChange: (Float) -> Unit,
) {
    val steps = (Math.round((max - min) / step) - 1).coerceAtLeast(0)
    fun snap(v: Float) = (Math.round((v - min) / step) * step + min).coerceIn(min, max)
    Column {
        Text("$label: ${show(value)}", Modifier.clearAndSetSemantics {}, style = MaterialTheme.typography.titleSmall)
        Slider(
            value = value,
            onValueChange = { onChange(snap(it)) },
            valueRange = min..max,
            steps = steps,
            modifier = Modifier.semantics {
                contentDescription = label
                stateDescription = say(value)
                customActions = listOf(
                    CustomAccessibilityAction("Naikkan satu langkah") { onChange(snap(value + step)); true },
                    CustomAccessibilityAction("Turunkan satu langkah") { onChange(snap(value - step)); true },
                    CustomAccessibilityAction("Naikkan lima langkah") { onChange(snap(value + 5 * step)); true },
                    CustomAccessibilityAction("Turunkan lima langkah") { onChange(snap(value - 5 * step)); true },
                )
            },
        )
    }
}

private val routeNames = listOf("Otomatis", "Hanya global", "Hanya sesi aplikasi")
private val routeHelp = listOf(
    "Otomatis: global dulu, bila gagal sesi aplikasi",
    "Hanya global: semua suara HP",
    "Hanya sesi aplikasi: pemutar yang melapor",
)

@Composable
private fun EqScreen() {
    val st by EqEngine.state.collectAsState()
    val status by EqEngine.status.collectAsState()
    val d = st.dyn
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    val apps by EqEngine.apps.collectAsState()
    var presetDlg by remember { mutableStateOf(false) }
    var roomDlg by remember { mutableStateOf(false) }
    var routeDlg by remember { mutableStateOf(false) }
    var saveDlg by remember { mutableStateOf(false) }
    var deleteDlg by remember { mutableStateOf(false) }
    var styleDlg by remember { mutableStateOf(false) }
    var bandDlg by remember { mutableStateOf(false) }
    var stepDlg by remember { mutableStateOf(false) }
    var curveDlg by remember { mutableStateOf(false) }
    var appDlg by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf("") }
    val customNames = st.customs().keys.toList()
    val centers = Bands.centers(st.bandCount)
    val gains = st.gains()
    val bandStep = if (st.fine) 0.5f else 1f

    if (roomDlg) {
        PickDialog(
            "Mode ruang",
            Rooms.names.mapIndexed { i, n -> if (i == st.room) "$n, dipakai" else n },
            onPick = {
                EqEngine.setRoom(it)
                roomDlg = false
            },
            onDismiss = { roomDlg = false },
        )
    }

    if (presetDlg) {
        val all = Presets.names + customNames.filter { it !in Presets.names }
        PickDialog(
            "Pilih mode",
            all.map { if (it == st.preset) "$it, dipakai" else it },
            onPick = {
                if (!st.enabled) EqEngine.setEnabled(true)
                EqEngine.applyPreset(all[it])
                presetDlg = false
            },
            onDismiss = { presetDlg = false },
        )
    }
    if (saveDlg) {
        var name by remember { mutableStateOf("") }
        var error by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { saveDlg = false },
            title = { Text("Simpan preset kustom", Modifier.semantics { heading() }) },
            text = {
                Column {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it; error = false },
                        label = { Text("Nama preset") },
                        singleLine = true,
                        isError = error,
                    )
                    if (error) Text(
                        "Nama tidak sah atau sudah dipakai preset bawaan.",
                        Modifier.semantics { liveRegion = LiveRegionMode.Assertive },
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (EqEngine.saveCustomPreset(name)) { info = "Preset disimpan."; saveDlg = false } else error = true
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { saveDlg = false }) { Text("Batal") } },
        )
    }
    if (deleteDlg) {
        PickDialog(
            "Hapus preset kustom",
            customNames.map { "Hapus $it" },
            onPick = { EqEngine.deleteCustomPreset(customNames[it]); info = "Preset dihapus."; deleteDlg = false },
            onDismiss = { deleteDlg = false },
        )
    }
    if (styleDlg) {
        PickDialog(
            "Gaya dinamika",
            listOf("Mati", "Ringan", "Sedang", "Kuat"),
            onPick = { EqEngine.dynStyle(it); styleDlg = false },
            onDismiss = { styleDlg = false },
        )
    }
    if (bandDlg) {
        PickDialog(
            "Jumlah pita",
            listOf(10, 32).map { if (it == st.bandCount) "$it pita, dipakai" else "$it pita" },
            onPick = { EqEngine.setBandCount(if (it == 0) 10 else 32); bandDlg = false },
            onDismiss = { bandDlg = false },
        )
    }
    if (stepDlg) {
        PickDialog(
            "Langkah slider pita",
            listOf("1 dB", "0,5 dB").mapIndexed { i, t -> if ((i == 1) == st.fine) "$t, dipakai" else t },
            onPick = { EqEngine.setFine(it == 1); stepDlg = false },
            onDismiss = { stepDlg = false },
        )
    }
    if (curveDlg) {
        val acts = buildList<Pair<String, () -> Unit>> {
            add("Simpan sebagai preset" to { saveDlg = true })
            if (customNames.isNotEmpty()) add("Hapus preset kustom" to { deleteDlg = true })
            add("Salin kurva" to { clip.setText(AnnotatedString(EqEngine.exportCurve())); info = "Kurva disalin." })
            add("Tempel kurva" to {
                info = if (EqEngine.importCurve(clip.getText()?.text.orEmpty())) "Kurva ditempel." else "Papan klip tidak berisi kurva yang sah."
            })
            add("Kembalikan ke datar" to { EqEngine.reset(); info = "Kembali ke datar." })
        }
        PickDialog(
            "Kelola kurva",
            acts.map { it.first },
            onPick = { curveDlg = false; acts[it].second() },
            onDismiss = { curveDlg = false },
        )
    }
    appDlg?.let { pkg ->
        val name = appLabel(ctx, pkg)
        val has = apps.firstOrNull { it.pkg == pkg }?.hasProfile == true
        val acts = buildList<Pair<String, () -> Unit>> {
            add("Simpan kurva sekarang" to { EqEngine.saveAppProfile(pkg); info = "Profil $name disimpan." })
            if (has) add("Hapus profil" to { EqEngine.deleteAppProfile(pkg); info = "Profil $name dihapus." })
        }
        PickDialog(
            name,
            acts.map { it.first },
            onPick = { appDlg = null; acts[it].second() },
            onDismiss = { appDlg = null },
        )
    }
    if (routeDlg) {
        PickDialog(
            "Mode kerja",
            routeHelp.mapIndexed { i, t -> if (i == st.route) "$t, dipakai" else t },
            onPick = { EqEngine.setRoute(it); routeDlg = false },
            onDismiss = { routeDlg = false },
        )
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("Equalizer Novan", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.semantics { heading() }) }
        item { SwitchRow("Aktifkan equalizer", st.enabled) { EqEngine.setEnabled(it) } }
        item { Text(status, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }) }

        item { Head("Mode") }
        item { Button(onClick = { presetDlg = true }, modifier = Modifier.fillMaxWidth()) { Text("Mode: ${st.preset}") } }
        item { OutlinedButton(onClick = { curveDlg = true }, modifier = Modifier.fillMaxWidth()) { Text("Kelola kurva") } }
        item { Text(info, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }) }

        item { Head("Nada dan lebar stereo") }
        item { ParamSlider("Bass", st.bass, -12f, 12f, 1f, ::dbText, ::dbSpoken) { EqEngine.setTone(it, st.treble) } }
        item { ParamSlider("Treble", st.treble, -12f, 12f, 1f, ::dbText, ::dbSpoken) { EqEngine.setTone(st.bass, it) } }
        item {
            ParamSlider(
                "Bass cerdas", st.smartBass.toFloat(), 0f, 100f, 5f,
                { if (it <= 0f) "mati" else "${it.toInt()} persen" },
                { if (it <= 0f) "mati" else "${it.toInt()} persen" },
            ) { EqEngine.setSmartBass(it.toInt()) }
        }
        item { Text("Bass lebih padat, gemuruh berkurang. Coba 20–40 persen.", style = MaterialTheme.typography.bodySmall) }
        item {
            ParamSlider(
                "Kejernihan vokal", st.clarity.toFloat(), 0f, 100f, 5f,
                { if (it <= 0f) "mati" else "${it.toInt()} persen" },
                { if (it <= 0f) "mati" else "${it.toInt()} persen" },
            ) { EqEngine.setClarity(it.toInt()) }
        }
        item { Text("Ucapan dan vokal lebih jelas. Coba 20–40 persen.", style = MaterialTheme.typography.bodySmall) }
        item {
            ParamSlider(
                "Penguat suara pelan", st.softVolume.toFloat(), 0f, 100f, 5f,
                { if (it <= 0f) "mati" else "${it.toInt()} persen" },
                { if (it <= 0f) "mati" else "${it.toInt()} persen" },
            ) { EqEngine.setSoftVolume(it.toInt()) }
        }
        item { Text(if (FxFactory.fullDynamics) "Meratakan suara pelan dan keras. Coba 20–40 persen." else "Android 7–8.1: hanya penguatan ringan. Coba 20–40 persen.", style = MaterialTheme.typography.bodySmall) }

        item {
            ParamSlider(
                "Lebar stereo", st.width.toFloat(), 0f, 100f, 10f,
                { if (it <= 0f) "mati" else "${it.toInt()} persen" },
                { if (it <= 0f) "mati" else "${it.toInt()} persen" },
            ) { EqEngine.setWidth(it.toInt()) }
        }
        item { OutlinedButton(onClick = { roomDlg = true }, modifier = Modifier.fillMaxWidth()) { Text("Reverb: ${Rooms.names[st.room.coerceIn(0, 5)]}") } }
        item { Text("Gema ruangan lewat efek bawaan Android; hasil dan dukungan bergantung HP.", style = MaterialTheme.typography.bodySmall) }

        item { Head("Pita") }
        item { OutlinedButton(onClick = { bandDlg = true }, modifier = Modifier.fillMaxWidth()) { Text("Jumlah pita: ${st.bandCount}") } }
        item { OutlinedButton(onClick = { stepDlg = true }, modifier = Modifier.fillMaxWidth()) { Text("Langkah pita: ${if (st.fine) "0,5" else "1"} dB") } }
        if (!FxFactory.fullDynamics) {
            item {
                Text(
                    "Android 7–8.1: kurva dipetakan ke pita fisik HP. Tanpa kompresor, pembatas, dan keseimbangan.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        item {
            val line = MaterialTheme.colorScheme.primary
            val base = MaterialTheme.colorScheme.outline
            Canvas(Modifier.fillMaxWidth().height(96.dp).clearAndSetSemantics {}) {
                val w = size.width
                val h = size.height
                drawLine(base, Offset(0f, h / 2), Offset(w, h / 2), strokeWidth = 2f)
                val n = gains.size
                for (i in 0 until n - 1) {
                    val x1 = w * i / (n - 1)
                    val x2 = w * (i + 1) / (n - 1)
                    val y1 = h / 2 - gains[i] / 12f * (h / 2)
                    val y2 = h / 2 - gains[i + 1] / 12f * (h / 2)
                    drawLine(line, Offset(x1, y1), Offset(x2, y2), strokeWidth = 6f)
                }
            }
        }
        itemsIndexed(centers.toList()) { i, f ->
            val g = gains.getOrElse(i) { 0f }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(Bands.label(f), Modifier.width(76.dp).clearAndSetSemantics {}, style = MaterialTheme.typography.labelLarge)
                Slider(
                    value = g,
                    onValueChange = { EqEngine.setGain(i, Math.round(it / bandStep) * bandStep) },
                    valueRange = -12f..12f,
                    steps = Math.round(24f / bandStep) - 1,
                    modifier = Modifier.weight(1f).semantics {
                        contentDescription = "Pita ${i + 1}, ${Bands.spoken(f)}"
                        stateDescription = dbSpoken(g)
                        customActions = listOf(
                            CustomAccessibilityAction("Naikkan satu langkah") { EqEngine.setGain(i, g + bandStep); true },
                            CustomAccessibilityAction("Turunkan satu langkah") { EqEngine.setGain(i, g - bandStep); true },
                            CustomAccessibilityAction("Naikkan 3 desibel") { EqEngine.setGain(i, g + 3f); true },
                            CustomAccessibilityAction("Turunkan 3 desibel") { EqEngine.setGain(i, g - 3f); true },
                        )
                    },
                )
                Text(dbText(g), Modifier.width(64.dp).clearAndSetSemantics {}, textAlign = TextAlign.End, style = MaterialTheme.typography.labelLarge)
            }
        }

        if (FxFactory.fullDynamics) {
            item { Head("Dinamika") }
            item { Text("Kompresor meratakan volume, pembatas mencegah pecah.", style = MaterialTheme.typography.bodySmall) }
            item { OutlinedButton(onClick = { styleDlg = true }, modifier = Modifier.fillMaxWidth()) { Text("Gaya cepat kompresor") } }
            item { SwitchRow("Kompresor 3 pita", d.compOn) { v -> EqEngine.updateDyn { it.copy(compOn = v) } } }
            if (d.compOn) {
                item { ParamSlider("Ambang kompresor", d.compThr, -60f, 0f, 1f, ::dbText, ::dbSpoken) { v -> EqEngine.updateDyn { it.copy(compThr = v) } } }
                item { ParamSlider("Rasio kompresor", d.compRatio, 1f, 20f, 1f, ::ratioText, ::ratioSpoken) { v -> EqEngine.updateDyn { it.copy(compRatio = v) } } }
                item { ParamSlider("Waktu serang kompresor", d.compAtk, 1f, 200f, 1f, ::msText, ::msSpoken) { v -> EqEngine.updateDyn { it.copy(compAtk = v) } } }
                item { ParamSlider("Waktu lepas kompresor", d.compRel, 10f, 2000f, 10f, ::msText, ::msSpoken) { v -> EqEngine.updateDyn { it.copy(compRel = v) } } }
                item { ParamSlider("Penguat susulan kompresor", d.compMakeup, 0f, 12f, 1f, ::dbText, ::dbSpoken) { v -> EqEngine.updateDyn { it.copy(compMakeup = v) } } }
            }
            item { SwitchRow("Pembatas", d.limOn) { v -> EqEngine.updateDyn { it.copy(limOn = v) } } }
            if (d.limOn) {
                item { ParamSlider("Ambang pembatas", d.limThr, -30f, 0f, 1f, ::dbText, ::dbSpoken) { v -> EqEngine.updateDyn { it.copy(limThr = v) } } }
                item { ParamSlider("Rasio pembatas", d.limRatio, 1f, 20f, 1f, ::ratioText, ::ratioSpoken) { v -> EqEngine.updateDyn { it.copy(limRatio = v) } } }
                item { ParamSlider("Waktu serang pembatas", d.limAtk, 0.5f, 50f, 0.5f, ::msText, ::msSpoken) { v -> EqEngine.updateDyn { it.copy(limAtk = v) } } }
                item { ParamSlider("Waktu lepas pembatas", d.limRel, 10f, 1000f, 10f, ::msText, ::msSpoken) { v -> EqEngine.updateDyn { it.copy(limRel = v) } } }
            }
            item { OutlinedButton(onClick = { EqEngine.resetDyn() }, modifier = Modifier.fillMaxWidth()) { Text("Reset dinamika dan keluaran") } }

        }

        item { Head("Keluaran") }
        item { ParamSlider("Penguat awal", st.preamp, -12f, 12f, 1f, ::dbText, ::dbSpoken) { EqEngine.setPreamp(it) } }
        item { SwitchRow("Headroom otomatis (suara bisa lebih pelan)", st.headroom) { EqEngine.setHeadroom(it) } }
        item { Text("Mati: suara tidak diturunkan, pembatas yang mencegah pecah. Nyalakan bila suara pecah.", style = MaterialTheme.typography.bodySmall) }
        item { ParamSlider("Penguat akhir", d.outGain, -12f, 12f, 1f, ::dbText, ::dbSpoken) { v -> EqEngine.updateDyn { it.copy(outGain = v) } } }
        if (FxFactory.fullDynamics) {
            item { ParamSlider("Keseimbangan kiri kanan", d.balance, -12f, 12f, 1f, ::balText, ::balSpoken) { v -> EqEngine.updateDyn { it.copy(balance = v) } } }
        }

        if (!Bat.ok) {
            item { Head("Latar belakang") }
            item { Button(onClick = { requestIgnore(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Izinkan berjalan di latar belakang") } }
            item {
                Text(
                    "ColorOS: Info aplikasi, Penggunaan baterai, izinkan aktivitas latar belakang dan otomatis.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }

        item { Head("Per aplikasi") }
        item { SwitchRow("Profil per aplikasi", st.perApp) { EqEngine.setPerApp(it) } }
        item { Text("Tiap pemutar punya kurva sendiri. Mode kerja jadi Hanya sesi aplikasi.", style = MaterialTheme.typography.bodySmall) }
        if (st.perApp) {
            if (apps.isEmpty()) {
                item { Text("Belum ada pemutar. Putar lagu dulu, lalu kembali ke sini.") }
            }
            items(apps, key = { it.pkg }) { app ->
                val name = appLabel(ctx, app.pkg)
                OutlinedButton(onClick = { appDlg = app.pkg }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (app.hasProfile) "$name, punya profil" else "$name, belum ada profil")
                }
            }
        }

        item { Head("Lanjutan") }
        item { SwitchRow("Profil otomatis per keluaran", st.autoProfile) { EqEngine.setAutoProfile(it) } }
        item { Text("Speaker, kabel, dan Bluetooth punya kurva masing-masing.", style = MaterialTheme.typography.bodySmall) }
        item { OutlinedButton(onClick = { routeDlg = true }, modifier = Modifier.fillMaxWidth()) { Text("Mode kerja: ${routeNames[st.route]}") } }
        item {
            Text(
                "Suara tidak berubah? Pilih Hanya sesi aplikasi, lalu putar ulang lagu.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun PickDialog(title: String, options: List<String>, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, Modifier.semantics { heading() }) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEachIndexed { i, o ->
                    TextButton(onClick = { onPick(i) }, modifier = Modifier.fillMaxWidth()) {
                        Text(o, Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}
