# Equalizer Novan

Equalizer Android 10 dan 32 pita, dirancang ramah pembaca layar. Mendukung Android 7 (API 24) sampai Android terbaru, HP 32-bit maupun 64-bit (satu APK untuk semua, tanpa pustaka native).

- Android 9 ke atas: DynamicsProcessing, 10 atau 32 pita sungguhan, kompresor, pembatas, keseimbangan.
- Android 7 sampai 8.1: Equalizer bawaan sistem (biasanya 5 pita) plus LoudnessEnhancer. Kurva 10 atau 32 pita dipetakan ke pita fisik HP. Kompresor, pembatas, dan keseimbangan tidak tersedia.

## Fitur
- Equalizer 10 atau 32 pita, rentang minus 12 sampai plus 12 dB, langkah 1 atau 0,5 dB.
- Mode siap pakai (Pop, Rock, Bass, Vokal, Treble, Hip hop, dan lain-lain; memilih mode otomatis menyalakan equalizer) dan preset kustom (simpan, hapus). Salin dan tempel kurva lewat papan klip.
- Kompresor 3 pita (gaya cepat dan pengaturan penuh), pembatas, penguat awal, penguat akhir, keseimbangan kiri kanan.
- Profil otomatis per keluaran (speaker HP, earphone kabel, Bluetooth).
- Profil per aplikasi pemutar (mode Hanya sesi aplikasi).
- Tombol cepat di notifikasi: aktifkan atau matikan, preset berikutnya.
- Tombol izin berjalan di latar belakang (pengecualian hemat baterai).
- Tema mengikuti sistem, warna dinamis di Android 12 ke atas.
- Semua slider punya aksi aksesibilitas naik atau turun satu langkah dan lima langkah.

## Cara kerja
Efek dipasang di sesi global (semua suara) dan di sesi tiap pemutar yang memberi tahu nomor sesinya.
Mode kerja: Otomatis, Hanya global, Hanya sesi aplikasi.

## Membangun
Dorong ke GitHub; berkas `.github/workflows/build.yml` membuat APK debug di Artifacts.

## Riwayat tahap
1. Dasar equalizer 10 dan 32 pita.
2. Preset kustom, aksi aksesibilitas slider.
3. Kompresor, pembatas, penguat akhir, keseimbangan, langkah halus, salin dan tempel kurva.
4. Izin latar belakang.
5. Tombol notifikasi.
6. Profil per keluaran.
7. Tema ikut sistem.
8. Profil per aplikasi.
9. Perapian: perbaikan direktori sumber daya rusak, pembersihan kode, README.
10. Dukungan Android 7 sampai 8.1 (minSdk 24): jalur efek kompatibel, ikon dan saluran notifikasi aman untuk Android lama.
11. Pilihan mode siap pakai yang lebih banyak, tombol Mode di bagian atas.
12. Nama pita dipersingkat: "Pita 1", "Pita 2", dan seterusnya.
13. Bass dan Treble (rak nada), mode Film dan Volume pelan, penguat awal turun otomatis saat memilih mode.
14. Lebar stereo 0 sampai 100 persen lewat Virtualizer bawaan Android (hasil bergantung HP).


## Tahap 15
- Menambahkan pengatur Kejernihan vokal (0–100%). Efek berupa penguatan bell lebar pada wilayah artikulasi sekitar 2,6 kHz dan diterapkan langsung ke jalur equalizer global maupun sesi aplikasi. Nilainya tersimpan otomatis.
- Tidak menyertakan fitur pembanding A/B.


## Tahap 16
- Penyempurnaan headroom otomatis: memperhitungkan puncak kurva EQ, penguat awal, makeup kompresor, dan penguat akhir pada Android 9 ke atas.
- Pada Android 7 sampai 8.1, penguatan global dikurangi berdasarkan puncak EQ positif karena jalur efek lama tidak menyediakan DynamicsProcessing/limiter.
- Tujuan: mengurangi risiko clipping ketika beberapa penguat dinaikkan bersamaan. Ini bukan pengukur true-peak dan hasil akhir tetap bergantung pada pemrosesan audio perangkat.


## Tahap 17
- Menambahkan pengaturan Bass Cerdas 0–100 persen yang diterapkan langsung ke jalur audio global dan sesi aplikasi.
- Kurva mengangkat area bass rendah secara bertahap hingga maksimum sekitar 4,5 dB dan mengurangi area 180–350 Hz hingga sekitar 2,2 dB untuk membantu mengurangi bunyi boomy/muddy.
- Pengaturan tersimpan otomatis dan ikut disimpan pada profil per aplikasi; format profil lama tetap dapat dibaca.
- Tidak memakai efek bass khusus vendor sehingga kompatibel dengan jalur DynamicsProcessing Android 9+ dan Equalizer sistem Android 7–8.1.
- Hasil suara tetap bergantung pada respons speaker/headset dan pemrosesan audio perangkat.

## Tahap 18
- Menambahkan slider Penguat suara pelan 0–100 persen.
- Android 9 ke atas: memakai kompresor multiband DynamicsProcessing dengan rasio dan ambang yang meningkat bertahap, serta makeup gain terbatas hingga 4,5 dB. Headroom otomatis memperhitungkan makeup gain fitur ini.
- Android 7 sampai 8.1: tidak tersedia kompresor multiband pada jalur kompatibel, sehingga fitur memberi penguatan statis terbatas hingga 4 dB melalui jalur LoudnessEnhancer/level EQ; ini bukan pemerataan dinamika.
- Nilai disimpan otomatis dan ikut disimpan pada profil keluaran serta profil per aplikasi. Profil Tahap 15–17 tetap dapat dibaca.
- Pengaktifan atau penonaktifan fitur membangun ulang konfigurasi efek agar blok MBC tersedia atau dilepas dengan benar.


## Tahap 19
- Tampilan diringkas: pilihan Jumlah pita (10/32), Langkah pita (1 atau 0,5 dB), Kelola kurva (simpan, hapus, salin, tempel, datarkan) dan profil tiap aplikasi kini lewat dialog menu.
- Semua keterangan dan status dipersingkat.
- Perbaikan: penguat awal tidak lagi turun dua kali saat memilih mode (headroom sudah otomatis sejak tahap 16); "Kembalikan ke datar" kini juga mematikan Bass cerdas, Kejernihan vokal, dan Penguat suara pelan; tempel kurva menolak nilai NaN atau tak hingga.


## Tahap 20
- Menambahkan **Reverb** dengan lima mode ruang (Kamar kecil, Ruang tamu, Studio, Aula konser, Gereja atau katedral), memakai efek PresetReverb bawaan Android di jalur global dan sesi aplikasi. Hasil dan dukungan bergantung HP; bila tidak didukung, status memberi tahu. Pengaturan tersimpan otomatis dan ikut "Reset".
- Menambahkan mode siap pakai **Treble terang** dan **Podcast dan pidato** (kurva yang sama dengan mesin audio Novan di YT music player).
- Catatan: Mono, Hi-Res, laju keluaran, bit-perfect, dan ReplayGain tidak bisa dibuat di sini karena aplikasi ini memakai efek sistem Android, bukan memproses audio sendiri; fitur itu hanya ada di mesin audio Novan.


## Tahap 21
- Suara tidak lagi terdengar lebih pelan: headroom otomatis (tahap 16) sekarang punya sakelar **Headroom otomatis** dan bawaannya MATI. Penguatan tidak dipotong lagi; pada Android 9 ke atas pembatas (limiter) yang menjaga puncak, jadi suara tetap aman dari pecah. Nyalakan sakelar itu bila suara terdengar pecah. Pada Android 7 sampai 8.1 tidak ada pembatas, jadi bila suara pecah nyalakan headroom otomatis.


## Tahap 22
- Menambahkan **Karakter bass** (Standar, Halus, Hangat, Padat, Dalam) di bawah slider Bass cerdas. Bawaan: Standar.
- Pilihan tersimpan otomatis, berlaku di jalur global dan sesi aplikasi, dan ikut dikembalikan saat "Kembalikan ke datar".
- Karakter selain Standar langsung terasa dengan kekuatan sedang (50 persen) walau slider Bass cerdas 0; slider mengatur kekuatan.


## Tahap 23
- Dialog pilihan (Mode, Kelola kurva, dan lainnya): daftar dibuat dengan LazyColumn, bukan Column yang digulir. Tujuannya supaya geser kanan dan kiri pembaca layar tidak singgah di wadah daftar ("tombol-tombol") dan tidak membacakan isi daftar berulang.
