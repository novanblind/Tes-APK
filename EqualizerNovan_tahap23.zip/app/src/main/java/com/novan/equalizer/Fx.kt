package com.novan.equalizer

import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.os.Build
import androidx.annotation.RequiresApi
import kotlin.math.ln

/**
 * Satu efek yang terpasang pada satu sesi suara. Ada dua jenis, dipilih menurut versi Android:
 * [DpFx] (Android 9 ke atas, DynamicsProcessing, pita bebas) dan [LegacyFx] (Android 7 sampai 8.1,
 * Equalizer bawaan sistem dengan pita fisik tetap).
 */
interface Fx {
    /** Terapkan seluruh kurva pita dari [st]. */
    fun setBands(st: EqState)

    /** Terapkan perubahan satu pita; jenis kompatibel menerapkan ulang seluruh kurva dari [st]. */
    fun setBand(index: Int, edge: Float, gain: Float, st: EqState)

    /** Terapkan penguat, keseimbangan, pembatas, dan kompresor dari [st]. */
    fun setLevels(st: EqState)

    fun release()

    /** True bila efek lebar stereo berhasil dipasang (HP mendukung). */
    val widthActive: Boolean

    /** True bila efek reverb berhasil dipasang (HP mendukung). */
    val roomActive: Boolean

    /** Jumlah pita fisik pada mode kompatibel; 0 bila jumlah pita bebas. */
    val deviceBands: Int
}

/** Lebar stereo lewat Virtualizer bawaan Android; kekuatan 0 sampai 100 persen, 0 berarti mati. Hasil bergantung HP. */
class Widener(private val session: Int) {
    private var v: Virtualizer? = null
    private var last = -1
    val active: Boolean get() = v != null

    fun set(pct: Int) {
        if (pct == last) return
        last = pct
        runCatching {
            if (pct <= 0) {
                v?.setEnabled(false)
            } else {
                val e = v ?: Virtualizer(0, session).also { v = it }
                if (e.strengthSupported) e.setStrength((pct * 10).coerceIn(0, 1000).toShort())
                e.setEnabled(true)
            }
        }
    }

    fun release() {
        runCatching { v?.release() }
        v = null
    }
}

/** Reverb ruang lewat PresetReverb bawaan Android; 0 mati, 1 sampai 5 dari kamar kecil sampai katedral. Hasil bergantung HP. */
class Roomer(private val session: Int) {
    private var r: PresetReverb? = null
    private var last = -1
    val active: Boolean get() = r != null

    fun set(idx: Int) {
        if (idx == last) return
        last = idx
        runCatching {
            if (idx <= 0) {
                r?.setEnabled(false)
            } else {
                val e = r ?: PresetReverb(0, session).also { r = it }
                e.setPreset(idx.coerceIn(1, 5).toShort())
                e.setEnabled(true)
            }
        }
    }

    fun release() {
        runCatching { r?.release() }
        r = null
    }
}

object FxFactory {
    /** Kompresor, pembatas, dan keseimbangan hanya ada di Android 9 ke atas. */
    val fullDynamics: Boolean get() = Build.VERSION.SDK_INT >= 28

    fun create(session: Int, st: EqState): Fx? =
        if (Build.VERSION.SDK_INT >= 28) DpFx.create(session, st) else LegacyFx.create(session, st)
}

/** Android 9 ke atas: DynamicsProcessing dengan 10 atau 32 pita, kompresor 3 pita, pembatas. */
@RequiresApi(28)
class DpFx private constructor(private val dp: DynamicsProcessing, session: Int) : Fx {
    private val wide = Widener(session)
    private val room = Roomer(session)
    override val widthActive: Boolean get() = wide.active
    override val roomActive: Boolean get() = room.active
    override val deviceBands: Int get() = 0

    private fun applyHeadroom(st: EqState) {
        // Sisakan headroom untuk seluruh penguatan positif sebelum keluaran:
        // preamp, puncak kurva EQ, makeup kompresor, dan gain keluaran limiter.
        // Ini bukan true-peak limiter, tetapi mengurangi risiko clipping akibat penumpukan gain.
        val peakEq = maxOf(0f, st.effGains().maxOrNull() ?: 0f)
        val compMakeup = if (st.dyn.compOn) maxOf(0f, st.dyn.compMakeup) else 0f
        val softMakeup = st.softVolume.coerceIn(0, 100) * 0.045f
        val outputBoost = maxOf(0f, st.dyn.outGain)
        // Bawaan mati: headroom yang memotong penguatan membuat suara lebih pelan. Pembatas tetap menjaga puncak.
        val reserve = if (st.headroom) peakEq + compMakeup + softMakeup + outputBoost else 0f
        val input = st.preamp - reserve
        dp.setInputGainbyChannel(0, input - maxOf(0f, st.dyn.balance))
        dp.setInputGainbyChannel(1, input - maxOf(0f, -st.dyn.balance))
    }

    override fun setBands(st: EqState) {
        val n = st.bandCount
        val g = st.effGains()
        val e = Bands.edges(n)
        for (i in 0 until n) dp.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, e[i], g[i]))
        applyHeadroom(st)
    }

    override fun setBand(index: Int, edge: Float, gain: Float, st: EqState) {
        dp.setPreEqBandAllChannelsTo(index, DynamicsProcessing.EqBand(true, edge, gain))
        applyHeadroom(st)
    }

    override fun setLevels(st: EqState) {
        val d = st.dyn
        applyHeadroom(st)
        dp.setLimiterAllChannelsTo(limiter(d))
        if (d.compOn || st.softVolume > 0) for (i in 0 until 3) dp.setMbcBandAllChannelsTo(i, mbcBand(i, d, st.softVolume))
        wide.set(st.width)
        room.set(st.room)
    }

    override fun release() {
        wide.release()
        room.release()
        dp.release()
    }

    companion object {
        private val mbcEdges = floatArrayOf(250f, 2500f, 21000f)

        private fun mbcBand(i: Int, d: Dyn, softPct: Int = 0) : DynamicsProcessing.MbcBand {
            val amount = softPct.coerceIn(0, 100) / 100f
            // Saat kompresor manual mati, gunakan rasio 1–3, ambang -36 sampai -24 dB,
            // serang/lepas sedang, dan makeup maksimum 4,5 dB.
            val softOnly = softPct > 0 && !d.compOn
            val threshold = if (softOnly) -36f + 12f * amount else d.compThr
            val ratio = if (softOnly) 1f + 2f * amount else d.compRatio
            val attack = if (softOnly) 18f else d.compAtk
            val release = if (softOnly) 220f else d.compRel
            val makeup = (if (d.compOn) d.compMakeup else 0f) + 4.5f * amount
            return DynamicsProcessing.MbcBand(
                true, mbcEdges[i], attack, release, ratio, threshold, 6f, -90f, 1f, 0f, makeup,
            )
        }

        private fun limiter(d: Dyn) = DynamicsProcessing.Limiter(
            true, true, 0, d.limAtk, d.limRel,
            if (d.limOn) d.limRatio else 1f,
            if (d.limOn) d.limThr else 0f,
            d.outGain,
        )

        fun create(session: Int, st: EqState): Fx? = try {
            val n = st.bandCount
            val comp = st.dyn.compOn || st.softVolume > 0
            val cfg = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2,
                true, n, comp, if (comp) 3 else 0, false, 0, true,
            ).build()
            val dp = DynamicsProcessing(0, session, cfg)
            val g = st.effGains()
            val e = Bands.edges(n)
            val eq = DynamicsProcessing.Eq(true, true, n)
            for (i in 0 until n) eq.setBand(i, DynamicsProcessing.EqBand(true, e[i], g[i]))
            dp.setPreEqAllChannelsTo(eq)
            if (comp) {
                val mbc = DynamicsProcessing.Mbc(true, true, 3)
                for (i in 0 until 3) mbc.setBand(i, mbcBand(i, st.dyn, st.softVolume))
                dp.setMbcAllChannelsTo(mbc)
            }
            val fx = DpFx(dp, session)
            fx.setLevels(st)
            dp.setEnabled(true)
            fx
        } catch (t: Throwable) {
            null
        }
    }
}

/**
 * Android 7 sampai 8.1: Equalizer bawaan sistem (biasanya 5 pita) ditambah LoudnessEnhancer untuk penguatan.
 * Kurva 10 atau 32 pita dipetakan ke pita fisik perangkat dengan interpolasi pada skala frekuensi logaritmik.
 * Kompresor, pembatas, dan keseimbangan kiri kanan tidak tersedia di jenis ini.
 */
class LegacyFx private constructor(
    private val eq: Equalizer,
    private val loud: LoudnessEnhancer?,
    session: Int,
) : Fx {
    private val wide = Widener(session)
    private val room = Roomer(session)
    override val widthActive: Boolean get() = wide.active
    override val roomActive: Boolean get() = room.active
    private val count: Int = eq.numberOfBands.toInt()
    private val centers = FloatArray(count) { eq.getCenterFreq(it.toShort()) / 1000f }
    private val minMb: Int = eq.bandLevelRange[0].toInt()
    private val maxMb: Int = eq.bandLevelRange[1].toInt()

    override val deviceBands: Int get() = count

    override fun setBands(st: EqState) = push(st)
    override fun setBand(index: Int, edge: Float, gain: Float, st: EqState) = push(st)
    override fun setLevels(st: EqState) = push(st)

    override fun release() {
        runCatching { eq.release() }
        runCatching { loud?.release() }
        wide.release()
        room.release()
    }

    private fun sample(f: Float, c: FloatArray, g: List<Float>): Float {
        val last = c.size - 1
        if (f <= c[0]) return g[0]
        if (f >= c[last]) return g[last]
        var j = 0
        while (j < last - 1 && f >= c[j + 1]) j++
        val t = ((ln(f.toDouble()) - ln(c[j].toDouble())) / (ln(c[j + 1].toDouble()) - ln(c[j].toDouble()))).toFloat()
        return g[j] + (g[j + 1] - g[j]) * t
    }

    private fun push(st: EqState) {
        wide.set(st.width)
        room.set(st.room)
        val c = Bands.centers(st.bandCount)
        val g = st.effGains()
        // Pada perangkat lama tidak ada DynamicsProcessing/limiter. Kurangi gain
        // global berdasarkan puncak EQ positif agar boost pita tidak menumpuk tanpa headroom.
        val peakEq = maxOf(0f, g.maxOrNull() ?: 0f)
        val softGain = st.softVolume.coerceIn(0, 100) * 0.04f
        val net = st.preamp + st.dyn.outGain + softGain - (if (st.headroom) peakEq else 0f)
        // Penguatan positif lewat LoudnessEnhancer; bila tidak ada, ikut digeser pada pita.
        val shift = if (loud != null) minOf(net, 0f) else net
        for (b in 0 until count) {
            val mb = Math.round((sample(centers[b], c, g) + shift) * 100f).coerceIn(minMb, maxMb)
            eq.setBandLevel(b.toShort(), mb.toShort())
        }
        val le = loud
        if (le != null) {
            val boost = maxOf(net, 0f)
            runCatching {
                le.setTargetGain(Math.round(boost * 100f))
                le.setEnabled(boost > 0f)
            }
        }
    }

    companion object {
        fun create(session: Int, st: EqState): Fx? {
            val eq = try { Equalizer(0, session) } catch (t: Throwable) { return null }
            val loud = try { LoudnessEnhancer(session) } catch (t: Throwable) { null }
            return try {
                val fx = LegacyFx(eq, loud, session)
                fx.push(st)
                eq.setEnabled(true)
                fx
            } catch (t: Throwable) {
                runCatching { eq.release() }
                runCatching { loud?.release() }
                null
            }
        }
    }
}
