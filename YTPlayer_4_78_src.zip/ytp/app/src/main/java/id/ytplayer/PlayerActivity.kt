package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.SurfaceView
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat
import androidx.core.view.ViewCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import org.schabi.newpipe.extractor.stream.Description
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamType
import java.util.Locale

/**
 * Halaman tonton: video (opsional), tombol kontrol besar, bilah posisi yang bisa
 * digeser TalkBack, mode audio saja, kecepatan, pewaktu tidur, deskripsi, video terkait.
 * Pemutaran sebenarnya berjalan di PlaybackService, sehingga lanjut di latar belakang.
 */
class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_UPLOADER = "uploader"
        const val EXTRA_FROM_NOTIFICATION = "from_notification"

        fun intent(ctx: Context, item: VideoItem): Intent =
            Intent(ctx, PlayerActivity::class.java)
                .putExtra(EXTRA_URL, item.url)
                .putExtra(EXTRA_TITLE, item.title)
                .putExtra(EXTRA_UPLOADER, item.uploader)

        private val SPEEDS = floatArrayOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f)
        private const val NORMAL_SPEED_IDX = 3
        private val SLEEP_OPTIONS = intArrayOf(0, 15, 30, 45, 60)
    }

    // views
    private lateinit var scroll: ScrollView
    private lateinit var videoBox: RatioFrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var loading: ProgressBar
    private lateinit var audioOnlyLabel: TextView
    private lateinit var titleTv: TextView
    private lateinit var metaTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var btnBack: Button
    private lateinit var btnPlay: Button
    private lateinit var btnForward: Button
    private lateinit var seek: SeekBar
    private lateinit var positionTv: TextView
    private lateinit var swAudio: Switch
    private lateinit var swAutoplay: Switch
    private val isYtm: Boolean by lazy { Store.appMode(this) == Store.MODE_YTM }
    private lateinit var btnSpeed: Button
    private lateinit var btnAudioQ: Button
    private lateinit var btnSleep: Button
    private lateinit var btnNext: Button
    private lateinit var btnPrevious: Button
    private lateinit var btnDownload: Button
    private lateinit var btnQuality: Button
    private lateinit var btnRepeat: Button
    private lateinit var btnFav: Button
    private lateinit var btnShare: Button
    private lateinit var btnChannel: Button
    private lateinit var btnSubscribe: Button
    private lateinit var descHeader: TextView
    private lateinit var descTv: TextView
    private lateinit var btnDescMore: Button
    private lateinit var relatedHeader: TextView
    private lateinit var relatedBox: LinearLayout

    // state
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var videoUrl = ""
    private var info: StreamInfo? = null
    private var related: List<VideoItem> = emptyList()
    private var retries = 0
    private var tracking = false
    private var speedIdx = NORMAL_SPEED_IDX
    private var uploaderName = ""
    private var sleepIdx = 0
    private var tickCount = 0
    private var suppressModeSwitch = false

    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            ui.postDelayed(this, 500)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            Store.K_AUDIO_ONLY -> applyModeUi()
            Store.K_QUALITY -> updateQualityLabel()
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            loading.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            when (playbackState) {
                Player.STATE_BUFFERING -> setStatus("Menyangga…")
                Player.STATE_READY -> {
                    retries = 0
                    setStatus("")
                }
                Player.STATE_ENDED -> setStatus("Video selesai")
            }
            updatePlayButton()
            updateProgress()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) = updatePlayButton()

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = updatePlayButton()

        override fun onPlayerError(error: PlaybackException) = handlePlayerError(error)

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                videoBox.ratio = videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
            }
            updateQualityLabel()
        }

        override fun onRepeatModeChanged(repeatMode: Int) = updateRepeatLabel()

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val id = mediaItem?.mediaId.orEmpty()
            if (id.isNotEmpty() && id != videoUrl) {
                // Putar otomatis di layanan memilih video berikutnya.
                videoUrl = id
                titleTv.text = mediaItem?.mediaMetadata?.title?.toString().orEmpty()
                metaTv.text = mediaItem?.mediaMetadata?.artist?.toString().orEmpty()
                StreamCache.get(id)?.let { info = it; showInfo(it) }
            }
        }
    }

    // ------------------------------------------------------------------ siklus hidup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        bindViews()
        if (isYtm) {
            // Mode YouTube Musik: istilahnya "lagu", bukan "video".
            btnNext.text = "Lagu berikutnya"
            btnPrevious.text = "Lagu sebelumnya"
            relatedHeader.text = "Lagu terkait"
            swAutoplay.text = "Putar otomatis lagu berikutnya"
        }

        videoUrl = intent.getStringExtra(EXTRA_URL).orEmpty()
        titleTv.text = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        uploaderName = intent.getStringExtra(EXTRA_UPLOADER).orEmpty()
        metaTv.text = uploaderName

        ViewCompat.setAccessibilityHeading(titleTv, true)
        ViewCompat.setAccessibilityHeading(descHeader, true)
        ViewCompat.setAccessibilityHeading(relatedHeader, true)

        setupControls()
        applyModeUi()
        Store.prefs(this).registerOnSharedPreferenceChangeListener(prefListener)
        // Jangan menunggu pengendali tersambung: ambil aliran video berbarengan dengan itu.
        if (videoUrl.isNotEmpty()) Repo.prefetch(videoUrl)
        connect()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val url = intent.getStringExtra(EXTRA_URL).orEmpty()
        if (url.isNotEmpty() && url != videoUrl && !intent.getBooleanExtra(EXTRA_FROM_NOTIFICATION, false)) {
            startNewVideo(
                url,
                intent.getStringExtra(EXTRA_TITLE).orEmpty(),
                intent.getStringExtra(EXTRA_UPLOADER).orEmpty()
            )
        }
    }

    override fun onResume() {
        super.onResume()
        if (::btnSubscribe.isInitialized) updateChannelLabel()
    }

    override fun onStart() {
        super.onStart()
        updateSeekLabels() // lompatan bisa diubah di Pengaturan
        applySurface()
        updateKeepScreenOn()
        ui.post(tick)
    }

    override fun onStop() {
        ui.removeCallbacks(tick)
        controller?.clearVideoSurfaceView(surface)
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onStop()
    }

    override fun onDestroy() {
        Store.prefs(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ pemasangan UI

    private fun bindViews() {
        scroll = findViewById(R.id.scroll)
        videoBox = findViewById(R.id.videoBox)
        surface = findViewById(R.id.surface)
        loading = findViewById(R.id.loading)
        audioOnlyLabel = findViewById(R.id.audioOnlyLabel)
        titleTv = findViewById(R.id.title)
        metaTv = findViewById(R.id.meta)
        statusTv = findViewById(R.id.status)
        btnBack = findViewById(R.id.btnBack)
        btnPlay = findViewById(R.id.btnPlay)
        btnForward = findViewById(R.id.btnForward)
        seek = findViewById(R.id.seek)
        positionTv = findViewById(R.id.position)
        swAudio = findViewById(R.id.swAudioOnly)
        swAutoplay = findViewById(R.id.swAutoplay)
        btnSpeed = findViewById(R.id.btnSpeed)
        btnAudioQ = findViewById(R.id.btnAudioQ)
        btnSleep = findViewById(R.id.btnSleep)
        btnNext = findViewById(R.id.btnNext)
        btnPrevious = findViewById(R.id.btnPrevious)
        btnDownload = findViewById(R.id.btnDownload)
        btnQuality = findViewById(R.id.btnQuality)
        btnRepeat = findViewById(R.id.btnRepeat)
        btnFav = findViewById(R.id.btnFav)
        btnShare = findViewById(R.id.btnShare)
        btnChannel = findViewById(R.id.btnChannel)
        btnSubscribe = findViewById(R.id.btnSubscribe)
        descHeader = findViewById(R.id.descHeader)
        descTv = findViewById(R.id.desc)
        btnDescMore = findViewById(R.id.btnDescMore)
        relatedHeader = findViewById(R.id.relatedHeader)
        relatedBox = findViewById(R.id.relatedBox)
    }

    private fun setupControls() {
        btnPlay.setOnClickListener { togglePlay() }
        btnBack.setOnClickListener {
            controller?.seekBack()
            announcePosition("Mundur ${Store.seekBackSec(this)} detik")
        }
        btnForward.setOnClickListener {
            controller?.seekForward()
            announcePosition("Maju ${Store.seekFwdSec(this)} detik")
        }

        seek.contentDescription = getString(R.string.position)
        seek.keyProgressIncrement = 10
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                positionTv.text = "${Fmt.clock(progress.toLong())} / ${Fmt.clock(sb.max.toLong())}"
                // Saat digeser, TalkBack mengucapkan persentase posisi (mis. "42 persen").
                ViewCompat.setStateDescription(seek, "${percentOf(progress, sb.max)} persen")
                // Digeser lewat TalkBack tidak memicu start/stop tracking → langsung lompat.
                if (!tracking) controller?.seekTo(progress * 1000L)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {
                tracking = true
            }

            override fun onStopTrackingTouch(sb: SeekBar) {
                tracking = false
                controller?.seekTo(sb.progress * 1000L)
            }
        })

        swAudio.setOnCheckedChangeListener { _, checked ->
            if (!suppressModeSwitch) Store.setAudioOnly(this, checked)
        }
        swAutoplay.isChecked = Store.autoplay(this)
        swAutoplay.setOnCheckedChangeListener { _, checked -> Store.setAutoplay(this, checked) }

        updateSpeedLabel()
        btnSpeed.setOnClickListener { showSpeedDialog() }
        updateAudioQLabel()
        btnAudioQ.setOnClickListener { showAudioQDialog() }
        updateSeekLabels()

        updateQualityLabel()
        btnQuality.setOnClickListener { showQualityDialog() }

        findViewById<Button>(R.id.btnEq).setOnClickListener {
            startActivity(Intent(this, id.ytplayer.music.NovanEngineActivity::class.java))
        }

        updateRepeatLabel()
        btnRepeat.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            c.repeatMode = if (c.repeatMode == Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_OFF
            else Player.REPEAT_MODE_ONE
            updateRepeatLabel()
            setStatus(btnRepeat.text.toString())
        }

        updateFavLabel()
        btnFav.setOnClickListener {
            val i = info
            if (i == null) {
                setStatus("Video belum selesai dimuat. Coba lagi sebentar lagi.")
            } else {
                val added = Store.toggleFavorite(this, Repo.itemFrom(videoUrl, i))
                updateFavLabel()
                setStatus(if (added) "Ditambahkan ke favorit" else "Dihapus dari favorit")
            }
        }

        btnShare.text = "Bagikan tautan video"
        btnShare.setOnClickListener {
            if (videoUrl.isEmpty()) return@setOnClickListener
            VideoBinder.shareLink(this, info?.name ?: titleTv.text.toString(), videoUrl)
        }

        btnChannel.setOnClickListener {
            val name = (info?.uploaderName ?: uploaderName).trim()
            val cid = YtApi.channelIdFromUrl(info?.uploaderUrl)
            if (name.isEmpty()) {
                setStatus("Nama channel belum diketahui.")
            } else if (cid != null) {
                startActivity(ChannelActivity.intent(this, cid, name))
            } else {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra(MainActivity.EXTRA_QUERY, name)
                )
            }
        }
        updateChannelLabel()
        btnSubscribe.setOnClickListener { onSubscribeClicked() }
        // Muat ulang daftar langganan di latar belakang bila sudah lama, supaya status "sudah subscribe" tepat.
        if (YtAccount.isLoggedIn(this) && YtAccount.subsStale(this)) {
            Thread {
                YtApi.listSubscriptions(this)
                runOnUiThread { if (!isFinishing && !isDestroyed) updateChannelLabel() }
            }.start()
        }

        showSleep(0)
        btnSleep.setOnClickListener {
            sleepIdx = (sleepIdx + 1) % SLEEP_OPTIONS.size
            sendSleep(SLEEP_OPTIONS[sleepIdx])
        }

        btnPrevious.setOnClickListener {
            // Mengikuti daftar yang tampil saat dipilih (hasil pencarian dll.); bila tidak ada, riwayat putar.
            val q = PlayQueue.previous(videoUrl)
            if (q != null) startNewVideo(q.url, q.title, q.uploader, pushBack = false)
            else if (!PlayQueue.contains(videoUrl) && PlayedSet.hasBack()) {
                val url = PlayedSet.popBack()
                if (url != null) startNewVideo(url, "", "", pushBack = false)
            } else setStatus(if (isYtm) "Tidak ada lagu sebelumnya" else "Tidak ada video sebelumnya")
        }

        btnNext.setOnClickListener {
            // Urutan mengikuti daftar yang tampil saat dipilih (hasil pencarian dll.).
            val q = PlayQueue.next(videoUrl)
            if (q != null) {
                startNewVideo(q.url, q.title, q.uploader)
                return@setOnClickListener
            }
            PlayedSet.add(videoUrl)
            var next = related.firstOrNull { !PlayedSet.has(it.url) }
            if (next == null) {
                // Semua video terkait sudah pernah diputar: mulai daftar dari awal.
                PlayedSet.reset(videoUrl)
                next = related.firstOrNull { it.url != videoUrl }
            }
            if (next == null) setStatus(if (isYtm) "Tidak ada lagu berikutnya" else "Tidak ada video berikutnya")
            else openRelated(next, null)
        }

        btnDownload.setOnClickListener { showDownloadDialog() }

        btnDescMore.setOnClickListener {
            val expanded = descTv.maxLines == Int.MAX_VALUE
            descTv.maxLines = if (expanded) 5 else Int.MAX_VALUE
            btnDescMore.setText(if (expanded) R.string.show_more else R.string.show_less)
        }
        descHeader.visibility = View.GONE
        descTv.visibility = View.GONE
        btnDescMore.visibility = View.GONE
        relatedHeader.visibility = View.GONE
    }

    private fun showDownloadDialog() {
        val i = info
        if (i == null) {
            setStatus("Video belum selesai dimuat. Coba lagi sebentar lagi.")
            return
        }
        if (i.streamType == StreamType.LIVE_STREAM || i.streamType == StreamType.AUDIO_LIVE_STREAM) {
            setStatus("Siaran langsung tidak bisa diunduh.")
            return
        }
        val opts = DownloadOptions.options(i)
        if (opts.isEmpty()) {
            setStatus("Tidak ada format yang bisa diunduh untuk video ini.")
            return
        }
        val name = i.name ?: titleTv.text.toString()
        val groups = listOf(DownloadOptions.GROUP_MP3, DownloadOptions.GROUP_M4A, DownloadOptions.GROUP_MP4)
            .filter { g -> opts.any { it.group == g } }
        val groupLabels = groups.map {
            when (it) {
                DownloadOptions.GROUP_MP3 -> "MP3 (audio, dikonversi)"
                DownloadOptions.GROUP_M4A -> "M4A (audio asli YouTube)"
                else -> "MP4 (video)"
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Pilih format unduhan")
            .setItems(groupLabels.toTypedArray()) { _, which ->
                showDownloadQuality(name, opts.filter { it.group == groups[which] }, groupLabels[which])
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showDownloadQuality(name: String, options: List<DownloadOptions.Option>, title: String) {
        // Hanya satu pilihan: langsung unduh tanpa dialog.
        if (options.size == 1) {
            Downloads.request(this, videoUrl, name, options[0].key)
            setStatus("Memulai unduhan: ${options[0].label}")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("$title: pilih kualitas")
            .setItems(options.map { it.label }.toTypedArray()) { _, which ->
                Downloads.request(this, videoUrl, name, options[which].key)
                setStatus("Memulai unduhan: ${options[which].label}")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Downloads.onPermissionResult(this, requestCode, grantResults)
    }

    private fun speedText(v: Float): String =
        String.format(Locale("id", "ID"), "%.2f", v).trimEnd('0').trimEnd(',')

    private fun updateSpeedLabel() {
        btnSpeed.text = "Kecepatan ${speedText(SPEEDS[speedIdx])}x"
    }

    private fun showSpeedDialog() {
        val labels = SPEEDS.map { if (it == 1.0f) "Normal (1x)" else "${speedText(it)}x" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Kecepatan pemutaran")
            .setSingleChoiceItems(labels, speedIdx) { d, which ->
                speedIdx = which
                controller?.setPlaybackSpeed(SPEEDS[which])
                updateSpeedLabel()
                setStatus(btnSpeed.text.toString())
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun audioQName(level: Int) = when (level) {
        Store.AUDIO_HEMAT -> "Hemat"
        Store.AUDIO_TERBAIK -> "Terbaik"
        else -> "Normal"
    }

    private fun updateAudioQLabel() {
        btnAudioQ.text = "Kualitas audio: ${audioQName(Store.audioQuality(this))}"
    }

    private fun showAudioQDialog() {
        val labels = arrayOf(
            "Hemat",
            "Normal",
            "Terbaik (bawaan, seperti YouTube asli)"
        )
        AlertDialog.Builder(this)
            .setTitle("Kualitas audio (mode audio saja)")
            .setSingleChoiceItems(labels, Store.audioQuality(this)) { d, which ->
                Store.setAudioQuality(this, which)
                updateAudioQLabel()
                setStatus("Kualitas audio: ${audioQName(which)}. Berlaku di mode audio saja.")
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun updateSeekLabels() {
        val b = Store.seekBackSec(this)
        val f = Store.seekFwdSec(this)
        btnBack.text = "Mundur $b detik"
        btnForward.text = "Maju $f detik"
    }

    private fun updateQualityLabel() {
        val q = Store.quality(this)
        val actual = controller?.videoSize?.height ?: 0
        btnQuality.text = when {
            Store.audioOnly(this) -> "Resolusi: audio saja"
            q > 0 -> "Resolusi: ${q}p"
            actual > 0 -> "Resolusi: otomatis (${actual}p)"
            else -> "Resolusi: otomatis"
        }
    }

    private fun showQualityDialog() {
        val i = info
        if (i == null) {
            setStatus("Video belum selesai dimuat. Coba lagi sebentar lagi.")
            return
        }
        if (i.streamType == StreamType.LIVE_STREAM || i.streamType == StreamType.AUDIO_LIVE_STREAM) {
            setStatus("Siaran langsung tidak punya pilihan resolusi.")
            return
        }
        val heights = DownloadOptions.videoPlans(i).map { it.height }
        if (heights.isEmpty()) {
            setStatus("Video ini tidak punya pilihan resolusi.")
            return
        }
        val labels = ArrayList<String>()
        val values = ArrayList<Int>()
        labels += "Otomatis (hemat kuota)"
        values += 0
        heights.forEach {
            labels += "${it}p"
            values += it
        }
        val checked = values.indexOf(Store.quality(this)).let { if (it < 0) 0 else it }
        AlertDialog.Builder(this)
            .setTitle("Resolusi video")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                Store.setQuality(this, values[which])
                if (Store.audioOnly(this)) Store.setAudioOnly(this, false)
                updateQualityLabel()
                setStatus("Resolusi: ${labels[which]}")
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun updateRepeatLabel() {
        val on = controller?.repeatMode == Player.REPEAT_MODE_ONE
        btnRepeat.text = if (on) "Ulangi video: hidup" else "Ulangi video: mati"
    }

    private fun updateFavLabel() {
        btnFav.text = if (videoUrl.isNotEmpty() && Store.isFavorite(this, videoUrl))
            "Hapus dari favorit" else "Tambah ke favorit"
    }

    private fun updateChannelLabel() {
        val name = (info?.uploaderName ?: uploaderName).trim()
        btnChannel.text = if (name.isEmpty()) "Video lain dari channel ini" else "Video lain dari $name"
        // Tombol subscribe / berhenti subscribe muncul untuk semua channel YouTube; labelnya mengikuti status.
        val cid = YtApi.channelIdFromUrl(info?.uploaderUrl)
        if (cid != null && name.isNotEmpty()) btnChannel.text = "Buka channel: $name"
        btnSubscribe.visibility = if (cid == null || name.isEmpty()) View.GONE else View.VISIBLE
        btnSubscribe.text = SubscribeHelper.label(this, cid, name)
    }

    /** Subscribe atau berhenti subscribe (dengan konfirmasi) untuk channel video yang sedang diputar. */
    private fun onSubscribeClicked() {
        val channelId = YtApi.channelIdFromUrl(info?.uploaderUrl)
        if (channelId == null) {
            setStatus("Info channel belum siap atau tautan channel tidak dikenali. Coba lagi sebentar.")
            return
        }
        val name = (info?.uploaderName ?: uploaderName).trim().ifEmpty { "channel ini" }
        SubscribeHelper.toggle(this, channelId, name, { setStatus(it) }) { updateChannelLabel() }
    }

    private fun showSleep(remainingMin: Int) {
        btnSleep.text = if (remainingMin > 0) "Pewaktu tidur: $remainingMin menit lagi"
        else "Pewaktu tidur: mati"
        if (remainingMin > 0) setStatus(btnSleep.text.toString())
    }

    // ------------------------------------------------------------------ pengendali media

    private fun connect() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        controllerFuture = f
        f.addListener({
            try {
                controller = f.get()
                onConnected()
            } catch (e: Exception) {
                setStatus("Gagal terhubung ke pemutar")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onConnected() {
        val c = controller ?: return
        c.addListener(playerListener)
        applySurface()
        updatePlayButton()

        // Sinkronkan pewaktu tidur & kecepatan dari layanan.
        sendSleep(-1)
        speedIdx = SPEEDS.indexOfFirst { it == c.playbackParameters.speed }
            .let { if (it < 0) NORMAL_SPEED_IDX else it }
        updateSpeedLabel()
        updateRepeatLabel()
        updateQualityLabel()

        if (videoUrl.isEmpty()) {
            // Dibuka dari notifikasi: ikuti video yang sedang diputar.
            videoUrl = c.currentMediaItem?.mediaId.orEmpty()
            if (videoUrl.isEmpty()) {
                finish(); return
            }
            val md = c.mediaMetadata
            titleTv.text = md.title?.toString().orEmpty()
            metaTv.text = md.artist?.toString().orEmpty()
        }

        val cur = c.currentMediaItem
        if (cur != null && cur.mediaId == videoUrl) {
            // Video ini sudah diputar: hanya tampilkan halamannya, tanpa memuat atau memutar ulang.
            val cached = StreamCache.get(videoUrl)
            if (cached != null) {
                info = cached; showInfo(cached)
            } else {
                val u = videoUrl
                Repo.fetchStream(u) { stream, _ ->
                    if (isDestroyed || u != videoUrl || stream == null) return@fetchStream
                    info = stream
                    showInfo(stream)
                }
            }
            updateProgress()
        } else {
            loadVideo(videoUrl, 0L)
        }
    }

    private fun loadVideo(url: String, startMs: Long) {
        setStatus(getString(R.string.loading))
        loading.visibility = View.VISIBLE
        Repo.fetchStream(url) { stream, err ->
            if (isDestroyed || url != videoUrl) return@fetchStream
            if (stream == null) {
                loading.visibility = View.GONE
                setStatus(err ?: "Gagal memuat video")
                return@fetchStream
            }
            info = stream
            showInfo(stream)
            val res = StreamResolver.resolve(stream, Store.audioOnly(this), Store.quality(this), Store.audioQuality(this))
            if (res == null) {
                loading.visibility = View.GONE
                setStatus("Tidak ada aliran yang bisa diputar untuk video ini.")
                return@fetchStream
            }
            // Sudah dikirim dari halaman daftar (QuickPlay): jangan memuat ulang, suara sudah terputar.
            if (startMs == 0L && QuickPlay.consumeSent(url)) return@fetchStream
            val c = controller ?: return@fetchStream
            c.sendCustomCommand(PlaybackService.LOAD_COMMAND, StreamResolver.toBundle(url, stream, res, startMs))
            Store.addHistory(this, Repo.itemFrom(url, stream))
        }
    }

    private fun handlePlayerError(error: PlaybackException) {
        val url = videoUrl
        if (url.isNotEmpty() && retries < 1) {
            // Tautan aliran biasanya kedaluwarsa → ambil ulang sekali lalu lanjutkan.
            retries++
            QuickPlay.clear()
            val pos = controller?.currentPosition ?: 0L
            StreamCache.remove(url)
            setStatus("Mencoba lagi…")
            loadVideo(url, pos)
        } else {
            loading.visibility = View.GONE
            setStatus("Gagal memutar video (${error.errorCodeName}). Coba video lain.")
        }
    }

    private fun togglePlay() {
        val c = controller ?: return
        when {
            c.playbackState == Player.STATE_ENDED -> { c.seekTo(0); c.play() }
            c.playWhenReady -> c.pause()
            else -> {
                if (c.playbackState == Player.STATE_IDLE) c.prepare()
                c.play()
            }
        }
    }

    private fun updatePlayButton() {
        val c = controller
        val playing = c != null && c.playWhenReady &&
            c.playbackState != Player.STATE_ENDED && c.playbackState != Player.STATE_IDLE
        btnPlay.setText(if (playing) R.string.pause else R.string.play)
        updateKeepScreenOn()
    }

    /**
     * Seperti YouTube asli: layar tidak mati selama video sedang diputar (mode video) di halaman
     * ini. Dijeda, selesai, atau mode audio saja = ikut pengaturan HP. Suara tetap berbunyi saat
     * layar dimatikan / aplikasi ditutup karena diputar oleh PlaybackService.
     */
    private fun updateKeepScreenOn() {
        val c = controller
        val keep = c != null && c.playWhenReady && !Store.audioOnly(this) &&
            (c.playbackState == Player.STATE_READY || c.playbackState == Player.STATE_BUFFERING)
        if (keep) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun applySurface() {
        val c = controller ?: return
        if (Store.audioOnly(this)) c.clearVideoSurfaceView(surface) else c.setVideoSurfaceView(surface)
    }

    private fun applyModeUi() {
        val audioOnly = Store.audioOnly(this)
        if (swAudio.isChecked != audioOnly) {
            suppressModeSwitch = true
            swAudio.isChecked = audioOnly
            suppressModeSwitch = false
        }
        videoBox.visibility = if (audioOnly) View.GONE else View.VISIBLE
        audioOnlyLabel.visibility = if (audioOnly) View.VISIBLE else View.GONE
        // Kualitas audio hanya relevan (dan tampil) saat mode audio saja aktif.
        btnAudioQ.visibility = if (audioOnly) View.VISIBLE else View.GONE
        applySurface()
        updateKeepScreenOn()
    }

    // ------------------------------------------------------------------ sleep timer

    private fun sendSleep(minutes: Int) {
        val c = controller ?: return
        val args = Bundle().apply { putInt(PlaybackService.KEY_MINUTES, minutes) }
        val f = c.sendCustomCommand(PlaybackService.SLEEP_COMMAND, args)
        f.addListener({
            try {
                val left = f.get().extras.getInt(PlaybackService.KEY_MINUTES, 0)
                showSleep(left)
                if (minutes == 0) setStatus("Pewaktu tidur dimatikan")
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ------------------------------------------------------------------ progres

    private fun updateProgress() {
        val c = controller ?: return
        val posSec = (c.currentPosition / 1000).coerceAtLeast(0)
        val durMs = c.duration
        val live = c.isCurrentMediaItemLive
        val durSec = if (durMs > 0 && !live) durMs / 1000 else 0L

        seek.isEnabled = durSec > 0
        val max = durSec.coerceAtLeast(1).toInt()
        if (seek.max != max) seek.max = max
        if (!tracking) {
            seek.progress = posSec.coerceAtMost(max.toLong()).toInt()
            positionTv.text = if (live) "Siaran langsung" else "${Fmt.clock(posSec)} / ${Fmt.clock(durSec)}"
        }
        // stateDescription tidak diperbarui terlalu sering agar TalkBack tidak cerewet.
        if (!tracking && tickCount++ % 10 == 0) {
            ViewCompat.setStateDescription(
                seek,
                if (live) "Siaran langsung"
                else "${percentOf(posSec.toInt(), max)} persen, " +
                    "${Fmt.spokenDuration(posSec)} dari ${Fmt.spokenDuration(durSec)}"
            )
        }
    }

    private fun percentOf(progress: Int, max: Int): Int =
        if (max <= 0) 0 else (progress * 100L / max).toInt().coerceIn(0, 100)

    private fun announcePosition(prefix: String) {
        val c = controller ?: return
        ui.postDelayed({
            setStatus("$prefix. Posisi ${Fmt.spokenDuration(c.currentPosition / 1000)}")
        }, 150)
    }

    // ------------------------------------------------------------------ info video

    private fun setStatus(text: String) {
        // Area status tidak memakan ruang saat kosong; tampil dulu baru teks diubah agar tetap dibacakan.
        statusTv.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
        statusTv.text = text
    }

    private fun showInfo(stream: StreamInfo) {
        titleTv.text = stream.name
        uploaderName = stream.uploaderName ?: uploaderName
        updateFavLabel()
        updateChannelLabel()
        val item = Repo.itemFrom(videoUrl, stream)
        metaTv.text = item.meta()

        val d = stream.description
        val text = if (d != null && d.type == Description.HTML)
            HtmlCompat.fromHtml(d.content, HtmlCompat.FROM_HTML_MODE_COMPACT).toString().trim()
        else d?.content.orEmpty()
        val has = text.isNotBlank()
        descTv.text = text
        descHeader.visibility = if (has) View.VISIBLE else View.GONE
        descTv.visibility = if (has) View.VISIBLE else View.GONE
        btnDescMore.visibility = if (has && text.length > 200) View.VISIBLE else View.GONE

        showRelated(Repo.relatedOf(stream))
    }

    private fun showRelated(items: List<VideoItem>) {
        related = items.take(20)
        relatedBox.removeAllViews()
        val inflater = LayoutInflater.from(this)
        related.forEach { item ->
            val v = inflater.inflate(R.layout.item_video, relatedBox, false)
            VideoBinder.bind(v, item) { i, audio -> openRelated(i, audio) }
            relatedBox.addView(v)
        }
        relatedHeader.visibility = if (related.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun openRelated(item: VideoItem, audio: Boolean?) {
        if (audio != null) Store.setAudioOnly(this, audio)
        startNewVideo(item.url, item.title, item.uploader)
    }

    private fun startNewVideo(url: String, title: String, uploader: String, pushBack: Boolean = true) {
        PlayedSet.add(videoUrl)
        if (pushBack && videoUrl != url) PlayedSet.pushBack(videoUrl)
        videoUrl = url
        retries = 0
        info = null
        uploaderName = uploader
        updateFavLabel()
        updateChannelLabel()
        titleTv.text = title
        metaTv.text = uploader
        descHeader.visibility = View.GONE
        descTv.visibility = View.GONE
        btnDescMore.visibility = View.GONE
        relatedBox.removeAllViews()
        relatedHeader.visibility = View.GONE
        related = emptyList()
        scroll.scrollTo(0, 0)
        // Pindahkan fokus TalkBack ke judul video yang baru.
        titleTv.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
        loadVideo(url, 0L)
    }
}
