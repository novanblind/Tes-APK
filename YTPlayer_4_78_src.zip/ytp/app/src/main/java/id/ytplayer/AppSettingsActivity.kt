package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.core.view.ViewCompat
import id.ytplayer.music.NovanEngineActivity
import id.ytplayer.music.Prefs

/**
 * Satu halaman pengaturan untuk YT Player dan YouTube Music (keduanya memakai pemutar dan pengaturan yang
 * sama), termasuk jalan masuk ke Mesin audio Novan, dan jalan masuk ke pengaturan Music Player.
 */
class AppSettingsActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var btnAudioQ: Button
    private lateinit var btnSeekBack: Button
    private lateinit var btnSeekFwd: Button
    private lateinit var btnPrevSec: Button
    private lateinit var btnAudioOnly: Button
    private lateinit var btnAudioFocus: Button
    private lateinit var btnLoudness: Button
    private lateinit var btnNovan: Button
    private lateinit var btnAccount: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_settings)
        ViewCompat.setAccessibilityHeading(findViewById(R.id.setTitle), true)
        status = findViewById(R.id.setStatus)
        btnAudioQ = findViewById(R.id.setAudioQ)
        btnSeekBack = findViewById(R.id.setSeekBack)
        btnSeekFwd = findViewById(R.id.setSeekFwd)
        btnPrevSec = findViewById(R.id.setPrevSec)
        btnAudioOnly = findViewById(R.id.setAudioOnly)
        btnAudioFocus = findViewById(R.id.setAudioFocus)
        btnLoudness = findViewById(R.id.setLoudness)
        btnNovan = findViewById(R.id.setNovan)
        btnAccount = findViewById(R.id.setAccount)
        val btnMusic = findViewById<Button>(R.id.setMusic)
        btnMusic.text = "Pengaturan Music Player"
        findViewById<Button>(R.id.setClose).apply {
            text = "Kembali"
            setOnClickListener { finish() }
        }

        btnAudioQ.setOnClickListener { chooseAudioQ() }
        btnSeekBack.setOnClickListener { chooseSeek(true) }
        btnSeekFwd.setOnClickListener { chooseSeek(false) }
        btnPrevSec.setOnClickListener { choosePrevSec() }
        btnAudioOnly.setOnClickListener {
            Store.setAudioOnly(this, !Store.audioOnly(this))
            refresh()
            status.text = btnAudioOnly.text
        }
        btnAudioFocus.setOnClickListener {
            Store.setAudioFocus(this, !Store.audioFocus(this))
            refresh()
            status.text = btnAudioFocus.text.toString() + if (Store.audioFocus(this))
                ". Pemutaran dijeda saat aplikasi lain bersuara." else ". Pemutaran jalan terus bersama suara aplikasi lain."
        }
        btnLoudness.setOnClickListener {
            Store.setLoudness(this, !Store.loudness(this))
            refresh()
            status.text = btnLoudness.text.toString() + if (Store.loudness(this))
                ". Suara diperkuat dan dirata-ratakan agar lebih jelas." else ". Suara apa adanya."
        }
        // Mesin audio Novan: satu pengaturan yang sama untuk YT Player, YouTube Music, dan Music Player.
        btnNovan.setOnClickListener {
            startActivity(Intent(this, NovanEngineActivity::class.java))
        }
        btnAccount.setOnClickListener { onAccountClicked() }
        findViewById<Button>(R.id.setAddAccount).setOnClickListener {
            // Menyimpan akun yang sedang dipakai lebih dulu (bila ada), lalu membuka layar masuk untuk akun lain.
            startActivityForResult(
                Intent(this, YtLoginActivity::class.java).putExtra(YtLoginActivity.EXTRA_ADD, true), REQ_LOGIN
            )
        }
        btnMusic.setOnClickListener {
            startActivity(Intent(this, id.ytplayer.music.SettingsActivity::class.java))
        }
        status.text = "Pengaturan di halaman ini berlaku sama untuk YT Player dan YouTube Music. Pengaturan Music Player ada di tombol paling bawah."
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh() // status Mesin audio Novan bisa berubah di layarnya sendiri
    }

    private fun audioQName(level: Int) = when (level) {
        Store.AUDIO_HEMAT -> "Hemat"
        Store.AUDIO_TERBAIK -> "Terbaik"
        else -> "Normal"
    }

    private fun refresh() {
        btnAudioQ.text = "Kualitas audio pemutaran: ${audioQName(Store.audioQuality(this))}"
        btnSeekBack.text = "Lompat mundur: ${Store.seekBackSec(this)} detik"
        btnSeekFwd.text = "Lompat maju: ${Store.seekFwdSec(this)} detik"
        btnPrevSec.text = "Tombol sebelumnya mengulang setelah: ${Prefs.prevRestartSec(this)} detik"
        btnAudioOnly.text = "Mode audio saja: " + if (Store.audioOnly(this)) "hidup" else "mati"
        btnAudioFocus.text = "Fokus suara YT Player dan YouTube Music: " + if (Store.audioFocus(this)) "hidup" else "mati"
        btnLoudness.text = "Volume stabil: " + if (Store.loudness(this)) "hidup" else "mati"
        val novanOn = Prefs.of(this).getBoolean(id.ytplayer.music.NovanEngine.K_ON, false)
        btnNovan.text = "Mesin audio Novan: " + (if (novanOn) "menyala" else "mati") + ". Buka"
        btnNovan.contentDescription = "Mesin audio Novan, pemrosesan suara 64-bit untuk YT Player, YouTube Music, dan Music Player. " +
            "Sekarang " + (if (novanOn) "menyala" else "mati") + ". Buka pengaturannya"
        val acc = try { YtAccount.isLoggedIn(this) } catch (_: Throwable) { false }
        val accName = if (acc) YtAccount.name(this) else null
        btnAccount.text = when {
            !acc -> "Akun YouTube: belum masuk. Buka untuk masuk"
            accName != null -> "Akun YouTube: masuk sebagai $accName. Buka"
            else -> "Akun YouTube: sudah masuk. Buka"
        }
        // Kualitas audio hanya tampil saat mode audio saja aktif.
        btnAudioQ.visibility = if (Store.audioOnly(this)) View.VISIBLE else View.GONE
    }

    /** Daftar akun: pindah, tambah, keluar; plus periksa status akun yang sedang dipakai. */
    private fun onAccountClicked() {
        val logged = YtAccount.isLoggedIn(this)
        AccountDialog.show(
            this, REQ_LOGIN,
            if (logged) "Periksa status akun" else null,
            { checkAccount() }
        ) { msg -> status.text = msg; refresh() }
    }

    private fun checkAccount() {
        status.text = "Memeriksa akun YouTube, mohon tunggu."
        Thread {
            val r = YtApi.checkStatus(this)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                status.text = when (r) {
                    is YtApi.Status.Ok -> "Akun YouTube aktif. Masuk sebagai ${r.name}."
                    YtApi.Status.NotLoggedIn -> "Belum masuk ke akun YouTube."
                    YtApi.Status.Invalid -> "Sesi akun tidak sah atau sudah kedaluwarsa. Pilih Keluar, lalu masuk lagi."
                    is YtApi.Status.Error -> "Gagal memeriksa akun: ${r.message}. Periksa sambungan internet."
                }
                refresh()
            }
        }.start()
    }

    private fun confirmLogout() {
        AlertDialog.Builder(this)
            .setTitle("Keluar dari akun YouTube?")
            .setMessage("Sesi yang tersimpan di aplikasi ini dihapus. Pemutaran dan unduhan tidak terpengaruh.")
            .setPositiveButton("Keluar") { _, _ ->
                YtAccount.clear(this)
                val cm = android.webkit.CookieManager.getInstance()
                cm.removeAllCookies(null)
                cm.flush()
                status.text = "Sudah keluar dari akun YouTube."
                refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_LOGIN) {
            if (resultCode == RESULT_OK) {
                status.text = "Berhasil masuk ke akun YouTube. Memeriksa nama akun."
                refresh()
                checkAccount()
            } else {
                status.text = "Masuk dibatalkan."
            }
        }
    }

    companion object {
        private const val REQ_LOGIN = 41
    }

    private fun chooseAudioQ() {
        val labels = arrayOf("Hemat", "Normal", "Terbaik")
        AlertDialog.Builder(this)
            .setTitle("Kualitas audio (mode audio saja)")
            .setSingleChoiceItems(labels, Store.audioQuality(this)) { d, which ->
                Store.setAudioQuality(this, which)
                refresh()
                status.text = "Kualitas audio: ${audioQName(which)}. Berlaku di mode audio saja."
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Batas waktu tombol "sebelumnya"; pengaturan yang sama dipakai Music Player dan YouTube Music. */
    private fun choosePrevSec() {
        val choices = Prefs.PREV_RESTART_CHOICES
        AlertDialog.Builder(this)
            .setTitle("Tombol sebelumnya mengulang setelah")
            .setSingleChoiceItems(
                choices.map { "$it detik" }.toTypedArray(),
                choices.indexOf(Prefs.prevRestartSec(this)).coerceAtLeast(0)
            ) { d, which ->
                Prefs.setPrevRestartSec(this, choices[which])
                refresh()
                status.text = "Sebelumnya: lewat ${choices[which]} detik, lagu diulang dari awal; sebelum itu pindah ke item sebelumnya."
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun chooseSeek(back: Boolean) {
        val choices = Store.SEEK_CHOICES
        val cur = if (back) Store.seekBackSec(this) else Store.seekFwdSec(this)
        AlertDialog.Builder(this)
            .setTitle(if (back) "Lompat mundur" else "Lompat maju")
            .setSingleChoiceItems(choices.map { "$it detik" }.toTypedArray(), choices.indexOf(cur).coerceAtLeast(0)) { d, which ->
                if (back) Store.setSeekBackSec(this, choices[which]) else Store.setSeekFwdSec(this, choices[which])
                refresh()
                status.text = (if (back) "Mundur " else "Maju ") + "${choices[which]} detik"
                d.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
