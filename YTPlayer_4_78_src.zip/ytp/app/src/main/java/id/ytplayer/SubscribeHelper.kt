package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent

/**
 * Subscribe dan berhenti subscribe dalam satu tombol, dipakai di pemutar, halaman channel,
 * dan daftar channel. Berhenti subscribe selalu minta konfirmasi.
 */
object SubscribeHelper {

    fun isSubscribed(c: Context, channelId: String?): Boolean =
        channelId != null && YtAccount.isLoggedIn(c) && YtAccount.subs(c).contains(channelId)

    fun label(c: Context, channelId: String?, name: String): String =
        if (isSubscribed(c, channelId)) "Berhenti subscribe: $name" else "Subscribe: $name"

    /** [say] mengumumkan status; [onChanged] dipanggil di utas UI dengan status baru (true = sekarang subscribe). */
    fun toggle(act: Activity, channelId: String, name: String, say: (String) -> Unit, onChanged: (Boolean) -> Unit) {
        if (!YtAccount.isLoggedIn(act)) {
            AlertDialog.Builder(act)
                .setTitle("Belum masuk akun YouTube")
                .setMessage("Untuk subscribe atau berhenti subscribe, masuk dulu ke akun YouTube.")
                .setPositiveButton("Masuk") { _, _ -> act.startActivity(Intent(act, YtLoginActivity::class.java)) }
                .setNegativeButton("Batal", null)
                .show()
            return
        }
        if (isSubscribed(act, channelId)) {
            AlertDialog.Builder(act)
                .setTitle("Berhenti subscribe dari $name?")
                .setPositiveButton("Berhenti subscribe") { _, _ -> run(act, channelId, name, false, say, onChanged) }
                .setNegativeButton("Batal", null)
                .show()
        } else {
            run(act, channelId, name, true, say, onChanged)
        }
    }

    private fun run(
        act: Activity, channelId: String, name: String, subscribe: Boolean,
        say: (String) -> Unit, onChanged: (Boolean) -> Unit
    ) {
        say(if (subscribe) "Subscribe ke $name, mohon tunggu." else "Berhenti subscribe dari $name, mohon tunggu.")
        Thread {
            val r = YtApi.setSubscribed(act, channelId, subscribe)
            act.runOnUiThread {
                if (act.isFinishing || act.isDestroyed) return@runOnUiThread
                say(when (r) {
                    YtApi.Result.Ok ->
                        if (subscribe) "Berhasil subscribe ke $name." else "Berhasil berhenti subscribe dari $name."
                    YtApi.Result.NotLoggedIn -> "Belum masuk akun YouTube."
                    YtApi.Result.Invalid -> "Sesi akun tidak sah atau kedaluwarsa. Buka Anda, Keluar, lalu masuk lagi."
                    is YtApi.Result.Error -> "Gagal: ${r.message}. Periksa sambungan internet."
                })
                if (r == YtApi.Result.Ok) onChanged(subscribe)
            }
        }.start()
    }
}
