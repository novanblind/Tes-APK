package id.ytplayer

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import id.ytplayer.music.BitPerfect
import id.ytplayer.music.NovanEngine
import id.ytplayer.music.NovanRenderersFactory
import id.ytplayer.music.Prefs
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamType
import kotlin.math.ceil

/**
 * Pemutar yang berjalan di latar belakang (foreground service + MediaSession).
 * Tetap memutar saat layar mati / aplikasi ditutup, dan bisa dikendalikan dari
 * notifikasi, layar kunci, serta tombol headset.
 */
class PlaybackService : MediaSessionService() {

    companion object {
        const val CMD_SLEEP = "id.ytplayer.SLEEP_TIMER"
        const val CMD_LOAD = "id.ytplayer.LOAD"
        const val KEY_MINUTES = "minutes"
        val SLEEP_COMMAND = SessionCommand(CMD_SLEEP, Bundle.EMPTY)
        val LOAD_COMMAND = SessionCommand(CMD_LOAD, Bundle.EMPTY)
    }

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private lateinit var sourceFactory: DefaultMediaSourceFactory
    private var curVideoUri: String? = null
    private var curAudioUri: String? = null
    private var loudness: LoudnessEnhancer? = null
    private val handler = Handler(Looper.getMainLooper())

    private var sleepAt = 0L
    private val sleepRunnable = Runnable {
        player.pause()
        sleepAt = 0L
    }

    /**
     * Mesin audio Novan: pengaturan suara per perangkat (speaker, kabel, Bluetooth, USB) ikut berganti
     * saat perangkat keluaran berganti, sama seperti di Music Player.
     */
    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) = syncEngineDevice()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) = syncEngineDevice()
    }

    private fun syncEngineDevice() {
        handler.postDelayed({ NovanEngine.syncDevice(this) }, 500L)
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Store.K_AUDIO_ONLY || key == Store.K_QUALITY || key == Store.K_AUDIO_QUALITY) reloadForMode()
        if (key == Store.K_LOUDNESS) applyLoudness()
        if (key == Store.K_AUDIO_FOCUS) {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                Store.audioFocus(this)
            )
        }
    }

    private val callback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(SLEEP_COMMAND)
                .add(LOAD_COMMAND)
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        /**
         * Tombol media dari luar (pembaca layar seperti Jieshuo, headset, Bluetooth).
         * "Berikutnya" dan "sebelumnya" ditangani langsung di sini, tanpa bergantung pada
         * pemeriksaan perintah/aksi sesi, karena pemutar ini hanya memuat satu item.
         */
        override fun onMediaButtonEvent(
            session: MediaSession,
            controllerInfo: MediaSession.ControllerInfo,
            intent: Intent
        ): Boolean {
            val ke: KeyEvent? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
            }
            if (ke == null) return false
            return when (ke.keyCode) {
                KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    if (ke.action == KeyEvent.ACTION_DOWN && ke.repeatCount == 0) goNext()
                    true
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    if (ke.action == KeyEvent.ACTION_DOWN && ke.repeatCount == 0) goPrevious()
                    true
                }
                else -> false
            }
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == CMD_LOAD) {
                val item = StreamResolver.mediaItemFrom(args)
                startPlayback(item, args.getString("audio"), args.getLong("start", 0L), true)
                prefetchNext(item.mediaId)
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
            }
            if (customCommand.customAction == CMD_SLEEP) {
                val minutes = args.getInt(KEY_MINUTES, -1)
                if (minutes >= 0) setSleep(minutes)
                val out = Bundle().apply { putInt(KEY_MINUTES, remainingMinutes()) }
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS, out))
            }
            return super.onCustomCommand(session, controller, customCommand, args)
        }
    }

    override fun onCreate() {
        super.onCreate()

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(DownloaderImpl.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)

        sourceFactory = DefaultMediaSourceFactory(this).setDataSourceFactory(http)

        // Mulai putar setelah ±0,5 detik terisi (bawaan 2,5 detik) agar video lebih cepat bunyi.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs = */ 30_000,
                /* maxBufferMs = */ 60_000,
                /* bufferForPlaybackMs = */ 500,
                /* bufferForPlaybackAfterRebufferMs = */ 2_000
            )
            .build()

        // Mesin audio Novan (pemrosesan suara 64-bit sendiri), sama dengan Music Player dan memakai
        // pengaturan yang sama (Pengaturan > Mesin audio Novan). Berlaku untuk YT Player dan YouTube Music.
        NovanEngine.reload(this)
        NovanEngine.setReplayGain(0.0) // ReplayGain hanya untuk Music Player; jangan bawa sisa nilai lagu terakhir
        NovanEngine.syncDevice(this)

        player = ExoPlayer.Builder(this, NovanRenderersFactory(this))
            .setMediaSourceFactory(sourceFactory)
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                /* handleAudioFocus = */ Store.audioFocus(this)
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) onEnded()
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                applyLoudness()
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                // Perangkat menolak laju atau mode keluaran pilihan mesin Novan: ulangi dengan laju berkas.
                if (NovanEngine.handleSinkError(error)) {
                    player.prepare()
                    player.play()
                }
            }
        })
        // Sesi audio sendiri yang tetap, supaya "Volume stabil" menempel padanya.
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val sid = am.generateAudioSessionId()
        if (sid != AudioManager.ERROR) player.setAudioSessionId(sid)
        am.registerAudioDeviceCallback(deviceCallback, handler)
        applyLoudness()
        applyTrackSelection(Store.audioOnly(this))

        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_FROM_NOTIFICATION, true)
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, SeekPlayer(player))
            .setId("yt_player")
            .setCallback(callback)
            .setSessionActivity(open)
            .build()

        Store.prefs(this).registerOnSharedPreferenceChangeListener(prefListener)
    }

    /** "Volume stabil": penguat + pembatas bawaan Android pada sesi audio pemutar. */
    private fun applyLoudness() {
        try {
            loudness?.release()
            loudness = null
            if (!Store.loudness(this)) return
            val sid = player.audioSessionId
            if (sid == C.AUDIO_SESSION_ID_UNSET) return
            loudness = LoudnessEnhancer(sid).apply {
                setTargetGain(500) // +5 dB
                enabled = true
            }
        } catch (e: Throwable) {
            loudness = null
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Aplikasi digeser dari daftar terbaru: tetap memutar bila sedang berjalan. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        Store.prefs(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        handler.removeCallbacksAndMessages(null)
        try {
            (getSystemService(AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(deviceCallback)
        } catch (_: Throwable) {}
        if (Build.VERSION.SDK_INT >= 34) BitPerfect.clear(this)
        session?.release()
        session = null
        try { loudness?.release() } catch (e: Throwable) {}
        loudness = null
        player.release()
        super.onDestroy()
    }

    // ------------------------------------------------------------------

    /** Tombol mundur / maju (aplikasi, notifikasi, layar kunci, headset) memakai lompatan pilihan pengguna. */
    private inner class SeekPlayer(p: Player) : ForwardingPlayer(p) {
        override fun getSeekBackIncrement(): Long = Store.seekBackSec(this@PlaybackService) * 1000L
        override fun getSeekForwardIncrement(): Long = Store.seekFwdSec(this@PlaybackService) * 1000L

        override fun seekBack() {
            val w = getWrappedPlayer()
            w.seekTo((w.currentPosition - getSeekBackIncrement()).coerceAtLeast(0L))
        }

        override fun seekForward() {
            val w = getWrappedPlayer()
            var target = w.currentPosition + getSeekForwardIncrement()
            val dur = w.duration
            if (dur != C.TIME_UNSET) target = minOf(target, dur)
            w.seekTo(target)
        }

        // Pemutar hanya memuat satu video, sehingga media3 menganggap tidak ada item berikutnya/sebelumnya
        // dan menyembunyikan/menonaktifkan tombolnya di notifikasi. Tombol dinyalakan di sini:
        // berikutnya memutar video terkait pertama yang belum diputar (seperti putar otomatis),
        // sebelumnya kembali ke video yang diputar sebelumnya (atau mengulang dari awal bila sudah
        // lewat batas di Pengaturan (bawaan 10 detik) atau tidak ada video sebelumnya).
        override fun getAvailableCommands(): Player.Commands =
            super.getAvailableCommands().buildUpon()
                .add(Player.COMMAND_SEEK_TO_NEXT)
                .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                .build()

        override fun isCommandAvailable(command: Int): Boolean =
            command == Player.COMMAND_SEEK_TO_NEXT ||
                command == Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM ||
                command == Player.COMMAND_SEEK_TO_PREVIOUS ||
                command == Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM ||
                super.isCommandAvailable(command)

        override fun hasNextMediaItem(): Boolean = true

        override fun seekToNext() = goNext()

        override fun seekToNextMediaItem() = goNext()

        override fun seekToPrevious() = goPrevious()

        override fun seekToPreviousMediaItem() {
            if (canGoPrevious()) playPrevious() else getWrappedPlayer().seekTo(0L)
        }
    }

    /** Lagu/video berikutnya (dipakai tombol media dari mana pun). */
    private fun goNext() {
        if (player.mediaItemCount == 0) return
        playNext()
    }

    /**
     * Sebelumnya: bila sudah lewat batas di Pengaturan (bawaan 10 detik) atau tidak ada item
     * sebelumnya, ulang dari awal; selain itu mundur satu item. Pengaturannya sama dengan Music Player.
     */
    private fun goPrevious() {
        if (player.mediaItemCount == 0) return
        val restart = Prefs.of(this).getBoolean(Prefs.PREV_RESTART, true)
        if ((restart && player.currentPosition > Prefs.prevRestartMs(this)) || !canGoPrevious()) {
            player.seekTo(0L)
        } else {
            playPrevious()
        }
    }

    private fun applyTrackSelection(audioOnly: Boolean) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly)
            .build()
    }

    /** Video + audio terpisah digabung (resolusi tinggi) atau satu aliran biasa. */
    private fun startPlayback(item: MediaItem, audioUri: String?, startMs: Long, play: Boolean) {
        curVideoUri = item.localConfiguration?.uri?.toString()
        curAudioUri = audioUri
        if (audioUri == null) {
            player.setMediaItem(item, startMs)
        } else {
            val v = sourceFactory.createMediaSource(item)
            val a = sourceFactory.createMediaSource(MediaItem.fromUri(audioUri))
            player.setMediaSource(MergingMediaSource(v, a), startMs)
        }
        player.prepare()
        player.playWhenReady = play
    }

    /** Mode audio saja atau resolusi diganti: bangun ulang sumber media di posisi yang sama. */
    private fun reloadForMode() {
        val audioOnly = Store.audioOnly(this)
        applyTrackSelection(audioOnly)
        val cur = player.currentMediaItem ?: return
        val key = cur.mediaId
        val info = StreamCache.get(key) ?: return
        val res = StreamResolver.resolve(info, audioOnly, Store.quality(this), Store.audioQuality(this)) ?: return
        if (res.uri == curVideoUri && res.audioUri == curAudioUri) return
        startPlayback(
            StreamResolver.mediaItem(key, info, res), res.audioUri,
            player.currentPosition, player.playWhenReady
        )
    }

    /** Video selesai: putar video terkait pertama bila "putar otomatis" aktif. */
    private fun onEnded() {
        if (!Store.autoplay(this)) return
        playNext()
    }

    /**
     * Putar video berikutnya. Dipakai putar otomatis dan tombol "berikutnya" di notifikasi,
     * layar kunci, serta headset. Urutan mengikuti daftar yang tampil saat video dipilih
     * (hasil pencarian dll.); bila video ini tidak ada di antrean, putar video terkait
     * pertama yang belum diputar.
     */
    private fun playNext() {
        val key = player.currentMediaItem?.mediaId ?: return
        val q = PlayQueue.next(key)
        if (q != null) {
            playQueueItem(key, q, 5)
            return
        }
        val cached = StreamCache.get(key)
        if (cached != null) {
            playRelatedOf(key, cached)
        } else {
            // Cache kedaluwarsa: ambil ulang info video ini untuk mendapatkan daftar video terkait.
            Repo.fetchStream(key) { info, _ -> if (info != null) playRelatedOf(key, info) }
        }
    }

    /** Putar [item] dari antrean; bila gagal dimuat, coba video sesudahnya (paling banyak [tries] kali). */
    private fun playQueueItem(from: String, item: VideoItem, tries: Int) {
        Repo.fetchStream(item.url) { i, _ ->
            if (i != null) {
                PlayedSet.add(from)
                PlayedSet.pushBack(from)
                playInfo(item.url, i)
            } else if (tries > 1) {
                PlayQueue.next(item.url)?.let { playQueueItem(from, it, tries - 1) }
            } else {
                // Tidak ada lagi yang dicoba.
            }
        }
    }

    private fun playRelatedOf(key: String, info: StreamInfo) {
        PlayedSet.add(key)
        val videos = info.relatedItems
            .filterIsInstance<org.schabi.newpipe.extractor.stream.StreamInfoItem>()
            .filter { it.streamType == StreamType.VIDEO_STREAM && it.url != key }
        val next = videos.firstOrNull { !PlayedSet.has(it.url) }
            ?: run {
                // Semua video terkait sudah pernah diputar: mulai daftar dari awal, jangan diam saja.
                PlayedSet.reset(key)
                videos.firstOrNull()
            }
            ?: return
        Repo.fetchStream(next.url) { i, _ ->
            if (i != null) {
                PlayedSet.pushBack(key)
                playInfo(next.url, i)
            }
        }
    }

    /** Ada video sebelumnya? Bila video ini ada di antrean, antrean yang menentukan. */
    private fun canGoPrevious(): Boolean {
        val key = player.currentMediaItem?.mediaId.orEmpty()
        if (PlayQueue.contains(key)) return PlayQueue.previous(key) != null
        return PlayedSet.hasBack()
    }

    /** Kembali ke video sebelumnya (tombol "sebelumnya"): di antrean, atau yang diputar sebelumnya. */
    private fun playPrevious() {
        val key = player.currentMediaItem?.mediaId.orEmpty()
        val q = PlayQueue.previous(key)
        if (q != null) {
            Repo.fetchStream(q.url) { i, _ -> if (i != null) playInfo(q.url, i) }
            return
        }
        if (PlayQueue.contains(key)) { player.seekTo(0L); return }
        val url = PlayedSet.popBack() ?: run { player.seekTo(0L); return }
        val cached = StreamCache.get(url)
        if (cached != null) {
            playInfo(url, cached)
        } else {
            Repo.fetchStream(url) { i, _ ->
                if (i != null) playInfo(url, i) else PlayedSet.pushBack(url)
            }
        }
    }

    private fun playInfo(key: String, info: StreamInfo) {
        val res = StreamResolver.resolve(info, Store.audioOnly(this), Store.quality(this), Store.audioQuality(this)) ?: return
        startPlayback(StreamResolver.mediaItem(key, info, res), res.audioUri, 0L, true)
        Store.addHistory(this, Repo.itemFrom(key, info))
        prefetchNext(key)
    }

    /** Siapkan info video berikutnya di antrean agar tombol "berikutnya" langsung bunyi. */
    private fun prefetchNext(key: String) {
        handler.postDelayed({
            if (player.currentMediaItem?.mediaId == key) {
                PlayQueue.next(key)?.let { Repo.prefetch(it.url) }
            }
        }, 4000L)
    }

    private fun setSleep(minutes: Int) {
        handler.removeCallbacks(sleepRunnable)
        if (minutes > 0) {
            sleepAt = SystemClock.elapsedRealtime() + minutes * 60_000L
            handler.postDelayed(sleepRunnable, minutes * 60_000L)
        } else {
            sleepAt = 0L
        }
    }

    private fun remainingMinutes(): Int {
        if (sleepAt == 0L) return 0
        val left = sleepAt - SystemClock.elapsedRealtime()
        return if (left <= 0) 0 else ceil(left / 60_000.0).toInt()
    }
}
