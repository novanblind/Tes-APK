package id.ytplayer

import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

/** Pengunduh HTTP sederhana (HttpURLConnection) untuk NewPipeExtractor. */
object DownloaderImpl : Downloader() {

    const val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"

    // Bahasa YouTube dipaksa "id" (bukan "id-ID") supaya judul video tampil berbahasa Indonesia,
    // bukan terjemahan otomatis ke Inggris.
    private val HL_JSON = Regex("\"hl\"\\s*:\\s*\"[^\"]*\"")
    private val HL_QUERY = Regex("([?&])hl=[^&#]*")

    private fun isYoutubeHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return h == "youtube.com" || h.endsWith(".youtube.com") || h == "youtubei.googleapis.com"
    }

    @Throws(IOException::class, ReCaptchaException::class)
    override fun execute(request: Request): Response {
        var target = request.url()
        val yt = isYoutubeHost(try { URL(target).host } catch (_: Exception) { null })
        if (yt && HL_QUERY.containsMatchIn(target)) target = HL_QUERY.replace(target, "\$1hl=id")
        val conn = URL(target).openConnection() as HttpURLConnection
        var ok = false
        try {
            conn.requestMethod = request.httpMethod()
            conn.connectTimeout = 30_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", USER_AGENT)

            val reqHeaders = LinkedHashMap<String, List<String>>(request.headers())
            if (yt) {
                if (reqHeaders.keys.none { it.equals("Accept-Language", ignoreCase = true) }) {
                    conn.setRequestProperty("Accept-Language", "id-ID,id;q=0.9,en;q=0.4")
                }
                // Cookie PREF=hl=id&gl=ID: YouTube web menganggap penonton berbahasa Indonesia.
                val key = reqHeaders.keys.firstOrNull { it.equals("Cookie", ignoreCase = true) }
                val old = if (key != null) reqHeaders[key].orEmpty().joinToString("; ") else ""
                if (!old.contains("PREF=")) {
                    reqHeaders[key ?: "Cookie"] = listOf(if (old.isEmpty()) "PREF=hl=id&gl=ID" else "$old; PREF=hl=id&gl=ID")
                }
            }

            for ((name, values) in reqHeaders) {
                values.forEachIndexed { i, v ->
                    if (i == 0) conn.setRequestProperty(name, v) else conn.addRequestProperty(name, v)
                }
            }

            var data = request.dataToSend()
            if (yt && data != null && data.isNotEmpty() && data[0] == '{'.code.toByte()) {
                val text = String(data, Charsets.UTF_8)
                if (HL_JSON.containsMatchIn(text)) {
                    data = HL_JSON.replace(text, "\"hl\":\"id\"").toByteArray(Charsets.UTF_8)
                }
            }
            if (data != null) {
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(data.size)
                conn.outputStream.use { it.write(data) }
            }

            val code = conn.responseCode
            if (code == 429) {
                throw ReCaptchaException("Permintaan dibatasi (HTTP 429)", request.url())
            }

            val raw = if (code >= 400) conn.errorStream else conn.inputStream
            val body = raw?.let { s ->
                val stream = if ("gzip".equals(conn.contentEncoding, ignoreCase = true)) GZIPInputStream(s) else s
                stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } ?: ""

            val headers = HashMap<String, List<String>>()
            for ((k, v) in conn.headerFields) {
                if (k != null) headers[k] = v
            }
            ok = true
            return Response(code, conn.responseMessage ?: "", headers, body, conn.url.toString())
        } finally {
            // Badan respons sudah dibaca habis & ditutup → koneksi dikembalikan ke kolam keep-alive
            // dan dipakai ulang permintaan berikutnya (tanpa jabat tangan TLS baru).
            // disconnect() hanya bila gagal.
            if (!ok) conn.disconnect()
        }
    }
}
