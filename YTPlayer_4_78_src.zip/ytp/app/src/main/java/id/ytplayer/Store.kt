package id.ytplayer

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/** Pengaturan sederhana + riwayat tontonan + favorit (SharedPreferences). */
object Store {
    const val K_AUDIO_ONLY = "audio_only"
    const val K_QUALITY = "quality"
    const val K_AUDIO_QUALITY = "audio_quality"
    private const val K_APP_MODE = "app_mode"
    const val MODE_YT = "yt"
    const val MODE_MUSIC = "music"
    const val MODE_YTM = "ytm"
    private const val K_YTM_TYPE = "ytm_type"
    private const val K_SEEK_BACK = "seek_back_sec"
    private const val K_SEEK_FWD = "seek_fwd_sec"
    const val AUDIO_HEMAT = 0
    const val AUDIO_NORMAL = 1
    const val AUDIO_TERBAIK = 2
    val SEEK_CHOICES = listOf(10, 20, 30)
    const val K_AUDIO_FOCUS = "audio_focus"
    const val K_LOUDNESS = "loudness"
    private const val K_AUTOPLAY = "autoplay"
    private const val K_HISTORY = "history"
    private const val K_FAVORITES = "favorites"
    private const val K_SEARCHES = "searches"
    private const val K_LAST_CLIP = "last_clip"

    fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("yt_player", Context.MODE_PRIVATE)

    /** Fokus suara YT Player; bawaan mati (tidak dijeda aplikasi lain). */
    fun audioFocus(c: Context) = prefs(c).getBoolean(K_AUDIO_FOCUS, false)
    fun setAudioFocus(c: Context, v: Boolean) = prefs(c).edit().putBoolean(K_AUDIO_FOCUS, v).apply()

    /** Penguat volume (mirip "Volume stabil" YouTube); bawaan mati. */
    fun loudness(c: Context) = prefs(c).getBoolean(K_LOUDNESS, false)
    fun setLoudness(c: Context, v: Boolean) = prefs(c).edit().putBoolean(K_LOUDNESS, v).apply()

    fun audioOnly(c: Context) = prefs(c).getBoolean(K_AUDIO_ONLY, false)
    fun setAudioOnly(c: Context, v: Boolean) = prefs(c).edit().putBoolean(K_AUDIO_ONLY, v).apply()

    fun autoplay(c: Context) = prefs(c).getBoolean(K_AUTOPLAY, false)
    fun setAutoplay(c: Context, v: Boolean) = prefs(c).edit().putBoolean(K_AUTOPLAY, v).apply()

    /** Tinggi video pilihan (mis. 720). 0 = otomatis. */
    fun quality(c: Context) = prefs(c).getInt(K_QUALITY, 0)
    fun setQuality(c: Context, v: Int) = prefs(c).edit().putInt(K_QUALITY, v).apply()

    /** Tampilan utama aplikasi: "yt" (YT Player, bawaan), "ytm" (YouTube Music) atau "music" (Music Player). */
    fun appMode(c: Context): String =
        when (prefs(c).getString(K_APP_MODE, MODE_YT)) {
            MODE_MUSIC -> MODE_MUSIC
            MODE_YTM -> MODE_YTM
            else -> MODE_YT
        }
    fun setAppMode(c: Context, v: String) = prefs(c).edit().putString(K_APP_MODE, v).apply()

    /** Jenis hasil di mode YouTube Music: 0 = lagu (bawaan), 1 = video musik. */
    fun ytmType(c: Context) = prefs(c).getInt(K_YTM_TYPE, 0).coerceIn(0, 1)
    fun setYtmType(c: Context, v: Int) = prefs(c).edit().putInt(K_YTM_TYPE, v).apply()

    /** Riwayat, favorit, dan pencarian YouTube Music disimpan terpisah dari YT Player. */
    private fun k(c: Context, base: String) = if (appMode(c) == MODE_YTM) base + "_ytm" else base

    /** Kualitas audio pemutaran (mode audio saja): 0 hemat, 1 normal, 2 terbaik (bawaan, Opus bitrate tertinggi seperti YouTube asli). */
    fun audioQuality(c: Context) = prefs(c).getInt(K_AUDIO_QUALITY, AUDIO_TERBAIK).coerceIn(AUDIO_HEMAT, AUDIO_TERBAIK)
    fun setAudioQuality(c: Context, v: Int) = prefs(c).edit().putInt(K_AUDIO_QUALITY, v).apply()

    /** Lompatan tombol mundur / maju dalam detik (10, 20, atau 30). */
    fun seekBackSec(c: Context) = prefs(c).getInt(K_SEEK_BACK, 10).let { if (it in SEEK_CHOICES) it else 10 }
    fun setSeekBackSec(c: Context, v: Int) = prefs(c).edit().putInt(K_SEEK_BACK, v).apply()
    fun seekFwdSec(c: Context) = prefs(c).getInt(K_SEEK_FWD, 10).let { if (it in SEEK_CHOICES) it else 10 }
    fun setSeekFwdSec(c: Context, v: Int) = prefs(c).edit().putInt(K_SEEK_FWD, v).apply()

    private fun load(c: Context, key: String): List<VideoItem> {
        val raw = prefs(c).getString(key, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { VideoItem.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(c: Context, key: String, list: List<VideoItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(c).edit().putString(key, arr.toString()).apply()
    }

    fun history(c: Context): List<VideoItem> = load(c, k(c, K_HISTORY))

    fun addHistory(c: Context, v: VideoItem) {
        val list = history(c).filter { it.url != v.url }.toMutableList()
        list.add(0, v)
        save(c, k(c, K_HISTORY), list.take(50))
    }

    fun clearHistory(c: Context) = prefs(c).edit().remove(k(c, K_HISTORY)).apply()

    fun removeHistory(c: Context, url: String) =
        save(c, k(c, K_HISTORY), history(c).filter { it.url != url })

    /** Riwayat kata kunci pencarian (terbaru di depan), dipakai untuk rekomendasi beranda. */
    fun searches(c: Context): List<String> {
        val raw = prefs(c).getString(k(c, K_SEARCHES), null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addSearch(c: Context, q: String) {
        val list = searches(c).filter { !it.equals(q, ignoreCase = true) }.toMutableList()
        list.add(0, q)
        val arr = JSONArray()
        list.take(20).forEach { arr.put(it) }
        prefs(c).edit().putString(k(c, K_SEARCHES), arr.toString()).apply()
    }

    fun clearSearches(c: Context) = prefs(c).edit().remove(k(c, K_SEARCHES)).apply()

    /** Tautan di clipboard yang sudah pernah ditawari unduh (agar tidak muncul berulang). */
    fun lastClip(c: Context): String = prefs(c).getString(K_LAST_CLIP, "") ?: ""
    fun setLastClip(c: Context, v: String) = prefs(c).edit().putString(K_LAST_CLIP, v).apply()

    fun favorites(c: Context): List<VideoItem> = load(c, k(c, K_FAVORITES))

    fun isFavorite(c: Context, url: String) = favorites(c).any { it.url == url }

    /** Mengembalikan true bila video kini menjadi favorit, false bila dihapus dari favorit. */
    fun toggleFavorite(c: Context, v: VideoItem): Boolean {
        val list = favorites(c).toMutableList()
        val existing = list.indexOfFirst { it.url == v.url }
        return if (existing >= 0) {
            list.removeAt(existing)
            save(c, k(c, K_FAVORITES), list)
            false
        } else {
            list.add(0, v)
            save(c, k(c, K_FAVORITES), list.take(200))
            true
        }
    }
}
