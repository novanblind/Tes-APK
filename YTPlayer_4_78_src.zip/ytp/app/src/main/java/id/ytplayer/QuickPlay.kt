package id.ytplayer

import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController

/**
 * Putar langsung dari daftar video (halaman utama / hasil pencarian) tanpa menunggu layar pemutar
 * selesai dibuka dan menyambung ke layanan. Sambungan pengendali milik halaman daftar diserahkan
 * ke sini, dipakai mengirim perintah putar begitu aliran siap, lalu dilepas.
 */
object QuickPlay {
    private const val WINDOW_MS = 20_000L

    private var latest: String? = null
    private var sentUrl: String? = null
    private var sentAt = 0L

    fun start(ctx: android.content.Context, controller: MediaController, url: String) {
        latest = url
        Repo.fetchStream(url) { stream, _ ->
            // Pengguna sudah memilih video lain, atau gagal: biarkan layar pemutar yang menangani.
            if (latest != url || stream == null) {
                release(controller)
                return@fetchStream
            }
            val res = StreamResolver.resolve(
                stream, Store.audioOnly(ctx), Store.quality(ctx), Store.audioQuality(ctx)
            )
            if (res == null) {
                release(controller)
                return@fetchStream
            }
            try {
                val f = controller.sendCustomCommand(
                    PlaybackService.LOAD_COMMAND,
                    StreamResolver.toBundle(url, stream, res, 0L)
                )
                sentUrl = url
                sentAt = SystemClock.elapsedRealtime()
                Store.addHistory(ctx, Repo.itemFrom(url, stream))
                f.addListener({ release(controller) }, ContextCompat.getMainExecutor(ctx))
            } catch (_: Exception) {
                release(controller)
            }
        }
    }

    /** Sama seperti [start], tetapi sambungan pengendali masih disiapkan (dibuat lebih awal). */
    fun startFromFuture(
        ctx: android.content.Context,
        future: com.google.common.util.concurrent.ListenableFuture<MediaController>,
        url: String
    ) {
        future.addListener({
            try {
                start(ctx, future.get(), url)
            } catch (_: Exception) {
                // Gagal tersambung: layar pemutar yang akan memutar seperti biasa.
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    /** True bila video ini baru saja dikirim ke layanan lewat [start] (sekali pakai). */
    fun consumeSent(url: String): Boolean {
        val ok = sentUrl == url && SystemClock.elapsedRealtime() - sentAt < WINDOW_MS
        if (ok) sentUrl = null
        return ok
    }

    fun clear() {
        sentUrl = null
    }

    private fun release(c: MediaController) {
        try { c.release() } catch (_: Exception) {}
    }
}
