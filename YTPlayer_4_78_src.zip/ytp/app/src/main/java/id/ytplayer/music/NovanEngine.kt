package id.ytplayer.music

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Satu pita filter: jenis 0 = puncak (peaking), 1 = rak bawah, 2 = rak atas,
 * 3 = lolos bawah (low-pass), 4 = lolos atas (high-pass), 5 = penolak (notch).
 * Jenis 3 sampai 5 mengabaikan [db].
 */
data class NBand(val type: Int, val hz: Double, val q: Double, val db: Double)

/** Pengaturan mesin audio (tidak berubah setelah dibuat; diganti utuh saat ada perubahan). */
class NParams(
    val on: Boolean,
    val preampDb: Double,
    val bands: List<NBand>,
    val bassDb: Double,
    val trebleDb: Double,
    val width: Double,      // 1.0 = normal, 0 = mono sempit, 2.0 = lebar
    val mono: Boolean,
    val balance: Double,    // -1 kiri penuh .. +1 kanan penuh
    val limiter: Boolean,
    val revMix: Double,     // 0 = reverb mati .. 1.0 = paling basah
    val revRoom: Double,    // ukuran ruang 0..1
    val revDamp: Double,    // peredam frekuensi tinggi 0..1
    val compOn: Boolean = false,      // kompresor 3 pita
    val compThr: Double = -24.0,      // ambang (dB)
    val compRatio: Double = 3.0,
    val compAtk: Double = 10.0,       // ms
    val compRel: Double = 200.0,      // ms
    val compMakeup: Double = 0.0,     // dB
    val softVol: Double = 0.0,        // penguat suara pelan 0..1
    val outGainDb: Double = 0.0,      // penguat akhir sebelum limiter
    val limCeilDb: Double = -0.5,     // batas limiter (dB)
    val limRelMs: Double = 150.0,     // pelepasan limiter (ms)
    val headroom: Boolean = false     // headroom otomatis dari puncak kurva (bawaan mati agar suara tidak lebih pelan)
)

/**
 * Pengaturan mesin audio Novan. Disimpan di Prefs (awalan "ne_") dan dibaca oleh semua
 * prosesor lewat [params]. Setiap perubahan menaikkan [version] sehingga prosesor
 * menghitung ulang koefisien filter di buffer berikutnya.
 */
object NovanEngine {
    const val K_ON = "ne_on"
    const val K_PREAMP = "ne_preamp"        // langkah 1 dB, -12..12
    const val K_MODE = "ne_mode"            // 10 atau 32 pita
    const val K_G10 = "ne_g10"              // gain per pita (dB, dipisah koma)
    const val K_G32 = "ne_g32"
    const val K_BASS = "ne_bass"            // dB -12..12
    const val K_TREBLE = "ne_treble"        // dB -12..12
    const val K_WIDTH = "ne_width"          // persen 0..200
    const val K_MONO = "ne_mono"
    const val K_BALANCE = "ne_balance"      // -100..100
    const val K_LIMITER = "ne_limiter"
    const val K_LIM_CEIL = "ne_lim_ceil"    // batas limiter, per 0,1 dB (-300..0; bawaan -5 = -0,5 dB)
    const val K_LIM_REL = "ne_lim_rel"      // pelepasan limiter, ms (10..1000)
    const val K_OUTGAIN = "ne_outgain"      // penguat akhir dB -12..12
    const val K_HEADROOM = "ne_headroom"    // headroom otomatis (bawaan: mati)
    const val K_COMP_ON = "ne_comp_on"      // kompresor 3 pita (250 Hz dan 2,5 kHz)
    const val K_COMP_THR = "ne_comp_thr"    // dB -60..0
    const val K_COMP_RATIO = "ne_comp_ratio" // 1..20
    const val K_COMP_ATK = "ne_comp_atk"    // ms 1..200
    const val K_COMP_REL = "ne_comp_rel"    // ms 10..2000
    const val K_COMP_MK = "ne_comp_mk"      // dB 0..12
    const val K_SOFTVOL = "ne_softvol"      // penguat suara pelan, persen 0..100
    const val K_CLARITY = "ne_clarity"      // kejernihan vokal, persen 0..100
    const val K_SMARTBASS = "ne_smartbass"  // bass cerdas, persen 0..100
    const val K_BASSCHAR = "ne_basschar"    // karakter bass cerdas: 0 Standar, 1 Halus, 2 Hangat, 3 Padat, 4 Dalam
    val BASS_CHARS = listOf(
        "Standar" to "Bass seimbang, bawaan lama.",
        "Halus" to "Lembut, tidak menggelegar. Enak untuk lama.",
        "Hangat" to "Bulat dan hangat, tidak tajam.",
        "Padat" to "Ketukan rapat dan tegas, tanpa gemuruh.",
        "Dalam" to "Rendah dan dalam, terasa getar."
    )
    const val K_FINE = "ne_fine"            // langkah pita 0,5 dB (hanya tampilan)
    private const val K_CUSTOM = "ne_custom_" // mode kustom buatan pengguna, akhiran 10 atau 32
    const val K_REV_MIX = "ne_rev_mix"      // persen 0..100 (0 = mati)
    const val K_REV_ROOM = "ne_rev_room"    // persen 0..100
    const val K_REV_DAMP = "ne_rev_damp"    // persen 0..100
    const val K_PRESET = "ne_preset"        // indeks mode suara; -1 = kustom
    const val K_ROOM_PRESET = "ne_room_preset" // indeks mode ruang; -1 = kustom
    const val K_HIRES = "ne_hires"          // keluaran Hi-Res: float 32-bit tanpa dither (bawaan: aktif; hanya berlaku bila mesin audio menyala)
    const val K_RATE = "ne_rate"            // laju keluaran: "auto", "file", "48000", "96000", "192000", "384000"
    const val K_BITPERFECT = "ne_bitperfect" // bit-perfect Android 14+ (bawaan: mati)

    const val K_PERDEV = "ne_perdev"        // pengaturan suara terpisah untuk tiap jenis perangkat keluaran
    private const val K_DEV_CUR = "ne_dev_cur"
    private const val K_DEV_SNAP = "ne_dev_snap_"

    val HZ10 = doubleArrayOf(31.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)

    /** 32 pita berjarak logaritmik dari 20 Hz sampai 20 kHz. */
    val HZ32: DoubleArray = DoubleArray(32) { i ->
        val raw = 20.0 * (1000.0).pow(i / 31.0)
        // dibulatkan agar label mudah dibaca
        when {
            raw < 100 -> Math.round(raw).toDouble()
            raw < 1000 -> Math.round(raw / 5.0) * 5.0
            else -> Math.round(raw / 50.0) * 50.0
        }
    }

    @Volatile
    var params: NParams = NParams(false, 0.0, emptyList(), 0.0, 0.0, 1.0, false, 0.0, true, 0.0, 0.5, 0.5)
        private set

    @Volatile
    var version = 0
        private set

    /** Penguatan ReplayGain (dB) untuk lagu yang sedang diputar; diterapkan prosesor walau equalizer mati. */
    @Volatile
    var rgDb = 0.0
        private set

    fun setReplayGain(db: Double) {
        if (abs(db - rgDb) < 0.01) return
        rgDb = db
        version++
    }

    /** Keluaran Hi-Res (float 32-bit). Dibaca prosesor saat format dikonfigurasi, yaitu di awal tiap lagu. */
    @Volatile
    var hires = true
        private set

    /** Mesin audio menyala. Bila mati, Hi-Res, laju keluaran, dan bit-perfect ikut mati. */
    @Volatile
    var engineOn = false
        private set

    @Volatile
    var rateMode = "auto"
        private set

    @Volatile
    var bitPerfect = false
        private set

    /** True bila perangkat menolak laju atau mode pilihan; sisa sesi memakai laju berkas lagu. */
    @Volatile
    var rateFailed = false
        private set

    /** Ringkasan jalur keluaran lagu terakhir, ditampilkan di layar pengaturan. */
    @Volatile
    var lastNote = ""
        private set

    private var appCtx: Context? = null

    private val musicAttrs: android.media.AudioAttributes by lazy {
        android.media.AudioAttributes.Builder()
            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
    }

    /** Rencana keluaran untuk satu lagu: laju sampel akhir dan apakah float 32-bit. */
    class Plan(val rate: Int, val float: Boolean)

    private fun nativeRate(ctx: Context): Int = try {
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
            .getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
    } catch (_: Throwable) {
        48000
    }

    @RequiresApi(29)
    private fun directOk(rate: Int, ch: Int): Boolean = try {
        AudioTrack.isDirectPlaybackSupported(
            AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                .setSampleRate(rate)
                .setChannelMask(if (ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO)
                .build(),
            musicAttrs
        )
    } catch (_: Throwable) {
        false
    }

    /** Apakah perangkat sanggup membuka jalur keluaran pada laju ini. */
    private fun usable(rate: Int, ch: Int): Boolean {
        if (rate > 192000) return Build.VERSION.SDK_INT >= 29 && directOk(rate, ch)
        return try {
            AudioTrack.getMinBufferSize(
                rate,
                if (ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_FLOAT
            ) > 0
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Menentukan laju keluaran. Resampling dilakukan oleh mesin Novan (hitungan 64-bit), sehingga
     * pengubah laju bawaan Android tidak perlu bekerja. Laju tidak pernah diturunkan di sini.
     */
    private fun chooseRate(ctx: Context, inRate: Int, ch: Int): Int {
        if (rateFailed || rateMode == "file") return inRate
        val fixed = rateMode.toIntOrNull()
        if (fixed != null) return if (fixed > inRate && usable(fixed, ch)) fixed else inRate
        // Otomatis: laju tertinggi yang bisa dikirim langsung (DAC USB), selain itu laju mixer perangkat.
        if (Build.VERSION.SDK_INT >= 29) {
            for (r in intArrayOf(192000, 96000)) if (r > inRate && directOk(r, ch)) return r
        }
        val native = nativeRate(ctx)
        return if (native > inRate && native <= 192000) native else inRate
    }

    /** Dipanggil prosesor saat format lagu dikonfigurasi (awal tiap lagu). */
    fun plan(inRate: Int, channels: Int): Plan {
        val ctx = appCtx
        if (ctx == null) return Plan(inRate, hires)
        if (!engineOn) {
            // Mesin audio mati: tanpa Hi-Res, tanpa menaikkan laju, tanpa bit-perfect.
            if (Build.VERSION.SDK_INT >= 34) BitPerfect.clear(ctx)
            lastNote = "mesin audio mati, $inRate Hz masuk dan keluar, 16-bit"
            return Plan(inRate, false)
        }
        if (rateFailed) {
            if (Build.VERSION.SDK_INT >= 34) BitPerfect.clear(ctx)
            lastNote = "perangkat menolak laju pilihan, memakai laju berkas ($inRate Hz)"
            return Plan(inRate, hires)
        }
        var bp = false
        var rate = inRate
        var float = hires
        if (bitPerfect && Build.VERSION.SDK_INT >= 34 && channels == 2) {
            val fixed = rateMode.toIntOrNull() ?: 0
            val r = BitPerfect.activate(ctx, if (fixed > inRate) fixed else inRate)
            if (r != null) {
                rate = r.first
                float = r.second
                bp = true
            }
        } else if (Build.VERSION.SDK_INT >= 34) {
            BitPerfect.clear(ctx)
        }
        if (!bp) rate = chooseRate(ctx, inRate, channels)
        lastNote = "$inRate Hz masuk, $rate Hz keluar, " + (if (float) "float 32-bit" else "16-bit") +
            (if (bp) ", bit-perfect aktif" else if (bitPerfect) ", bit-perfect tidak tersedia pada keluaran ini" else "")
        return Plan(rate, float)
    }

    /**
     * Dipanggil pemutar saat jalur audio gagal dibuka. Bila penyebabnya laju atau mode pilihan kita,
     * kembali ke laju berkas lagu dan beri tahu pemanggil agar mencoba lagi.
     */
    @OptIn(UnstableApi::class)
    fun handleSinkError(error: Throwable): Boolean {
        if (!engineOn) return false
        if (rateFailed || (rateMode == "file" && !bitPerfect)) return false
        var c: Throwable? = error
        while (c != null) {
            if (c is AudioSink.InitializationException || c is AudioSink.ConfigurationException) {
                rateFailed = true
                appCtx?.let { if (Build.VERSION.SDK_INT >= 34) BitPerfect.clear(it) }
                return true
            }
            c = c.cause
        }
        return false
    }

    @RequiresApi(29)
    private fun directInfo(): String {
        val ok = ArrayList<String>()
        for (r in intArrayOf(96000, 192000, 384000)) if (directOk(r, 2)) ok.add("${r / 1000} kHz")
        return if (ok.isEmpty()) "Keluaran langsung tanpa mixer: tidak terdeteksi pada jalur saat ini.\n"
        else "Keluaran langsung tanpa mixer didukung: " + ok.joinToString(", ") + ".\n"
    }

    /** Ringkasan kemampuan perangkat keluaran untuk layar pengaturan. */
    fun deviceInfo(ctx: Context): String {
        val sb = StringBuilder()
        sb.append("Laju mixer bawaan Android: ${nativeRate(ctx)} Hz.\n")
        if (Build.VERSION.SDK_INT >= 29) sb.append(directInfo())
        if (Build.VERSION.SDK_INT >= 34) sb.append(BitPerfect.info(ctx)).append('\n')
        else sb.append("Bit-perfect: perlu Android 14 ke atas.\n")
        if (lastNote.isNotEmpty()) sb.append("Jalur lagu terakhir: $lastNote.")
        return sb.toString().trim()
    }


    /** Mode suara siap pakai: kurva 10 pita (31 Hz .. 16 kHz), bass, treble, dan lebar stereo. */
    class Preset(
        val name: String,
        val desc: String,
        val g10: IntArray,
        val bass: Int = 0,
        val treble: Int = 0,
        val width: Int = 100
    )

    val PRESETS: List<Preset> = listOf(
        Preset("Datar", "Suara asli.", intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)),
        Preset("Bass kuat", "Bass tebal.", intArrayOf(6, 5, 4, 2, 0, 0, 0, 0, 0, 0), bass = 3),
        Preset("Vokal jernih", "Suara orang jelas.", intArrayOf(-2, -2, -1, 0, 2, 4, 4, 3, 1, 0)),
        Preset("Treble terang", "Nada tinggi terang.", intArrayOf(0, 0, 0, 0, 0, 1, 3, 5, 6, 6), treble = 2),
        Preset("Pop", "Vokal menonjol.", intArrayOf(-1, -1, 0, 2, 4, 4, 2, 0, -1, -2)),
        Preset("Rock", "Bass dan treble kuat.", intArrayOf(5, 4, 3, 1, -1, -1, 0, 2, 4, 5)),
        Preset("Jazz", "Hangat, akustik.", intArrayOf(3, 2, 1, 2, -2, -2, 0, 1, 3, 4)),
        Preset("Klasik", "Luas, lembut.", intArrayOf(4, 3, 3, 2, -1, -1, 0, 2, 3, 4), width = 120),
        Preset("Dance", "Bass kencang, stereo lebar.", intArrayOf(6, 5, 2, 0, 0, -2, -1, 0, 3, 4), bass = 2, width = 130),
        Preset("Akustik", "Gitar dan piano natural.", intArrayOf(4, 3, 3, 1, 1, 1, 2, 3, 3, 2)),
        Preset("Podcast dan pidato", "Fokus suara bicara.", intArrayOf(-4, -3, -1, 1, 3, 4, 4, 2, 0, -2)),
        Preset("Volume pelan", "Enak untuk volume kecil.", intArrayOf(5, 3, 0, 0, 0, 0, 0, 0, 2, 3)),
        Preset("Hip hop", "Bass dalam, vokal tegas.", intArrayOf(6, 5, 3, 1, -1, -1, 1, 0, 2, 3), bass = 2),
        Preset("Elektronik", "Bass dan treble berkilau.", intArrayOf(5, 4, 1, 0, -2, 2, 1, 2, 4, 5), width = 120),
        Preset("Dangdut", "Gendang dan vokal jelas.", intArrayOf(5, 4, 3, 1, 0, 1, 2, 3, 2, 1)),
        Preset("Metal", "Gitar tajam, bass padat.", intArrayOf(4, 3, 0, -2, -3, 0, 3, 4, 4, 3)),
        Preset("Film", "Dialog jelas, ledakan terasa.", intArrayOf(5, 4, 2, 0, 0, 2, 3, 2, 2, 1), bass = 1, width = 120)
    )

    /** Mode ruang siap pakai untuk reverb: jumlah, ukuran ruang, peredam (persen). */
    class Room(val name: String, val desc: String, val mix: Int, val room: Int, val damp: Int)

    val ROOMS: List<Room> = listOf(
        Room("Mati", "Tanpa gema.", 0, 50, 50),
        Room("Kamar kecil", "Gema tipis.", 10, 25, 65),
        Room("Ruang tamu", "Sedang, hangat.", 15, 40, 55),
        Room("Studio", "Rapat, jernih.", 20, 45, 40),
        Room("Aula konser", "Luas.", 30, 75, 45),
        Room("Gereja atau katedral", "Sangat luas, gema panjang.", 45, 95, 30)
    )

    /** Ubah kurva 10 pita menjadi 32 pita dengan interpolasi pada skala frekuensi logaritmik. */
    private fun to32(g10: IntArray): IntArray = IntArray(32) { i ->
        val lf = Math.log(HZ32[i]) / Math.log(2.0)
        val lo = Math.log(HZ10[0]) / Math.log(2.0)
        val hi = Math.log(HZ10[9]) / Math.log(2.0)
        if (lf <= lo) g10[0]
        else if (lf >= hi) g10[9]
        else {
            var k = 0
            while (k < 8 && Math.log(HZ10[k + 1]) / Math.log(2.0) < lf) k++
            val a = Math.log(HZ10[k]) / Math.log(2.0)
            val b = Math.log(HZ10[k + 1]) / Math.log(2.0)
            val t = (lf - a) / (b - a)
            Math.round(g10[k] + (g10[k + 1] - g10[k]) * t).toInt()
        }
    }

    /** Terapkan mode suara: kurva (10 dan 32 pita), bass, treble, lebar, preamp; mesin otomatis menyala. */
    fun applyPreset(ctx: Context, idx: Int) {
        val pr = PRESETS.getOrNull(idx) ?: return
        // Bila headroom otomatis aktif, mesin sendiri menyisakan ruang dari puncak kurva, jadi preamp tidak
        // diturunkan lagi (supaya tidak turun dua kali). Bila mati, preamp turun separuh puncak seperti dulu.
        val peak = (pr.g10.maxOrNull() ?: 0).coerceAtLeast(0) + pr.bass.coerceAtLeast(0)
        val preamp = if (Prefs.of(ctx).getBoolean(K_HEADROOM, false)) 0 else -(peak / 2)
        Prefs.of(ctx).edit()
            .putBoolean(K_ON, true)
            .putInt(K_PRESET, idx)
            .putInt(K_PREAMP, preamp.coerceIn(-12, 0))
            .putString(K_G10, pr.g10.joinToString(","))
            .putString(K_G32, to32(pr.g10).joinToString(","))
            .putInt(K_BASS, pr.bass)
            .putInt(K_TREBLE, pr.treble)
            .putInt(K_WIDTH, pr.width)
            .putBoolean(K_MONO, false)
            .putInt(K_BALANCE, 0)
            .apply()
        reload(ctx)
    }

    /** Terapkan mode ruang (reverb); mesin otomatis menyala. */
    fun applyRoom(ctx: Context, idx: Int) {
        val r = ROOMS.getOrNull(idx) ?: return
        Prefs.of(ctx).edit()
            .putBoolean(K_ON, true)
            .putInt(K_ROOM_PRESET, idx)
            .putInt(K_REV_MIX, r.mix)
            .putInt(K_REV_ROOM, r.room)
            .putInt(K_REV_DAMP, r.damp)
            .apply()
        reload(ctx)
    }

    // ---- Pengaturan suara per perangkat ----

    /** Pengaturan yang ikut disimpan dan dipulihkan per perangkat (semua pengaturan suara, bukan pengaturan keluaran Hi-Res). */
    private val DEV_KEYS = listOf(
        K_ON, K_PREAMP, K_MODE, K_G10, K_G32, K_BASS, K_TREBLE, K_WIDTH, K_MONO, K_BALANCE, K_LIMITER,
        K_REV_MIX, K_REV_ROOM, K_REV_DAMP, K_PRESET, K_ROOM_PRESET,
        K_LIM_CEIL, K_LIM_REL, K_OUTGAIN, K_HEADROOM, K_COMP_ON, K_COMP_THR, K_COMP_RATIO, K_COMP_ATK,
        K_COMP_REL, K_COMP_MK, K_SOFTVOL, K_CLARITY, K_SMARTBASS, K_BASSCHAR
    )

    val DEV_NAMES = mapOf("speaker" to "Speaker HP", "wired" to "Headphone kabel", "bluetooth" to "Bluetooth", "usb" to "USB (DAC)")

    /** Jenis perangkat keluaran yang sedang dipakai: usb, bluetooth, wired, atau speaker. */
    fun deviceCategory(ctx: Context): String {
        val devs = try {
            (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        } catch (_: Throwable) {
            return "speaker"
        }
        var usb = false; var bt = false; var wired = false
        for (d in devs) {
            when (d.type) {
                11, 22 -> usb = true                 // USB_DEVICE, USB_HEADSET
                8, 7, 26, 23 -> bt = true            // A2DP, SCO, BLE_HEADSET, HEARING_AID
                3, 4, 5 -> wired = true              // WIRED_HEADSET, WIRED_HEADPHONES, LINE_ANALOG
            }
        }
        return if (usb) "usb" else if (bt) "bluetooth" else if (wired) "wired" else "speaker"
    }

    fun perDeviceEnabled(ctx: Context): Boolean = Prefs.of(ctx).getBoolean(K_PERDEV, false)

    private fun snapshot(p: android.content.SharedPreferences): String {
        val all = p.all
        val o = org.json.JSONObject()
        for (k in DEV_KEYS) if (all.containsKey(k)) o.put(k, all[k])
        return o.toString()
    }

    private fun restore(p: android.content.SharedPreferences, json: String) {
        val o = try { org.json.JSONObject(json) } catch (_: Exception) { return }
        val e = p.edit()
        for (k in DEV_KEYS) {
            // kunci yang tidak ada di cadangan berarti nilai bawaan
            if (!o.has(k)) { e.remove(k); continue }
            when (val v = o.get(k)) {
                is Boolean -> e.putBoolean(k, v)
                is Int -> e.putInt(k, v)
                is String -> e.putString(k, v)
            }
        }
        e.apply()
    }

    /**
     * Dipanggil saat perangkat keluaran berubah (dan saat layanan mulai). Menyimpan pengaturan suara perangkat
     * sebelumnya, lalu memakai pengaturan yang pernah disimpan untuk perangkat baru. Bila perangkat baru belum
     * punya pengaturan, pengaturan yang sedang dipakai tetap berlaku dan menjadi milik perangkat itu.
     */
    fun syncDevice(ctx: Context) {
        val p = Prefs.of(ctx)
        if (!p.getBoolean(K_PERDEV, false)) return
        val now = deviceCategory(ctx)
        val old = p.getString(K_DEV_CUR, null)
        if (old == now) return
        if (old != null) p.edit().putString(K_DEV_SNAP + old, snapshot(p)).apply()
        val saved = p.getString(K_DEV_SNAP + now, null)
        if (saved != null) restore(p, saved)
        p.edit().putString(K_DEV_CUR, now).apply()
        reload(ctx)
    }

    /** Menyalakan atau mematikan fitur; saat menyala, pengaturan sekarang menjadi milik perangkat yang sedang dipakai. */
    fun setPerDevice(ctx: Context, on: Boolean) {
        val p = Prefs.of(ctx)
        val e = p.edit().putBoolean(K_PERDEV, on)
        if (on) e.putString(K_DEV_CUR, deviceCategory(ctx))
        e.apply()
    }

    fun hz(mode: Int): DoubleArray = if (mode == 32) HZ32 else HZ10

    fun gains(ctx: Context, mode: Int): DoubleArray {
        val n = if (mode == 32) 32 else 10
        val raw = Prefs.of(ctx).getString(if (mode == 32) K_G32 else K_G10, "") ?: ""
        val parts = raw.split(',')
        return DoubleArray(n) { parts.getOrNull(it)?.toDoubleOrNull()?.coerceIn(-12.0, 12.0) ?: 0.0 }
    }

    fun setGain(ctx: Context, mode: Int, band: Int, db: Double) {
        val g = gains(ctx, mode)
        if (band !in g.indices) return
        g[band] = db
        Prefs.of(ctx).edit().putString(if (mode == 32) K_G32 else K_G10, g.joinToString(",")).putInt(K_PRESET, -1).apply()
        reload(ctx)
    }

    // ---- Mode kustom, salin dan tempel kurva ----

    /** Daftar mode kustom buatan pengguna untuk 10 atau 32 pita, urut sesuai waktu simpan. */
    fun customs(ctx: Context, mode: Int): LinkedHashMap<String, DoubleArray> {
        val n = if (mode == 32) 32 else 10
        val out = LinkedHashMap<String, DoubleArray>()
        val raw = Prefs.of(ctx).getString(K_CUSTOM + n, "") ?: ""
        for (line in raw.split('\n')) {
            val parts = line.split('|')
            if (parts.size != 2 || parts[0].isBlank()) continue
            val g = parseCurve(parts[1], n) ?: continue
            out[parts[0]] = g
        }
        return out
    }

    private fun writeCustoms(ctx: Context, mode: Int, m: Map<String, DoubleArray>) {
        val n = if (mode == 32) 32 else 10
        val raw = m.entries.joinToString("\n") { it.key + "|" + curveText(it.value) }
        Prefs.of(ctx).edit().putString(K_CUSTOM + n, raw).apply()
    }

    fun saveCustom(ctx: Context, mode: Int, name: String, g: DoubleArray) {
        val clean = name.replace('|', ' ').replace('\n', ' ').trim()
        if (clean.isEmpty()) return
        val m = customs(ctx, mode)
        m[clean] = g.copyOf()
        writeCustoms(ctx, mode, m)
    }

    fun deleteCustom(ctx: Context, mode: Int, name: String) {
        val m = customs(ctx, mode)
        if (m.remove(name) != null) writeCustoms(ctx, mode, m)
    }

    /** Kurva sebagai teks dipisah koma, nilai bulat ditulis tanpa desimal. */
    fun curveText(g: DoubleArray): String =
        g.joinToString(",") { if (it == Math.rint(it)) it.toInt().toString() else it.toString() }

    /** Baca kurva dari teks; menolak jumlah pita yang salah, NaN, dan tak hingga. Nilai dijepit -12..12 dB. */
    fun parseCurve(raw: String, n: Int): DoubleArray? {
        val parts = raw.trim().split(',')
        if (parts.size != n) return null
        val out = DoubleArray(n)
        for (i in 0 until n) {
            val v = parts[i].trim().toDoubleOrNull() ?: return null
            if (v.isNaN() || v.isInfinite()) return null
            out[i] = v.coerceIn(-12.0, 12.0)
        }
        return out
    }

    /** Teks kurva untuk papan klip, formatnya sama dengan aplikasi Equalizer Novan: EQN1;jumlah pita;gain;preamp. */
    fun exportCurve(ctx: Context, mode: Int): String {
        val n = if (mode == 32) 32 else 10
        return "EQN1;$n;${curveText(gains(ctx, n))};${Prefs.of(ctx).getInt(K_PREAMP, 0)}"
    }

    /** Tempel kurva berformat EQN1 (jumlah pita ikut berganti). Mengembalikan false bila teks tidak sah. */
    fun importCurve(ctx: Context, text: String): Boolean {
        val parts = text.trim().split(';')
        if (parts.size != 4 || parts[0] != "EQN1") return false
        val n = parts[1].toIntOrNull() ?: return false
        if (n != 10 && n != 32) return false
        val g = parseCurve(parts[2], n) ?: return false
        val pre = parts[3].toDoubleOrNull() ?: return false
        if (pre.isNaN() || pre.isInfinite()) return false
        Prefs.of(ctx).edit()
            .putString(K_MODE, n.toString())
            .putString(if (n == 32) K_G32 else K_G10, curveText(g))
            .putInt(K_PREAMP, Math.round(pre).toInt().coerceIn(-12, 12))
            .putInt(K_PRESET, -1)
            .apply()
        reload(ctx)
        return true
    }

    /** Pasang satu kurva penuh untuk 10 atau 32 pita (mode suara menjadi Kustom). */
    fun setCurve(ctx: Context, mode: Int, g: DoubleArray) {
        Prefs.of(ctx).edit()
            .putString(if (mode == 32) K_G32 else K_G10, curveText(g))
            .putInt(K_PRESET, -1)
            .apply()
        reload(ctx)
    }

    fun mode(ctx: Context): Int = if ((Prefs.of(ctx).getString(K_MODE, "10") ?: "10") == "32") 32 else 10

    /** Baca ulang semua pengaturan dari Prefs dan beri tahu prosesor yang sedang berjalan. */
    fun reload(ctx: Context) {
        val p = Prefs.of(ctx)
        val mode = mode(ctx)
        val bands = ArrayList<NBand>()
        run {
            val g = gains(ctx, mode)
            val f = hz(mode)
            val q = if (mode == 32) 4.3 else 1.41
            for (i in g.indices) if (abs(g[i]) >= 0.05) bands.add(NBand(0, f[i], q, g[i]))
        }
        // Kejernihan vokal: bell lebar sekitar 2,6 kHz, sampai +4,5 dB.
        val clarity = p.getInt(K_CLARITY, 0).coerceIn(0, 100)
        if (clarity > 0) bands.add(NBand(0, 2600.0, 0.65, clarity * 0.045))
        // Bass cerdas: bentuk kurva mengikuti karakter bass (Standar, Halus, Hangat, Padat, Dalam).
        val bassChar = p.getInt(K_BASSCHAR, 0).coerceIn(0, BASS_CHARS.size - 1)
        val smartPct = p.getInt(K_SMARTBASS, 0).coerceIn(0, 100)
        // Karakter selain Standar langsung terasa (kekuatan sedang) walau slider Bass cerdas 0.
        val smart = (if (smartPct > 0) smartPct else if (bassChar != 0) 50 else 0) / 100.0
        if (smart > 0.0) {
            when (bassChar) {
                1 -> { // Halus: rak lebar dan lembut, gemuruh sangat rendah dipotong
                    bands.add(NBand(1, 110.0, 0.5, 3.2 * smart))
                    bands.add(NBand(0, 260.0, 0.7, -2.6 * smart))
                    bands.add(NBand(1, 35.0, 0.707, -2.0 * smart))
                }
                2 -> { // Hangat: dorongan agak ke atas, bulat
                    bands.add(NBand(1, 190.0, 0.55, 3.8 * smart))
                    bands.add(NBand(0, 300.0, 0.75, -1.0 * smart))
                    bands.add(NBand(1, 35.0, 0.707, -1.0 * smart))
                }
                3 -> { // Padat: puncak sempit di sekitar 85 Hz, bawah dan tengah dirapikan
                    bands.add(NBand(1, 95.0, 0.707, 1.5 * smart))
                    bands.add(NBand(0, 85.0, 1.0, 3.2 * smart))
                    bands.add(NBand(0, 230.0, 0.8, -2.6 * smart))
                    bands.add(NBand(1, 35.0, 0.707, -2.5 * smart))
                }
                4 -> { // Dalam: rak rendah kuat
                    bands.add(NBand(1, 85.0, 0.6, 5.5 * smart))
                    bands.add(NBand(0, 240.0, 0.84, -1.5 * smart))
                }
                else -> { // Standar: seperti sebelumnya
                    bands.add(NBand(1, 145.0, 0.707, 4.5 * smart))
                    bands.add(NBand(0, 245.0, 0.84, -2.2 * smart))
                }
            }
        }
        params = NParams(
            on = p.getBoolean(K_ON, false),
            preampDb = p.getInt(K_PREAMP, 0).toDouble().coerceIn(-12.0, 12.0),
            bands = bands,
            bassDb = p.getInt(K_BASS, 0).toDouble().coerceIn(-12.0, 12.0),
            trebleDb = p.getInt(K_TREBLE, 0).toDouble().coerceIn(-12.0, 12.0),
            width = p.getInt(K_WIDTH, 100).coerceIn(0, 200) / 100.0,
            mono = p.getBoolean(K_MONO, false),
            balance = p.getInt(K_BALANCE, 0).coerceIn(-100, 100) / 100.0,
            limiter = p.getBoolean(K_LIMITER, true),
            revMix = p.getInt(K_REV_MIX, 0).coerceIn(0, 100) / 100.0,
            revRoom = p.getInt(K_REV_ROOM, 50).coerceIn(0, 100) / 100.0,
            revDamp = p.getInt(K_REV_DAMP, 50).coerceIn(0, 100) / 100.0,
            compOn = p.getBoolean(K_COMP_ON, false),
            compThr = p.getInt(K_COMP_THR, -24).coerceIn(-60, 0).toDouble(),
            compRatio = p.getInt(K_COMP_RATIO, 3).coerceIn(1, 20).toDouble(),
            compAtk = p.getInt(K_COMP_ATK, 10).coerceIn(1, 200).toDouble(),
            compRel = p.getInt(K_COMP_REL, 200).coerceIn(10, 2000).toDouble(),
            compMakeup = p.getInt(K_COMP_MK, 0).coerceIn(0, 12).toDouble(),
            softVol = p.getInt(K_SOFTVOL, 0).coerceIn(0, 100) / 100.0,
            outGainDb = p.getInt(K_OUTGAIN, 0).coerceIn(-12, 12).toDouble(),
            limCeilDb = p.getInt(K_LIM_CEIL, -5).coerceIn(-300, 0) / 10.0,
            limRelMs = p.getInt(K_LIM_REL, 150).coerceIn(10, 1000).toDouble(),
            headroom = p.getBoolean(K_HEADROOM, false)
        )
        // Hi-Res mengikuti mesin audio: mesin mati berarti Hi-Res mati, mesin menyala berarti Hi-Res sesuai saklarnya.
        engineOn = p.getBoolean(K_ON, false)
        hires = p.getBoolean(K_HIRES, true) && engineOn
        appCtx = ctx.applicationContext
        rateMode = p.getString(K_RATE, "auto") ?: "auto"
        val bp = p.getBoolean(K_BITPERFECT, false)
        if (bitPerfect && !bp && Build.VERSION.SDK_INT >= 34) BitPerfect.clear(ctx.applicationContext)
        bitPerfect = bp
        rateFailed = false
        version++
    }

    fun resetAll(ctx: Context) {
        Prefs.of(ctx).edit()
            .putInt(K_PREAMP, 0).putString(K_G10, "").putString(K_G32, "")
            .putInt(K_BASS, 0).putInt(K_TREBLE, 0).putInt(K_WIDTH, 100)
            .putBoolean(K_MONO, false).putInt(K_BALANCE, 0).putBoolean(K_LIMITER, true)
            .putInt(K_REV_MIX, 0).putInt(K_REV_ROOM, 50).putInt(K_REV_DAMP, 50)
            .putInt(K_PRESET, 0).putInt(K_ROOM_PRESET, 0)
            .putInt(K_LIM_CEIL, -5).putInt(K_LIM_REL, 150).putInt(K_OUTGAIN, 0)
            .putBoolean(K_COMP_ON, false).putInt(K_COMP_THR, -24).putInt(K_COMP_RATIO, 3)
            .putInt(K_COMP_ATK, 10).putInt(K_COMP_REL, 200).putInt(K_COMP_MK, 0)
            .putInt(K_SOFTVOL, 0).putInt(K_CLARITY, 0).putInt(K_SMARTBASS, 0).putInt(K_BASSCHAR, 0)
            .apply()
        reload(ctx)
    }
}

/** Filter biquad (bentuk transposed direct form II), dihitung dalam Double. */
private class Biquad {
    var b0 = 1.0; var b1 = 0.0; var b2 = 0.0; var a1 = 0.0; var a2 = 0.0
    val z1 = DoubleArray(2)
    val z2 = DoubleArray(2)

    fun design(type: Int, fs: Double, hz: Double, q: Double, db: Double) {
        val f = hz.coerceIn(10.0, fs * 0.45)
        val a = 10.0.pow(db / 40.0)
        val w = 2.0 * PI * f / fs
        val cs = cos(w)
        val al = sin(w) / (2.0 * q)
        val a0: Double
        when (type) {
            3 -> {
                b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = (1 - cs) / 2
                a0 = 1 + al; a1 = -2 * cs; a2 = 1 - al
            }
            4 -> {
                b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = (1 + cs) / 2
                a0 = 1 + al; a1 = -2 * cs; a2 = 1 - al
            }
            5 -> {
                b0 = 1.0; b1 = -2 * cs; b2 = 1.0
                a0 = 1 + al; a1 = -2 * cs; a2 = 1 - al
            }
            1 -> {
                val s = 2.0 * sqrt(a) * al
                b0 = a * ((a + 1) - (a - 1) * cs + s)
                b1 = 2 * a * ((a - 1) - (a + 1) * cs)
                b2 = a * ((a + 1) - (a - 1) * cs - s)
                a0 = (a + 1) + (a - 1) * cs + s
                a1 = -2 * ((a - 1) + (a + 1) * cs)
                a2 = (a + 1) + (a - 1) * cs - s
            }
            2 -> {
                val s = 2.0 * sqrt(a) * al
                b0 = a * ((a + 1) + (a - 1) * cs + s)
                b1 = -2 * a * ((a - 1) + (a + 1) * cs)
                b2 = a * ((a + 1) + (a - 1) * cs - s)
                a0 = (a + 1) - (a - 1) * cs + s
                a1 = 2 * ((a - 1) - (a + 1) * cs)
                a2 = (a + 1) - (a - 1) * cs - s
            }
            else -> {
                b0 = 1 + al * a
                b1 = -2 * cs
                b2 = 1 - al * a
                a0 = 1 + al / a
                a1 = -2 * cs
                a2 = 1 - al / a
            }
        }
        b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0
    }

    /** Respons amplitudo (dB) pada frekuensi [f] untuk laju sampel [fs]. */
    fun magDb(f: Double, fs: Double): Double {
        val w = 2.0 * PI * f / fs
        val c1 = cos(w); val s1 = sin(w); val c2 = cos(2 * w); val s2 = sin(2 * w)
        val nr = b0 + b1 * c1 + b2 * c2
        val ni = -(b1 * s1 + b2 * s2)
        val dr = 1 + a1 * c1 + a2 * c2
        val di = -(a1 * s1 + a2 * s2)
        return 10.0 * log10((nr * nr + ni * ni) / max(1e-30, dr * dr + di * di))
    }

    fun run(ch: Int, x: Double): Double {
        val y = b0 * x + z1[ch]
        z1[ch] = b1 * x - a1 * y + z2[ch]
        z2[ch] = b2 * x - a2 * y
        return y
    }
}

/**
 * Kompresor satu pita dengan lutut lunak 6 dB, dihitung dalam Double. Deteksi puncak, pengurangan penguatan
 * dihaluskan dengan waktu serang dan lepas. Penguatan dibagi dua kanal oleh pemanggil (deteksi stereo terhubung).
 */
private class BandComp {
    private var thr = -24.0
    private var ratio = 3.0
    private var makeupDb = 0.0
    private var atk = 0.0
    private var rel = 0.0
    private var env = 0.0   // pengurangan penguatan (dB, nol atau negatif), sudah dihaluskan

    fun setup(fs: Double, thrDb: Double, ratio: Double, atkMs: Double, relMs: Double, makeupDb: Double) {
        this.thr = thrDb
        this.ratio = max(1.0, ratio)
        this.makeupDb = makeupDb
        atk = exp(-1.0 / (max(0.1, atkMs) * 0.001 * fs))
        rel = exp(-1.0 / (max(1.0, relMs) * 0.001 * fs))
    }

    fun reset() {
        env = 0.0
    }

    /** Penguatan linear untuk puncak pita [peak] (skala penuh = 1.0). */
    fun gain(peak: Double): Double {
        val lvl = 20.0 * log10(max(peak, 1e-9))
        val over = lvl - thr
        val knee = 6.0
        val target = if (2.0 * over < -knee) 0.0
        else if (2.0 * abs(over) <= knee) (1.0 / ratio - 1.0) * (over + knee / 2.0) * (over + knee / 2.0) / (2.0 * knee)
        else (1.0 / ratio - 1.0) * over
        val coef = if (target < env) atk else rel
        env = coef * env + (1.0 - coef) * target
        if (abs(env) < 1e-12) env = 0.0
        return 10.0.pow((env + makeupDb) / 20.0)
    }
}

/**
 * Pembagi 3 pita Linkwitz-Riley orde 4 (batas 250 Hz dan 2,5 kHz). Pita bawah dilewatkan juga lewat
 * penyama fase pada 2,5 kHz sehingga jumlah ketiga pita rata (tanpa kompresi, keluaran sama dengan masukan).
 */
private class Split3 {
    private val lp1 = Array(2) { Biquad() }
    private val hp1 = Array(2) { Biquad() }
    private val lp2m = Array(2) { Biquad() }
    private val hp2m = Array(2) { Biquad() }
    private val lp2l = Array(2) { Biquad() }
    private val hp2l = Array(2) { Biquad() }

    fun design(fs: Double) {
        val q = 0.7071067811865476
        for (b in lp1) b.design(3, fs, 250.0, q, 0.0)
        for (b in hp1) b.design(4, fs, 250.0, q, 0.0)
        for (b in lp2m) b.design(3, fs, 2500.0, q, 0.0)
        for (b in hp2m) b.design(4, fs, 2500.0, q, 0.0)
        for (b in lp2l) b.design(3, fs, 2500.0, q, 0.0)
        for (b in hp2l) b.design(4, fs, 2500.0, q, 0.0)
    }

    /** Pisahkan satu sampel kanal [c] ke [out] (indeks 0 bawah, 1 tengah, 2 atas). */
    fun run(c: Int, x: Double, out: DoubleArray) {
        val low0 = lp1[1].run(c, lp1[0].run(c, x))
        val hi0 = hp1[1].run(c, hp1[0].run(c, x))
        out[1] = lp2m[1].run(c, lp2m[0].run(c, hi0))
        out[2] = hp2m[1].run(c, hp2m[0].run(c, hi0))
        out[0] = lp2l[1].run(c, lp2l[0].run(c, low0)) + hp2l[1].run(c, hp2l[0].run(c, low0))
    }
}

/**
 * Reverb ruang (gaya Freeverb): 8 filter comb paralel lalu 4 allpass berderet per kanal,
 * dihitung dalam Double. Panjang jalur mengikuti laju sampel sehingga ukuran ruang sama
 * di 44,1 kHz, 96 kHz, atau 192 kHz. Kanal kanan memakai jalur sedikit lebih panjang
 * supaya ruang terasa lebar.
 */
private class Reverb(fs: Double) {
    private class Comb(val buf: DoubleArray) {
        var idx = 0
        var store = 0.0
    }

    private val combTune = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val apTune = intArrayOf(556, 441, 341, 225)
    private val scale = fs / 44100.0
    private val combs = Array(2) { c ->
        Array(8) { i -> Comb(DoubleArray(max(1, ((combTune[i] + c * 23) * scale).toInt()))) }
    }
    private val aps = Array(2) { c ->
        Array(4) { i -> DoubleArray(max(1, ((apTune[i] + c * 23) * scale).toInt())) }
    }
    private val apIdx = Array(2) { IntArray(4) }
    private var feedback = 0.84
    private var damp = 0.2

    fun setup(room: Double, dampening: Double) {
        feedback = room * 0.28 + 0.7
        damp = dampening * 0.4
    }

    fun process(c: Int, input: Double): Double {
        var out = 0.0
        for (cb in combs[c]) {
            val v = cb.buf[cb.idx]
            cb.store = v * (1.0 - damp) + cb.store * damp
            if (abs(cb.store) < 1e-20) cb.store = 0.0
            cb.buf[cb.idx] = input + cb.store * feedback
            cb.idx++
            if (cb.idx >= cb.buf.size) cb.idx = 0
            out += v
        }
        for (i in 0 until 4) {
            val b = aps[c][i]
            val k = apIdx[c][i]
            val bo = b[k]
            val o = -out + bo
            b[k] = out + bo * 0.5
            out = o
            apIdx[c][i] = if (k + 1 >= b.size) 0 else k + 1
        }
        return out
    }
}

/**
 * Prosesor audio sendiri yang dipasang di jalur ExoPlayer, di luar efek bawaan Android.
 * Semua hitungan memakai Double (64-bit). Masukan boleh 16/24/32-bit atau float. Keluaran: float 32-bit
 * (mode Hi-Res, bawaan) atau 16-bit dengan dither TPDF. Hanya mono dan stereo; format lain dilewatkan apa adanya.
 */
@OptIn(UnstableApi::class)
class NovanProcessor : BaseAudioProcessor() {

    private var fs = 44100.0
    private var ch = 2
    private var seen = -1
    private var chain = ArrayList<Biquad>()
    private var extra = ArrayList<Biquad>()       // bass dan treble
    private var preamp = 1.0
    private var on = false
    private var width = 1.0
    private var mono = false
    private var gainL = 1.0
    private var gainR = 1.0
    private var limiter = true
    private var limGain = 1.0
    private var rg = 1.0
    private var hiRes = true
    private var rev = Reverb(44100.0)
    private var revMix = 0.0
    private var relCoef = 0.999
    private var rng = 0x2545F491
    private var ceiling = 10.0.pow(-0.5 / 20.0)
    private var outGain = 1.0
    private var mbOn = false
    private val split = Split3()
    private val comps = Array(3) { BandComp() }
    private val bandBuf = Array(2) { DoubleArray(3) }
    private val bandGain = DoubleArray(3)

    /** Laju keluaran akhir yang direncanakan untuk lagu ini; 0 bila prosesor tidak aktif. Dibaca [NovanResampler]. */
    @Volatile
    var plannedRate = 0
        private set

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val enc = inputAudioFormat.encoding
        val ok = enc == C.ENCODING_PCM_16BIT || enc == C.ENCODING_PCM_24BIT ||
            enc == C.ENCODING_PCM_32BIT || enc == C.ENCODING_PCM_FLOAT
        if (!ok || inputAudioFormat.channelCount !in 1..2) {
            plannedRate = 0
            return AudioProcessor.AudioFormat.NOT_SET
        }
        fs = inputAudioFormat.sampleRate.toDouble()
        ch = inputAudioFormat.channelCount
        relCoef = exp(-1.0 / (0.15 * fs))
        rev = Reverb(fs)
        split.design(fs)
        for (c in comps) c.reset()
        limGain = 1.0
        seen = -1
        val plan = NovanEngine.plan(inputAudioFormat.sampleRate, inputAudioFormat.channelCount)
        hiRes = plan.float
        plannedRate = plan.rate
        return AudioProcessor.AudioFormat(
            inputAudioFormat.sampleRate, ch,
            if (hiRes) C.ENCODING_PCM_FLOAT else C.ENCODING_PCM_16BIT
        )
    }

    private fun refresh() {
        val v = NovanEngine.version
        if (v == seen) return
        seen = v
        val p = NovanEngine.params
        on = p.on
        rg = 10.0.pow(NovanEngine.rgDb / 20.0)
        val list = ArrayList<Biquad>()
        for (b in p.bands) list.add(Biquad().also { it.design(b.type, fs, b.hz, b.q, b.db) })
        chain = list
        val ex = ArrayList<Biquad>()
        if (abs(p.bassDb) >= 0.05) ex.add(Biquad().also { it.design(1, fs, 100.0, 0.707, p.bassDb) })
        if (abs(p.trebleDb) >= 0.05) ex.add(Biquad().also { it.design(2, fs, 8000.0, 0.707, p.trebleDb) })
        extra = ex

        // Kompresor 3 pita dan penguat suara pelan memakai tiga kompresor yang sama (satu per pita).
        val amt = p.softVol.coerceIn(0.0, 1.0)
        val softOnly = amt > 0.0 && !p.compOn
        val cThr = if (softOnly) -36.0 + 12.0 * amt else p.compThr
        val cRatio = if (softOnly) 1.0 + 2.0 * amt else p.compRatio
        val cAtk = if (softOnly) 18.0 else p.compAtk
        val cRel = if (softOnly) 220.0 else p.compRel
        val cMakeup = (if (p.compOn) p.compMakeup else 0.0) + 4.5 * amt
        for (c in comps) c.setup(fs, cThr, cRatio, cAtk, cRel, cMakeup)
        mbOn = p.compOn || amt > 0.0

        // Headroom otomatis: kurangi penguatan sebesar puncak respons gabungan semua filter (EQ, bass, treble,
        // kejernihan, bass cerdas) ditambah makeup kompresor, supaya penumpukan penguatan tidak memecahkan suara.
        val reserve = if (p.headroom) max(0.0, peakGainDb(list, ex)) + (if (mbOn) cMakeup else 0.0) else 0.0
        preamp = 10.0.pow((p.preampDb - reserve) / 20.0)
        outGain = 10.0.pow(p.outGainDb / 20.0)
        ceiling = 10.0.pow(p.limCeilDb / 20.0)
        relCoef = exp(-1.0 / (p.limRelMs * 0.001 * fs))
        width = p.width
        mono = p.mono
        gainL = if (p.balance > 0) 1.0 - p.balance else 1.0
        gainR = if (p.balance < 0) 1.0 + p.balance else 1.0
        limiter = p.limiter
        revMix = p.revMix
        rev.setup(p.revRoom, p.revDamp)
    }

    /** Puncak respons amplitudo gabungan (dB) dari semua filter pada 20 Hz sampai 20 kHz. */
    private fun peakGainDb(a: List<Biquad>, b: List<Biquad>): Double {
        if (a.isEmpty() && b.isEmpty()) return 0.0
        val lo = ln(20.0)
        val hi = ln(min(20000.0, fs * 0.45))
        var best = -1e9
        val steps = 240
        for (i in 0 until steps) {
            val f = exp(lo + (hi - lo) * i / (steps - 1.0))
            var sum = 0.0
            for (x in a) sum += x.magDb(f, fs)
            for (x in b) sum += x.magDb(f, fs)
            if (sum > best) best = sum
        }
        return best
    }

    private fun readSample(buf: ByteBuffer, enc: Int): Double = when (enc) {
        C.ENCODING_PCM_16BIT -> buf.short / 32768.0
        C.ENCODING_PCM_24BIT -> {
            val b0 = buf.get().toInt() and 0xFF
            val b1 = buf.get().toInt() and 0xFF
            val b2 = buf.get().toInt()
            ((b2 shl 16) or (b1 shl 8) or b0) / 8388608.0
        }
        C.ENCODING_PCM_32BIT -> buf.int / 2147483648.0
        else -> buf.float.toDouble()
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val enc = inputAudioFormat.encoding
        val bytes = when (enc) {
            C.ENCODING_PCM_16BIT -> 2
            C.ENCODING_PCM_24BIT -> 3
            else -> 4
        }
        val frames = inputBuffer.remaining() / (bytes * ch)
        if (frames == 0) {
            inputBuffer.position(inputBuffer.limit())
            return
        }
        refresh()
        val out = replaceOutputBuffer(frames * ch * (if (hiRes) 4 else 2))
        val x = DoubleArray(2)
        for (n in 0 until frames) {
            for (c in 0 until ch) x[c] = readSample(inputBuffer, enc)
            if (rg != 1.0) for (c in 0 until ch) x[c] *= rg
            if (on) {
                for (c in 0 until ch) {
                    var v = x[c] * preamp
                    for (f in chain) v = f.run(c, v)
                    for (f in extra) v = f.run(c, v)
                    x[c] = v
                }
                if (mbOn) {
                    for (c in 0 until ch) split.run(c, x[c], bandBuf[c])
                    for (b in 0 until 3) {
                        var pk = abs(bandBuf[0][b])
                        if (ch == 2) pk = max(pk, abs(bandBuf[1][b]))
                        bandGain[b] = comps[b].gain(pk)
                    }
                    for (c in 0 until ch) {
                        val bb = bandBuf[c]
                        x[c] = bb[0] * bandGain[0] + bb[1] * bandGain[1] + bb[2] * bandGain[2]
                    }
                }
                if (revMix > 0.0) {
                    val inp = if (ch == 2) (x[0] + x[1]) * 0.03 else x[0] * 0.042
                    val wl = rev.process(0, inp)
                    val wr = if (ch == 2) rev.process(1, inp) else wl
                    val dryG = 1.0 - 0.5 * revMix
                    val wetG = 0.8 * revMix
                    x[0] = x[0] * dryG + wl * wetG
                    if (ch == 2) x[1] = x[1] * dryG + wr * wetG
                }
                if (ch == 2) {
                    var l = x[0]
                    var r = x[1]
                    if (mono) {
                        val m = (l + r) * 0.5
                        l = m; r = m
                    } else if (width != 1.0) {
                        val m = (l + r) * 0.5
                        val s = (l - r) * 0.5 * width
                        l = m + s; r = m - s
                    }
                    x[0] = l * gainL
                    x[1] = r * gainR
                } else if (ch == 1) {
                    x[0] *= max(gainL, gainR)
                }
                if (outGain != 1.0) for (c in 0 until ch) x[c] *= outGain
            }
            if (limiter && (on || rg > 1.0)) {
                var pk = abs(x[0])
                if (ch == 2) pk = max(pk, abs(x[1]))
                val target = if (pk > ceiling) ceiling / pk else 1.0
                limGain = if (target < limGain) target else limGain + (target - limGain) * (1.0 - relCoef)
                for (c in 0 until ch) x[c] *= limGain
            }
            if (hiRes) {
                for (c in 0 until ch) out.putFloat(x[c].coerceIn(-1.0, 1.0).toFloat())
                continue
            }
            for (c in 0 until ch) {
                rng = rng xor (rng shl 13); rng = rng xor (rng ushr 17); rng = rng xor (rng shl 5)
                val r1 = (rng and 0xFFFF) / 65536.0
                rng = rng xor (rng shl 13); rng = rng xor (rng ushr 17); rng = rng xor (rng shl 5)
                val r2 = (rng and 0xFFFF) / 65536.0
                val dither = (r1 - r2) / 32768.0
                val s = Math.round((x[c] + dither).coerceIn(-1.0, 1.0) * 32767.0).toInt()
                out.putShort(s.toShort())
            }
        }
        out.flip()
    }
}

/**
 * Pengubah laju sampel sendiri (hitungan 64-bit), dipasang setelah [NovanProcessor]. Hanya menaikkan laju:
 * polifase dengan filter sinc berjendela Kaiser (96 titik per fase, redaman sekitar 80 dB). Dengan begitu
 * pengubah laju bawaan Android tidak perlu bekerja, atau, pada DAC USB, laju tinggi bisa dikirim langsung.
 * Menerima float atau 16-bit (dengan dither); format lain dilewatkan apa adanya.
 */
@OptIn(UnstableApi::class)
class NovanResampler(private val src: NovanProcessor) : BaseAudioProcessor() {

    private companion object {
        const val TAPS = 96
        const val RING = 128
        const val MASK = RING - 1
        const val MAX_L = 4096

        private var cacheL = 0
        private var cacheTable = DoubleArray(0)

        private fun bessel(x: Double): Double {
            var sum = 1.0
            var term = 1.0
            for (k in 1..60) {
                val h = x / (2.0 * k)
                term *= h * h
                sum += term
                if (term < 1e-14 * sum) break
            }
            return sum
        }

        private tailrec fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)

        /** Tabel koefisien terurut per fase: indeks fase * TAPS + j. Tiap fase dinormalkan ke penguatan 1. */
        @Synchronized
        fun table(l: Int): DoubleArray {
            if (l == cacheL) return cacheTable
            val n = l * TAPS
            val c = (n - 1) / 2.0
            val fc = 0.474 / l
            val beta = 8.0
            val i0 = bessel(beta)
            val h = DoubleArray(n)
            for (i in 0 until n) {
                val x = i - c
                val s = if (x == 0.0) 2.0 * fc else sin(2.0 * PI * fc * x) / (PI * x)
                val r = x / c
                val w = bessel(beta * sqrt(max(0.0, 1.0 - r * r))) / i0
                h[i] = s * w
            }
            val t = DoubleArray(n)
            for (p in 0 until l) {
                var sum = 0.0
                for (j in 0 until TAPS) sum += h[p + j * l]
                for (j in 0 until TAPS) t[p * TAPS + j] = h[p + j * l] / sum
            }
            cacheL = l
            cacheTable = t
            return t
        }
    }

    // pengaturan menunggu (diisi onConfigure), dipakai saat onFlush
    private var pL = 1
    private var pM = 1
    private var pCh = 2
    private var pFloat = true
    private var pSkip = 0
    private var pCoef = DoubleArray(0)

    // pengaturan aktif
    private var l = 1
    private var m = 1
    private var ch = 2
    private var isFloat = true
    private var skip = 0
    private var coef = DoubleArray(0)
    private val hist = Array(2) { DoubleArray(RING) }
    private var wp = 0
    private var acc = 0
    private var rng = 0x1F123BB5

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val target = src.plannedRate
        val enc = inputAudioFormat.encoding
        val rate = inputAudioFormat.sampleRate
        if (target <= rate || inputAudioFormat.channelCount !in 1..2 ||
            (enc != C.ENCODING_PCM_FLOAT && enc != C.ENCODING_PCM_16BIT)
        ) return AudioProcessor.AudioFormat.NOT_SET
        val g = gcd(target, rate)
        val ll = target / g
        val mm = rate / g
        if (ll > MAX_L) return AudioProcessor.AudioFormat.NOT_SET
        pL = ll
        pM = mm
        pCh = inputAudioFormat.channelCount
        pFloat = enc == C.ENCODING_PCM_FLOAT
        pCoef = table(ll)
        // tunda filter (setengah panjangnya) dibuang di awal supaya lagu tidak bergeser
        pSkip = Math.round(((ll * TAPS - 1) / 2.0) / mm).toInt()
        return AudioProcessor.AudioFormat(target, inputAudioFormat.channelCount, enc)
    }

    override fun onFlush() {
        l = pL
        m = pM
        ch = pCh
        isFloat = pFloat
        skip = pSkip
        coef = pCoef
        acc = 0
        wp = 0
        hist[0].fill(0.0)
        hist[1].fill(0.0)
    }

    override fun onReset() {
        pCoef = DoubleArray(0)
        coef = DoubleArray(0)
    }

    private fun emit(out: ByteBuffer, v: Double) {
        if (isFloat) {
            out.putFloat(v.coerceIn(-1.0, 1.0).toFloat())
            return
        }
        rng = rng xor (rng shl 13); rng = rng xor (rng ushr 17); rng = rng xor (rng shl 5)
        val r1 = (rng and 0xFFFF) / 65536.0
        rng = rng xor (rng shl 13); rng = rng xor (rng ushr 17); rng = rng xor (rng shl 5)
        val r2 = (rng and 0xFFFF) / 65536.0
        val d = (r1 - r2) / 32768.0
        out.putShort(Math.round((v + d).coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort())
    }

    /** Memasukkan satu frame masukan dan menulis semua frame keluaran yang sudah bisa dihitung. */
    private fun push(x: DoubleArray, out: ByteBuffer) {
        for (c in 0 until ch) hist[c][wp and MASK] = x[c]
        while (acc < l) {
            if (skip > 0) {
                skip--
                acc += m
                continue
            }
            val base = acc * TAPS
            for (c in 0 until ch) {
                val h = hist[c]
                var idx = wp
                var s = 0.0
                for (j in 0 until TAPS) {
                    s += coef[base + j] * h[idx and MASK]
                    idx--
                }
                emit(out, s)
            }
            acc += m
        }
        acc -= l
        wp++
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (coef.isEmpty()) onFlush()
        val bytes = if (isFloat) 4 else 2
        val frames = inputBuffer.remaining() / (bytes * ch)
        if (frames == 0) {
            inputBuffer.position(inputBuffer.limit())
            return
        }
        val maxFrames = (frames.toLong() * l / m + 4).toInt()
        val out = replaceOutputBuffer(maxFrames * ch * bytes)
        val x = DoubleArray(2)
        for (n in 0 until frames) {
            for (c in 0 until ch) {
                x[c] = if (isFloat) inputBuffer.float.toDouble() else inputBuffer.short / 32768.0
            }
            push(x, out)
        }
        out.flip()
    }

    /** Di akhir lagu, dorong ekor filter keluar dengan frame hening supaya akhir lagu tidak terpotong. */
    override fun onQueueEndOfStream() {
        if (!isActive || coef.isEmpty()) return
        val bytes = if (isFloat) 4 else 2
        val zeros = TAPS / 2 + 2
        val maxFrames = (zeros.toLong() * l / m + 8).toInt()
        val out = replaceOutputBuffer(maxFrames * ch * bytes)
        val z = DoubleArray(2)
        repeat(zeros) { push(z, out) }
        out.flip()
    }
}

/**
 * Mengubah PCM 24/32-bit atau float menjadi 16-bit supaya pemroses bawaan ExoPlayer
 * (lewati-hening dan pengatur kecepatan, yang hanya menerima 16-bit) tidak menolak formatnya.
 * Bila masukan sudah 16-bit, prosesor ini tidak aktif dan tidak mengubah apa pun.
 */
@OptIn(UnstableApi::class)
private class ToPcm16 : BaseAudioProcessor() {
    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        return when (inputAudioFormat.encoding) {
            C.ENCODING_PCM_16BIT -> AudioProcessor.AudioFormat.NOT_SET
            C.ENCODING_PCM_24BIT, C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT ->
                AudioProcessor.AudioFormat(inputAudioFormat.sampleRate, inputAudioFormat.channelCount, C.ENCODING_PCM_16BIT)
            else -> throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val enc = inputAudioFormat.encoding
        val bytes = if (enc == C.ENCODING_PCM_24BIT) 3 else 4
        val n = inputBuffer.remaining() / bytes
        if (n == 0) {
            inputBuffer.position(inputBuffer.limit())
            return
        }
        val out = replaceOutputBuffer(n * 2)
        for (i in 0 until n) {
            val v: Double = when (enc) {
                C.ENCODING_PCM_24BIT -> {
                    val b0 = inputBuffer.get().toInt() and 0xFF
                    val b1 = inputBuffer.get().toInt() and 0xFF
                    val b2 = inputBuffer.get().toInt()
                    ((b2 shl 16) or (b1 shl 8) or b0) / 8388608.0
                }
                C.ENCODING_PCM_32BIT -> inputBuffer.int / 2147483648.0
                else -> inputBuffer.float.toDouble()
            }
            out.putShort(Math.round(v.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort())
        }
        out.flip()
    }
}

/**
 * Rantai prosesor audio: lewati-hening dan pengatur kecepatan bawaan ExoPlayer (hanya mengerti PCM 16-bit)
 * dijalankan LEBIH DULU, baru [NovanProcessor] yang keluarannya bisa float 32-bit (Hi-Res).
 * Bila urutannya terbalik, jalur audio gagal dikonfigurasi dan lagu tidak mau diputar.
 */
@OptIn(UnstableApi::class)
private class NovanChain : DefaultAudioSink.AudioProcessorChain {
    private val to16 = ToPcm16()
    private val silence = SilenceSkippingAudioProcessor()
    private val sonic = SonicAudioProcessor()
    private val novan = NovanProcessor()
    private val resampler = NovanResampler(novan)

    override fun getAudioProcessors(): Array<AudioProcessor> = arrayOf(to16, silence, sonic, novan, resampler)

    override fun applyPlaybackParameters(playbackParameters: PlaybackParameters): PlaybackParameters {
        sonic.setSpeed(playbackParameters.speed)
        sonic.setPitch(playbackParameters.pitch)
        return playbackParameters
    }

    override fun applySkipSilenceEnabled(skipSilenceEnabled: Boolean): Boolean {
        silence.setEnabled(skipSilenceEnabled)
        return skipSilenceEnabled
    }

    override fun getMediaDuration(playoutDuration: Long): Long =
        if (sonic.isActive()) sonic.getMediaDuration(playoutDuration) else playoutDuration

    override fun getSkippedOutputFrameCount(): Long = silence.getSkippedFrames()
}

/** Pabrik pemutar yang memasang [NovanProcessor] di jalur audio ExoPlayer. */
@OptIn(UnstableApi::class)
class NovanRenderersFactory(ctx: Context) : DefaultRenderersFactory(ctx) {
    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink? =
        DefaultAudioSink.Builder(context)
            .setEnableFloatOutput(enableFloatOutput)
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
            .setAudioProcessorChain(NovanChain())
            .build()
}
