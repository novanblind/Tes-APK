package id.ytplayer

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import org.json.JSONArray
import org.json.JSONObject

/**
 * Sesi akun YouTube (cookie hasil login WebView). Cookie setara kunci akun, jadi disimpan
 * terenkripsi (AES-GCM, kunci di Android Keystore) dan tidak pernah ditulis ke log atau laporan galat.
 * Dipakai HANYA untuk panggilan akun (subscribe, daftar channel); pemutaran dan unduhan lewat
 * NewPipe tidak memakainya.
 */
object YtAccount {
    private const val ALIAS = "ytplayer_account_key"
    private const val PREFS = "yt_account"
    private const val K_COOKIE = "c"
    private const val K_NAME = "name"
    private const val K_PHOTO = "photo"
    private const val K_HANDLE = "handle"
    private const val K_SUBS = "subs"
    private const val K_SUBS_AT = "subs_at"
    const val ORIGIN = "https://www.youtube.com"

    /**
     * Identitas peramban untuk login dan panggilan akun: Chrome desktop yang sama dengan YMusic.
     * Dipakai di WebView login dan di YtApi supaya sesi tampil dari satu "perangkat" yang konsisten.
     * (Ekstraksi video NewPipe tetap memakai user agent sendiri dan tidak memakai cookie.)
     */
    const val UA =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"

    @Volatile private var cached: String? = null
    @Volatile private var loaded = false

    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + ct, Base64.NO_WRAP)
    }

    private fun decrypt(stored: String): String? = try {
        val all = Base64.decode(stored, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        String(cipher.doFinal(all, 12, all.size - 12), Charsets.UTF_8)
    } catch (_: Throwable) {
        null
    }

    /** Memecah "A=1; B=2" menjadi peta nama ke nilai. */
    fun parse(cookie: String?): Map<String, String> {
        if (cookie.isNullOrBlank()) return emptyMap()
        val m = LinkedHashMap<String, String>()
        for (part in cookie.split(";")) {
            val i = part.indexOf('=')
            if (i > 0) m[part.substring(0, i).trim()] = part.substring(i + 1).trim()
        }
        return m
    }

    /** Cookie dianggap sah bila ada SAPISID atau padanannya (dibutuhkan untuk tanda tangan). */
    fun looksLoggedIn(cookie: String?): Boolean {
        val m = parse(cookie)
        return !m["SAPISID"].isNullOrEmpty() || !m["__Secure-3PAPISID"].isNullOrEmpty()
    }

    /** Membuang cookie bernilai kosong (seperti YMusic), lalu menyusun ulang "A=1; B=2". */
    fun clean(cookie: String?): String =
        parse(cookie).filter { it.value.isNotEmpty() }.entries.joinToString("; ") { "${it.key}=${it.value}" }

    fun save(c: Context, cookie: String) {
        val tidy = clean(cookie)
        prefs(c).edit().putString(K_COOKIE, encrypt(tidy)).remove(K_NAME).remove(K_PHOTO).remove(K_HANDLE).apply()
        cached = tidy
        loaded = true
        epoch++
    }

    fun cookie(c: Context): String? {
        if (!loaded) {
            val stored = prefs(c).getString(K_COOKIE, null)
            cached = stored?.let { decrypt(it) }
            loaded = true
        }
        return cached
    }

    fun isLoggedIn(c: Context) = looksLoggedIn(cookie(c))

    fun name(c: Context): String? = prefs(c).getString(K_NAME, null)
    fun setName(c: Context, n: String?) {
        prefs(c).edit().apply { if (n.isNullOrBlank()) remove(K_NAME) else putString(K_NAME, n) }.apply()
        // Akun yang sama bisa tersimpan dua kali bila ditambah lagi: buang salinan lama yang bernama sama.
        if (!n.isNullOrBlank()) {
            for (id in ids(c)) if (snapName(c, id) == n) dropStored(c, id)
        }
    }

    /** Foto profil dan handle channel (mis. "@nama") untuk layar Anda; boleh kosong bila tidak terbaca. */
    fun photo(c: Context): String? = prefs(c).getString(K_PHOTO, null)
    fun handle(c: Context): String? = prefs(c).getString(K_HANDLE, null)
    fun setProfile(c: Context, photo: String?, handle: String?) {
        prefs(c).edit().apply {
            if (photo.isNullOrBlank()) remove(K_PHOTO) else putString(K_PHOTO, photo)
            if (handle.isNullOrBlank()) remove(K_HANDLE) else putString(K_HANDLE, handle.trim())
        }.apply()
    }

    /** ID channel yang diketahui sudah di-subscribe (dari daftar channel dan dari aksi di aplikasi ini). */
    fun subs(c: Context): Set<String> = prefs(c).getStringSet(K_SUBS, emptySet()) ?: emptySet()
    fun setSubs(c: Context, ids: Collection<String>) {
        prefs(c).edit().putStringSet(K_SUBS, HashSet(ids)).putLong(K_SUBS_AT, System.currentTimeMillis()).apply()
    }

    /** True bila daftar langganan belum pernah dimuat atau sudah lebih dari satu jam. */
    fun subsStale(c: Context): Boolean {
        val at = prefs(c).getLong(K_SUBS_AT, 0L)
        return at == 0L || System.currentTimeMillis() - at > 3_600_000L
    }

    private const val K_SEEN = "seen_"
    private const val K_FIRST = "first_at"

    /** Waktu (detik) video terbaru channel yang sudah dilihat; video lebih baru = titik biru. */
    fun seenAt(c: Context, channelId: String): Long {
        val p = prefs(c)
        val v = p.getLong(K_SEEN + channelId, -1L)
        if (v >= 0) return v
        var first = p.getLong(K_FIRST, 0L)
        if (first == 0L) {
            first = System.currentTimeMillis() / 1000 - 86400L
            p.edit().putLong(K_FIRST, first).apply()
        }
        return first
    }

    fun markSeen(c: Context, channelId: String, at: Long) {
        prefs(c).edit().putLong(K_SEEN + channelId, at).apply()
    }

    /** Keluar dari akun yang sedang dipakai. Bila ada akun lain tersimpan, akun itu yang dipakai berikutnya. */
    fun logout(c: Context) {
        clear(c)
        val cm = android.webkit.CookieManager.getInstance()
        cm.removeAllCookies(null)
        cm.flush()
        val next = ids(c).firstOrNull()
        if (next != null) switchTo(c, next) else store(c).edit().remove(K_ACTIVE).commit()
        epoch++
    }
    fun markSub(c: Context, id: String, subscribed: Boolean) {
        val set = HashSet(subs(c))
        if (subscribed) set.add(id) else set.remove(id)
        setSubs(c, set)
    }

    fun clear(c: Context) {
        prefs(c).edit().clear().apply()
        cached = null
        loaded = true
        epoch++
    }


    // ---- beberapa akun
    // Akun yang sedang dipakai tetap di prefs biasa (semua fungsi lain tidak berubah). Akun lain disimpan
    // sebagai salinan seluruh isi prefs-nya (cookie tetap terenkripsi) di penyimpanan terpisah.

    private const val STORE = "yt_accounts_store"
    private const val K_ACTIVE = "active_id"
    private const val K_IDS = "ids"

    /** Naik setiap akun berubah (masuk, ganti, keluar), supaya layar lain tahu harus memuat ulang. */
    @Volatile private var epochValue = 0
    private var epoch: Int
        get() = epochValue
        set(v) { epochValue = v }
    fun epoch(): Int = epochValue

    class Entry(val id: String, val name: String?, val active: Boolean)

    private fun store(c: Context) = c.applicationContext.getSharedPreferences(STORE, Context.MODE_PRIVATE)

    private fun ids(c: Context): List<String> =
        (store(c).getString(K_IDS, "") ?: "").split(",").filter { it.isNotEmpty() }

    private fun newId() = java.lang.Long.toString(System.currentTimeMillis(), 36) + (Math.random() * 1000).toInt()

    private fun activeId(c: Context): String {
        store(c).getString(K_ACTIVE, null)?.let { return it }
        val id = newId()
        store(c).edit().putString(K_ACTIVE, id).commit()
        return id
    }

    private fun snapshot(c: Context): JSONObject {
        val o = JSONObject()
        for ((k, v) in prefs(c).all) {
            when (v) {
                is String -> o.put(k, JSONObject().put("t", "s").put("v", v))
                is Long -> o.put(k, JSONObject().put("t", "l").put("v", v))
                is Set<*> -> o.put(k, JSONObject().put("t", "set").put("v", JSONArray(v.map { it.toString() })))
            }
        }
        return o
    }

    private fun restore(c: Context, o: JSONObject) {
        val e = prefs(c).edit().clear()
        for (k in o.keys()) {
            val x = o.getJSONObject(k)
            when (x.getString("t")) {
                "s" -> e.putString(k, x.getString("v"))
                "l" -> e.putLong(k, x.getLong("v"))
                "set" -> {
                    val a = x.getJSONArray("v")
                    val set = HashSet<String>()
                    for (i in 0 until a.length()) set.add(a.getString(i))
                    e.putStringSet(k, set)
                }
            }
        }
        e.commit()
        cached = null
        loaded = false
    }

    private fun snapName(c: Context, id: String): String? = try {
        JSONObject(store(c).getString("snap_$id", null) ?: "").optJSONObject(K_NAME)?.optString("v")?.takeIf { it.isNotBlank() }
    } catch (_: Throwable) { null }

    private fun dropStored(c: Context, id: String) {
        store(c).edit().remove("snap_$id").putString(K_IDS, ids(c).filter { it != id }.joinToString(",")).commit()
    }

    /** Daftar akun: yang sedang dipakai lebih dulu, lalu akun tersimpan lainnya. */
    fun list(c: Context): List<Entry> {
        val out = ArrayList<Entry>()
        if (isLoggedIn(c)) out += Entry(activeId(c), name(c), true)
        for (id in ids(c)) out += Entry(id, snapName(c, id), false)
        return out
    }

    /** Simpan akun yang sedang dipakai ke daftar, lalu kosongkan tempat aktif (dipakai sebelum menambah akun). */
    fun stashActive(c: Context) {
        if (!isLoggedIn(c)) return
        val id = activeId(c)
        store(c).edit()
            .putString("snap_$id", snapshot(c).toString())
            .putString(K_IDS, (ids(c) + id).distinct().joinToString(","))
            .putString(K_ACTIVE, newId())
            .commit()
        prefs(c).edit().clear().commit()
        cached = null
        loaded = false
        epoch++
    }

    /** Pindah ke akun tersimpan [id]; akun yang sedang dipakai disimpan dulu. */
    fun switchTo(c: Context, id: String): Boolean {
        val snap = store(c).getString("snap_$id", null) ?: return false
        val obj = try { JSONObject(snap) } catch (_: Throwable) { return false }
        stashActive(c)
        restore(c, obj)
        store(c).edit()
            .remove("snap_$id")
            .putString(K_IDS, ids(c).filter { it != id }.joinToString(","))
            .putString(K_ACTIVE, id)
            .commit()
        epoch++
        return true
    }

    private fun sha1Hex(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    /**
     * Nilai header Authorization: SAPISIDHASH <waktu>_<SHA1("waktu SAPISID origin")>.
     * Bila ada, SAPISID1PHASH dan SAPISID3PHASH ikut ditambahkan (cara yang dipakai yt-dlp).
     */
    fun authorization(c: Context, origin: String = ORIGIN): String? {
        val m = parse(cookie(c))
        val sapisid = m["SAPISID"] ?: m["__Secure-3PAPISID"] ?: return null
        val t = System.currentTimeMillis() / 1000
        val parts = ArrayList<String>()
        parts += "SAPISIDHASH ${t}_${sha1Hex("$t $sapisid $origin")}"
        m["__Secure-1PAPISID"]?.let { parts += "SAPISID1PHASH ${t}_${sha1Hex("$t $it $origin")}" }
        m["__Secure-3PAPISID"]?.let { parts += "SAPISID3PHASH ${t}_${sha1Hex("$t $it $origin")}" }
        return parts.joinToString(" ")
    }
}
