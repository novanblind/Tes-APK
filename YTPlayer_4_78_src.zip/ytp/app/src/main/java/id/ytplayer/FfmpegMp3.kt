package id.ytplayer

import java.io.File
import java.io.IOException

/** Pustaka konversi MP3 tidak ada atau tidak bisa dimuat di HP ini (bukan masalah internet). */
class Mp3UnavailableException(message: String) : IOException(message)

/**
 * Konverter M4A/WebM/MP4 -> MP3 memakai pustaka native ramping libytmp3.so (FFmpeg yang hanya memuat
 * dekoder AAC/Opus/Vorbis + encoder libmp3lame; sumber dan skrip build di folder native/).
 * Tidak memakai dekoder bawaan HP (MediaCodec). Ini satu-satunya jalur konversi MP3 (tanpa cadangan).
 */
object FfmpegMp3 {
    fun interface Progress {
        /** [pct] 0..100. Kembalikan false untuk membatalkan. */
        fun onProgress(pct: Int): Boolean
    }

    private val loadError: Throwable? = try {
        System.loadLibrary("ytmp3")
        null
    } catch (e: Throwable) {
        e
    }

    @JvmStatic
    external fun nConvert(src: String, dest: String, kbps: Int, cb: Progress): Boolean

    /**
     * @return true bila selesai; false bila dibatalkan lewat [isCancelled].
     * @throws IOException bila konversi gagal; [Mp3UnavailableException] bila pustaka tidak termuat.
     */
    fun convert(
        src: File, dest: File, kbps: Int,
        isCancelled: () -> Boolean, onProgress: (Int) -> Unit
    ): Boolean {
        loadError?.let { throw Mp3UnavailableException("Pustaka MP3 gagal dimuat: ${it.message}") }
        val ok = try {
            nConvert(src.absolutePath, dest.absolutePath, kbps) { pct ->
                onProgress(pct)
                !isCancelled()
            }
        } catch (e: UnsatisfiedLinkError) {
            throw Mp3UnavailableException("Pustaka MP3 tidak cocok: ${e.message}")
        }
        if (!ok || isCancelled()) {
            try { dest.delete() } catch (_: Exception) {}
            return false
        }
        if (!dest.exists() || dest.length() < 1024) throw IOException("Hasil MP3 kosong atau terlalu kecil.")
        return true
    }
}
