package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.core.view.ViewCompat

/**
 * Layar "Langganan": daftar channel YouTube yang di-subscribe akun yang sedang masuk.
 * Ketuk channel untuk pilihan: lihat video channel, atau berhenti subscribe.
 */
class SubscriptionsActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val channels = ArrayList<YtApi.Channel>()
    private var loading = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(ch: YtApi.Channel) = if (ch.subs.isBlank()) ch.title else "${ch.title}. ${ch.subs}"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            fitsSystemWindows = true
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val title = TextView(this).apply {
            text = "Langganan"
            setTextColor(getColor(R.color.text))
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, dp(8))
        }
        ViewCompat.setAccessibilityHeading(title, true)
        status = TextView(this).apply {
            setTextColor(getColor(R.color.text_secondary))
            textSize = 16f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(0, 0, 0, dp(8))
        }
        list = ListView(this).apply {
            divider = null
            dividerHeight = dp(4)
        }
        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ArrayList()) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(getColor(R.color.text))
                v.textSize = 18f
                v.minHeight = dp(56)
                return v
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> channels.getOrNull(pos)?.let { chooseAction(it) } }

        val refresh = button("Segarkan daftar") { load() }
        val back = button("Kembali") { finish() }
        root.addView(title)
        root.addView(status)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(refresh)
        root.addView(back)
        setContentView(root)
        load()
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(getColor(R.color.text))
        textSize = 16f
        setBackgroundResource(R.drawable.btn_bg)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun render() {
        adapter.clear()
        adapter.addAll(channels.map { label(it) })
        adapter.notifyDataSetChanged()
    }

    private fun load() {
        if (loading) return
        if (!YtAccount.isLoggedIn(this)) {
            status.text = "Belum masuk akun YouTube. Buka Pengaturan, lalu Akun YouTube."
            return
        }
        loading = true
        status.text = "Memuat daftar channel, mohon tunggu."
        Thread {
            val r = YtApi.listSubscriptions(this)
            runOnUiThread {
                loading = false
                if (isFinishing || isDestroyed) return@runOnUiThread
                when (r) {
                    is YtApi.ListResult.Ok -> {
                        channels.clear()
                        channels.addAll(r.channels)
                        render()
                        status.text = "${channels.size} channel. Ketuk channel untuk pilihan."
                    }
                    is YtApi.ListResult.Unrecognized -> {
                        status.text = "Daftar kosong atau bentuk respons YouTube belum dikenali."
                        AlertDialog.Builder(this)
                            .setTitle("Respons belum dikenali")
                            .setMessage("Jika Anda yakin punya channel yang di-subscribe, kirim teks ini ke pengembang:\n" +
                                r.kinds.joinToString(", "))
                            .setPositiveButton("Tutup", null)
                            .show()
                    }
                    YtApi.ListResult.NotLoggedIn -> status.text = "Belum masuk akun YouTube."
                    YtApi.ListResult.Invalid ->
                        status.text = "Sesi akun tidak sah atau kedaluwarsa. Buka Pengaturan, Akun YouTube, Keluar, lalu masuk lagi."
                    is YtApi.ListResult.Error -> status.text = "Gagal memuat: ${r.message}. Periksa sambungan internet."
                }
            }
        }.start()
    }

    private fun chooseAction(ch: YtApi.Channel) {
        AlertDialog.Builder(this)
            .setTitle(ch.title)
            .setItems(arrayOf("Buka channel", "Berhenti subscribe")) { _, which ->
                if (which == 0) {
                    startActivity(ChannelActivity.intent(this, ch.id, ch.title))
                } else {
                    SubscribeHelper.toggle(this, ch.id, ch.title, { status.text = it }) { nowSubscribed ->
                        if (!nowSubscribed) {
                            channels.removeAll { it.id == ch.id }
                            render()
                            status.text = "Berhenti subscribe dari ${ch.title}. Sisa ${channels.size} channel."
                        }
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
