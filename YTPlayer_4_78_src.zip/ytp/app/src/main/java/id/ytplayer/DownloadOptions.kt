package id.ytplayer

import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.Stream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.VideoStream

/**
 * Menentukan pilihan unduhan dari StreamInfo.
 *
 * - Audio: M4A (AAC) asli dari YouTube, tanpa konversi ulang (kualitas tidak turun).
 * - Video: MP4. Bila ada aliran gabungan (video+audio) dipakai langsung; bila tidak,
 *   aliran video H.264 dan audio M4A diunduh terpisah lalu digabung di HP (MediaMuxer).
 */
object DownloadOptions {
    const val KEY_AUDIO = "audio"
    const val KEY_VIDEO_BEST = "video:best"
    const val KEY_MP3_BEST = "mp3:192"
    const val MP3_PREFIX = "mp3:"
    const val M4A_PREFIX = "m4a:"
    const val GROUP_MP3 = "MP3"
    const val GROUP_M4A = "M4A"
    const val GROUP_MP4 = "MP4"
    val MP3_RATES = listOf(320, 256, 224, 192, 160, 128, 112, 96, 80, 64)
    private const val VIDEO_PREFIX = "video:"
    /** Playlist: kualitas tertinggi yang tidak melebihi tinggi ini (video yang lebih rendah tetap diunduh). */
    const val VIDEOMAX_PREFIX = "videomax:"
    val PLAYLIST_HEIGHTS = listOf(1080, 720, 480, 360, 240, 144)

    class Option(val key: String, val label: String, val group: String)

    /** audioUrl == null → videoUrl sudah berisi video+audio. */
    class VideoPlan(val height: Int, val videoUrl: String, val audioUrl: String?, val sizeBytes: Long = -1L)

    /** Ukuran berkas aliran dari metadata YouTube; -1 bila tidak diketahui. */
    private fun sizeOf(s: Stream): Long {
        val n = try { s.itagItem?.contentLength ?: -1L } catch (e: Exception) { -1L }
        return if (n > 0) n else -1L
    }

    private fun sizeText(bytes: Long): String {
        val mb = bytes / 1048576.0
        return when {
            mb >= 1024 -> String.format(java.util.Locale("id", "ID"), "%.1f GB", mb / 1024)
            mb >= 1 -> "${Math.round(mb)} MB"
            else -> "< 1 MB"
        }
    }

    /**
     * Peringkat jalur audio: 0 = suara asli video, makin besar makin tidak diinginkan.
     * YouTube kini punya beberapa jalur audio (dubbing otomatis, deskripsi audio); tanpa
     * pemilihan ini yang terambil bisa jalur dubbing berbahasa Inggris.
     */
    private fun trackRank(s: AudioStream): Int {
        val type = try { s.audioTrackType?.name } catch (e: Throwable) { null }
        return when (type) {
            "ORIGINAL" -> 0
            null -> 1
            "SECONDARY" -> 2
            "DUBBED" -> 3
            else -> 4 // deskripsi audio
        }
    }

    /**
     * Aliran audio yang boleh dipakai: hanya dari jalur terbaik (suara asli). Bila [m4aOnly],
     * hanya aliran M4A yang dipertimbangkan (untuk penggabungan ke MP4).
     */
    fun audioPool(info: StreamInfo, m4aOnly: Boolean = false): List<AudioStream> {
        val all = info.audioStreams.filter {
            it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.isUrl &&
                (!m4aOnly || it.format?.suffix == "m4a")
        }
        val best = all.minOfOrNull { trackRank(it) } ?: return emptyList()
        return all.filter { trackRank(it) == best }
    }

    fun pickAudio(info: StreamInfo): AudioStream? =
        audioPool(info)
            .sortedWith(
                compareByDescending<AudioStream> { it.format?.suffix == "m4a" }
                    .thenByDescending { it.averageBitrate }
            )
            .firstOrNull()

    private fun isOpus(s: AudioStream): Boolean {
        val sfx = s.format?.suffix
        return sfx == "webm" || sfx == "opus"
    }

    /**
     * Audio terbaik untuk pemutaran: Opus (seperti YouTube asli, sekitar 160 kbps) bila ada,
     * jika tidak M4A dengan bitrate tertinggi. Hanya untuk diputar; unduhan tetap M4A.
     */
    fun pickAudioForVideo(info: StreamInfo): AudioStream? {
        val pool = audioPool(info)
        if (pool.isEmpty()) return null
        val opus = pool.filter { isOpus(it) }.maxByOrNull { it.averageBitrate }
        return opus ?: pickAudio(info)
    }

    /**
     * Audio untuk pemutaran online (mode audio saja) menurut [level]. Opus (VBR, seperti YouTube asli)
     * selalu diutamakan: 0 hemat = Opus berbitrate terendah, 1 normal = Opus sedang (bitrate tertinggi
     * yang tidak lebih dari 100 kbps; bila tidak ada, yang terdekat), 2 terbaik = Opus berbitrate tertinggi.
     * Bila video tidak punya Opus dipakai M4A seperti sebelumnya. Hanya untuk diputar; unduhan tetap M4A.
     */
    fun pickAudioForPlayback(info: StreamInfo, level: Int): AudioStream? {
        val pool = audioPool(info)
        if (pool.isEmpty()) return null
        val opus = pool.filter { isOpus(it) && it.averageBitrate > 0 }.sortedBy { it.averageBitrate }
        if (opus.isNotEmpty()) {
            return when (level) {
                Store.AUDIO_HEMAT -> opus.first()
                Store.AUDIO_TERBAIK -> opus.last()
                else -> opus.lastOrNull { it.averageBitrate <= 100 } ?: opus.first()
            }
        }
        // Opus tanpa bitrate yang diketahui: pilihan terbaik seperti biasa (Opus bila ada).
        if (level != Store.AUDIO_HEMAT) pool.filter { isOpus(it) }.firstOrNull()?.let { return it }
        val base = pool.filter { it.format?.suffix == "m4a" }.ifEmpty { pool }
        val known = base.filter { it.averageBitrate > 0 }.sortedBy { it.averageBitrate }
        if (known.isEmpty()) return pickAudio(info)
        return when (level) {
            Store.AUDIO_HEMAT -> known.first()
            Store.AUDIO_TERBAIK -> known.last()
            else -> known.lastOrNull { it.averageBitrate <= 160 } ?: known.first()
        }
    }

    /**
     * Aliran audio untuk MP3 dari yang paling cocok ke cadangan: Opus terbaik dulu, lalu M4A, bitrate stereo wajar
     * (<= 260 kbps, bukan surround 5.1) diutamakan, lalu bitrate tertinggi. Bila aliran pertama
     * gagal diunduh/dikonversi, aliran berikutnya dipakai.
     */
    fun mp3Candidates(info: StreamInfo): List<AudioStream> {
        val base = audioPool(info)
            .sortedWith(
                compareByDescending<AudioStream> { it.format?.suffix == "m4a" }
                    .thenByDescending { it.averageBitrate in 1..260 }
                    .thenByDescending { it.averageBitrate }
            )
        // Opus terbaik (stereo wajar, bitrate tertinggi) dicoba lebih dulu; cadangannya M4A.
        val opus = base.filter { isOpus(it) }
            .sortedWith(
                compareByDescending<AudioStream> { it.averageBitrate in 1..260 }
                    .thenByDescending { it.averageBitrate }
            )
            .firstOrNull()
        return if (opus != null) listOf(opus) + base.filter { it !== opus } else base
    }

    /** Aliran audio untuk kunci unduhan "audio" (terbaik) atau "m4a:<kbps>" (bitrate tertentu). */
    fun audioFor(info: StreamInfo, key: String): AudioStream? {
        val want = if (key.startsWith(M4A_PREFIX)) key.removePrefix(M4A_PREFIX).toIntOrNull() else null
        if (want != null) {
            val exact = audioPool(info, true).firstOrNull { it.averageBitrate == want }
            if (exact != null) return exact
        }
        return pickAudio(info)
    }

    /**
     * Kandidat audio M4A untuk digabung ke MP4, kualitas terbaik lebih dulu: AAC-LC (mp4a.40.2) stereo
     * (<= 260 kbps) dengan bitrate tertinggi dipakai dulu; surround 5.1 dan format lain jadi cadangan.
     * Bila hasil gabungan ternyata tidak bersuara, percobaan berikutnya memakai kandidat berikutnya.
     */
    fun m4aCandidates(info: StreamInfo): List<AudioStream> =
        audioPool(info, true).sortedWith(
            compareByDescending<AudioStream> { it.codec?.startsWith("mp4a.40.2") == true }
                .thenByDescending { it.averageBitrate in 1..260 }
                .thenByDescending { it.averageBitrate }
        )

    private fun pickM4a(info: StreamInfo, idx: Int = 0): AudioStream? {
        val l = m4aCandidates(info)
        return if (l.isEmpty()) null else l[idx.coerceAtLeast(0) % l.size]
    }

    /** "720p60" dst. = 50 fps ke atas; berkasnya jauh lebih besar daripada versi 30 fps. */
    private fun isHighFps(v: VideoStream): Boolean {
        val r = v.resolution ?: return false
        val fps = Regex("p(\\d+)").find(r)?.groupValues?.get(1)?.toIntOrNull() ?: return false
        return fps >= 50
    }

    fun videoPlans(info: StreamInfo, audioIdx: Int = 0): List<VideoPlan> {
        val byHeight = HashMap<Int, VideoPlan>()

        // Video-only H.264 (perlu digabung dengan audio M4A suara asli). Untuk tiap tinggi dipilih
        // aliran 30 fps yang paling kecil (bukan 60 fps / versi bitrate "premium" yang besar).
        val audio = pickM4a(info, audioIdx)
        if (audio != null) {
            info.videoOnlyStreams
                .filter {
                    it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.isUrl &&
                        it.format?.suffix == "mp4" && it.codec?.startsWith("avc1") == true &&
                        it.height > 0
                }
                .groupBy { it.height }
                .forEach { (h, list) ->
                    val v = list.sortedWith(
                        compareBy<VideoStream> { isHighFps(it) }
                            .thenBy { val n = sizeOf(it); if (n > 0) n else Long.MAX_VALUE }
                    ).first()
                    val vs = sizeOf(v)
                    val asz = sizeOf(audio)
                    val total = if (vs > 0) vs + (if (asz > 0) asz else 0L) else -1L
                    byHeight[h] = VideoPlan(h, v.content, audio.content, total)
                }
        }

        // Aliran gabungan MP4 hanya mengisi tinggi yang tidak punya pasangan video+audio asli:
        // jalur suaranya tidak bisa dipilih (bisa berupa dubbing) dan biasanya lebih besar.
        info.videoStreams
            .filter {
                it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.isUrl &&
                    !it.isVideoOnly() && it.format?.suffix == "mp4"
            }
            .forEach { v ->
                if (v.height > 0 && !byHeight.containsKey(v.height)) {
                    byHeight[v.height] = VideoPlan(v.height, v.content, null, sizeOf(v))
                }
            }

        return byHeight.values.sortedByDescending { it.height }
    }

    fun options(info: StreamInfo): List<Option> {
        val list = ArrayList<Option>()
        val best = pickAudio(info)
        if (best != null) {
            // M4A (AAC asli YouTube, tanpa konversi) dengan pilihan bitrate.
            val rates = audioPool(info, true)
                .filter { it.averageBitrate > 0 }
                .map { it.averageBitrate }
                .distinct()
                .sortedDescending()
            if (rates.isNotEmpty()) {
                list += Option(KEY_AUDIO, "M4A kualitas terbaik (${rates.first()} kbps)", GROUP_M4A)
                rates.drop(1).forEach { list += Option("$M4A_PREFIX$it", "M4A $it kbps", GROUP_M4A) }
            } else {
                val ext = (best.format?.suffix ?: "m4a").uppercase()
                list += Option(KEY_AUDIO, "Audio $ext kualitas asli", GROUP_M4A)
            }
            // MP3 dikonversi di HP dengan VBR (LAME); kualitas tidak bisa melebihi audio sumber.
            MP3_RATES.forEach { kbps ->
                list += Option("$MP3_PREFIX$kbps", "MP3 $kbps kbps", GROUP_MP3)
            }
        }
        videoPlans(info).take(8).forEach { p ->
            val size = if (p.sizeBytes > 0) " • ${sizeText(p.sizeBytes)}" else ""
            list += Option("$VIDEO_PREFIX${p.height}", "${p.height}p$size", GROUP_MP4)
        }
        return list
    }

    fun planFor(info: StreamInfo, key: String, audioIdx: Int = 0): VideoPlan? {
        val plans = videoPlans(info, audioIdx)
        if (plans.isEmpty()) return null
        if (key == KEY_VIDEO_BEST) return plans.firstOrNull { it.height <= 1080 } ?: plans.last()
        if (key.startsWith(VIDEOMAX_PREFIX)) {
            val max = key.removePrefix(VIDEOMAX_PREFIX).toIntOrNull() ?: return null
            // plans terurut dari tinggi ke rendah: ambil yang tertinggi di bawah batas, atau yang terendah.
            return plans.firstOrNull { it.height <= max } ?: plans.last()
        }
        val h = key.removePrefix(VIDEO_PREFIX).toIntOrNull() ?: return null
        return plans.firstOrNull { it.height == h }
    }
}
