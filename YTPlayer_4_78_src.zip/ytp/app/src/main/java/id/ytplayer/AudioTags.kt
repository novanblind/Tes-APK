package id.ytplayer

import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer

/**
 * Menulis tag judul + artis ke berkas audio hasil unduhan. TANPA gambar sampul.
 *  - MP3: ID3v2.3 (TIT2 + TPE1). Tag lama (mis. bawaan FFmpeg) diganti.
 *  - M4A/MP4 audio: atom iTunes (©nam + ©ART) di dalam moov; offset potongan disesuaikan.
 * Hasil M4A diperiksa lagi (bisa dibaca MediaExtractor); bila ragu/gagal, berkas asli dipakai apa adanya.
 */
object AudioTags {

    /**
     * Pisahkan judul video "Artis - Lagu" menjadi (judul, artis). Kata sampah di kurung seperti
     * (Official Video) dibuang. Tanpa pemisah " - ", artis diambil dari nama kanal [channel].
     * Bila bagian kanan sama dengan nama kanal ("Lagu - Artis"), urutannya dibalik.
     */
    fun fromVideo(videoTitle: String, channel: String): Pair<String, String> {
        val noise = Regex(
            "(?i)\\s*[(\\[][^)\\]]*\\b(official|video|audio|lyrics?|lirik|mv|hd|4k|clip|visualizer)\\b[^)\\]]*[)\\]]"
        )
        var t = noise.replace(videoTitle, "").trim()
        if (t.isEmpty()) t = videoTitle.trim()
        val m = Regex("^(.{1,80}?)\\s+[-\u2013\u2014]\\s+(.+)$").find(t) ?: return Pair(t, channel)
        val left = m.groupValues[1].trim()
        val right = m.groupValues[2].trim()
        if (left.isEmpty() || right.isEmpty()) return Pair(t, channel)
        fun same(a: String, b: String) = b.isNotEmpty() && a.equals(b, ignoreCase = true)
        return if (same(right, channel) && !same(left, channel)) Pair(left, right) else Pair(right, left)
    }

    /** @return berkas baru ber-tag (hapus sendiri setelah dipakai), atau null bila tidak ditulis. */
    fun tag(src: File, ext: String, title: String, artist: String): File? {
        val dst = File(src.parentFile, src.name + ".tag")
        return try {
            val ok = when (ext.lowercase()) {
                "mp3" -> { writeMp3(src, dst, title, artist); true }
                "m4a", "mp4" -> writeM4a(src, dst, title, artist) && playable(dst)
                else -> false
            }
            if (ok) dst else { dst.delete(); null }
        } catch (_: Throwable) {
            try { dst.delete() } catch (_: Exception) {}
            null
        }
    }

    // ------------------------------------------------------------------ MP3 (ID3v2.3)

    private fun textFrame(id: String, text: String): ByteArray {
        val body = ByteArrayOutputStream()
        body.write(1) // UTF-16 dengan BOM
        body.write(0xFF); body.write(0xFE)
        body.write(text.toByteArray(Charsets.UTF_16LE))
        val b = body.toByteArray()
        val out = ByteArrayOutputStream()
        out.write(id.toByteArray(Charsets.ISO_8859_1))
        out.write(ByteBuffer.allocate(4).putInt(b.size).array())
        out.write(0); out.write(0)
        out.write(b)
        return out.toByteArray()
    }

    private fun writeMp3(src: File, dst: File, title: String, artist: String) {
        val frames = ByteArrayOutputStream()
        if (title.isNotBlank()) frames.write(textFrame("TIT2", title))
        if (artist.isNotBlank()) frames.write(textFrame("TPE1", artist))
        val f = frames.toByteArray()
        val sz = f.size
        val header = byteArrayOf(
            'I'.code.toByte(), 'D'.code.toByte(), '3'.code.toByte(), 3, 0, 0,
            ((sz shr 21) and 0x7F).toByte(), ((sz shr 14) and 0x7F).toByte(),
            ((sz shr 7) and 0x7F).toByte(), (sz and 0x7F).toByte()
        )
        RandomAccessFile(src, "r").use { inp ->
            // Lewati tag ID3v2 lama bila ada.
            var skip = 0L
            val h = ByteArray(10)
            if (inp.length() >= 10) {
                inp.readFully(h)
                if (h[0] == 'I'.code.toByte() && h[1] == 'D'.code.toByte() && h[2] == '3'.code.toByte()) {
                    val old = ((h[6].toInt() and 0x7F) shl 21) or ((h[7].toInt() and 0x7F) shl 14) or
                        ((h[8].toInt() and 0x7F) shl 7) or (h[9].toInt() and 0x7F)
                    val footer = if (h[3].toInt() >= 4 && (h[5].toInt() and 0x10) != 0) 10 else 0
                    skip = 10L + old + footer
                }
            }
            inp.seek(skip)
            dst.outputStream().use { o ->
                if (f.isNotEmpty()) { o.write(header); o.write(f) }
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                }
            }
        }
    }

    // ------------------------------------------------------------------ M4A / MP4

    private class Box(val type: String, val start: Long, val size: Long, val header: Int)

    private fun readBoxes(raf: RandomAccessFile, from: Long, to: Long): List<Box> {
        val list = ArrayList<Box>()
        var pos = from
        val h = ByteArray(16)
        while (pos + 8 <= to) {
            raf.seek(pos)
            raf.readFully(h, 0, 8)
            var size = ByteBuffer.wrap(h, 0, 4).int.toLong() and 0xFFFFFFFFL
            val type = String(h, 4, 4, Charsets.ISO_8859_1)
            var hdr = 8
            if (size == 1L) {
                raf.readFully(h, 8, 8)
                size = ByteBuffer.wrap(h, 8, 8).long
                hdr = 16
            } else if (size == 0L) {
                size = to - pos
            }
            if (size < hdr || pos + size > to) break
            list += Box(type, pos, size, hdr)
            pos += size
        }
        return list
    }

    private fun be32(b: ByteArray, o: Int) = ByteBuffer.wrap(b, o, 4).int
    private fun put32(b: ByteArray, o: Int, v: Int) { ByteBuffer.wrap(b, o, 4).putInt(v) }

    private fun box(type: String, payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(ByteBuffer.allocate(4).putInt(8 + payload.size).array())
        out.write(type.toByteArray(Charsets.ISO_8859_1))
        out.write(payload)
        return out.toByteArray()
    }

    private fun boxRaw(type: ByteArray, payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(ByteBuffer.allocate(4).putInt(8 + payload.size).array())
        out.write(type)
        out.write(payload)
        return out.toByteArray()
    }

    private fun dataItem(type: ByteArray, text: String): ByteArray {
        val d = ByteArrayOutputStream()
        d.write(byteArrayOf(0, 0, 0, 1)) // jenis: teks UTF-8
        d.write(byteArrayOf(0, 0, 0, 0)) // lokal
        d.write(text.toByteArray(Charsets.UTF_8))
        return boxRaw(type, box("data", d.toByteArray()))
    }

    private fun buildUdta(title: String, artist: String): ByteArray {
        val ilst = ByteArrayOutputStream()
        if (title.isNotBlank()) ilst.write(dataItem(byteArrayOf(0xA9.toByte(), 'n'.code.toByte(), 'a'.code.toByte(), 'm'.code.toByte()), title))
        if (artist.isNotBlank()) ilst.write(dataItem(byteArrayOf(0xA9.toByte(), 'A'.code.toByte(), 'R'.code.toByte(), 'T'.code.toByte()), artist))
        val hdlrPayload = ByteArrayOutputStream().apply {
            write(ByteArray(8))                      // versi+flag, pre_defined
            write("mdir".toByteArray(Charsets.ISO_8859_1))
            write(ByteArray(12))                     // reserved
            write(0)                                 // nama kosong
        }.toByteArray()
        val meta = ByteArrayOutputStream().apply {
            write(ByteArray(4))                      // versi+flag
            write(box("hdlr", hdlrPayload))
            write(box("ilst", ilst.toByteArray()))
        }.toByteArray()
        return box("udta", box("meta", meta))
    }

    /** Tambah delta ke semua offset di stco/co64 di dalam moov (trak > mdia > minf > stbl). */
    private fun shiftOffsets(moov: ByteArray, start: Int, end: Int, delta: Long) {
        var p = start
        while (p + 8 <= end) {
            val size = be32(moov, p)
            if (size < 8 || p + size > end) return
            val type = String(moov, p + 4, 4, Charsets.ISO_8859_1)
            when (type) {
                "trak", "mdia", "minf", "stbl" -> shiftOffsets(moov, p + 8, p + size, delta)
                "stco" -> {
                    val n = be32(moov, p + 12)
                    for (i in 0 until n) {
                        val o = p + 16 + i * 4
                        put32(moov, o, (be32(moov, o).toLong() and 0xFFFFFFFFL).plus(delta).toInt())
                    }
                }
                "co64" -> {
                    val n = be32(moov, p + 12)
                    for (i in 0 until n) {
                        val o = p + 16 + i * 8
                        val v = ByteBuffer.wrap(moov, o, 8).long + delta
                        ByteBuffer.wrap(moov, o, 8).putLong(v)
                    }
                }
            }
            p += size
        }
    }

    /** Ada base_data_offset mutlak di tfhd (fragmen MP4)? Bila ada, jangan geser apa pun. */
    private fun hasAbsoluteBase(raf: RandomAccessFile, moof: Box): Boolean {
        for (traf in readBoxes(raf, moof.start + moof.header, moof.start + moof.size)) {
            if (traf.type != "traf") continue
            for (b in readBoxes(raf, traf.start + traf.header, traf.start + traf.size)) {
                if (b.type == "tfhd") {
                    raf.seek(b.start + b.header)
                    val flags = raf.readInt() and 0xFFFFFF
                    if (flags and 0x01 != 0) return true
                }
            }
        }
        return false
    }

    private fun writeM4a(src: File, dst: File, title: String, artist: String): Boolean {
        RandomAccessFile(src, "r").use { raf ->
            val len = raf.length()
            val top = readBoxes(raf, 0, len)
            val moov = top.firstOrNull { it.type == "moov" } ?: return false
            if (moov.header != 8 || moov.size > 32L * 1024 * 1024) return false
            val dataAfter = top.any { (it.type == "mdat" || it.type == "moof") && it.start > moov.start }
            // sidx sebelum moov: offsetnya ikut bergeser, terlalu berisiko.
            if (top.any { it.type == "sidx" && it.start < moov.start }) return false
            if (dataAfter && top.any { it.type == "moof" && hasAbsoluteBase(raf, it) }) return false

            // Isi moov tanpa udta lama, lalu tambah udta baru.
            val inner = readBoxes(raf, moov.start + 8, moov.start + moov.size)
            val body = ByteArrayOutputStream()
            for (c in inner) {
                if (c.type == "udta") continue
                val b = ByteArray(c.size.toInt())
                raf.seek(c.start)
                raf.readFully(b)
                body.write(b)
            }
            body.write(buildUdta(title, artist))
            val bodyBytes = body.toByteArray()
            val newMoov = ByteArray(8 + bodyBytes.size)
            put32(newMoov, 0, newMoov.size)
            "moov".toByteArray(Charsets.ISO_8859_1).copyInto(newMoov, 4)
            bodyBytes.copyInto(newMoov, 8)
            val delta = newMoov.size.toLong() - moov.size
            if (dataAfter && delta != 0L) shiftOffsets(newMoov, 8, newMoov.size, delta)

            dst.outputStream().use { o ->
                val buf = ByteArray(64 * 1024)
                fun copy(from: Long, to: Long) {
                    raf.seek(from)
                    var left = to - from
                    while (left > 0) {
                        val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) break
                        o.write(buf, 0, n)
                        left -= n
                    }
                }
                copy(0, moov.start)
                o.write(newMoov)
                copy(moov.start + moov.size, len)
            }
        }
        return true
    }

    private fun playable(f: File): Boolean {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(f.absolutePath)
            var ok = false
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
                if (mime != null && mime.startsWith("audio/")) {
                    ex.selectTrack(i)
                    ok = ex.readSampleData(ByteBuffer.allocate(1 shl 16), 0) > 0
                    break
                }
            }
            ok
        } catch (_: Exception) {
            false
        } finally {
            try { ex.release() } catch (_: Exception) {}
        }
    }
}
