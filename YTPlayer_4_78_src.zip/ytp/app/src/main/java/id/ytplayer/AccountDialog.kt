package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent

/** Daftar akun YouTube: pindah akun, tambah akun, keluar dari akun yang sedang dipakai. */
object AccountDialog {

    fun show(
        act: Activity,
        reqLogin: Int = -1,
        extraLabel: String? = null,
        extra: (() -> Unit)? = null,
        onChanged: (String) -> Unit
    ) {
        val accounts = YtAccount.list(act)
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        if (accounts.isEmpty()) {
            labels += "Masuk akun YouTube"
            actions += { launchLogin(act, false, reqLogin) }
        } else {
            for ((i, a) in accounts.withIndex()) {
                val nm = a.name ?: "Akun ${i + 1}"
                if (a.active) {
                    labels += "$nm, sedang dipakai"
                    actions += { }
                } else {
                    labels += "Pindah ke akun $nm"
                    actions += {
                        if (YtAccount.switchTo(act, a.id)) onChanged("Sekarang memakai akun ${YtAccount.name(act) ?: nm}.")
                        else onChanged("Gagal pindah akun.")
                    }
                }
            }
            labels += "Tambah akun"
            actions += { launchLogin(act, true, reqLogin) }
            labels += "Keluar dari akun ini"
            actions += { confirmLogout(act, onChanged) }
        }
        if (extraLabel != null && extra != null) {
            labels += extraLabel
            actions += extra
        }
        AlertDialog.Builder(act)
            .setTitle("Akun YouTube")
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun launchLogin(act: Activity, add: Boolean, reqLogin: Int) {
        val i = Intent(act, YtLoginActivity::class.java).putExtra(YtLoginActivity.EXTRA_ADD, add)
        if (reqLogin >= 0) act.startActivityForResult(i, reqLogin) else act.startActivity(i)
    }

    private fun confirmLogout(act: Activity, onChanged: (String) -> Unit) {
        AlertDialog.Builder(act)
            .setTitle("Keluar dari akun ini?")
            .setMessage("Hanya akun ini yang keluar. Akun lain tetap tersimpan.")
            .setPositiveButton("Keluar") { _, _ ->
                YtAccount.logout(act)
                onChanged(
                    if (YtAccount.isLoggedIn(act)) "Sudah keluar. Sekarang memakai akun ${YtAccount.name(act) ?: "lain"}."
                    else "Sudah keluar dari akun YouTube."
                )
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
