package id.ytplayer

/**
 * Riwayat putar di sesi ini, dipakai tombol "berikutnya" / "sebelumnya" (notifikasi, layar kunci,
 * headset, dan layar pemutar) serta putar otomatis:
 *  - daftar video yang sudah diputar, agar "berikutnya" tidak bolak-balik ke video yang sama;
 *  - tumpukan "kembali", agar "sebelumnya" membuka video yang diputar sebelumnya.
 */
object PlayedSet {
    private val set = LinkedHashSet<String>()
    private val back = ArrayList<String>()

    @Synchronized
    fun add(url: String) {
        if (url.isEmpty()) return
        if (set.size > 50) set.clear()
        set.add(url)
    }

    @Synchronized
    fun has(url: String): Boolean = url in set

    /** Semua video terkait sudah pernah diputar: mulai daftar dari awal (hanya [keep] yang dianggap sudah diputar). */
    @Synchronized
    fun reset(keep: String) {
        set.clear()
        if (keep.isNotEmpty()) set.add(keep)
    }

    /** Simpan video yang ditinggalkan, supaya "sebelumnya" bisa kembali ke sana. */
    @Synchronized
    fun pushBack(url: String) {
        if (url.isEmpty() || back.lastOrNull() == url) return
        if (back.size >= 50) back.removeAt(0)
        back.add(url)
    }

    @Synchronized
    fun popBack(): String? = if (back.isEmpty()) null else back.removeAt(back.size - 1)

    @Synchronized
    fun hasBack(): Boolean = back.isNotEmpty()
}
