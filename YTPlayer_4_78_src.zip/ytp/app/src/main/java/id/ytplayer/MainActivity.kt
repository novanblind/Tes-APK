package id.ytplayer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.common.util.concurrent.ListenableFuture

/** Beranda bergaya aplikasi video: cari, kategori, daftar kartu video, mini player. */
class MainActivity : Activity() {

    companion object {
        const val EXTRA_QUERY = "query"
        private const val REQ_VOICE = 101
        private const val REC = "@@rekomendasi" // penanda chip Beranda (rekomendasi)
        private const val STALE_MS = 30 * 60_000L // dibuka lagi setelah selama ini: beranda disegarkan
        private const val FAV = "@@favorit" // penanda chip favorit
        private const val SUBS = "@@langganan" // penanda chip Subscription
        private const val SHORTS_Q = "#shorts Indonesia" // pencarian untuk tab Shorts
    }

    private data class Chip(val label: String, val query: String?) // query null = riwayat

    private val ytm: Boolean by lazy { Store.appMode(this) == Store.MODE_YTM }
    private val noun: String get() = if (ytm) "lagu" else "video"

    private val videoChips = listOf(
        Chip("Beranda", REC),
        Chip("Subscription", SUBS),
        Chip("Shorts", SHORTS_Q),
        Chip("Musik", "musik populer Indonesia"),
        Chip("Berita", "berita terkini"),
        Chip("Podcast", "podcast Indonesia"),
        Chip("Game", "gameplay Indonesia"),
        Chip("Belajar", "tutorial belajar"),
        Chip("Ceramah", "kajian ceramah"),
        Chip("Favorit", FAV),
        Chip("Riwayat", null)
    )

    private val musicChips = listOf(
        Chip("Beranda", REC),
        Chip("Populer Indonesia", "lagu populer Indonesia"),
        Chip("Pop", "lagu pop Indonesia"),
        Chip("Dangdut", "lagu dangdut"),
        Chip("Religi", "lagu religi islami"),
        Chip("Barat", "lagu pop barat"),
        Chip("K-pop", "lagu k-pop"),
        Chip("Kenangan", "lagu kenangan Indonesia"),
        Chip("Favorit", FAV),
        Chip("Riwayat", null)
    )

    private val chips: List<Chip> by lazy { if (ytm) musicChips else videoChips }

    /** Filter pencarian YouTube Music (null = pencarian video biasa). */
    private fun filterKey(): String? =
        if (!ytm) null else if (Store.ytmType(this) == 0) "music_songs" else "music_videos"

    private lateinit var searchBox: EditText
    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: VideoAdapter
    private lateinit var chipRow: LinearLayout
    private lateinit var btnCategory: Button
    private lateinit var swAudio: Switch
    private lateinit var btnClear: Button
    private lateinit var subsStrip: View
    private lateinit var subsRow: LinearLayout
    private lateinit var subsLoginBox: View
    private lateinit var ytBar: View
    private lateinit var topBar: View
    private lateinit var searchRow: View
    private lateinit var catRow: View
    private lateinit var subsChips: View
    private lateinit var subsChipRow: LinearLayout
    private var subsFilter = 0 // 0 Semua, 1 Hari ini, 2 Video, 3 Shorts
    private var feedNewest: Map<String, Long> = emptyMap()
    private var subsChannels: List<YtApi.Channel> = emptyList()
    private var feedCache: YtFeed.Result? = null
    private var feedCacheAt = 0L
    private var feedIds = 0
    private lateinit var navHome: Button
    private lateinit var navSubs: Button
    private lateinit var navYou: Button
    private lateinit var navShorts: Button
    private lateinit var youPage: View
    private var youOpen = false          // layar Anda sedang tampil
    private var profileTried = false     // foto/handle akun sudah dicoba diambil
    private var seenLogin = false
    private var seenEpoch = YtAccount.epoch()
    private lateinit var btnRefresh: View
    private lateinit var listWrap: FrameLayout
    private lateinit var swipe: SwipeRefreshLayout

    private lateinit var miniBar: View
    private lateinit var miniOpen: View
    private lateinit var miniTitle: TextView
    private lateinit var miniPlay: Button

    private var session: Repo.SearchSession? = null
    private var searchToken = 0
    private var loadingMore = false
    private var chipIndex = 0
    private var refreshChip = 0      // chip aktif (-1 = hasil pencarian ketik)
    private var lastQuery = ""
    private var dateIdx = 0                 // indeks DateFilter.options (0 = kapan saja)
    private lateinit var btnDate: Button
    private var stoppedAt = 0L
    private var currentLabel = ""

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = updateMini()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        // Pindah YT Player <-> YouTube Musik: tampilan baru dimulai bersih, tanpa memulihkan status lama.
        if (DrawerHelper.switching) return
        super.onSaveInstanceState(outState)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DrawerHelper.switching = false
        // Mode Music Player dipilih: tampilan utama aplikasi adalah pemutar musik.
        if (Store.appMode(this) == Store.MODE_MUSIC) {
            startActivity(DrawerHelper.launchIntent(this, Store.MODE_MUSIC))
            finish()
            return
        }
        setContentView(R.layout.activity_main)
        DrawerHelper.setup(this, if (ytm) Store.MODE_YTM else Store.MODE_YT)
        currentLabel = chips[0].label
        if (ytm) {
            findViewById<TextView>(R.id.appTitle).text = "YouTube Music"
            title = "YouTube Music"
        }
        CrashReport.showIfAny(this)

        searchBox = findViewById(R.id.searchBox)
        status = findViewById(R.id.status)
        list = findViewById(R.id.list)
        chipRow = findViewById(R.id.chipRow)
        btnCategory = findViewById(R.id.btnCategory)
        btnCategory.setOnClickListener { showCategoryDialog() }
        swAudio = findViewById(R.id.swAudioOnly)
        btnClear = findViewById(R.id.btnClear)
        subsStrip = findViewById(R.id.subsStrip)
        subsRow = findViewById(R.id.subsRow)
        subsLoginBox = findViewById(R.id.subsLoginBox)
        ytBar = findViewById(R.id.ytBar)
        topBar = findViewById(R.id.topBar)
        searchRow = findViewById(R.id.searchRow)
        catRow = findViewById(R.id.catRow)
        subsChips = findViewById(R.id.subsChips)
        subsChipRow = findViewById(R.id.subsChipRow)
        ViewCompat.setAccessibilityHeading(findViewById(R.id.barTitle), true)
        findViewById<View>(R.id.btnBarMenu).setOnClickListener { findViewById<View>(R.id.btnMenu).performClick() }
        findViewById<View>(R.id.btnBarRefresh).setOnClickListener { refresh() }
        findViewById<View>(R.id.btnBarSearch).setOnClickListener { openSearchFromSubs() }
        buildSubsChips()
        findViewById<Button>(R.id.btnSubsLogin).setOnClickListener {
            startActivity(Intent(this, YtLoginActivity::class.java))
        }
        findViewById<View>(R.id.btnAllChannels).setOnClickListener {
            startActivity(Intent(this, SubscriptionsActivity::class.java))
        }
        navHome = findViewById(R.id.navHome)
        navSubs = findViewById(R.id.navSubs)
        navYou = findViewById(R.id.navYou)
        navShorts = findViewById(R.id.navShorts)
        youPage = findViewById(R.id.youPage)
        seenLogin = YtAccount.isLoggedIn(this)
        if (ytm) {
            findViewById<View>(R.id.bottomNav).visibility = View.GONE
        } else {
            navHome.setOnClickListener { onNavTap(0) }
            navShorts.setOnClickListener { startActivity(Intent(this, ShortsActivity::class.java)) }
            navSubs.setOnClickListener { onNavTap(navIndex(SUBS)) }
            navYou.setOnClickListener { if (youOpen) youPage.scrollTo(0, 0) else showYouPage() }
            setupYouPage()
        }
        btnDate = findViewById(R.id.btnDate)
        btnRefresh = findViewById(R.id.btnRefresh)
        listWrap = findViewById(R.id.listWrap)
        swipe = findViewById(R.id.swipe)
        swipe.setOnRefreshListener { refresh() }
        miniBar = findViewById(R.id.miniBar)
        miniOpen = findViewById(R.id.miniOpen)
        miniTitle = findViewById(R.id.miniTitle)
        miniPlay = findViewById(R.id.miniPlay)

        ViewCompat.setAccessibilityHeading(findViewById(R.id.appTitle), true)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        adapter = VideoAdapter(
            onOpen = { item, audio -> openVideo(item, audio) },
            onRemove = { item ->
                Store.removeHistory(this, item.url)
                adapter.remove(item)
                Toast.makeText(this, "Dihapus dari riwayat", Toast.LENGTH_SHORT).show()
            }
        )
        val lm = LinearLayoutManager(this)
        list.layoutManager = lm
        list.adapter = adapter
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                val s = session ?: return
                if (dy > 0 && !loadingMore && !s.loading && s.hasMore &&
                    lm.findLastVisibleItemPosition() >= adapter.itemCount - 10
                ) {
                    loadingMore = true
                    Repo.loadMore(
                        s,
                        onChunk = { items -> if (s === session) adapter.add(items) },
                        onDone = { loadingMore = false }
                    )
                }
            }
        })

        findViewById<View>(R.id.searchBtn).setOnClickListener { submitSearch() }
        findViewById<View>(R.id.voiceBtn).setOnClickListener { startVoiceSearch() }
        searchBox.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                submitSearch(); true
            } else false
        }

        swAudio.isChecked = Store.audioOnly(this)
        swAudio.setOnCheckedChangeListener { _, checked -> Store.setAudioOnly(this, checked) }

        btnRefresh.setOnClickListener { refresh() }
        btnDate.setOnClickListener { showDateDialog() }
        updateDateButton()

        // TalkBack: usap dua jari ke bawah (gulir ke atas) saat daftar sudah di paling atas = segarkan.
        ViewCompat.setAccessibilityDelegate(listWrap, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                if (!list.canScrollVertically(-1)) {
                    info.addAction(AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_SCROLL_BACKWARD)
                    info.isScrollable = true
                }
            }

            override fun performAccessibilityAction(host: View, action: Int, args: Bundle?): Boolean {
                if (action == AccessibilityNodeInfoCompat.ACTION_SCROLL_BACKWARD && !list.canScrollVertically(-1)) {
                    refresh()
                    return true
                }
                return super.performAccessibilityAction(host, action, args)
            }
        })

        btnClear.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Hapus riwayat (tidak bisa dikembalikan)")
                .setItems(
                    arrayOf(
                        "Hapus riwayat tontonan",
                        "Hapus riwayat pencarian",
                        "Hapus semuanya"
                    )
                ) { _, which ->
                    if (which == 0 || which == 2) Store.clearHistory(this)
                    if (which == 1 || which == 2) Store.clearSearches(this)
                    Toast.makeText(this, "Riwayat dihapus", Toast.LENGTH_SHORT).show()
                    showHistory()
                }
                .setNegativeButton("Batal", null)
                .show()
        }

        buildChips()
        selectChip(0)
        handleIntent(intent)

        miniOpen.setOnClickListener { openCurrentPlayer() }
        miniPlay.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.playWhenReady && c.playbackState != Player.STATE_ENDED) c.pause()
            else {
                if (c.playbackState == Player.STATE_ENDED) c.seekTo(0)
                c.play()
            }
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (DrawerHelper.closeIfOpen(this)) return
        // Seperti YouTube asli: dari tab atau hasil pencarian mana pun, Kembali = ke Beranda;
        // baru dari Beranda Kembali keluar dari aplikasi.
        if (goBackToHome()) return
        super.onBackPressed()
    }

    /** True bila sedang di Beranda (bukan layar Anda, tab lain, atau hasil pencarian). */
    private fun atHome(): Boolean = !youOpen && refreshChip == 0

    /** Dari mana pun selain Beranda: kembali ke Beranda. False bila sudah di Beranda. */
    private fun goBackToHome(): Boolean {
        if (atHome()) return false
        if (youOpen) onNavTap(0) else selectChip(0)
        return true
    }

    // Android 13 ke atas (target 36): onBackPressed() tidak dipanggil lagi, jadi tombol Kembali
    // didaftarkan lewat BackApi33, aktif hanya bila bukan di Beranda. Android 12 ke bawah tetap
    // memakai onBackPressed() di atas dan tidak menyentuh kelas Android 13.
    private var back33: Any? = null

    private fun syncBackCallback() {
        if (Build.VERSION.SDK_INT < 33) return
        syncBack33(!atHome())
    }

    @androidx.annotation.RequiresApi(33)
    private fun syncBack33(need: Boolean) {
        val h = (back33 as? BackApi33) ?: BackApi33 {
            if (!goBackToHome()) {
                (back33 as? BackApi33)?.unregister(this)
                finish()
            }
        }.also { back33 = it }
        if (need) h.register(this) else h.unregister(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Dibuka dari halaman tonton ("Video lain dari channel ini"): langsung cari nama channelnya. */
    private fun handleIntent(i: Intent?) {
        val q = i?.getStringExtra(EXTRA_QUERY)?.trim().orEmpty()
        if (q.isNotEmpty()) {
            i?.removeExtra(EXTRA_QUERY)
            searchBox.setText(q)
            submitSearch()
        }
    }

    /** Muat ulang tampilan yang sedang aktif (kategori, favorit, riwayat, atau hasil pencarian). */
    private fun refresh() {
        swipe.isRefreshing = true
        if (refreshChip >= 0) selectChip(refreshChip)
        else if (lastQuery.isNotEmpty()) runQuery(lastQuery)
        else swipe.isRefreshing = false
        list.scrollToPosition(0)
    }

    private fun endRefresh() {
        swipe.isRefreshing = false
    }

    override fun onStart() {
        super.onStart()
        // Seperti YouTube: dibuka lagi setelah lama ditinggalkan = beranda dimuat ulang dari atas;
        // sebentar saja = tampilan dan posisi gulir dipertahankan. Daftar lokal (favorit, riwayat)
        // selalu diperbarui karena isinya berubah setelah menonton.
        if (stoppedAt > 0 && refreshChip >= 0 && !youOpen) {
            val q = chips[refreshChip].query
            if (SystemClock.elapsedRealtime() - stoppedAt > STALE_MS) {
                refresh()
            } else if (q == null) showHistory()
            else if (q == FAV) showFavorites()
        }
        val li = YtAccount.isLoggedIn(this)
        if (li != seenLogin || YtAccount.epoch() != seenEpoch) {
            seenLogin = li
            seenEpoch = YtAccount.epoch()
            profileTried = false
            feedCache = null
            subsChannels = emptyList()
            if (li && YtAccount.name(this) == null) Thread { YtApi.checkStatus(this) }.start()
            if (chips.getOrNull(refreshChip)?.query == SUBS) selectChip(refreshChip)
        }
        if (youOpen) refreshYouPage()
        swAudio.isChecked = Store.audioOnly(this)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        controllerFuture = f
        f.addListener({
            try {
                controller = f.get().also { it.addListener(playerListener) }
                updateMini()
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        stoppedAt = SystemClock.elapsedRealtime()
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        super.onStop()
        DrawerHelper.finishIfLeaving(this)
    }

    // ------------------------------------------------------------------ pencarian

    // ------------------------------------------------------------------ filter tanggal unggah

    private fun maxAge(): Long = if (ytm) 0L else DateFilter.options[dateIdx].maxAgeSec

    private fun dateLabel(): String = DateFilter.options[dateIdx].label

    private fun typeLabel(): String = if (Store.ytmType(this) == 0) "Lagu" else "Video musik"

    private fun updateDateButton() {
        val label = dateLabel()
        if (ytm) {
            btnDate.text = "Jenis hasil: ${typeLabel()}"
            btnDate.contentDescription = "Jenis hasil pencarian, sekarang ${typeLabel()}. Ketuk untuk mengubah"
        } else {
            btnDate.text = "Tanggal unggah: $label"
            btnDate.contentDescription = "Filter tanggal unggah, sekarang $label. Ketuk untuk mengubah"
        }
        // Favorit dan riwayat adalah daftar lokal: filter tanggal / jenis hasil tidak berlaku di sana.
        val local = refreshChip >= 0 && chips[refreshChip].query.let { it == null || it == FAV }
        btnDate.visibility = if (local) View.GONE else View.VISIBLE
    }

    /** Mode YouTube Music: pilih jenis hasil, lagu atau video musik (klip resmi). */
    private fun showTypeDialog() {
        val labels = arrayOf("Lagu", "Video musik")
        AlertDialog.Builder(this)
            .setTitle("Jenis hasil")
            .setSingleChoiceItems(labels, Store.ytmType(this)) { dialog, which ->
                dialog.dismiss()
                if (which != Store.ytmType(this)) {
                    Store.setYtmType(this, which)
                    updateDateButton()
                    reloadCurrent()
                    list.announceForAccessibility("Jenis hasil ${typeLabel()}")
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showDateDialog() {
        if (ytm) { showTypeDialog(); return }
        val labels = DateFilter.options.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tanggal unggah")
            .setSingleChoiceItems(labels, dateIdx) { dialog, which ->
                dialog.dismiss()
                if (which != dateIdx) {
                    dateIdx = which
                    updateDateButton()
                    reloadCurrent()
                    list.announceForAccessibility("Filter ${dateLabel()}")
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Muat ulang tampilan yang sedang aktif memakai filter tanggal yang baru. */
    private fun reloadCurrent() {
        if (refreshChip >= 0) selectChip(refreshChip)
        else if (lastQuery.isNotEmpty()) runQuery(lastQuery)
    }

    private fun filterNote(): String = if (maxAge() > 0) " (${dateLabel().lowercase()})" else ""

    private fun buildChips() {
        val dp = resources.displayMetrics.density
        chips.forEachIndexed { i, chip ->
            val b = Button(this).apply {
                text = chip.label
                isAllCaps = false
                textSize = 16f
                setBackgroundResource(R.drawable.chip_bg)
                setTextColor(ContextCompat.getColorStateList(this@MainActivity, R.color.chip_text))
                minHeight = (48 * dp).toInt()
                minimumHeight = (48 * dp).toInt()
                minWidth = (64 * dp).toInt()
                setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), 0)
                contentDescription = "Kategori ${chip.label}"
                setOnClickListener { onChipTap(i) }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = (8 * dp).toInt()
            lp.topMargin = (4 * dp).toInt()
            lp.bottomMargin = (4 * dp).toInt()
            chipRow.addView(b, lp)
        }
    }

    private fun updateCategoryButton(label: String) {
        btnCategory.text = "Kategori: $label  ▾"
        btnCategory.contentDescription = "Kategori: $label. Ketuk untuk mengganti kategori"
    }

    /** Semua kategori dalam satu daftar; memilih kategori yang sedang aktif = ke atas / segarkan. */
    private fun showCategoryDialog() {
        val names = chips.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih kategori")
            .setSingleChoiceItems(names, refreshChip) { d, which ->
                d.dismiss()
                onChipTap(which)
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    /** Seperti tab Beranda YouTube: ketuk sekali = ke atas, ketuk lagi di atas = segarkan. */
    private fun onChipTap(i: Int) {
        if (i == refreshChip) {
            if (list.canScrollVertically(-1)) {
                list.scrollToPosition(0)
                list.announceForAccessibility("Kembali ke atas")
            } else refresh()
        } else selectChip(i)
    }

    private fun selectChip(index: Int) {
        chipIndex = index
        refreshChip = index
        for (i in 0 until chipRow.childCount) {
            val v = chipRow.getChildAt(i)
            v.isSelected = i == index
            ViewCompat.setStateDescription(v, if (i == index) "Terpilih" else "Tidak terpilih")
        }
        val chip = chips[index]
        currentLabel = chip.label
        updateNav(chip.query)
        updateCategoryButton(chip.label)
        updateDateButton()
        val q = chip.query
        when {
            q == null -> showHistory()
            q == FAV -> showFavorites()
            q == REC -> showRecommendations()
            q == SUBS -> showSubscriptions()
            else -> runQuery(q)
        }
    }

    private fun setNavSelected(home: Boolean, shorts: Boolean, subs: Boolean, you: Boolean) {
        navHome.isSelected = home
        navShorts.isSelected = shorts
        navSubs.isSelected = subs
        navYou.isSelected = you
        for (b in listOf(navHome, navShorts, navSubs, navYou)) {
            ViewCompat.setStateDescription(b, if (b.isSelected) "Terpilih" else "Tidak terpilih")
        }
    }

    /** Menyorot tab bawah yang aktif dan menampilkan tombol daftar channel hanya di tab Subscription. */
    private fun updateNav(q: String?) {
        if (!::navHome.isInitialized) return
        // Memilih tampilan apa pun menutup layar Anda dan mengembalikan daftar video.
        youOpen = false
        youPage.visibility = View.GONE
        listWrap.visibility = View.VISIBLE
        status.visibility = View.VISIBLE
        setNavSelected(q == REC, q == SHORTS_Q, q == SUBS, false)
        val subs = q == SUBS
        subsStrip.visibility = if (subs) View.VISIBLE else View.GONE
        subsChips.visibility = if (subs) View.VISIBLE else View.GONE
        subsLoginBox.visibility = View.GONE
        // Tab Subscription memakai bilah atas ala YouTube; tab lain memakai bilah biasa.
        ytBar.visibility = if (subs) View.VISIBLE else View.GONE
        topBar.visibility = if (subs) View.GONE else View.VISIBLE
        searchRow.visibility = if (subs) View.GONE else View.VISIBLE
        catRow.visibility = if (subs) View.GONE else View.VISIBLE
        swAudio.visibility = if (subs) View.GONE else View.VISIBLE
        syncBackCallback()
    }

    // ------------------------------------------------------------------ layar Anda

    private fun navIndex(q: String): Int = chips.indexOfFirst { it.query == q }

    /** Ketuk tab bawah. Dari layar Anda, tab yang sama dengan tampilan sebelumnya hanya menutup layar Anda. */
    private fun onNavTap(i: Int) {
        if (i < 0) return
        if (youOpen) {
            if (i == refreshChip) leaveYou() else selectChip(i)
        } else onChipTap(i)
    }

    /** Kembali dari layar Anda ke tampilan sebelumnya tanpa memuat ulang daftar yang masih segar. */
    private fun leaveYou() {
        if (refreshChip >= 0) {
            val q = chips[refreshChip].query
            // Subscription memakai umpan yang tersimpan; favorit dan riwayat dibaca ulang karena bisa berubah.
            if (q == SUBS || q == FAV || q == null) {
                selectChip(refreshChip)
                return
            }
        }
        updateNav(if (refreshChip >= 0) chips[refreshChip].query else "@@hasil")
    }

    /** Memberi peran "Tombol" pada tampilan yang bisa diketuk agar TalkBack membacakannya sebagai tombol. */
    private fun asButton(v: View) {
        ViewCompat.setAccessibilityDelegate(v, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.className = Button::class.java.name
            }
        })
    }

    private fun setupYouPage() {
        val akun = findViewById<View>(R.id.youAkun)
        asButton(akun)
        akun.setOnClickListener { showAccountMenu() }
        findViewById<View>(R.id.youBell).setOnClickListener { onNavTap(navIndex(SUBS)) }
        findViewById<View>(R.id.youSearch).setOnClickListener { openSearchFromSubs() }
        findViewById<View>(R.id.youSettings).setOnClickListener {
            startActivity(Intent(this, AppSettingsActivity::class.java))
        }
        findViewById<View>(R.id.youBtnPremium).setOnClickListener { openWeb("https://www.youtube.com/premium") }
        val header = findViewById<View>(R.id.youHistoryHeader)
        ViewCompat.setAccessibilityHeading(header, true)
        header.setOnClickListener { onNavTap(chips.indexOfFirst { it.query == null }) }
        ViewCompat.setAccessibilityHeading(findViewById(R.id.youCollectionsTitle), true)
    }

    /** Layar Anda ala YouTube: akun, Histori (gulir ke samping), dan Koleksi. */
    private fun showYouPage() {
        youOpen = true
        endRefresh()
        val hide = listOf(
            ytBar, topBar, searchRow, catRow, swAudio, status, btnClear,
            subsStrip, subsChips, subsLoginBox, listWrap
        )
        for (v in hide) v.visibility = View.GONE
        youPage.visibility = View.VISIBLE
        setNavSelected(false, false, false, true)
        youPage.scrollTo(0, 0)
        refreshYouPage()
        youPage.announceForAccessibility("Anda")
        syncBackCallback()
    }

    private fun refreshYouPage() {
        val logged = YtAccount.isLoggedIn(this)
        val name = if (logged) YtAccount.name(this) else null
        val handle = if (logged) YtAccount.handle(this)?.trim()?.takeIf { it.isNotEmpty() } else null
        val photo = if (logged) YtAccount.photo(this) else null

        // Nama, handle, dan foto belum ada: ambil dari akun sekali, lalu gambar ulang.
        if (logged && !profileTried && (name == null || photo == null)) {
            profileTried = true
            Thread {
                YtApi.checkStatus(this)
                runOnUiThread { if (!isFinishing && !isDestroyed && youOpen) refreshYouPage() }
            }.start()
        }

        findViewById<TextView>(R.id.youName).text = if (!logged) "Belum masuk" else name ?: "Akun YouTube"
        findViewById<TextView>(R.id.youHandle).apply {
            val t = if (!logged) "Masuk untuk melihat video dari channel yang Anda subscribe" else handle
            text = t.orEmpty()
            visibility = if (t.isNullOrEmpty()) View.GONE else View.VISIBLE
        }
        findViewById<ImageView>(R.id.youAvatar).apply {
            if (photo != null) {
                setPadding(0, 0, 0, 0)
                ImageLoader.load(this, photo)
            } else {
                tag = null
                setPadding(dpi(8), dpi(8), dpi(8), dpi(8))
                setImageResource(R.drawable.ic_nav_you)
            }
        }

        findViewById<Button>(R.id.youBtnChannel).apply {
            text = if (logged) "Lihat channel" else "Masuk akun YouTube"
            contentDescription = if (logged) "Lihat channel Anda. Dibuka di peramban" else "Masuk akun YouTube"
            setOnClickListener {
                if (!logged) startActivity(Intent(this@MainActivity, YtLoginActivity::class.java))
                else openWeb(
                    if (handle != null) "https://www.youtube.com/" + (if (handle.startsWith("@")) handle else "@$handle")
                    else "https://www.youtube.com/account"
                )
            }
        }

        // Histori: kartu gulir ke samping, yang terbaru di depan.
        val hist = Store.history(this)
        val row = findViewById<LinearLayout>(R.id.youHistoryRow)
        row.removeAllViews()
        for (item in hist.take(12)) row.addView(buildHistoryCard(row, item, hist))
        findViewById<View>(R.id.youHistoryScroll).visibility = if (hist.isEmpty()) View.GONE else View.VISIBLE
        findViewById<View>(R.id.youHistoryEmpty).visibility = if (hist.isEmpty()) View.VISIBLE else View.GONE

        // Koleksi
        val cols = findViewById<LinearLayout>(R.id.youCollections)
        cols.removeAllViews()
        val favs = Store.favorites(this)
        addCollectionRow(
            cols, "Video yang disukai",
            if (favs.isEmpty()) "Pribadi" else "Pribadi • ${favs.size} video",
            "Video yang disukai. ${if (favs.isEmpty()) "Belum ada" else "${favs.size} video"}. Pribadi. Buka favorit",
            R.drawable.ic_thumb_up, favs.firstOrNull()?.thumb
        ) { onNavTap(chips.indexOfFirst { it.query == FAV }) }
        addCollectionRow(
            cols, "Unduhan", "Di perangkat ini",
            "Unduhan. Di perangkat ini. Buka daftar unduhan",
            R.drawable.ic_download, null
        ) { startActivity(Intent(this, DownloadsActivity::class.java)) }
        val nSubs = YtAccount.subs(this).size
        addCollectionRow(
            cols, "Channel yang di-subscribe",
            if (!logged) "Masuk untuk melihat" else if (nSubs > 0) "$nSubs channel" else "Daftar channel",
            "Channel yang di-subscribe. ${if (!logged) "Belum masuk akun" else if (nSubs > 0) "$nSubs channel" else "Buka daftar channel"}",
            R.drawable.ic_nav_subs, null
        ) { startActivity(Intent(this, SubscriptionsActivity::class.java)) }
    }

    private fun buildHistoryCard(parent: ViewGroup, item: VideoItem, queue: List<VideoItem>): View {
        val v = layoutInflater.inflate(R.layout.item_history_card, parent, false)
        ImageLoader.load(v.findViewById(R.id.histThumb), item.thumb)
        v.findViewById<TextView>(R.id.histDuration).apply {
            if (item.isLive) {
                text = "LANGSUNG"
                visibility = View.VISIBLE
            } else if (item.durationSec > 0) {
                text = Fmt.clock(item.durationSec)
                visibility = View.VISIBLE
            } else visibility = View.GONE
        }
        v.findViewById<TextView>(R.id.histTitle).text = item.title
        v.findViewById<TextView>(R.id.histMeta).text = item.uploader
        v.contentDescription = item.spoken()
        asButton(v)
        v.setOnClickListener { openVideo(item, null, queue) }
        v.setOnLongClickListener { openVideo(item, true, queue); true }
        // Aksi khusus TalkBack, sama seperti kartu video di Beranda.
        ViewCompat.addAccessibilityAction(v, getString(R.string.action_play_audio)) { _, _ -> openVideo(item, true, queue); true }
        ViewCompat.addAccessibilityAction(v, getString(R.string.action_play_video)) { _, _ -> openVideo(item, false, queue); true }
        ViewCompat.addAccessibilityAction(v, "Hapus dari riwayat") { _, _ -> removeFromHistory(item); true }
        v.findViewById<View>(R.id.histMore).apply {
            contentDescription = "Opsi untuk ${item.title}"
            setOnClickListener { showHistoryOptions(item, queue) }
        }
        return v
    }

    private fun showHistoryOptions(item: VideoItem, queue: List<VideoItem>) {
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setItems(
                arrayOf(getString(R.string.action_play_video), getString(R.string.action_play_audio), "Hapus dari riwayat")
            ) { _, which ->
                when (which) {
                    0 -> openVideo(item, false, queue)
                    1 -> openVideo(item, true, queue)
                    2 -> removeFromHistory(item)
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun removeFromHistory(item: VideoItem) {
        Store.removeHistory(this, item.url)
        refreshYouPage()
        Toast.makeText(this, "Dihapus dari riwayat", Toast.LENGTH_SHORT).show()
    }

    private fun addCollectionRow(
        parent: LinearLayout, title: String, sub: String, desc: String,
        badge: Int, thumb: String?, onClick: () -> Unit
    ) {
        val v = layoutInflater.inflate(R.layout.item_collection, parent, false)
        v.findViewById<TextView>(R.id.colTitle).text = title
        v.findViewById<TextView>(R.id.colSub).text = sub
        v.findViewById<ImageView>(R.id.colBadgeIcon).setImageResource(badge)
        val center = v.findViewById<ImageView>(R.id.colCenterIcon)
        ImageLoader.load(v.findViewById(R.id.colThumb), thumb)
        if (thumb.isNullOrEmpty()) {
            center.setImageResource(badge)
            center.visibility = View.VISIBLE
        } else center.visibility = View.GONE
        v.contentDescription = desc
        asButton(v)
        v.setOnClickListener { onClick() }
        parent.addView(v)
    }

    /** Tombol Akun: pindah, tambah, atau keluar akun YouTube, dan membuka menu aplikasi (YT Player, Music Player). */
    private fun showAccountMenu() {
        AccountDialog.show(
            this, -1,
            "Menu aplikasi: YT Player, YouTube Music, Music Player",
            { findViewById<View>(R.id.btnMenu).performClick() }
        ) { msg -> afterAccountChange(msg) }
    }

    private fun afterAccountChange(msg: String) {
        seenLogin = YtAccount.isLoggedIn(this)
        seenEpoch = YtAccount.epoch()
        profileTried = false
        feedCache = null
        subsChannels = emptyList()
        status.text = msg
        if (seenLogin && YtAccount.name(this) == null) Thread { YtApi.checkStatus(this) }.start()
        if (youOpen) refreshYouPage()
        else if (chips.getOrNull(refreshChip)?.query == SUBS) selectChip(refreshChip)
    }

    private fun openWeb(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Tidak ada peramban untuk membuka tautan ini", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dpi(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Baris channel ala YouTube: foto bulat + nama; titik biru bila ada video baru, yang baru di depan. */
    private fun renderStrip() {
        subsRow.removeAllViews()
        val ordered = subsChannels.sortedByDescending { feedNewest[it.id] ?: 0L }
        for (ch in ordered) {
            val newest = feedNewest[ch.id] ?: 0L
            val hasNew = newest > YtAccount.seenAt(this, ch.id)
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER_HORIZONTAL
                setPadding(dpi(6), dpi(4), dpi(6), dpi(4))
                isClickable = true
                isFocusable = true
                contentDescription =
                    if (hasNew) "Channel ${ch.title}, ada video baru. Buka channel" else "Channel ${ch.title}. Buka channel"
            }
            val box = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpi(64), dpi(64))
            }
            val img = android.widget.ImageView(this).apply {
                scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0x33888888)
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(v: View, o: android.graphics.Outline) { o.setOval(0, 0, v.width, v.height) }
                }
                clipToOutline = true
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            box.addView(img, FrameLayout.LayoutParams(dpi(64), dpi(64)))
            ImageLoader.load(img, ch.thumb)
            val dot = View(this).apply {
                setBackgroundResource(R.drawable.dot_new)
                visibility = if (hasNew) View.VISIBLE else View.GONE
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            box.addView(
                dot,
                FrameLayout.LayoutParams(dpi(16), dpi(16), android.view.Gravity.BOTTOM or android.view.Gravity.END)
            )
            val tv = TextView(this).apply {
                text = ch.title
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                textSize = 12f
                gravity = android.view.Gravity.CENTER
                setTextColor(getColor(R.color.text))
                setPadding(0, dpi(4), 0, 0)
                layoutParams = LinearLayout.LayoutParams(dpi(72), ViewGroup.LayoutParams.WRAP_CONTENT)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            col.addView(box)
            col.addView(tv)
            col.setOnClickListener {
                if (newest > 0L) YtAccount.markSeen(this@MainActivity, ch.id, newest)
                dot.visibility = View.GONE
                col.contentDescription = "Channel ${ch.title}. Buka channel"
                startActivity(ChannelActivity.intent(this@MainActivity, ch.id, ch.title))
            }
            subsRow.addView(col)
        }
    }

    // ---- chip filter tab Subscription (Semua, Hari ini, Video, Shorts)

    private val subsChipLabels = listOf("Semua", "Hari ini", "Video", "Shorts")

    private fun buildSubsChips() {
        subsChipLabels.forEachIndexed { i, label ->
            val b = Button(this).apply {
                text = label
                isAllCaps = false
                textSize = 14f
                setBackgroundResource(R.drawable.chip_yt_bg)
                setTextColor(ContextCompat.getColorStateList(this@MainActivity, R.color.chip_text))
                minHeight = dpi(40)
                minimumHeight = dpi(40)
                minWidth = dpi(48)
                setPadding(dpi(14), 0, dpi(14), 0)
                isSelected = i == subsFilter
                ViewCompat.setStateDescription(this, if (isSelected) "Terpilih" else "Tidak terpilih")
                contentDescription = "Filter $label"
                setOnClickListener { selectSubsFilter(i) }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dpi(40))
            lp.marginEnd = dpi(8)
            lp.topMargin = dpi(4)
            lp.bottomMargin = dpi(4)
            subsChipRow.addView(b, lp)
        }
    }

    private fun selectSubsFilter(i: Int) {
        if (i == subsFilter) return
        subsFilter = i
        for (k in 0 until subsChipRow.childCount) {
            val v = subsChipRow.getChildAt(k)
            v.isSelected = k == i
            ViewCompat.setStateDescription(v, if (k == i) "Terpilih" else "Tidak terpilih")
        }
        feedCache?.let { applyFeed(it) }
        list.scrollToPosition(0)
    }

    private fun subsFilterMatches(v: VideoItem): Boolean = when (subsFilter) {
        1 -> {
            val age = if (v.publishedAt > 0L) System.currentTimeMillis() / 1000 - v.publishedAt else Fmt.ageSeconds(v.date)
            age in 0..86400L
        }
        2 -> !v.isShort
        3 -> v.isShort
        else -> true
    }

    /** Ikon cari di bilah atas Subscription: pindah ke Beranda dan buka kotak cari. */
    private fun openSearchFromSubs() {
        selectChip(0)
        searchBox.post {
            searchBox.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun applyFeed(res: YtFeed.Result) {
        val shown = res.items.filter { subsFilterMatches(it) }
        adapter.set(shown)
        val note = when (subsFilter) {
            1 -> " (hari ini)"
            2 -> " (video, tanpa Shorts)"
            3 -> " (Shorts)"
            else -> ""
        }
        status.text = if (shown.isEmpty()) "Tidak ada video$note dari $feedIds channel."
        else "${shown.size} video terbaru dari ${res.channels} channel$note" +
            (if (res.failed > 0) ", ${res.failed} channel gagal dimuat" else "") + "."
    }

    /** Tab Subscription: baris channel + video terbaru dari channel yang di-subscribe (RSS tiap channel). */
    private fun showSubscriptions() {
        val token = ++searchToken
        session?.cancelled = true
        session = null
        btnClear.visibility = View.GONE
        if (!YtAccount.isLoggedIn(this)) {
            endRefresh()
            adapter.set(emptyList())
            subsChannels = emptyList()
            renderStrip()
            subsStrip.visibility = View.GONE
            subsChips.visibility = View.GONE
            subsLoginBox.visibility = View.VISIBLE
            // Pesan sudah ada di kotak masuk (subsLoginMsg); sembunyikan agar tidak dobel.
            status.text = ""
            status.visibility = View.GONE
            return
        }
        // Ganti filter tanggal tidak perlu mengunduh ulang: pakai umpan yang baru dimuat (5 menit).
        val cached = feedCache
        if (!swipe.isRefreshing && cached != null && SystemClock.elapsedRealtime() - feedCacheAt < 5 * 60_000L) {
            endRefresh()
            feedNewest = cached.newest
            renderStrip()
            applyFeed(cached)
            return
        }
        if (!swipe.isRefreshing) adapter.set(emptyList())
        status.text = "Memuat video terbaru dari channel yang Anda subscribe."
        Thread {
            val lr = YtApi.listSubscriptions(this)
            val ids = if (lr is YtApi.ListResult.Ok) lr.channels.map { it.id } else YtAccount.subs(this).toList()
            val feed = if (ids.isEmpty()) null else YtFeed.load(ids)
            runOnUiThread {
                if (token != searchToken || isFinishing || isDestroyed) return@runOnUiThread
                endRefresh()
                feedNewest = feed?.newest ?: emptyMap()
                if (lr is YtApi.ListResult.Ok) {
                    subsChannels = lr.channels
                    renderStrip()
                }
                if (feed == null) {
                    adapter.set(emptyList())
                    status.text = when (lr) {
                        YtApi.ListResult.Invalid -> "Sesi akun tidak sah atau kedaluwarsa. Ketuk Anda, Keluar, lalu masuk lagi."
                        is YtApi.ListResult.Error -> "Gagal memuat daftar channel: ${lr.message}. Periksa sambungan internet."
                        else -> "Belum ada channel yang di-subscribe, atau daftar channel belum dikenali."
                    }
                } else {
                    feedCache = feed
                    feedCacheAt = SystemClock.elapsedRealtime()
                    feedIds = ids.size
                    applyFeed(feed)
                    fillFeedDurations(feed, token)
                }
            }
        }.start()
    }

    /**
     * RSS tidak memuat durasi. Setelah umpan tampil, durasi dilengkapi dari halaman channel (youtubei)
     * untuk channel video teratas saja, bertahap dan di latar belakang. Gagal = daftar tetap tampil apa adanya.
     */
    private fun fillFeedDurations(feed: YtFeed.Result, token: Int) {
        val chIds = feed.items.asSequence()
            .filter { !it.isShort && it.durationSec == 0L }
            .map { it.channelId }.filter { it.isNotEmpty() }
            .distinct().take(24).toList()
        if (chIds.isEmpty()) return
        Thread {
            val durations = java.util.concurrent.ConcurrentHashMap<String, VideoItem>()
            val pool = java.util.concurrent.Executors.newFixedThreadPool(3)
            try {
                val futures = chIds.map { cid ->
                    pool.submit(Runnable {
                        val d = YtChannel.details(this, cid)
                        if (d.isEmpty()) return@Runnable
                        durations.putAll(d)
                        if (token != searchToken) return@Runnable
                        runOnUiThread { mergeFeedDurations(token, durations) }
                    })
                }
                for (f in futures) try { f.get() } catch (_: Exception) { }
            } finally {
                pool.shutdown()
            }
        }.start()
    }

    private fun mergeFeedDurations(token: Int, extra: Map<String, VideoItem>) {
        if (token != searchToken || isFinishing || isDestroyed) return
        val cur = feedCache ?: return
        var changed = false
        val merged = cur.items.map { v ->
            if (v.durationSec != 0L) return@map v
            val d = extra[v.url] ?: return@map v
            if (d.durationSec == 0L) return@map v
            changed = true
            v.copy(durationSec = d.durationSec)
        }
        if (!changed) return
        val res = YtFeed.Result(merged, cur.channels, cur.failed, cur.newest)
        feedCache = res
        val shown = res.items.filter { subsFilterMatches(it) }
        adapter.set(shown)
    }

    private fun submitSearch() {
        val q = searchBox.text.toString().trim()
        if (q.isEmpty()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(searchBox.windowToken, 0)
        for (i in 0 until chipRow.childCount) {
            chipRow.getChildAt(i).isSelected = false
            ViewCompat.setStateDescription(chipRow.getChildAt(i), "Tidak terpilih")
        }
        Store.addSearch(this, q)
        currentLabel = "\"$q\""
        updateCategoryButton("Hasil pencarian")
        refreshChip = -1
        syncBackCallback()
        lastQuery = q
        updateDateButton()
        runQuery(q)
    }

    /** Penelusuran suara: memakai pengenal ucapan bawaan perangkat, hasilnya langsung dicari. */
    private fun startVoiceSearch() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_prompt))
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        try {
            startActivityForResult(i, REQ_VOICE)
        } catch (_: ActivityNotFoundException) {
            status.text = getString(R.string.voice_unavailable)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_VOICE || resultCode != RESULT_OK) return
        val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()?.trim().orEmpty()
        if (text.isEmpty()) {
            status.text = getString(R.string.voice_no_result)
            return
        }
        searchBox.setText(text)
        searchBox.setSelection(text.length)
        submitSearch()
    }

    private fun showFavorites() {
        endRefresh()
        searchToken++
        session?.cancelled = true
        session = null
        btnClear.visibility = View.GONE
        val f = Store.favorites(this)
        adapter.set(f)
        status.text = if (f.isEmpty())
            "Belum ada favorit. Buka sebuah $noun lalu pilih Tambah ke favorit."
        else "${f.size} $noun favorit"
    }

    private fun showHistory() {
        endRefresh()
        searchToken++
        session?.cancelled = true
        session = null
        val h = Store.history(this)
        btnClear.visibility = if (h.isEmpty()) View.GONE else View.VISIBLE
        adapter.set(h, removable = true)
        status.text = if (h.isEmpty()) "Riwayat masih kosong" else "${h.size} $noun di riwayat"
    }

    /** Beranda: rekomendasi dari riwayat tontonan dan pencarian (video populer bila belum ada riwayat). */
    private fun showRecommendations() {
        val token = ++searchToken
        session?.cancelled = true
        session = null
        btnClear.visibility = View.GONE
        if (!swipe.isRefreshing) adapter.set(emptyList())
        status.text = getString(R.string.loading)
        var got = 0
        Repo.recommend(
            this, maxAge(),
            onChunk = { chunk ->
                if (token == searchToken) {
                    if (got == 0) {
                        endRefresh()
                        adapter.set(chunk)
                        list.scrollToPosition(0)
                        status.text = "${chunk.size} $noun pertama tampil, memuat $noun lainnya…"
                    } else adapter.add(chunk)
                    got += chunk.size
                }
            },
            onDone = { personal, err ->
                if (token == searchToken) {
                    endRefresh()
                    if (got == 0) {
                        status.text = err ?: if (maxAge() > 0) "Tidak ada video untuk filter ${dateLabel().lowercase()}" else "Belum ada rekomendasi"
                    } else {
                        val n = adapter.itemCount
                        status.text = if (personal) "$n $noun rekomendasi untuk Anda${filterNote()}, berdasarkan riwayat dan pencarian"
                        else "$n $noun populer${filterNote()}. Rekomendasi akan menyesuaikan setelah Anda memutar atau mencari."
                    }
                }
            },
            filter = filterKey()
        )
    }

    private fun runQuery(query: String) {
        updateNav(if (query == SHORTS_Q) SHORTS_Q else "@@hasil")
        val token = ++searchToken
        session?.cancelled = true
        session = null
        btnClear.visibility = View.GONE
        if (!swipe.isRefreshing) adapter.set(emptyList())
        status.text = getString(R.string.loading)
        Repo.startSearch(
            query, maxAge(),
            cb = { s, items, err ->
                if (token != searchToken) {
                    s?.cancelled = true
                } else {
                    endRefresh()
                    if (err != null) {
                        status.text = err
                    } else {
                        session = s
                        adapter.set(items)
                        status.text = if (items.isEmpty()) "Tidak ada hasil untuk $currentLabel${filterNote()}"
                        else "${items.size} $noun pertama tampil untuk $currentLabel${filterNote()}, memuat $noun lainnya…"
                    }
                }
            },
            onMore = { items -> if (token == searchToken) adapter.add(items) },
            onDone = {
                if (token == searchToken && adapter.itemCount > 0) {
                    status.text = "${adapter.itemCount} $noun ditemukan untuk $currentLabel${filterNote()}. Gulir ke bawah untuk memuat lebih banyak."
                }
            },
            filter = filterKey()
        )
    }

    // ------------------------------------------------------------------ tautan di clipboard

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) checkClipboard()
    }

    /** Ada tautan YouTube yang baru disalin: langsung buka halaman pilihan putar/unduh. */
    private fun checkClipboard() {
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            if (!cm.hasPrimaryClip()) return
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            val clipText = clip.getItemAt(0).coerceToText(this)?.toString()
            val link = YtLink.extract(clipText) ?: YtLink.extractPlaylist(clipText) ?: TikTokLink.extract(clipText) ?: FacebookLink.extract(clipText) ?: return
            val stamp = if (Build.VERSION.SDK_INT >= 26) clip.description.timestamp else 0L
            val key = "$link|$stamp"
            if (Store.lastClip(this) == key) return
            Store.setLastClip(this, key)
            startActivity(Intent(this, LinkActivity::class.java).putExtra(LinkActivity.EXTRA_LINK, clipText.orEmpty()))
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        if (Build.VERSION.SDK_INT >= 33) (back33 as? BackApi33)?.unregister(this)
        if (::adapter.isInitialized) PlayQueue.detachLoader(adapter.sourceId)
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Downloads.onPermissionResult(this, requestCode, grantResults)
    }

    // ------------------------------------------------------------------ pemutar

    private fun openVideo(item: VideoItem, audio: Boolean?, queue: List<VideoItem>? = null) {
        // Video yang sedang diputar dipilih lagi: cukup buka halaman pemutaran, jangan diputar dari awal.
        val c0 = controller
        val sameNow = c0 != null && c0.currentMediaItem?.mediaId == item.url &&
            c0.playbackState != Player.STATE_IDLE && c0.playbackState != Player.STATE_ENDED
        val modeChanged = audio != null && audio != Store.audioOnly(this)
        if (sameNow && !modeChanged) {
            startActivity(PlayerActivity.intent(this, item))
            return
        }
        if (audio != null) {
            Store.setAudioOnly(this, audio)
            swAudio.isChecked = audio
        }
        // Ambil aliran sekarang, berbarengan dengan layar pemutar yang sedang dibuka.
        Repo.prefetch(item.url)
        // Video berikutnya / sebelumnya mengikuti daftar yang sedang tampil (hasil pencarian dll.).
        // Dari layar Anda (Histori), antreannya adalah daftar riwayat itu sendiri.
        if (queue != null) {
            PlayQueue.set(queue, PlayQueue.newSourceId(), null)
        } else {
            PlayQueue.set(adapter.snapshot(), adapter.sourceId) {
                val s = session
                if (s != null && !loadingMore && !s.loading && s.hasMore) {
                    loadingMore = true
                    Repo.loadMore(
                        s,
                        onChunk = { items -> if (s === session) adapter.add(items) },
                        onDone = { loadingMore = false }
                    )
                }
            }
        }
        // Putar langsung lewat sambungan yang sudah ada, tanpa menunggu layar pemutar tersambung.
        controller?.let { c ->
            c.removeListener(playerListener)
            controller = null
            controllerFuture = null
            QuickPlay.start(applicationContext, c, item.url)
        }
        startActivity(PlayerActivity.intent(this, item))
    }

    private fun openCurrentPlayer() {
        val cur = controller?.currentMediaItem ?: return
        val md = cur.mediaMetadata
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_URL, cur.mediaId)
                .putExtra(PlayerActivity.EXTRA_TITLE, md.title?.toString() ?: "")
                .putExtra(PlayerActivity.EXTRA_UPLOADER, md.artist?.toString() ?: "")
                .putExtra(PlayerActivity.EXTRA_FROM_NOTIFICATION, true)
        )
    }

    private fun updateMini() {
        val c = controller
        val cur: MediaItem? = c?.currentMediaItem
        if (c == null || cur == null || c.playbackState == Player.STATE_IDLE && !c.playWhenReady) {
            miniBar.visibility = View.GONE
            return
        }
        val title = cur.mediaMetadata.title?.toString().orEmpty()
        val playing = c.playWhenReady && c.playbackState != Player.STATE_ENDED
        miniBar.visibility = View.VISIBLE
        miniTitle.text = title
        miniOpen.contentDescription = "${getString(R.string.now_playing)}: $title. ${getString(R.string.open_player)}"
        miniPlay.text = getString(if (playing) R.string.pause else R.string.play)
    }
}
