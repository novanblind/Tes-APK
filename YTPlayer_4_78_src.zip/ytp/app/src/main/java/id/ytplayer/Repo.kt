package id.ytplayer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Process
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.exceptions.ContentNotAvailableException
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.exceptions.SignInConfirmNotBotException
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import java.io.IOException
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Cache StreamInfo di memori (dipakai bersama oleh Activity dan Service). */
object StreamCache {
    private class Entry(val info: StreamInfo, val time: Long)

    private val map = object : LinkedHashMap<String, Entry>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry>?) = size > 20
    }
    private const val TTL_MS = 30 * 60 * 1000L

    @Synchronized
    fun get(url: String): StreamInfo? {
        val e = map[url] ?: return null
        if (System.currentTimeMillis() - e.time > TTL_MS) {
            map.remove(url)
            return null
        }
        return e.info
    }

    @Synchronized
    fun put(url: String, info: StreamInfo) {
        map[url] = Entry(info, System.currentTimeMillis())
    }

    @Synchronized
    fun remove(url: String) {
        map.remove(url)
    }
}

object Repo {
    class SearchSession(val query: String, val handler: SearchQueryHandler, val maxAgeSec: Long = 0L) {
        @Volatile var nextPage: Page? = null
        @Volatile var hasMore = false
        @Volatile var loading = false
        @Volatile var cancelled = false // pencarian lama ditinggalkan → hentikan muat di latar
        internal val seen = HashSet<String>() // hanya disentuh dari satu thread pada satu waktu
    }

    private val io = Executors.newFixedThreadPool(3)
    private val rec = Executors.newFixedThreadPool(6)

    /** Pool khusus pengambilan aliran video, agar tidak antre di belakang rekomendasi/pencarian. */
    private val stream = Executors.newFixedThreadPool(3)

    /**
     * Pool khusus pengambilan awal (prefetch) diam-diam, berprioritas rendah. Dipisah dari [stream]
     * supaya prefetch kartu lain tidak menghalangi video yang benar-benar dipilih pengguna.
     */
    private val warm = Executors.newFixedThreadPool(2) { r ->
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            r.run()
        }
    }

    /** Satu pengambilan aliran; hanya dijalankan sekali walau diajukan ke dua pool. */
    private class Job(val url: String) {
        val started = AtomicBoolean(false)
        @Volatile var tid = 0
    }

    /** Pekerjaan per url yang sedang antre/berjalan (sejajar dengan [pending]; hanya thread utama). */
    private val jobs = HashMap<String, Job>()

    /** Permintaan aliran yang sedang berjalan → semua peminta ikut menunggu satu permintaan yang sama. */
    private val pending = HashMap<String, MutableList<(StreamInfo?, String?) -> Unit>>()
    private val main = Handler(Looper.getMainLooper())

    fun friendly(e: Throwable): String = when (e) {
        is SignInConfirmNotBotException ->
            "YouTube meminta verifikasi bukan robot untuk video ini. Coba lagi nanti atau pilih video lain."
        is ReCaptchaException -> "YouTube membatasi permintaan. Coba lagi beberapa saat lagi."
        is ContentNotAvailableException -> e.message ?: "Video tidak tersedia."
        is IOException -> "Gagal terhubung ke internet. Periksa koneksi Anda."
        else -> "Terjadi kesalahan: ${e.message ?: e.javaClass.simpleName}"
    }

    fun bestThumb(images: List<Image>?): String? {
        if (images.isNullOrEmpty()) return null
        return images.firstOrNull { it.width in 300..800 }?.url
            ?: images.maxByOrNull { it.width }?.url
            ?: images.first().url
    }

    private fun toVideos(items: List<InfoItem>?): List<VideoItem> =
        items.orEmpty().filterIsInstance<StreamInfoItem>().map {
            val live = it.streamType == StreamType.LIVE_STREAM ||
                it.streamType == StreamType.AUDIO_LIVE_STREAM
            VideoItem(
                url = it.url,
                title = it.name ?: "",
                uploader = it.uploaderName ?: "",
                thumb = bestThumb(it.thumbnails),
                durationSec = if (live) -1 else it.duration,
                views = it.viewCount,
                date = it.textualUploadDate ?: ""
            )
        }

    fun relatedOf(info: StreamInfo): List<VideoItem> = toVideos(info.relatedItems)

    /** Pencarian khusus video (tanpa kanal/daftar putar) agar lebih banyak video per halaman. */
    private fun handlerFor(query: String, filter: String? = null): SearchQueryHandler {
        val f = ServiceList.YouTube.searchQHFactory
        return try {
            // filter YouTube Music: "music_songs" (lagu) atau "music_videos" (video musik).
            f.fromQuery(query, listOf(filter ?: "videos"), "")
        } catch (e: Exception) {
            f.fromQuery(query)
        }
    }

    private fun addNew(session: SearchSession, list: List<VideoItem>, out: MutableList<VideoItem>) {
        for (v in list) {
            if (!DateFilter.matches(v, session.maxAgeSec)) continue
            if (session.seen.add(v.url)) out.add(v)
        }
    }

    /**
     * Ambil halaman berikutnya (beberapa sekaligus) sampai hasil yang lolos filter cukup
     * ([want]), halaman habis, atau batas [maxPages] tercapai. Mengembalikan galat terakhir bila ada.
     */
    private fun pullPages(session: SearchSession, out: MutableList<VideoItem>, want: Int, maxPages: Int): Exception? {
        var pages = 0
        var err: Exception? = null
        while (session.hasMore && out.size < want && pages < maxPages) {
            try {
                val page = SearchInfo.getMoreItems(ServiceList.YouTube, session.handler, session.nextPage)
                session.nextPage = page.nextPage
                session.hasMore = Page.isValid(page.nextPage)
                addNew(session, toVideos(page.items), out)
                err = null
            } catch (e: Exception) {
                err = e
                break
            }
            pages++
        }
        return err
    }

    /** Video ditampilkan bertahap, tiap kiriman paling banyak sekian video. */
    private const val CHUNK_SIZE = 15

    /** Kirim [list] ke UI per [CHUNK_SIZE] video (tiap potongan satu kiriman terpisah). */
    private fun postChunks(list: List<VideoItem>, sink: (List<VideoItem>) -> Unit) {
        list.chunked(CHUNK_SIZE).forEach { c -> main.post { sink(c) } }
    }

    /** Ambil satu halaman hasil; mengembalikan video baru yang lolos filter, atau melempar galat. */
    private fun pullOne(session: SearchSession): List<VideoItem> {
        val page = SearchInfo.getMoreItems(ServiceList.YouTube, session.handler, session.nextPage)
        session.nextPage = page.nextPage
        session.hasMore = Page.isValid(page.nextPage)
        val out = ArrayList<VideoItem>()
        addNew(session, toVideos(page.items), out)
        return out
    }

    /**
     * Pencarian bertahap: [cb] dipanggil secepatnya dengan 15 video pertama; sisanya menyusul lewat
     * [onMore] (15 video per kiriman) sementara halaman berikutnya dimuat di latar belakang;
     * [onDone] dipanggil saat pemuatan awal selesai.
     */
    fun startSearch(
        query: String,
        maxAgeSec: Long,
        cb: (SearchSession?, List<VideoItem>, String?) -> Unit,
        onMore: (List<VideoItem>) -> Unit,
        onDone: () -> Unit,
        filter: String? = null
    ) {
        io.execute {
            var session: SearchSession? = null
            var shown = 0
            try {
                val handler = handlerFor(query, filter)
                val info = SearchInfo.getInfo(ServiceList.YouTube, handler)
                val s = SearchSession(query, handler, maxAgeSec)
                s.nextPage = info.nextPage
                s.hasMore = Page.isValid(info.nextPage)
                val items = ArrayList<VideoItem>()
                addNew(s, toVideos(info.relatedItems), items)
                // Filter tanggal bisa membuang banyak hasil: tambah halaman sampai ada 15 video.
                var guard = 0
                while (items.size < CHUNK_SIZE && s.hasMore && guard < 10) {
                    try { items.addAll(pullOne(s)) } catch (e: Exception) { break }
                    guard++
                }
                session = s
                shown = items.size
                s.loading = true
                val first = items.take(CHUNK_SIZE)
                val rest = items.drop(CHUNK_SIZE)
                main.post { cb(s, first, null) }
                postChunks(rest, onMore)
            } catch (e: Exception) {
                main.post { cb(null, emptyList(), friendly(e)) }
                return@execute
            }

            val s = session ?: return@execute
            // Lanjut memuat halaman berikutnya di latar belakang, ditampilkan per 15 video.
            val target = if (maxAgeSec > 0) 40 else 80
            var pages = 0
            while (!s.cancelled && s.hasMore && shown < target && pages < 12) {
                val more = try { pullOne(s) } catch (e: Exception) { break }
                shown += more.size
                postChunks(more, onMore)
                pages++
            }
            main.post {
                s.loading = false
                onDone()
            }
        }
    }

    /** Hasil pencarian [pages] halaman (dipakai beranda), sudah disaring tanggal bila perlu. */
    private fun searchBlocking(query: String, pages: Int = 1, maxAgeSec: Long = 0L, filter: String? = null): List<VideoItem> {
        val service = ServiceList.YouTube
        val handler = handlerFor(query, filter)
        val info = SearchInfo.getInfo(service, handler)
        val s = SearchSession(query, handler, maxAgeSec)
        s.nextPage = info.nextPage
        s.hasMore = Page.isValid(info.nextPage)
        val out = ArrayList<VideoItem>()
        addNew(s, toVideos(info.relatedItems), out)
        if (pages > 1) pullPages(s, out, Int.MAX_VALUE, pages - 1)
        return out
    }

    private fun relatedBlocking(url: String, maxAgeSec: Long): List<VideoItem> {
        val info = StreamCache.get(url)
            ?: StreamInfo.getInfo(ServiceList.YouTube, url).also { StreamCache.put(url, it) }
        return relatedOf(info).filter { DateFilter.matches(it, maxAgeSec) }
    }

    /**
     * Jalankan semua tugas bersamaan dan serahkan hasil tiap tugas begitu selesai (urutan selesai,
     * bukan urutan daftar). Yang gagal atau terlambat (> 35 detik) dilewati. Mengembalikan galat pertama.
     */
    private fun runProgressive(tasks: List<Callable<List<VideoItem>>>, onList: (List<VideoItem>) -> Unit): Exception? {
        val cs = ExecutorCompletionService<List<VideoItem>>(rec)
        val futures = tasks.map { cs.submit(it) }
        var firstError: Exception? = null
        val end = System.currentTimeMillis() + 35_000L
        for (i in futures.indices) {
            val left = end - System.currentTimeMillis()
            val f = (if (left > 0) cs.poll(left, TimeUnit.MILLISECONDS) else null) ?: break
            try {
                val l = f.get()
                if (l.isNotEmpty()) onList(l.shuffled())
            } catch (e: Exception) {
                if (firstError == null) firstError = (e.cause as? Exception) ?: e
            }
        }
        futures.forEach { it.cancel(true) }
        return firstError
    }

    /** Gabung beberapa daftar secara bergantian (satu dari tiap sumber per putaran), tanpa duplikat. */
    private fun interleave(lists: List<List<VideoItem>>, exclude: Set<String>, max: Int): List<VideoItem> {
        val seen = HashSet<String>()
        val out = ArrayList<VideoItem>()
        var round = 0
        while (out.size < max && lists.any { round < it.size }) {
            for (l in lists) {
                val v = l.getOrNull(round) ?: continue
                if (v.url in exclude || !seen.add(v.url)) continue
                out.add(v)
                if (out.size >= max) break
            }
            round++
        }
        return out
    }

    private val popularQueries = listOf(
        "video populer Indonesia", "musik populer Indonesia", "berita terkini",
        "podcast Indonesia", "gameplay Indonesia", "tutorial belajar", "kajian ceramah"
    )

    private val musicPopularQueries = listOf(
        "lagu populer Indonesia", "lagu pop Indonesia terbaru", "lagu dangdut", "lagu pop barat",
        "lagu religi islami", "lagu kenangan Indonesia", "lagu k-pop"
    )

    private fun popularTasks(maxAgeSec: Long, filter: String? = null): List<Callable<List<VideoItem>>> {
        val pages = if (maxAgeSec > 0) 4 else 2
        val qs = if (filter != null) musicPopularQueries else popularQueries
        return qs.map { q -> Callable { searchBlocking(q, pages, maxAgeSec, filter) } }
    }

    /**
     * Rekomendasi beranda dari riwayat tontonan dan pencarian: video terkait tontonan terakhir,
     * hasil pencarian terakhir, dan video lain dari kanal yang sering ditonton. Bila kurang banyak
     * (atau belum ada riwayat) ditambah video populer. [maxAgeSec] > 0 = hanya video yang diunggah
     * dalam rentang itu.
     *
     * Bertahap: tiap sumber yang selesai langsung diurai ke [onChunk] (15 video per kiriman), jadi
     * 15 video pertama muncul tanpa menunggu semua sumber. [onDone] (dipersonalisasi?, galat?)
     * dipanggil di akhir; galat hanya diisi bila tidak ada satu pun video.
     */
    fun recommend(
        ctx: Context,
        maxAgeSec: Long,
        onChunk: (List<VideoItem>) -> Unit,
        onDone: (Boolean, String?) -> Unit,
        filter: String? = null
    ) {
        val history = Store.history(ctx)
        val searches = Store.searches(ctx)
        io.execute {
            try {
                val deep = if (maxAgeSec > 0) 4 else 2
                val watched = history.map { it.url }.toHashSet()
                val emitted = HashSet<String>(watched)
                val lists = ArrayList<List<VideoItem>>()
                var total = 0
                var personal = false
                var error: Exception? = null

                // Tambahkan satu sumber, lalu kirim video baru (selang-seling antarsumber).
                fun push(l: List<VideoItem>) {
                    lists.add(l)
                    val fresh = interleave(lists, emitted, 200 - total)
                    if (fresh.isEmpty()) return
                    fresh.forEach { emitted.add(it.url) }
                    total += fresh.size
                    postChunks(fresh, onChunk)
                }

                if (history.isNotEmpty() || searches.isNotEmpty()) {
                    val tasks = ArrayList<Callable<List<VideoItem>>>()
                    // Mode YouTube Music: tanpa video terkait (isinya video biasa), hanya lagu dari pencarian.
                    if (filter == null) history.take(8).forEach { h ->
                        tasks += Callable { relatedBlocking(h.url, maxAgeSec) }
                    }
                    searches.take(6).forEach { q ->
                        tasks += Callable { searchBlocking(q, deep, maxAgeSec, filter) }
                    }
                    history.map { it.uploader }.filter { it.isNotBlank() }.distinct().take(4).forEach { u ->
                        tasks += Callable { searchBlocking(u, deep, maxAgeSec, filter) }
                    }
                    error = runProgressive(tasks) { push(it) }
                    personal = total > 0
                }

                val enough = if (maxAgeSec > 0) 20 else 60
                if (total < enough) {
                    lists.clear() // daftar populer selang-seling sendiri, yang sudah tampil dikecualikan
                    val e2 = runProgressive(popularTasks(maxAgeSec, filter)) { push(it) }
                    if (error == null) error = e2
                }

                val p = personal
                val err = if (total == 0 && error != null) friendly(error) else null
                main.post { onDone(p, err) }
            } catch (e: Exception) {
                main.post { onDone(false, friendly(e)) }
            }
        }
    }

    /** Muat halaman berikutnya; video datang per 15 lewat [onChunk], [onDone] dipanggil di akhir. */
    fun loadMore(session: SearchSession, onChunk: (List<VideoItem>) -> Unit, onDone: (String?) -> Unit) {
        if (session.loading || !session.hasMore) {
            main.post { onDone(null) }
            return
        }
        session.loading = true
        io.execute {
            val want = if (session.maxAgeSec > 0) 20 else 30
            val maxPages = if (session.maxAgeSec > 0) 8 else 3
            var got = 0
            var pages = 0
            var err: Exception? = null
            while (!session.cancelled && session.hasMore && got < want && pages < maxPages) {
                val more = try { pullOne(session) } catch (e: Exception) { err = e; break }
                got += more.size
                pages++
                postChunks(more, onChunk)
            }
            val failure = err
            main.post {
                session.loading = false
                if (got == 0 && failure != null) {
                    session.hasMore = false
                    onDone(friendly(failure))
                } else onDone(null)
            }
        }
    }

    /**
     * Hasil selalu dikirim di thread utama; wajib dipanggil dari thread utama.
     * Bila video yang sama sedang diambil (mis. oleh prefetch), peminta baru ikut menunggu
     * permintaan itu, tidak membuat permintaan ganda.
     */
    fun fetchStream(url: String, cb: (StreamInfo?, String?) -> Unit) {
        StreamCache.get(url)?.let { cached -> main.post { cb(cached, null) }; return }
        val waiters = pending[url]
        if (waiters != null) {
            waiters.add(cb)
            // Pengguna sudah menunggu: bila prefetch-nya masih antre (belum mulai), jalankan juga
            // di pool utama supaya tidak menunggu antrean prefetch. Pekerjaan hanya jalan sekali.
            jobs[url]?.let { j ->
                if (!j.started.get()) {
                    stream.execute { runJob(j) }
                } else if (j.tid != 0) {
                    // Sudah berjalan di pool prefetch (prioritas rendah): naikkan ke prioritas biasa.
                    try { Process.setThreadPriority(j.tid, Process.THREAD_PRIORITY_DEFAULT) } catch (_: Throwable) {}
                }
            }
            return
        }
        // Pengguna memilih video ini: prefetch kartu lain yang masih antre (belum mulai) dibatalkan
        // supaya jaringan dan CPU dipakai untuk video yang dipilih.
        cancelQueuedPrefetch()
        val job = Job(url)
        jobs[url] = job
        pending[url] = arrayListOf(cb)
        stream.execute { runJob(job) }
    }

    private fun runJob(job: Job) {
        if (!job.started.compareAndSet(false, true)) return
        val url = job.url
        val tid = Process.myTid()
        val basePrio = try { Process.getThreadPriority(tid) } catch (_: Throwable) { Process.THREAD_PRIORITY_DEFAULT }
        job.tid = tid
        var info: StreamInfo? = null
        var err: String? = null
        try {
            info = StreamInfo.getInfo(ServiceList.YouTube, url)
            StreamCache.put(url, info)
        } catch (e: Exception) {
            err = friendly(e)
        }
        val result = info
        val msg = err
        // Kembalikan prioritas thread ke semula (bisa sempat dinaikkan saat video ini dipilih).
        try { Process.setThreadPriority(tid, basePrio) } catch (_: Throwable) {}
        main.post {
            jobs.remove(url)
            pending.remove(url).orEmpty().forEach { it(result, msg) }
        }
    }

    /** Ambil info halaman pertama playlist (nama, jumlah video) di thread latar. */
    fun fetchPlaylist(url: String, cb: (PlaylistInfo?, String?) -> Unit) {
        stream.execute {
            var info: PlaylistInfo? = null
            var err: String? = null
            try {
                info = PlaylistInfo.getInfo(ServiceList.YouTube, url)
            } catch (e: Exception) {
                err = friendly(e)
            }
            val result = info
            val msg = err
            main.post { cb(result, msg) }
        }
    }

    /** Mulai mengambil aliran video lebih awal (diam-diam) supaya saat dibuka sudah siap. */
    /** Batalkan prefetch yang masih antre (belum mulai dan tidak ada yang menunggu). Thread utama. */
    fun cancelQueuedPrefetch() {
        for (j in ArrayList(jobs.values)) {
            if (!j.started.get() && pending[j.url]?.isEmpty() == true && j.started.compareAndSet(false, true)) {
                jobs.remove(j.url)
                pending.remove(j.url)
            }
        }
    }

    fun prefetch(url: String) {
        if (url.isBlank()) return
        if (StreamCache.get(url) != null || pending.containsKey(url)) return
        val job = Job(url)
        jobs[url] = job
        pending[url] = arrayListOf()
        warm.execute { runJob(job) }
    }

    fun itemFrom(url: String, info: StreamInfo): VideoItem {
        val live = info.streamType == StreamType.LIVE_STREAM ||
            info.streamType == StreamType.AUDIO_LIVE_STREAM
        return VideoItem(
            url = url,
            title = info.name ?: "",
            uploader = info.uploaderName ?: "",
            thumb = bestThumb(info.thumbnails),
            durationSec = if (live) -1 else info.duration,
            views = info.viewCount,
            date = info.textualUploadDate ?: ""
        )
    }
}
