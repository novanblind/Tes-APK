package id.ytplayer

import android.net.Uri

/** Mengenali tautan video TikTok (tiktok.com/@user/video/ID, vm/vt.tiktok.com, tiktok.com/t/...). */
object TikTokLink {
    private val urlRe = Regex("https?://\\S+")

    /** Mengembalikan tautan TikTok pertama pada teks (apa adanya), atau null. */
    fun extract(text: String?): String? {
        if (text.isNullOrBlank()) return null
        for (m in urlRe.findAll(text)) {
            val raw = m.value.trimEnd('.', ',', ')', '"', '\'')
            val u = try {
                Uri.parse(raw)
            } catch (e: Exception) {
                continue
            }
            val host = u.host?.lowercase() ?: continue
            if (host != "tiktok.com" && !host.endsWith(".tiktok.com")) continue
            val path = u.path.orEmpty()
            val short = host.startsWith("vm.") || host.startsWith("vt.") || host.startsWith("vn.")
            if (short || path.contains("/video/") || path.contains("/photo/") ||
                path.startsWith("/t/") || path.startsWith("/v/")
            ) return raw
        }
        return null
    }
}
