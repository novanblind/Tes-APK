package id.ytplayer

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.GZIPInputStream

/**
 * Mengambil alamat video Facebook (publik) untuk diunduh. Hasilnya memakai kelas data yang sama dengan
 * [TikTokResolver] ([TikTokResolver.Info] dan [TikTokResolver.Quality]) sehingga alur unduhan
 * (MP4, M4A, MP3) bisa dipakai bersama. Galat memakai [TikTokException] dengan pesan Bahasa Indonesia.
 *
 * Cara 1: membaca halaman video (data JSON di dalam halaman: browser_native_hd_url, playable_url,
 * progressive_url, format DASH, atau tag og:video), dicoba dengan beberapa penyamaran peramban dan alamat
 * (alamat akhir setelah pengalihan, /watch/?v=ID, halaman sematan, m., mbasic.). Bila halaman memuat banyak
 * video (daftar Reels), hanya bagian di sekitar ID video yang diminta yang dibaca.
 * Cara 2 (cadangan): WebView tersembunyi yang memuat halaman seperti peramban sungguhan, lalu membaca
 * data video dari halaman itu, atau dari alamat berkas yang diminta pemutarnya.
 * Format DASH (video dan suara terpisah) memakai [TikTokResolver.Quality.audioUrl]; penggabungannya di HP.
 *
 * Tidak resmi dan bisa berhenti bekerja bila Facebook mengubah sistemnya. Hanya video publik yang bisa
 * diunduh; video privat, grup tertutup, atau yang meminta login tidak bisa.
 */
object FacebookResolver {
    const val PREFIX = "fb:"
    const val KEY_MP4 = "fb:mp4:"   // diikuti kode kualitas (2 = HD, 1 = standar, 0 = terbaik)
    const val KEY_M4A = "fb:m4a"
    const val KEY_MP3 = "fb:mp3:"   // diikuti kbps

    private const val UA_DESKTOP =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
    private const val UA_ANDROID =
        "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

    /** Penyamaran sebagai perayap pratinjau tautan: Facebook memberi tag og:video untuk video publik. */
    private const val UA_BOT = "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"

    private class Cached(val time: Long, val info: TikTokResolver.Info)

    private val cache = LinkedHashMap<String, Cached>()
    private const val CACHE_TTL_MS = 10 * 60 * 1000L

    @Synchronized
    private fun cacheGet(link: String): TikTokResolver.Info? {
        val c = cache[link] ?: return null
        if (System.currentTimeMillis() - c.time > CACHE_TTL_MS) {
            cache.remove(link)
            return null
        }
        return c.info
    }

    @Synchronized
    private fun cachePut(link: String, info: TikTokResolver.Info) {
        cache[link] = Cached(System.currentTimeMillis(), info)
        while (cache.size > 8) cache.remove(cache.keys.first())
    }

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /** Hasil dikirim di thread utama. Pesan galat sudah Bahasa Indonesia. */
    fun resolveAsync(link: String, cb: (TikTokResolver.Info?, String?) -> Unit) {
        io.execute {
            try {
                val info = resolve(link)
                main.post { cb(info, null) }
            } catch (e: Exception) {
                val msg = if (e is TikTokException) e.message else Repo.friendly(e)
                main.post { cb(null, msg) }
            }
        }
    }

    private class Plan(val pages: List<String>, val watch: String?, val id: String?)

    private fun idOf(url: String?): String? {
        if (url.isNullOrEmpty()) return null
        return Regex("(?:/videos/(?:[^/?#]+/)?|/reel/|/reels/|[?&]v=|video_id=)(\\d{6,})")
            .find(url)?.groupValues?.get(1)
    }

    /** Facebook kadang mengalihkan ke /login/?next=ALAMAT_ASLI; ambil alamat aslinya. */
    private fun unwrapLogin(url: String): String {
        if (!url.contains("/login")) return url
        return try {
            Uri.parse(url).getQueryParameter("next") ?: url
        } catch (_: Exception) {
            url
        }
    }

    /** Mengikuti pengalihan tanpa membaca isi halaman (fb.watch, /share/...) untuk tahu alamat akhirnya. */
    private fun finalUrl(start: String, ua: String): String {
        var url = start
        for (hop in 0 until 6) {
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 15_000
                conn.readTimeout = 15_000
                conn.setRequestProperty("User-Agent", ua)
                conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location") ?: return url
                    url = URL(URL(url), loc).toString()
                    continue
                }
                return url
            } finally {
                conn.disconnect()
            }
        }
        return url
    }

    /** Alamat halaman yang dicoba: alamat akhir, halaman /watch/?v=ID yang baku, lalu tautan asli. */
    private fun planFor(link: String): Plan {
        var fin = link
        try {
            fin = unwrapLogin(finalUrl(link, UA_DESKTOP))
        } catch (_: Exception) {
        }
        val id = idOf(fin) ?: idOf(link)
        val watch = if (id != null) "https://www.facebook.com/watch/?v=$id" else null
        val pages = LinkedHashSet<String>()
        pages.add(fin)
        if (watch != null) pages.add(watch)
        pages.add(link)
        return Plan(pages.toList(), watch, id)
    }

    /** Halaman sematan (embed) Facebook: isinya lebih sederhana dan jarang meminta login. */
    private fun embedPages(plan: Plan): List<String> {
        val id = plan.id ?: return emptyList()
        val watch = plan.watch ?: return emptyList()
        return listOf(
            "https://www.facebook.com/plugins/video.php?href=" + URLEncoder.encode(watch, "UTF-8") +
                "&show_text=false&width=560",
            "https://www.facebook.com/video/embed?video_id=$id"
        )
    }

    /**
     * Memblokir thread; panggil dari thread latar. Hasil disimpan 10 menit; [fresh] = abaikan simpanan.
     * Putaran 1: halaman asli, halaman /watch/?v=ID, dan halaman sematan, tiap halaman dengan beberapa
     * penyamaran. Putaran 2: versi seluler (m., mbasic.) lalu WebView tersembunyi. Berhenti sekitar 80 detik.
     */
    fun resolve(link: String, fresh: Boolean = false): TikTokResolver.Info {
        if (!fresh) cacheGet(link)?.let { return it }
        var net: IOException? = null
        var last: TikTokException? = null
        val detail = LinkedHashMap<String, String>()
        fun note(src: String, e: Exception) {
            detail[src] = (e.message ?: e.javaClass.simpleName).replace('\n', ' ').take(140)
        }
        val plan = planFor(link)
        val deadline = System.currentTimeMillis() + 80_000L
        var webTried = false
        for (round in 0 until 2) {
            if (round > 0) Thread.sleep(1500L)
            val tries = ArrayList<Triple<String, String, String>>()   // nama, alamat, penyamaran
            var n = 0
            if (round == 0) {
                for (p in plan.pages) {
                    val uas = if (p == plan.pages.first()) listOf(UA_DESKTOP, UA_BOT, UA_ANDROID) else listOf(UA_DESKTOP, UA_BOT)
                    for (ua in uas) {
                        n++
                        tries.add(Triple("Halaman Facebook #$n", p, ua))
                    }
                }
                for (p in embedPages(plan)) tries.add(Triple("Halaman sematan", p, UA_DESKTOP))
            } else {
                val basis = plan.watch ?: plan.pages.first()
                for (host in listOf("m.facebook.com", "mbasic.facebook.com")) {
                    for (ua in listOf(UA_ANDROID, UA_DESKTOP)) {
                        n++
                        tries.add(Triple("Halaman Facebook ($host) #$n", swapHost(basis, host), ua))
                    }
                }
            }
            for ((name, target, ua) in tries) {
                if (System.currentTimeMillis() > deadline) break
                try {
                    return viaPage(target, ua, plan.id).also { cachePut(link, it) }
                } catch (e: TikTokException) {
                    if (e.fatal) throw e
                    last = e
                    note(name, e)
                } catch (e: IOException) {
                    net = e
                    note(name, e)
                } catch (e: Exception) {
                    note("$name (data tidak terbaca)", e)
                }
            }
            if (!webTried && (round == 1 || System.currentTimeMillis() > deadline)) {
                webTried = true
                try {
                    return viaWebView(plan.watch ?: link, plan.id).also { cachePut(link, it) }
                } catch (e: TikTokException) {
                    if (e.fatal) throw e
                    last = e
                    note("WebView", e)
                } catch (e: Exception) {
                    note("WebView", e)
                }
            }
        }
        if (net != null && last == null) throw net
        throw TikTokException(
            "Gagal mengambil video Facebook setelah beberapa kali mencoba. Pastikan videonya publik " +
                "(bukan privat atau grup tertutup, dan tidak meminta login), lalu coba lagi nanti." +
                (if (detail.isEmpty()) "" else " Rincian: " + detail.entries.joinToString("; ") { "${it.key}: ${it.value}" })
        )
    }

    private fun swapHost(link: String, host: String): String = try {
        val u = URL(link)
        "https://$host${u.file}"
    } catch (_: Exception) {
        link
    }

    // ------------------------------------------------------------------ cara 1: halaman Facebook

    private fun viaPage(link: String, ua: String, id: String?): TikTokResolver.Info {
        val cookies = LinkedHashMap<String, String>()
        val r = get(link, cookies, ua)
        return parse(r.url, r.body, ua, id)
    }

    private fun jsonStr(raw: String): String = try {
        (JSONTokener("\"$raw\"").nextValue() as? String).orEmpty()
    } catch (_: Exception) {
        raw.replace("\\/", "/").replace("\\u0026", "&").replace("\\u0025", "%")
    }

    private fun htmlUnescape(s: String): String =
        s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#039;", "'")
            .replace("&#x27;", "'").replace("&lt;", "<").replace("&gt;", ">")

    private fun looksLikeVideo(u: String): Boolean {
        val l = u.lowercase()
        return l.startsWith("http") && (l.contains(".mp4") || l.contains("fbcdn.net"))
    }

    private fun xmlAttr(s: String, name: String): String =
        Regex("\\b" + name + "=\"([^\"]*)\"").find(s)?.groupValues?.get(1).orEmpty()

    /** Mengambil objek JSON {...} yang melingkupi posisi [pos] pada teks [t] (null bila terlalu besar). */
    private fun objectAround(t: String, pos: Int): String? {
        var depth = 0
        var s = minOf(pos, t.length - 1)
        val from = s
        while (s >= 0) {
            val c = t[s]
            if (c == '}') {
                depth++
            } else if (c == '{') {
                if (depth == 0) break
                depth--
            }
            s--
            if (from - s > 4000) return null
        }
        if (s < 0) return null
        depth = 0
        var e = s
        while (e < t.length) {
            val c = t[e]
            if (c == '{') {
                depth++
            } else if (c == '}') {
                depth--
                if (depth == 0) return t.substring(s, e + 1)
            }
            e++
            if (e - s > 12000) return null
        }
        return null
    }

    /**
     * Halaman Facebook sering memuat beberapa video sekaligus (daftar Reels, video terkait). Bila ID video
     * diketahui, ambil hanya bagian teks di sekitar ID itu supaya alamat yang dipilih benar-benar video yang diminta.
     */
    private fun scopeFor(body: String, id: String?): String? {
        if (id == null) return null
        val re = Regex("\"(?:video_id|videoId|id)\"\\s*:\\s*\"" + id + "\"")
        val sb = StringBuilder()
        var lastEnd = 0
        var count = 0
        for (m in re.findAll(body)) {
            if (count >= 20) break
            count++
            val s = maxOf(lastEnd, m.range.first - 7000)
            val e = minOf(body.length, m.range.last + 1 + 7000)
            if (e > s) {
                sb.append(body, s, e).append('\n')
                lastEnd = e
            }
        }
        return if (sb.isEmpty()) null else sb.toString()
    }

    private class Rep(val url: String, val height: Int, val bw: Long, val audio: Boolean, val aac: Boolean = false)

    /**
     * Format DASH (video dan suara terpisah): dari "dash_manifest" (XML MPD) atau daftar "base_url" dengan
     * mime_type. Hasilnya tiap tinggi video sekali, semuanya berpasangan dengan suara terbaik. Hanya video
     * H.264/H.265 yang dipakai karena pustaka penggabung Android tidak bisa menyimpan VP9/AV1 ke MP4.
     */
    private fun dashQualities(text: String): List<TikTokResolver.Quality> {
        val reps = ArrayList<Rep>()
        val seen = HashSet<String>()
        fun add(url: String, mime: String, codecs: String, height: Int, bw: Long) {
            val u = url.trim()
            if (!looksLikeVideo(u) || !seen.add(u)) return
            val m = mime.lowercase()
            val c = codecs.lowercase()
            val audio = m.contains("audio") || c.startsWith("mp4a") || c.startsWith("opus") || c.startsWith("ec-3")
            val video = m.contains("video") || height > 0
            if (!audio && !video) return
            if (!audio && (m.contains("webm") || c.startsWith("vp") || c.startsWith("av01"))) return
            reps.add(Rep(u, height, bw, audio, c.startsWith("mp4a") || (c.isEmpty() && m.contains("mp4"))))
        }

        // (a) "dash_manifest": teks XML (kadang dikodekan persen) di dalam JSON.
        Regex("\"dash_manifest\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").findAll(text).forEach { m ->
            var xml = jsonStr(m.groupValues[1])
            if (!xml.contains("<")) {
                xml = try { URLDecoder.decode(xml, "UTF-8") } catch (_: Exception) { xml }
            }
            Regex("<Representation\\b([^>]*)>(.*?)</Representation>", RegexOption.DOT_MATCHES_ALL).findAll(xml).forEach { r ->
                val attrs = r.groupValues[1]
                val base = Regex("<BaseURL>([^<]+)</BaseURL>").find(r.groupValues[2])?.groupValues?.get(1)
                if (base != null) {
                    add(
                        htmlUnescape(base), xmlAttr(attrs, "mimeType"), xmlAttr(attrs, "codecs"),
                        xmlAttr(attrs, "height").toIntOrNull() ?: 0, xmlAttr(attrs, "bandwidth").toLongOrNull() ?: 0L
                    )
                }
            }
        }

        // (b) daftar representasi: {"base_url":"...","mime_type":"video/mp4","height":720,"bandwidth":...}
        Regex("\"base_url\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").findAll(text).forEach { m ->
            val obj = objectAround(text, m.range.first) ?: return@forEach
            val mime = Regex("\"mime_type\"\\s*:\\s*\"([^\"]*)\"").find(obj)?.groupValues?.get(1).orEmpty()
            val codecs = Regex("\"codecs\"\\s*:\\s*\"([^\"]*)\"").find(obj)?.groupValues?.get(1).orEmpty()
            if (mime.isEmpty() && codecs.isEmpty()) return@forEach
            val h = Regex("\"height\"\\s*:\\s*(\\d+)").find(obj)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val bw = Regex("\"bandwidth\"\\s*:\\s*(\\d+)").find(obj)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            add(jsonStr(m.groupValues[1]), mime, codecs, h, bw)
        }

        // Suara terbaik: AAC (bisa disimpan ke MP4) dengan bitrate tertinggi dulu; Opus/E-AC-3 hanya cadangan.
        val bestAudio = reps.filter { it.audio }
            .sortedWith(compareByDescending<Rep> { it.aac }.thenByDescending { it.bw })
            .firstOrNull()?.url
        val byHeight = LinkedHashMap<Int, Rep>()
        val videos = reps.filter { !it.audio }
            .sortedWith(compareByDescending<Rep> { it.height }.thenByDescending { it.bw })
        for (r in videos) {
            if (!byHeight.containsKey(r.height)) byHeight[r.height] = r
        }
        val out = ArrayList<TikTokResolver.Quality>()
        for ((h, r) in byHeight) {
            out.add(TikTokResolver.Quality(if (h > 0) "MP4 ${h}p" else "MP4", h, r.url, emptyList(), bestAudio))
        }
        return out
    }

    /** Semua kualitas yang bisa diunduh dari teks halaman; [text] = bagian halaman, [full] = seluruh halaman. */
    private fun collect(text: String, full: String): List<TikTokResolver.Quality> {
        val urls = LinkedHashMap<String, String>()   // "hd" / "sd" -> alamat
        fun put(kind: String, u: String) {
            if (u.startsWith("http") && !urls.containsKey(kind)) urls[kind] = u
        }
        fun field(name: String, kind: String) {
            Regex("\"" + Regex.escape(name) + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").findAll(text)
                .forEach { put(kind, jsonStr(it.groupValues[1])) }
        }
        // Urutan menentukan prioritas: yang pertama ditemukan dipakai.
        field("browser_native_hd_url", "hd")
        field("playable_url_quality_hd", "hd")
        field("hd_src_no_ratelimit", "hd")
        field("hd_src", "hd")
        field("browser_native_sd_url", "sd")
        field("playable_url", "sd")
        field("sd_src_no_ratelimit", "sd")
        field("sd_src", "sd")
        // Susunan baru: "progressive_urls":[{"progressive_url":"...","failure_reason":null,"metadata":{"quality":"HD"}}]
        Regex("\"progressive_url\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"[^{}]*\\{[^{}]*\"quality\"\\s*:\\s*\"(\\w+)\"")
            .findAll(text).forEach { m ->
                put(if (m.groupValues[2].equals("HD", ignoreCase = true)) "hd" else "sd", jsonStr(m.groupValues[1]))
            }
        // Tag og:video (halaman untuk perayap pratinjau tautan) ada di seluruh halaman, bukan di bagian JSON.
        val ogRes = listOf(
            Regex("<meta[^>]+property=\"og:video(?::secure_url|:url)?\"[^>]+content=\"([^\"]+)\"", RegexOption.IGNORE_CASE),
            Regex("<meta[^>]+content=\"([^\"]+)\"[^>]+property=\"og:video(?::secure_url|:url)?\"", RegexOption.IGNORE_CASE)
        )
        for (re in ogRes) {
            re.findAll(full).forEach { m ->
                val u = htmlUnescape(m.groupValues[1])
                if (looksLikeVideo(u)) put("sd", u)
            }
        }
        // Halaman sederhana (mbasic): tautan /video_redirect/?src=ALAMAT
        Regex("/video_redirect/\\?src=([^\"&]+)").find(full)?.let { m ->
            try {
                put("sd", URLDecoder.decode(htmlUnescape(m.groupValues[1]), "UTF-8"))
            } catch (_: Exception) {
            }
        }

        val list = ArrayList<TikTokResolver.Quality>()
        val hd = urls["hd"]
        val sd = urls["sd"]
        if (hd != null) list.add(TikTokResolver.Quality("MP4 HD", 2, hd))
        if (sd != null && sd != hd) list.add(TikTokResolver.Quality("MP4 standar", 1, sd))
        // Format DASH: dipakai bila tidak ada HD biasa, atau bila lebih tinggi dari 720p.
        for (q in dashQualities(text)) {
            if (hd == null || q.height > 720) list.add(q)
        }
        return list
    }

    private fun qualitiesOf(body: String, id: String?): List<TikTokResolver.Quality> {
        val scoped = scopeFor(body, id)
        if (scoped != null) {
            val r = collect(scoped, body)
            if (r.isNotEmpty()) return r
        }
        return collect(body, body)
    }

    private class Meta(
        val id: String, val title: String, val author: String, val durSec: Long, val headers: Map<String, String>
    )

    /** Judul, pemilik, ID, dan durasi video dari halaman. */
    private fun metaOf(pageUrl: String, body: String, ua: String): Meta {
        fun meta(prop: String): String {
            val a = Regex("<meta[^>]+property=\"" + prop + "\"[^>]+content=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(body)
            val b = Regex("<meta[^>]+content=\"([^\"]*)\"[^>]+property=\"" + prop + "\"", RegexOption.IGNORE_CASE).find(body)
            return htmlUnescape((a ?: b)?.groupValues?.get(1).orEmpty()).trim()
        }

        // Judul: og:title, tanpa akhiran "| Facebook" dan tanpa awalan hitungan tayangan/reaksi.
        var parts = meta("og:title").split(" | ").map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.isNotEmpty() && parts.last().equals("Facebook", ignoreCase = true)) parts = parts.dropLast(1)
        var title = parts.firstOrNull().orEmpty()
        val first = title.lowercase()
        if (parts.size > 1 && (first.contains("views") || first.contains("reactions") || first.contains("tayangan"))) {
            title = parts[1]
        }
        title = title.replace(Regex("\\s+"), " ").take(120).ifBlank { "Video Facebook" }

        // Pemilik video: dari data halaman bila ada, kalau tidak dari bagian pertama alamat.
        var author = Regex("\"owner\"\\s*:\\s*\\{[^{}]*?\"name\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"")
            .find(body)?.groupValues?.get(1)?.let { jsonStr(it) }.orEmpty()
        if (author.isBlank()) {
            val seg = try { URL(pageUrl).path.trim('/').substringBefore('/') } catch (_: Exception) { "" }
            val reserved = setOf("watch", "reel", "reels", "share", "video.php", "videos", "permalink.php", "story.php", "groups", "login", "plugins", "video")
            if (seg.isNotEmpty() && seg.lowercase() !in reserved && !seg.all { it.isDigit() }) author = seg
        }

        val id = idOf(pageUrl)
            ?: Regex("\"video_id\"\\s*:\\s*\"(\\d{6,})\"").find(body)?.groupValues?.get(1)
            ?: "fb${(pageUrl.hashCode().toLong() and 0xffffffffL)}"
        val durMs = Regex("\"playable_duration_in_ms\"\\s*:\\s*(\\d+)").find(body)?.groupValues?.get(1)?.toLongOrNull() ?: 0L

        val headers = LinkedHashMap<String, String>()
        headers["User-Agent"] = if (ua == UA_BOT) UA_DESKTOP else ua
        headers["Referer"] = "https://www.facebook.com/"
        return Meta(id, title, author, durMs / 1000, headers)
    }

    private fun reasonFor(pageUrl: String, body: String, id: String?): String {
        val l = body.lowercase()
        return when {
            l.contains("isn't available") || l.contains("is not available") ||
                l.contains("konten ini tidak tersedia") || l.contains("content isn't available") ->
                "video tidak tersedia (privat, dihapus, atau khusus teman)"
            pageUrl.contains("/login") || l.contains("log in to facebook") || l.contains("masuk ke facebook") ->
                "Facebook meminta login untuk halaman ini"
            id != null && !body.contains(id) ->
                "halaman tidak memuat video bernomor $id (isi ${body.length} karakter)"
            else -> "halaman tidak berisi alamat video (isi ${body.length} karakter)"
        }
    }

    /** Membaca data video dari HTML halaman Facebook (dipakai cara 1 dan cara 2). */
    private fun parse(pageUrl: String, body: String, ua: String, wantId: String?): TikTokResolver.Info {
        val list = qualitiesOf(body, wantId ?: idOf(pageUrl))
        if (list.isEmpty()) throw TikTokException(reasonFor(pageUrl, body, wantId ?: idOf(pageUrl)))
        val m = metaOf(pageUrl, body, ua)
        return TikTokResolver.Info(m.id, m.title, m.author, m.durSec, list, m.headers)
    }

    // ------------------------------------------------------------------ alamat dari lalu lintas WebView

    private class Media(val url: String, val audio: Boolean, val dash: Boolean, val height: Int, val lowAudio: Boolean = false)

    /**
     * Mencatat alamat berkas video Facebook yang diminta pemutar di WebView. Pemutar meminta potongan
     * berkas dengan parameter bytestart/byteend; kedua parameter itu dibuang supaya jadi alamat berkas utuh.
     * Jenis (suara/video, tinggi) dibaca dari parameter efg.
     */
    private fun noteMedia(raw: String, into: MutableList<Media>) {
        try {
            val l = raw.lowercase()
            if (!l.startsWith("http") || !l.contains("fbcdn.net") || !l.contains(".mp4")) return
            val u = Uri.parse(raw)
            var tag = ""
            val efg = u.getQueryParameter("efg")
            if (efg != null) {
                tag = try {
                    val bytes = Base64.decode(
                        efg.replace('+', '-').replace('/', '_'),
                        Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
                    )
                    JSONObject(String(bytes, Charsets.UTF_8)).optString("vencode_tag")
                } catch (_: Exception) {
                    ""
                }
            }
            val t = tag.lowercase()
            val audio = t.contains("audio")
            val dash = t.contains("dash")
            val h = Regex("(\\d{3,4})p").find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val b = u.buildUpon().clearQuery()
            for (n in u.queryParameterNames) {
                if (n == "bytestart" || n == "byteend") continue
                for (v in u.getQueryParameters(n)) b.appendQueryParameter(n, v)
            }
            val clean = b.build().toString()
            synchronized(into) {
                if (into.none { it.url == clean }) into.add(Media(clean, audio, dash, h, audio && t.contains("heaac")))
            }
        } catch (_: Exception) {
        }
    }

    private fun fromMedia(list: MutableList<Media>): List<TikTokResolver.Quality> {
        val snap = ArrayList<Media>()
        synchronized(list) { snap.addAll(list) }
        // Suara AAC biasa lebih diutamakan daripada HE-AAC (bitrate rendah).
        val audio = (snap.firstOrNull { it.audio && !it.lowAudio } ?: snap.firstOrNull { it.audio })?.url
        val out = ArrayList<TikTokResolver.Quality>()
        val seen = HashSet<Int>()
        for (m in snap.filter { !it.audio }.sortedByDescending { it.height }) {
            if (!seen.add(m.height)) continue
            val a = if (m.dash) audio else null
            out.add(TikTokResolver.Quality(if (m.height > 0) "MP4 ${m.height}p" else "MP4", m.height, m.url, emptyList(), a))
        }
        return out
    }

    // ------------------------------------------------------------------ cara 2: WebView tersembunyi

    /**
     * Memuat halaman di WebView yang tidak tampak (JavaScript dan cookie seperti peramban sungguhan), menunggu
     * data video muncul di halaman, lalu membacanya dengan [parse]. Memblokir thread pemanggil (maks. sekitar
     * 45 detik); jangan dipanggil dari thread utama.
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun viaWebView(link: String, wantId: String?): TikTokResolver.Info {
        val app = App.ctx ?: throw TikTokException("WebView belum siap.")
        if (Looper.myLooper() == Looper.getMainLooper()) throw TikTokException("WebView tidak bisa dipakai dari thread utama.")
        val done = CountDownLatch(1)
        val result = AtomicReference<TikTokResolver.Info?>(null)
        val error = AtomicReference<String?>(null)
        val finished = AtomicBoolean(false)
        val holder = arrayOfNulls<WebView>(1)   // hanya disentuh di thread utama
        val mainStatus = AtomicReference(0)
        val mainErr = AtomicReference<String?>(null)
        val lastNote = AtomicReference("")
        val polls = AtomicReference(0)
        val media = ArrayList<Media>()   // alamat berkas video yang diminta pemutar; akses lewat synchronized(media)

        fun diag(w: WebView?): String =
            "muat ${w?.progress ?: 0}%, pemeriksaan ${polls.get()} kali" +
                (lastNote.get().let { if (it.isEmpty()) "" else ", $it" }) +
                (mainStatus.get().let { if (it >= 400) ", HTTP $it" else "" }) +
                (mainErr.get()?.let { ", $it" } ?: "")

        fun finish(info: TikTokResolver.Info?, err: String?) {   // thread utama
            if (!finished.compareAndSet(false, true)) return
            if (info != null) result.set(info) else error.set(err)
            try { holder[0]?.stopLoading(); holder[0]?.destroy() } catch (_: Exception) {}
            holder[0] = null
            done.countDown()
        }

        fun poll(tries: Int) {   // thread utama
            val w = holder[0] ?: return
            if (finished.get()) return
            polls.set(tries + 1)
            val answered = AtomicBoolean(false)
            fun next() {
                if (finished.get()) return
                if (tries >= 30) {
                    finish(null, "halaman tidak berisi data video (" + diag(w) + ")")
                } else {
                    main.postDelayed({ poll(tries + 1) }, 1000)
                }
            }
            // Jaga bila jawaban evaluasi JS tidak pernah datang: tetap lanjut setelah 4 detik.
            main.postDelayed({ if (answered.compareAndSet(false, true)) next() }, 4000)
            // Sambil memeriksa, minta pemutar berbunyi (tanpa suara) supaya alamat berkas videonya ikut terlihat.
            val script = "(function(){try{var vs=document.querySelectorAll('video');" +
                "for(var i=0;i<vs.length;i++){vs[i].muted=true;var p=vs[i].play();if(p&&p.catch){p.catch(function(){});}}" +
                "}catch(e){}return document.documentElement.outerHTML;})()"
            w.evaluateJavascript(script) { v ->
                val html = try { JSONTokener(v).nextValue() as? String } catch (_: Exception) { null }
                var info: TikTokResolver.Info? = null
                if (html != null) {
                    val pu = try { w.url } catch (_: Exception) { null } ?: link
                    info = try {
                        parse(pu, html, UA_DESKTOP, wantId)
                    } catch (e: Exception) {
                        lastNote.set((e.message ?: "").take(80))
                        null
                    }
                    if (info == null) {
                        // Data tidak ada di halaman: pakai alamat berkas yang diminta pemutar (bila ada).
                        val q = fromMedia(media)
                        if (q.isNotEmpty()) {
                            val mt = try { metaOf(pu, html, UA_DESKTOP) } catch (_: Exception) { null }
                            if (mt != null) info = TikTokResolver.Info(mt.id, mt.title, mt.author, mt.durSec, q, mt.headers)
                        }
                    }
                }
                if (info != null) {
                    finish(info, null)
                } else if (answered.compareAndSet(false, true)) {
                    next()
                }
            }
        }

        main.post {
            try {
                val cm = CookieManager.getInstance()
                cm.setAcceptCookie(true)
                cm.removeAllCookies(null)   // mulai bersih
                val w = WebView(app)
                holder[0] = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.userAgentString = UA_DESKTOP
                w.settings.blockNetworkImage = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                cm.setAcceptThirdPartyCookies(w, true)
                var polling = false
                fun startPolling() {   // thread utama; dipanggil sekali
                    if (!polling) {
                        polling = true
                        poll(0)
                    }
                }
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        startPolling()
                    }

                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val u = request?.url?.toString()
                        if (u != null) noteMedia(u, media)
                        return null
                    }

                    // Facebook sering mengalihkan ke alamat khusus aplikasi (fb://, intent://) agar aplikasinya
                    // terbuka; blokir alihan non-web supaya tetap di halaman video.
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val sc = request?.url?.scheme?.lowercase()
                        return sc != "http" && sc != "https" && sc != "about"
                    }

                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true) {
                            mainErr.set("galat muat ${error?.errorCode ?: 0} ${error?.description ?: ""}".trim())
                        }
                    }

                    override fun onReceivedHttpError(
                        view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?
                    ) {
                        if (request?.isForMainFrame == true) mainStatus.set(errorResponse?.statusCode ?: 0)
                    }
                }
                w.loadUrl(link)
                // Jangan hanya menunggu onPageFinished: mulai memeriksa data halaman setelah 3 detik.
                main.postDelayed({ startPolling() }, 3000)
            } catch (e: Exception) {
                finish(null, "WebView gagal dibuka (${e.message ?: e.javaClass.simpleName})")
            }
        }
        main.postDelayed({
            finish(null, "waktu habis menunggu halaman (" + diag(holder[0]) + ")")
        }, 42_000)
        done.await(48, TimeUnit.SECONDS)

        result.get()?.let { return it }
        throw TikTokException(error.get() ?: "tidak mendapat data video")
    }

    // ------------------------------------------------------------------ HTTP

    private class Resp(val url: String, val body: String)

    /** GET dengan pengalihan manual agar cookie dari setiap lompatan terkumpul. */
    private fun get(start: String, cookies: LinkedHashMap<String, String>, ua: String): Resp {
        var url = start
        for (hop in 0 until 6) {
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 20_000
                conn.readTimeout = 20_000
                conn.setRequestProperty("User-Agent", ua)
                conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                if (ua != UA_BOT) {
                    // Header yang dikirim peramban sungguhan saat membuka halaman; tanpa ini Facebook kadang
                    // memberi halaman kosong atau halaman login.
                    conn.setRequestProperty("Upgrade-Insecure-Requests", "1")
                    conn.setRequestProperty("Sec-Fetch-Dest", "document")
                    conn.setRequestProperty("Sec-Fetch-Mode", "navigate")
                    conn.setRequestProperty("Sec-Fetch-Site", "none")
                    conn.setRequestProperty("Sec-Fetch-User", "?1")
                }
                if (cookies.isNotEmpty()) {
                    conn.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
                }
                val code = conn.responseCode
                for ((k, vs) in conn.headerFields) {
                    if (k != null && k.equals("Set-Cookie", ignoreCase = true)) {
                        vs.forEach { c ->
                            val nv = c.substringBefore(';')
                            val name = nv.substringBefore('=').trim()
                            if (name.isNotEmpty()) cookies[name] = nv.substringAfter('=', "").trim()
                        }
                    }
                }
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location")
                        ?: throw TikTokException("Facebook mengalihkan tautan tanpa tujuan.")
                    url = URL(URL(url), loc).toString()
                    continue
                }
                if (code == 429) throw TikTokException("dibatasi (HTTP 429), coba lagi beberapa saat lagi")
                if (code >= 400) throw TikTokException("ditolak dengan galat HTTP $code")
                val raw = conn.inputStream
                val stream = if ("gzip".equals(conn.contentEncoding, ignoreCase = true)) GZIPInputStream(raw) else raw
                val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                return Resp(url, body)
            } finally {
                conn.disconnect()
            }
        }
        throw TikTokException("Tautan Facebook dialihkan terlalu banyak kali.")
    }
}
