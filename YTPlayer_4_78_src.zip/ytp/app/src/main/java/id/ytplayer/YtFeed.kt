package id.ytplayer

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.time.OffsetDateTime
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/**
 * Umpan "Subscription": video terbaru dari channel yang di-subscribe, lewat RSS publik tiap channel
 * (youtube.com/feeds/videos.xml?channel_id=...). Tanpa cookie dan tanpa NewPipe, jadi ringan
 * dan tidak mengganggu pemutaran. Durasi tidak ada di RSS; MainActivity melengkapinya kemudian dari halaman channel (youtubei).
 */
object YtFeed {
    private const val MAX_CHANNELS = 60
    private const val PER_CHANNEL = 5
    private const val MAX_ITEMS = 150

    class Result(
        val items: List<VideoItem>, val channels: Int, val failed: Int,
        /** Waktu (detik) video terbaru tiap channel; dasar titik biru "video baru". */
        val newest: Map<String, Long> = emptyMap()
    )

    private class Entry(val published: Long, val item: VideoItem)

    fun load(channelIds: List<String>): Result {
        val ids = channelIds.distinct().take(MAX_CHANNELS)
        val pool = Executors.newFixedThreadPool(6)
        try {
            val futures = ids.map { id -> pool.submit(Callable { fetch(id, PER_CHANNEL, true) }) }
            val all = ArrayList<Entry>()
            var failed = 0
            for (f in futures) {
                val r = try { f.get() } catch (_: Exception) { null }
                if (r == null) failed++ else all += r
            }
            val newest = HashMap<String, Long>()
            for (e in all) {
                val cid = e.item.channelId
                if (cid.isNotEmpty() && e.published > (newest[cid] ?: 0L)) newest[cid] = e.published
            }
            all.sortByDescending { it.published }
            return Result(all.take(MAX_ITEMS).map { it.item }, ids.size - failed, failed, newest)
        } finally {
            pool.shutdown()
        }
    }

    /** Video terbaru satu channel (sampai [limit], RSS memuat paling banyak 15); null bila gagal. */
    fun channelVideos(channelId: String, limit: Int = 15): List<VideoItem>? =
        fetch(channelId, limit, false)?.sortedByDescending { it.published }?.map { it.item }

    private fun fetch(channelId: String, limit: Int, includeShorts: Boolean): List<Entry>? {
        val conn = URL("https://www.youtube.com/feeds/videos.xml?channel_id=$channelId")
            .openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 15_000
            conn.setRequestProperty("User-Agent", DownloaderImpl.USER_AGENT)
            if (conn.responseCode != 200) null else {
                val all = conn.inputStream.use { parse(it, 15, channelId) }
                val vids = all.filter { !it.item.isShort }.take(limit)
                if (includeShorts) vids + all.filter { it.item.isShort }.take(limit) else vids
            }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(stream: java.io.InputStream, limit: Int, channelId: String): List<Entry> {
        val p = Xml.newPullParser()
        p.setInput(stream, "UTF-8")
        val out = ArrayList<Entry>()
        var inEntry = false
        var inAuthor = false
        var id = ""; var title = ""; var published = ""; var author = ""
        var thumb = ""; var views = -1L; var href = ""
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT && out.size < limit) {
            if (ev == XmlPullParser.START_TAG) {
                val n = p.name.substringAfter(':')
                when {
                    n == "entry" -> {
                        inEntry = true; inAuthor = false
                        id = ""; title = ""; published = ""; author = ""; thumb = ""; views = -1L; href = ""
                    }
                    !inEntry -> {}
                    n == "author" -> inAuthor = true
                    n == "name" && inAuthor -> author = p.nextText()
                    n == "videoId" -> id = p.nextText()
                    n == "title" && title.isEmpty() -> title = p.nextText()
                    n == "published" -> published = p.nextText()
                    n == "thumbnail" -> thumb = p.getAttributeValue(null, "url").orEmpty()
                    n == "statistics" -> views = p.getAttributeValue(null, "views")?.toLongOrNull() ?: -1L
                    n == "link" && p.getAttributeValue(null, "rel") == "alternate" ->
                        href = p.getAttributeValue(null, "href").orEmpty()
                }
            } else if (ev == XmlPullParser.END_TAG) {
                val n = p.name.substringAfter(':')
                if (n == "author") inAuthor = false
                if (n == "entry" && inEntry) {
                    inEntry = false
                    // Shorts memakai tautan /shorts/ (dari ingatan, belum diuji): ditandai isShort.
                    if (id.isNotEmpty()) {
                        val t = try { OffsetDateTime.parse(published).toEpochSecond() } catch (_: Exception) { 0L }
                        out += Entry(
                            t,
                            VideoItem(
                                url = "https://www.youtube.com/watch?v=$id",
                                title = title,
                                uploader = author,
                                thumb = thumb.ifEmpty { null },
                                durationSec = 0,
                                views = views,
                                date = relative(t),
                                isShort = href.contains("/shorts/"),
                                channelId = channelId,
                                publishedAt = t
                            )
                        )
                    }
                }
            }
            ev = p.next()
        }
        return out
    }

    /** Keterangan umur dalam bentuk Inggris ("3 days ago") agar Fmt.indoDate dan Fmt.ageSeconds membacanya. */
    private fun relative(epoch: Long): String {
        if (epoch <= 0) return ""
        val age = (System.currentTimeMillis() / 1000 - epoch).coerceAtLeast(0)
        fun f(n: Long, u: String) = "$n $u${if (n == 1L) "" else "s"} ago"
        return when {
            age < 60 -> "just now"
            age < 3600 -> f(age / 60, "minute")
            age < 86400 -> f(age / 3600, "hour")
            age < 7 * 86400 -> f(age / 86400, "day")
            age < 30 * 86400 -> f(age / (7 * 86400), "week")
            age < 365 * 86400 -> f(age / (30 * 86400), "month")
            else -> f(age / (365 * 86400), "year")
        }
    }
}
