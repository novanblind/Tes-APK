package id.ytplayer

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import androidx.core.view.ViewCompat

/**
 * Masuk ke akun Google/YouTube lewat WebView. Begitu cookie sesi (SAPISID) terdeteksi di
 * youtube.com, cookie disimpan terenkripsi dan layar ditutup sendiri.
 */
class YtLoginActivity : Activity() {

    companion object {
        const val EXTRA_ADD = "tambah_akun"
    }

    private lateinit var web: WebView
    private lateinit var status: TextView
    private var done = false
    private var cleared = false
    private var savedStateFresh = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = getColor(R.color.bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            fitsSystemWindows = true
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val title = TextView(this).apply {
            text = "Masuk ke akun YouTube"
            setTextColor(getColor(R.color.text))
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, dp(8))
        }
        ViewCompat.setAccessibilityHeading(title, true)
        status = TextView(this).apply {
            text = "Masuk seperti biasa di halaman di bawah. Setelah berhasil, layar ini menutup sendiri. Bila muncul tes gambar, cari tombol verifikasi audio (ikon headphone)."
            setTextColor(getColor(R.color.text_secondary))
            textSize = 16f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(0, 0, 0, dp(8))
        }
        web = WebView(this)
        val btnDone = styledButton("Selesai, saya sudah masuk") { tryFinish(manual = true) }
        val cancel = styledButton("Batal") { finish() }
        root.addView(title)
        root.addView(status)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(btnDone)
        root.addView(cancel)
        setContentView(root)

        // Disalin dari YMusic: hanya JavaScript dan DOM storage, identitas peramban bawaan WebView
        // (YMusic tidak mengganti user agent di layar login), tanpa pengaturan tambahan.
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                CookieManager.getInstance().flush()
                val host = try { android.net.Uri.parse(url).host.orEmpty() } catch (_: Exception) { "" }
                if (host.endsWith("youtube.com")) tryFinish(manual = false)
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                val host = try { android.net.Uri.parse(url).host.orEmpty() } catch (_: Exception) { "" }
                if (host.endsWith("youtube.com")) tryFinish(manual = false)
            }
        }
        registerBack()
        savedStateFresh = savedInstanceState == null
        if (savedInstanceState == null) {
            // Hanya cookie di WebView ini yang dikosongkan (salinan akun yang sudah tersimpan tidak disentuh),
            // lalu halaman masuk dibuka. Tanpa cookie, alamat keluar-Google di bawah tidak mengakhiri sesi
            // akun lain di server, jadi akun utama tetap masuk dan layar ini siap untuk akun lain.
            val cm = CookieManager.getInstance()
            clearSessionCookies(cm)
            cleared = true
            web.loadUrl("https://accounts.google.com/Logout?continue=https://m.youtube.com/signin?app=mobile%26persist_app%3D1")
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    /**
     * Membuang cookie SESI akun (SID, SAPISID, dan sejenisnya) dari WebView, tetapi menyisakan cookie
     * penanda perangkat dan persetujuan (NID, SOCS, dan sejenisnya). Dengan begitu Google masih mengenali
     * perangkat ini dan jarang menampilkan tes gambar "pilih semua gambar dengan mobil" saat menambah akun.
     * Bila sesi lama ternyata masih tersisa, semua cookie WebView dibuang sebagai cadangan.
     */
    private fun clearSessionCookies(cm: CookieManager) {
        val keep = setOf(
            "NID", "AEC", "SOCS", "CONSENT", "__Secure-ENID", "PREF", "VISITOR_INFO1_LIVE",
            "VISITOR_PRIVACY_METADATA", "YSC", "__Secure-YEC", "__Secure-BUCKET", "GOOGLE_ABUSE_EXEMPTION"
        )
        val urls = listOf(
            "https://accounts.google.com", "https://www.google.com", "https://google.com",
            "https://www.youtube.com", "https://m.youtube.com", "https://music.youtube.com"
        )
        val expire = "=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/; Secure"
        try {
            for (u in urls) {
                val raw = cm.getCookie(u) ?: continue
                val host = android.net.Uri.parse(u).host.orEmpty()
                for (part in raw.split(";")) {
                    val name = part.substringBefore('=').trim()
                    if (name.isEmpty() || name in keep) continue
                    cm.setCookie(u, name + expire)
                    for (d in listOf("google.com", "youtube.com")) {
                        if (host.endsWith(d)) cm.setCookie(u, "$name$expire; Domain=.$d")
                    }
                }
            }
            cm.flush()
        } catch (_: Throwable) {
        }
        val still = YtAccount.looksLoggedIn(cm.getCookie(YtAccount.ORIGIN)) ||
            YtAccount.looksLoggedIn(cm.getCookie("https://music.youtube.com"))
        if (still) {
            cm.removeAllCookies(null)
            cm.flush()
        }
    }

    private fun styledButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(getColor(R.color.text))
        textSize = 16f
        setBackgroundResource(R.drawable.btn_bg)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply {
            topMargin = dp(8)
        }
        gravity = Gravity.CENTER
        setOnClickListener { onClick() }
    }

    private fun tryFinish(manual: Boolean) {
        if (done) return
        if (!cleared && savedStateFresh) return
        val cm = CookieManager.getInstance()
        var cookie = cm.getCookie(YtAccount.ORIGIN)
        if (!YtAccount.looksLoggedIn(cookie)) cookie = cm.getCookie("https://music.youtube.com")
        if (YtAccount.looksLoggedIn(cookie)) {
            done = true
            try {
                // Menambah akun: simpan dulu akun yang sedang dipakai, lalu akun baru jadi aktif.
                if (intent.getBooleanExtra(EXTRA_ADD, false)) YtAccount.stashActive(this)
                YtAccount.save(this, cookie)
            } catch (_: Throwable) {
                done = false
                status.text = "Gagal menyimpan sesi dengan aman di HP ini. Coba lagi."
                return
            }
            CookieManager.getInstance().flush()
            setResult(RESULT_OK)
            finish()
        } else if (manual) {
            status.text = "Belum terdeteksi masuk. Selesaikan masuk di halaman di atas, lalu tekan tombol ini lagi."
        }
    }

    // Tombol kembali: mundur di halaman WebView dulu, baru tutup layar.
    private fun handleBack() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else finish()
    }

    private var backCb: OnBackInvokedCallback? = null

    private fun registerBack() {
        if (Build.VERSION.SDK_INT >= 33) {
            val cb = OnBackInvokedCallback { handleBack() }
            backCb = cb
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb)
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (Build.VERSION.SDK_INT >= 33) super.onBackPressed() else handleBack()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        if (Build.VERSION.SDK_INT >= 33) backCb?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }
}
