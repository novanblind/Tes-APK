package id.ytplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Panggilan akun ke youtubei (klien WEB) dengan cookie + tanda tangan SAPISIDHASH.
 * Terpisah dari DownloaderImpl: ekstraksi video NewPipe tidak tersentuh.
 * Semua fungsi di sini memblokir jaringan: panggil dari utas latar.
 */
object YtApi {
    // Cadangan bila versi klien gagal diambil dari beranda YouTube.
    private const val FALLBACK_VERSION = "2.20251120.01.00"
    private val VERSION_RE = Regex("\"INNERTUBE_CONTEXT_CLIENT_VERSION\"\\s*:\\s*\"([^\"]+)\"")

    @Volatile private var clientVersion: String? = null

    private fun version(): String {
        clientVersion?.let { return it }
        val v = try {
            val conn = URL("${YtAccount.ORIGIN}/").openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 15_000
            conn.setRequestProperty("User-Agent", YtAccount.UA)
            conn.setRequestProperty("Accept-Language", "id-ID,id;q=0.9")
            val html = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            VERSION_RE.find(html)?.groupValues?.get(1)
        } catch (_: Exception) {
            null
        }
        val result = v ?: FALLBACK_VERSION
        if (v != null) clientVersion = v
        return result
    }

    /** POST ke youtubei/v1/<path>. Galat HTTP dilempar tanpa badan respons (bisa memuat data akun). */
    @Throws(IOException::class)
    fun post(c: Context, path: String, extra: JSONObject = JSONObject(), anon: Boolean = false): JSONObject {
        val auth = if (anon) null else (YtAccount.authorization(c) ?: throw IOException("Belum masuk"))
        val cookie = if (anon) null else (YtAccount.cookie(c) ?: throw IOException("Belum masuk"))
        val ver = version()
        val body = JSONObject(extra.toString()).apply {
            put("context", JSONObject().put("client", JSONObject()
                .put("clientName", "WEB").put("clientVersion", ver)
                .put("hl", "id").put("gl", "ID")))
        }
        val conn = URL("${YtAccount.ORIGIN}/youtubei/v1/$path?prettyPrint=false")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20_000
            conn.readTimeout = 20_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("User-Agent", YtAccount.UA)
            if (cookie != null && auth != null) {
                conn.setRequestProperty("Cookie", cookie)
                conn.setRequestProperty("Authorization", auth)
                conn.setRequestProperty("X-Goog-AuthUser", "0")
                conn.setRequestProperty("X-Youtube-Bootstrap-Logged-In", "true")
            }
            conn.setRequestProperty("Origin", YtAccount.ORIGIN)
            conn.setRequestProperty("X-Origin", YtAccount.ORIGIN)
            conn.setRequestProperty("Accept-Language", "id-ID,id;q=0.9")
            conn.setRequestProperty("Referer", "${YtAccount.ORIGIN}/")
            conn.setRequestProperty("X-YouTube-Client-Name", "1")
            conn.setRequestProperty("X-YouTube-Client-Version", ver)
            val bytes = body.toString().toByteArray(Charsets.UTF_8)
            conn.setFixedLengthStreamingMode(bytes.size)
            conn.outputStream.use { it.write(bytes) }
            val code = conn.responseCode
            if (code != 200) throw IOException("HTTP $code")
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return try { JSONObject(text) } catch (_: Exception) { throw IOException("Respons bukan JSON") }
        } finally {
            conn.disconnect()
        }
    }

    /** Mencari kunci tertentu di seluruh pohon JSON, tidak bergantung pada jalur yang bisa berubah. */
    internal fun findKey(node: Any?, key: String): Any? {
        when (node) {
            is JSONObject -> {
                if (node.has(key)) return node.get(key)
                val ks = node.keys()
                while (ks.hasNext()) findKey(node.opt(ks.next()), key)?.let { r -> return r }
            }
            is JSONArray -> for (i in 0 until node.length()) findKey(node.opt(i), key)?.let { r -> return r }
        }
        return null
    }

    sealed class Status {
        data class Ok(val name: String) : Status()
        object NotLoggedIn : Status()
        object Invalid : Status()
        data class Error(val message: String) : Status()
    }

    /** Tahap 2: periksa apakah sesi masih sah dan ambil nama akun. */
    fun checkStatus(c: Context): Status {
        if (!YtAccount.isLoggedIn(c)) return Status.NotLoggedIn
        return try {
            val json = post(c, "account/account_menu")
            val acc = findKey(json, "accountName") as? JSONObject
            val name = acc?.optString("simpleText")?.takeIf { it.isNotBlank() }
                ?: acc?.optJSONArray("runs")?.optJSONObject(0)?.optString("text")?.takeIf { it.isNotBlank() }
            if (name != null) {
                YtAccount.setName(c, name)
                // Foto profil dan handle (@nama) untuk layar Anda; bila tidak ada di respons, dibiarkan kosong.
                val photoArr = (findKey(json, "accountPhoto") as? JSONObject)?.optJSONArray("thumbnails")
                val photoUrl = photoArr?.optJSONObject(photoArr.length() - 1)?.optString("url").orEmpty()
                val photo = when {
                    photoUrl.isEmpty() -> null
                    photoUrl.startsWith("//") -> "https:$photoUrl"
                    else -> photoUrl
                }
                val handle = textOf(findKey(json, "channelHandle") as? JSONObject).takeIf { it.isNotBlank() }
                YtAccount.setProfile(c, photo, handle)
                Status.Ok(name)
            } else {
                Status.Invalid
            }
        } catch (e: IOException) {
            val m = e.message ?: "galat jaringan"
            if (m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) Status.Invalid else Status.Error(m)
        } catch (e: Exception) {
            Status.Error(e.javaClass.simpleName)
        }
    }

    private val CHANNEL_RE = Regex("/channel/(UC[A-Za-z0-9_-]{22})")

    /** ID channel (UC...) dari tautan channel NewPipe; null bila bentuk tautannya lain (mis. /@nama). */
    fun channelIdFromUrl(url: String?): String? = url?.let { CHANNEL_RE.find(it)?.groupValues?.get(1) }

    // Parameter dari kode YMusic: subscribe "EgIIAhgA", berhenti subscribe "CgIIAhgA".
    private const val PARAMS_SUBSCRIBE = "EgIIAhgA"
    private const val PARAMS_UNSUBSCRIBE = "CgIIAhgA"

    sealed class Result {
        object Ok : Result()
        object NotLoggedIn : Result()
        object Invalid : Result()
        data class Error(val message: String) : Result()
    }

    /** Tahap 3: subscribe (true) atau berhenti subscribe (false) ke satu channel. */
    fun setSubscribed(c: Context, channelId: String, subscribe: Boolean): Result {
        if (!YtAccount.isLoggedIn(c)) return Result.NotLoggedIn
        return try {
            val extra = JSONObject()
                .put("channelIds", JSONArray().put(channelId))
                .put("params", if (subscribe) PARAMS_SUBSCRIBE else PARAMS_UNSUBSCRIBE)
            post(c, if (subscribe) "subscription/subscribe" else "subscription/unsubscribe", extra)
            YtAccount.markSub(c, channelId, subscribe)
            Result.Ok
        } catch (e: IOException) {
            val m = e.message ?: "galat jaringan"
            if (m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) Result.Invalid else Result.Error(m)
        } catch (e: Exception) {
            Result.Error(e.javaClass.simpleName)
        }
    }

    class Channel(val id: String, val title: String, val subs: String, val thumb: String? = null)

    /** Daftar channel subscribe terakhir yang berhasil dimuat; dipakai baris foto channel di layar channel. */
    @Volatile var cachedChannels: List<Channel> = emptyList()

    /** Isi teks dari {"simpleText":..} atau {"runs":[{"text":..}]}. */
    internal fun textOf(o: JSONObject?): String {
        if (o == null) return ""
        o.optString("simpleText").takeIf { it.isNotBlank() }?.let { return it }
        val runs = o.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) sb.append(runs.optJSONObject(i)?.optString("text").orEmpty())
        return sb.toString()
    }

    /** URL foto channel (thumbnail terakhir = terbesar); "//host/..." dijadikan https. */
    private fun thumbOf(v: JSONObject): String? {
        val arr = v.optJSONObject("thumbnail")?.optJSONArray("thumbnails") ?: return null
        val u = arr.optJSONObject(arr.length() - 1)?.optString("url").orEmpty()
        return when {
            u.isEmpty() -> null
            u.startsWith("//") -> "https:$u"
            else -> u
        }
    }

    /** Mengumpulkan semua channelRenderer / gridChannelRenderer di pohon JSON. */
    private fun collectChannels(node: Any?, out: MutableList<Channel>, kinds: MutableSet<String>) {
        when (node) {
            is JSONObject -> {
                val ks = node.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    val v = node.opt(k)
                    if (k.endsWith("Renderer") || k.endsWith("ViewModel")) kinds.add(k)
                    if ((k == "channelRenderer" || k == "gridChannelRenderer") && v is JSONObject) {
                        val id = v.optString("channelId")
                        if (id.startsWith("UC")) {
                            out += Channel(
                                id,
                                textOf(v.optJSONObject("title")).ifBlank { id },
                                textOf(v.optJSONObject("subscriberCountText")).ifBlank { textOf(v.optJSONObject("videoCountText")) },
                                thumbOf(v)
                            )
                        }
                    } else {
                        collectChannels(v, out, kinds)
                    }
                }
            }
            is JSONArray -> for (i in 0 until node.length()) collectChannels(node.opt(i), out, kinds)
        }
    }

    sealed class ListResult {
        data class Ok(val channels: List<Channel>) : ListResult()
        /** Respons diterima tetapi tidak ada channel yang dikenali; [kinds] membantu menyesuaikan parser. */
        data class Unrecognized(val kinds: List<String>) : ListResult()
        object NotLoggedIn : ListResult()
        object Invalid : ListResult()
        data class Error(val message: String) : ListResult()
    }

    /** Tahap 4: daftar channel yang di-subscribe (browse FEchannels, sampai 10 halaman lanjutan). */
    fun listSubscriptions(c: Context): ListResult {
        if (!YtAccount.isLoggedIn(c)) return ListResult.NotLoggedIn
        return try {
            val all = LinkedHashMap<String, Channel>()
            val kinds = LinkedHashSet<String>()
            var json = post(c, "browse", JSONObject().put("browseId", "FEchannels"))
            var page = 0
            while (true) {
                val found = ArrayList<Channel>()
                collectChannels(json, found, kinds)
                found.forEach { all.putIfAbsent(it.id, it) }
                page++
                val cont = findKey(json, "continuationCommand") as? JSONObject
                val token = cont?.optString("token").orEmpty()
                if (token.isEmpty() || page >= 10) break
                json = post(c, "browse", JSONObject().put("continuation", token))
            }
            if (all.isEmpty()) ListResult.Unrecognized(kinds.take(25))
            else {
                YtAccount.setSubs(c, all.keys)
                cachedChannels = all.values.toList()
                ListResult.Ok(all.values.toList())
            }
        } catch (e: IOException) {
            val m = e.message ?: "galat jaringan"
            if (m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) ListResult.Invalid else ListResult.Error(m)
        } catch (e: Exception) {
            ListResult.Error(e.javaClass.simpleName)
        }
    }
}
