package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Outline
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat

/**
 * Halaman channel ala YouTube ("Kunjungi channel"): banner, foto, nama, @handle, jumlah subscriber dan
 * video, deskripsi ringkas, tombol subscribe, tab (Beranda, Video, Shorts, Live, Postingan, ...), dan
 * isi tab berupa bagian-bagian video (mis. "Live streaming sebelumnya"). Data dari [YtChannel].
 */
class ChannelPageActivity : Activity() {

    companion object {
        private const val EXTRA_ID = "channel_id"
        private const val EXTRA_NAME = "channel_name"
        fun intent(c: Context, id: String, name: String): Intent =
            Intent(c, ChannelPageActivity::class.java).putExtra(EXTRA_ID, id).putExtra(EXTRA_NAME, name)
    }

    private var channelId = ""
    private var channelName = ""
    private var info: YtChannel.Info? = null
    private var tabs: List<YtChannel.Tab> = emptyList()
    private var tabIdx = 0
    private var seq = 0
    private var loadingMore = false
    private val cache = HashMap<Int, YtChannel.TabData>()
    private val shown = ArrayList<VideoItem>()

    private lateinit var scroll: ScrollView
    private lateinit var banner: ImageView
    private lateinit var avatar: ImageView
    private lateinit var nameView: TextView
    private lateinit var handleView: TextView
    private lateinit var statsView: TextView
    private lateinit var descView: TextView
    private lateinit var btnSub: Button
    private lateinit var tabRow: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var btnMore: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        channelId = intent.getStringExtra(EXTRA_ID).orEmpty()
        channelName = intent.getStringExtra(EXTRA_NAME).orEmpty().ifBlank { "Channel" }
        info = YtChannel.Info(channelId, channelName, "", null, null, "", "", "", emptyList())
        tabs = listOf(YtChannel.Tab("Beranda", null, true))
        buildUi()
        updateSubButton()
        renderTabs()
        loadHome()
    }

    override fun onResume() {
        super.onResume()
        if (::btnSub.isInitialized) updateSubButton()
    }

    // ---- tampilan

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            fitsSystemWindows = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        bar.addView(iconButton(R.drawable.ic_arrow_back, "Kembali") { finish() })
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(iconButton(R.drawable.ic_search, "Cari video channel ini") { searchChannel() })
        bar.addView(iconButton(R.drawable.ic_more_vert, "Opsi lainnya") { showOptions() })
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        scroll = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        banner = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.avatar_bg)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(12).toFloat()) }
            }
            clipToOutline = true
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            visibility = View.GONE
        }
        // Banner YouTube kira-kira 3,6 : 1.
        val bannerBox = RatioFrameLayout(this).apply {
            ratio = 3.6f
            addView(banner, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        col.addView(bannerBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(16), dp(4), dp(16), 0)
        })

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), 0)
        }
        avatar = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.avatar_bg)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
            clipToOutline = true
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        head.addView(avatar, LinearLayout.LayoutParams(dp(88), dp(88)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        nameView = text(channelName, 24f, R.color.text, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
        ViewCompat.setAccessibilityHeading(nameView, true)
        handleView = text("", 14f, R.color.text_secondary, false).apply { visibility = View.GONE }
        statsView = text("", 14f, R.color.text_secondary, false).apply { visibility = View.GONE }
        names.addView(nameView)
        names.addView(handleView)
        names.addView(statsView)
        head.addView(names, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(16) })
        col.addView(head)

        descView = text("", 14f, R.color.text_secondary, false).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            visibility = View.GONE
            isClickable = true
            isFocusable = true
            setPadding(dp(16), dp(12), dp(16), dp(4))
            setOnClickListener { showAbout() }
        }
        col.addView(descView)

        btnSub = Button(this).apply {
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            compoundDrawablePadding = dp(8)
            setPadding(dp(16), 0, dp(16), 0)
            setOnClickListener {
                SubscribeHelper.toggle(this@ChannelPageActivity, channelId, channelName,
                    { say(it) }) { updateSubButton() }
            }
        }
        col.addView(btnSub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            setMargins(dp(16), dp(12), dp(16), dp(8))
        })

        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), 0, dp(8), 0)
        }
        tabScroll.addView(tabRow)
        col.addView(tabScroll)
        col.addView(View(this).apply { setBackgroundColor(getColor(R.color.outline)) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))

        status = text("", 14f, R.color.text_secondary, false).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        col.addView(status)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(content)
        btnMore = Button(this).apply {
            text = "Muat lagi"
            isAllCaps = false
            setTextColor(getColor(R.color.text))
            setBackgroundResource(R.drawable.btn_bg)
            visibility = View.GONE
            setOnClickListener { loadMore() }
        }
        col.addView(btnMore, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            setMargins(dp(16), dp(8), dp(16), dp(24))
        })

        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun text(t: String, sp: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(getColor(color))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun iconButton(icon: Int, desc: String, onClick: () -> Unit) = ImageButton(this).apply {
        setImageResource(icon)
        contentDescription = desc
        val tv = android.util.TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        setBackgroundResource(tv.resourceId)
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        setOnClickListener { onClick() }
    }

    private fun say(msg: String) {
        status.visibility = View.VISIBLE
        status.text = msg
    }

    private fun updateSubButton() {
        val subscribed = SubscribeHelper.isSubscribed(this, channelId)
        btnSub.contentDescription = SubscribeHelper.label(this, channelId, channelName)
        if (subscribed) {
            btnSub.text = "Disubscribe"
            btnSub.setTextColor(getColor(R.color.text))
            btnSub.setBackgroundResource(R.drawable.btn_bg)
            btnSub.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_bell, 0, R.drawable.ic_expand_more, 0)
        } else {
            btnSub.text = "Subscribe"
            btnSub.setTextColor(getColor(R.color.chip_selected_text))
            btnSub.setBackgroundResource(R.drawable.btn_pill_filled)
            btnSub.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0)
        }
    }

    private fun bindInfo(i: YtChannel.Info) {
        nameView.text = i.title
        titleForAccessibility(i)
        if (i.handle.isNotBlank()) { handleView.text = i.handle; handleView.visibility = View.VISIBLE }
        val stats = listOf(i.subs, i.videos).filter { it.isNotBlank() }.joinToString(" • ")
        if (stats.isNotBlank()) { statsView.text = stats; statsView.visibility = View.VISIBLE }
        ImageLoader.load(avatar, i.avatar)
        if (i.banner != null) {
            banner.visibility = View.VISIBLE
            ImageLoader.load(banner, i.banner)
        }
        if (i.description.isNotBlank()) {
            descView.text = i.description.replace(Regex("\\s*\\n\\s*"), " ")
            descView.contentDescription = "Deskripsi channel: ${descView.text}. Ketuk untuk selengkapnya"
            descView.visibility = View.VISIBLE
        }
        channelName = i.title
        updateSubButton()
    }

    private fun titleForAccessibility(i: YtChannel.Info) {
        nameView.contentDescription = i.title
    }

    private fun renderTabs() {
        tabRow.removeAllViews()
        tabs.forEachIndexed { idx, t ->
            val selected = idx == tabIdx
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
                isSelected = selected
                contentDescription = if (selected) "Tab ${t.title}, dipilih" else "Tab ${t.title}"
                setOnClickListener { if (idx != tabIdx) showTab(idx) }
            }
            val tv = text(t.title, 15f, if (selected) R.color.text else R.color.text_secondary, selected).apply {
                gravity = Gravity.CENTER
                minHeight = dp(44)
                setPadding(dp(14), dp(10), dp(14), dp(6))
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            val line = View(this).apply {
                setBackgroundColor(getColor(R.color.text))
                visibility = if (selected) View.VISIBLE else View.INVISIBLE
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            box.addView(tv)
            box.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
            tabRow.addView(box)
        }
    }

    // ---- data

    private fun loadHome() {
        say("Memuat halaman channel, mohon tunggu.")
        val my = ++seq
        val id = channelId
        Thread {
            val r = YtChannel.load(this, id)
            // Bila gagal, tampilkan setidaknya video terbaru dari RSS agar halaman tidak kosong.
            val rss = if (r is YtChannel.Load.Error) YtFeed.channelVideos(id) else null
            runOnUiThread {
                if (isFinishing || isDestroyed || my != seq) return@runOnUiThread
                when (r) {
                    is YtChannel.Load.Ok -> {
                        val page = r.page
                        info = page.info
                        bindInfo(page.info)
                        tabs = page.info.tabs.ifEmpty { listOf(YtChannel.Tab("Beranda", null, true)) }
                        tabIdx = tabs.indexOfFirst { it.selected }.coerceAtLeast(0)
                        cache[tabIdx] = YtChannel.TabData(page.sections, page.more)
                        renderTabs()
                        showTab(tabIdx)
                    }
                    is YtChannel.Load.Error -> {
                        val items = rss.orEmpty()
                        if (items.isNotEmpty()) {
                            cache[0] = YtChannel.TabData(listOf(YtChannel.Section("Video terbaru", items)), null)
                            showTab(0)
                            say("Halaman lengkap channel gagal dimuat (${r.message}). Menampilkan video terbaru saja.")
                        } else {
                            say("Gagal memuat halaman channel: ${r.message}. Periksa sambungan internet.")
                        }
                    }
                }
            }
        }.start()
    }

    private fun showTab(idx: Int) {
        tabIdx = idx
        renderTabs()
        content.removeAllViews()
        shown.clear()
        btnMore.visibility = View.GONE
        val my = ++seq
        val cached = cache[idx]
        if (cached != null) { renderData(cached); return }
        val tab = tabs[idx]
        val inf = info ?: return
        say("Memuat ${tab.title}, mohon tunggu.")
        Thread {
            val d: YtChannel.TabData? = try { YtChannel.loadTab(this, inf, tab) } catch (_: Exception) { null }
            runOnUiThread {
                if (isFinishing || isDestroyed || my != seq) return@runOnUiThread
                if (d == null) {
                    say("Gagal memuat ${tab.title}. Periksa sambungan internet.")
                } else {
                    cache[idx] = d
                    renderData(d)
                }
            }
        }.start()
    }

    private fun renderData(d: YtChannel.TabData) {
        renderSections(d.sections)
        val has = d.sections.any { it.items.isNotEmpty() || it.posts.isNotEmpty() }
        if (has) {
            status.visibility = View.GONE
            content.announceForAccessibility("Tab ${tabs[tabIdx].title}, ${shown.size} video")
        } else {
            say("Tidak ada isi yang bisa ditampilkan di tab ${tabs[tabIdx].title}.")
        }
        btnMore.visibility = if (d.more != null) View.VISIBLE else View.GONE
    }

    private fun loadMore() {
        val idx = tabIdx
        val old = cache[idx] ?: return
        val token = old.more ?: return
        val inf = info ?: return
        if (loadingMore) return
        loadingMore = true
        btnMore.isEnabled = false
        btnMore.text = "Memuat..."
        Thread {
            val d: YtChannel.TabData? = try { YtChannel.loadMore(this, inf, token) } catch (_: Exception) { null }
            runOnUiThread {
                loadingMore = false
                btnMore.isEnabled = true
                btnMore.text = "Muat lagi"
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (d == null) {
                    Toast.makeText(this, "Gagal memuat lagi. Periksa sambungan internet.", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val merged = YtChannel.TabData(old.sections + d.sections, d.more)
                cache[idx] = merged
                if (idx == tabIdx) {
                    renderSections(d.sections)
                    btnMore.visibility = if (d.more != null) View.VISIBLE else View.GONE
                    content.announceForAccessibility("${d.sections.sumOf { it.items.size }} video ditambahkan")
                }
            }
        }.start()
    }

    private fun renderSections(sections: List<YtChannel.Section>) {
        for (s in sections) {
            if (s.title.isNotBlank()) content.addView(sectionHeader(s.title))
            for (v in s.items) {
                shown += v
                val row = layoutInflater.inflate(R.layout.item_video_row, content, false)
                VideoBinder.bind(row, v) { i, audio -> openVideo(i, audio) }
                content.addView(row)
            }
            for (p in s.posts) content.addView(postView(p))
        }
    }

    private fun sectionHeader(title: String): View {
        val tv = text(title, 18f, R.color.text, true).apply {
            setPadding(dp(16), dp(20), dp(16), dp(8))
            setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_chevron_right, 0)
            compoundDrawablePadding = dp(4)
        }
        ViewCompat.setAccessibilityHeading(tv, true)
        return tv
    }

    private fun postView(p: YtChannel.Post): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            isFocusable = true
            contentDescription = if (p.date.isBlank()) p.text else "${p.text}. ${Fmt.indoDate(p.date)}"
        }
        val body = text(p.text, 15f, R.color.text, false).apply {
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        box.addView(body)
        if (p.date.isNotBlank()) {
            box.addView(text(Fmt.indoDate(p.date), 12f, R.color.text_secondary, false).apply {
                setPadding(0, dp(4), 0, 0)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            })
        }
        box.addView(View(this).apply { setBackgroundColor(getColor(R.color.outline)) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(12) })
        return box
    }

    private fun openVideo(item: VideoItem, audio: Boolean?) {
        if (audio != null) Store.setAudioOnly(this, audio)
        Repo.prefetch(item.url)
        PlayQueue.set(ArrayList(shown), PlayQueue.newSourceId(), null)
        startActivity(PlayerActivity.intent(this, item))
    }

    // ---- aksi

    private fun searchChannel() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(MainActivity.EXTRA_QUERY, channelName)
        )
    }

    private fun channelUrl(): String {
        val h = info?.handle.orEmpty()
        return if (h.startsWith("@")) "https://www.youtube.com/$h" else "https://www.youtube.com/channel/$channelId"
    }

    private fun showOptions() {
        val labels = arrayOf("Bagikan channel", "Buka di peramban", "Cari video channel ini")
        AlertDialog.Builder(this)
            .setTitle(channelName)
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> startActivity(
                        Intent.createChooser(
                            Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_SUBJECT, channelName)
                                .putExtra(Intent.EXTRA_TEXT, "$channelName\n${channelUrl()}"),
                            "Bagikan channel"
                        )
                    )
                    1 -> try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(channelUrl())))
                    } catch (_: ActivityNotFoundException) {
                        Toast.makeText(this, "Tidak ada peramban untuk membuka tautan ini", Toast.LENGTH_SHORT).show()
                    }
                    else -> searchChannel()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showAbout() {
        val i = info ?: return
        val lines = ArrayList<String>()
        if (i.handle.isNotBlank()) lines += i.handle
        listOf(i.subs, i.videos).filter { it.isNotBlank() }.joinToString(" • ").takeIf { it.isNotBlank() }?.let { lines += it }
        if (i.description.isNotBlank()) lines += "\n" + i.description
        AlertDialog.Builder(this)
            .setTitle(i.title)
            .setMessage(lines.joinToString("\n"))
            .setPositiveButton("Tutup", null)
            .show()
    }
}
