package id.ytplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.os.Build
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityActionCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import org.schabi.newpipe.extractor.stream.StreamInfo
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Shorts ala YouTube: video vertikal layar penuh, usap ke atas untuk video berikutnya (ke bawah untuk
 * sebelumnya), ketuk untuk jeda/putar, video berulang. Sumber: pencarian Shorts, disaring durasi <= 3 menit.
 * Untuk TalkBack: satu elemen fokus dengan tindakan "Video berikutnya/sebelumnya" (juga lewat gerakan
 * gulir TalkBack), plus tombol suka, unduh, bagikan, dan subscribe yang berlabel.
 */
class ShortsActivity : Activity() {

    companion object {
        // Setiap pemuatan memilih topik acak, supaya Shorts tidak itu-itu saja.
        private val TOPICS = listOf(
            "#shorts Indonesia", "#shorts lucu", "#shorts viral Indonesia", "#shorts bola", "#shorts musik",
            "#shorts masak", "#shorts religi", "#shorts hewan", "#shorts olahraga", "#shorts otomotif",
            "#shorts game", "#shorts berita", "#shorts komedi", "#shorts tutorial", "#shorts anime",
            "#shorts motivasi", "#shorts jalan jalan", "#shorts teknologi", "#shorts film", "#shorts kuliner"
        )
        private const val SEEN_KEEP = 400
        private const val MAX_SEC = 180L
    }

    private val ui = Handler(Looper.getMainLooper())
    private val items = ArrayList<VideoItem>()
    private val seen = HashSet<String>()
    private val usedTopics = ArrayList<String>()
    private val prefs by lazy { getSharedPreferences("shorts_seen", MODE_PRIVATE) }
    // Video yang sudah pernah ditonton di sesi sebelumnya: dilewati supaya selalu ada yang baru.
    private val oldSeen: HashSet<String> by lazy {
        HashSet((prefs.getString("urls", "") ?: "").split("\n").filter { it.isNotEmpty() })
    }
    private var index = -1
    private var token = 0
    private var feedLoading = false
    private var wantNext = false
    private var wasPlaying = true
    private var curInfo: StreamInfo? = null
    private var curChannelId: String? = null

    private lateinit var player: ExoPlayer
    private lateinit var sourceFactory: DefaultMediaSourceFactory
    private lateinit var videoBox: FrameLayout
    private lateinit var surface: TextureView
    private lateinit var blurBg: ImageView
    private lateinit var rootView: FrameLayout
    private var landscape = false
    private lateinit var touch: View
    private lateinit var status: TextView
    private lateinit var uploaderView: TextView
    private lateinit var titleView: TextView
    private lateinit var btnSub: Button
    private lateinit var btnLike: ImageView
    private lateinit var progress: View

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility =
            window.decorView.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        buildPlayer()
        buildUi()
        loadFeed()
    }

    private fun buildPlayer() {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(DownloaderImpl.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
        sourceFactory = DefaultMediaSourceFactory(this).setDataSourceFactory(http)
        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            repeatMode = Player.REPEAT_MODE_ONE
            addListener(object : Player.Listener {
                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    fit(
                        (videoSize.width * videoSize.pixelWidthHeightRatio).toInt(),
                        videoSize.height
                    )
                }

                override fun onRenderedFirstFrame() {
                    videoBox.alpha = 1f
                    status.visibility = View.GONE
                }

                override fun onPlayerError(error: PlaybackException) {
                    val my = token
                    say("Gagal memutar video ini. Lanjut ke video berikutnya.")
                    ui.postDelayed({ if (my == token) next() }, 1200)
                }
            })
        }
    }

    // ---- tampilan

    private fun buildUi() {
        // Bilah status dan tombol navigasi HP (termasuk Kembali) tetap tampil dan bisa ditekan;
        // video memenuhi area di antara keduanya, seperti YouTube asli.
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            fitsSystemWindows = true
        }
        rootView = root
        videoBox = FrameLayout(this).apply { alpha = 0f }
        // Latar buram untuk video lebar (seperti YouTube): isi layar dengan warna video itu sendiri.
        blurBg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setColorFilter(0xFF8A8A8A.toInt(), PorterDuff.Mode.MULTIPLY)
            visibility = View.GONE
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        videoBox.addView(blurBg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        surface = TextureView(this)
        videoBox.addView(surface, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        player.setVideoTextureView(surface)
        root.addView(videoBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Bayangan bawah supaya teks terbaca di atas video terang.
        val shade = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, 0xAA000000.toInt())
            )
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        root.addView(shade, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260), Gravity.BOTTOM))

        // Lapisan sentuh: usap atas/bawah ganti video, ketuk jeda/putar. Satu elemen fokus TalkBack.
        touch = View(this).apply {
            isFocusable = true
            contentDescription = "Shorts, memuat"
            setOnClickListener { togglePause() }
        }
        // Usap atas/bawah dihitung dari jarak saja (tanpa syarat kecepatan) supaya selalu terbaca.
        var downX = 0f
        var downY = 0f
        touch.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y }
                MotionEvent.ACTION_UP -> {
                    val dy = ev.y - downY
                    val dx = ev.x - downX
                    if (abs(dy) >= dp(50) && abs(dy) > abs(dx)) {
                        if (dy < 0) next() else previous()
                    } else if (abs(dy) < dp(16) && abs(dx) < dp(16)) {
                        togglePause()
                    }
                }
            }
            true
        }
        ViewCompat.addAccessibilityAction(touch, "Video berikutnya") { _, _ -> next(); true }
        ViewCompat.addAccessibilityAction(touch, "Video sebelumnya") { _, _ -> previous(); true }
        ViewCompat.addAccessibilityAction(touch, "Putar audio saja") { _, _ -> openInPlayer(true); true }
        ViewCompat.replaceAccessibilityAction(touch, AccessibilityActionCompat.ACTION_SCROLL_FORWARD, "Video berikutnya") { _, _ -> next(); true }
        ViewCompat.replaceAccessibilityAction(touch, AccessibilityActionCompat.ACTION_SCROLL_BACKWARD, "Video sebelumnya") { _, _ -> previous(); true }
        root.addView(touch, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Atas: kembali dan titik tiga.
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(iconBtn(R.drawable.ic_arrow_back, "Kembali") { finish() })
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(iconBtn(R.drawable.ic_more_vert, "Opsi lainnya untuk video ini") {
            items.getOrNull(index)?.let { VideoBinder.showMenu(this, it) { v, audio -> openInPlayer(audio, v) } }
        })
        root.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56), Gravity.TOP).apply {
            setMargins(dp(4), dp(4), dp(4), 0)
        })

        // Kanan: suka (favorit), unduh, bagikan.
        val side = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        btnLike = ImageView(this)
        side.addView(sideItem(btnLike, R.drawable.ic_thumb_up, "Suka", "Suka. Tambah atau hapus dari video yang disukai") { toggleLike() })
        side.addView(sideItem(ImageView(this), R.drawable.ic_download, "Unduh", "Unduh video ini") { downloadDialog() })
        side.addView(sideItem(ImageView(this), R.drawable.ic_share, "Bagikan", "Bagikan tautan video") {
            items.getOrNull(index)?.let { VideoBinder.shareLink(this, it.title, it.url) }
        })
        root.addView(side, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(8), dp(28))
        })

        // Kiri bawah: pengunggah + subscribe, judul.
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        uploaderView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; setTypeface(typeface, Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        btnSub = Button(this).apply {
            isAllCaps = false; textSize = 14f; minHeight = dp(48); minimumHeight = dp(48)
            setPadding(dp(16), 0, dp(16), 0)
            visibility = View.GONE
            setOnClickListener { toggleSub() }
        }
        row.addView(uploaderView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0f).apply { marginEnd = dp(12) })
        row.addView(btnSub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)))
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        info.addView(row)
        info.addView(titleView)
        root.addView(info, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(16), 0, dp(88), dp(20))
        })

        // Bilah kemajuan tipis di dasar.
        progress = View(this).apply {
            setBackgroundColor(Color.WHITE)
            pivotX = 0f
            scaleX = 0f
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        root.addView(progress, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2), Gravity.BOTTOM))

        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setPadding(dp(24), 0, dp(24), 0)
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            text = "Memuat Shorts, mohon tunggu."
        }
        root.addView(status, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        setContentView(root)
        ui.post(progressTick)
    }

    private fun iconBtn(icon: Int, desc: String, onClick: () -> Unit) = ImageView(this).apply {
        setImageResource(icon)
        setColorFilter(Color.WHITE)
        contentDescription = desc
        isFocusable = true
        isClickable = true
        setPadding(dp(12), dp(12), dp(12), dp(12))
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        setOnClickListener { onClick() }
    }

    private fun sideItem(icon: ImageView, res: Int, label: String, desc: String, onClick: () -> Unit): View {
        icon.setImageResource(res)
        icon.setColorFilter(Color.WHITE)
        icon.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isClickable = true
            isFocusable = true
            contentDescription = desc
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { onClick() }
        }
        box.addView(icon, LinearLayout.LayoutParams(dp(32), dp(32)))
        box.addView(TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        })
        return box
    }

    private fun say(msg: String) {
        status.visibility = View.VISIBLE
        status.text = msg
    }

    /** Video vertikal memenuhi layar (sedikit terpotong); video lebar muat utuh di tengah. */
    private fun fit(vw: Int, vh: Int) {
        if (vw <= 0 || vh <= 0) return
        val cw = videoBox.width
        val ch = videoBox.height
        if (cw == 0 || ch == 0) { videoBox.post { fit(vw, vh) }; return }
        val sx = cw.toFloat() / vw
        val sy = ch.toFloat() / vh
        landscape = vw >= vh
        val scale = if (vw < vh) max(sx, sy) else min(sx, sy)
        blurBg.visibility = if (landscape) View.VISIBLE else View.GONE
        surface.layoutParams = FrameLayout.LayoutParams((vw * scale).toInt(), (vh * scale).toInt(), Gravity.CENTER)
    }

    private val progressTick = object : Runnable {
        override fun run() {
            val d = player.duration
            progress.scaleX = if (d > 0) (player.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
            if (landscape && player.isPlaying && surface.isAvailable) {
                try {
                    // Gambar sangat kecil, lalu direntang memenuhi layar: hasilnya buram.
                    blurBg.setImageBitmap(surface.getBitmap(Bitmap.createBitmap(24, 14, Bitmap.Config.ARGB_8888)))
                } catch (_: Throwable) { }
            }
            ui.postDelayed(this, 300)
        }
    }

    // ---- daftar Shorts

    private fun accept(list: List<VideoItem>) {
        val ok = list.filter { it.durationSec in 1..MAX_SEC && it.url !in seen }
        val fresh = ok.filter { it.url !in oldSeen }
        // Diacak per kiriman; bila semua sudah pernah ditonton, tetap dipakai daripada kosong.
        for (v in (if (fresh.isNotEmpty()) fresh else ok).shuffled()) {
            seen.add(v.url)
            items += v
        }
    }

    private fun pickTopic(): String {
        val recent = usedTopics.takeLast(6)
        val t = TOPICS.filter { it !in recent }.random()
        usedTopics += t
        return t
    }

    private fun rememberSeen(url: String) {
        if (!oldSeen.add(url)) return
        val list = (prefs.getString("urls", "") ?: "").split("\n").filter { it.isNotEmpty() }.toMutableList()
        list += url
        prefs.edit().putString("urls", list.takeLast(SEEN_KEEP).joinToString("\n")).apply()
    }

    /** Usap ke bawah di Shorts pertama: muat Shorts baru, seperti YouTube asli. */
    private fun refreshFeed() {
        if (feedLoading) { touch.announceForAccessibility("Sedang memuat, mohon tunggu"); return }
        token++
        player.stop()
        items.clear()
        index = -1
        wantNext = false
        videoBox.alpha = 0f
        say("Memuat Shorts baru, mohon tunggu.")
        loadFeed()
    }

    private fun loadFeed() {
        feedLoading = true
        Repo.startSearch(
            pickTopic(), 0L,
            cb = { _, first, err ->
                if (isFinishing || isDestroyed) return@startSearch
                if (err != null) {
                    feedLoading = false
                    if (items.isEmpty()) say("Gagal memuat Shorts: $err")
                    else if (wantNext) { wantNext = false; status.visibility = View.GONE; Toast.makeText(this, "Gagal memuat Shorts baru", Toast.LENGTH_SHORT).show() }
                    return@startSearch
                }
                accept(first)
                if (index < 0 && items.isNotEmpty()) play(0)
                else if (wantNext && index + 1 < items.size) { wantNext = false; next() }
            },
            onMore = { more ->
                if (isFinishing || isDestroyed) return@startSearch
                accept(more)
                if (index < 0 && items.isNotEmpty()) play(0)
                if (wantNext && index + 1 < items.size) { wantNext = false; next() }
            },
            onDone = {
                feedLoading = false
                if (isFinishing || isDestroyed) return@startSearch
                if (items.isEmpty()) say("Tidak ada video Shorts yang ditemukan.")
                else if (wantNext && index + 1 >= items.size) {
                    wantNext = false
                    status.visibility = View.GONE
                    Toast.makeText(this, "Tidak ada Shorts baru", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // ---- pemutaran

    private fun play(i: Int) {
        if (i !in items.indices) return
        index = i
        val item = items[i]
        val my = ++token
        curInfo = null
        curChannelId = null
        wantNext = false
        videoBox.alpha = 0f
        blurBg.setImageDrawable(null)
        landscape = false
        player.stop()
        say("Memuat video ${i + 1}, mohon tunggu.")
        bind(item)
        rememberSeen(item.url)
        // Hampir habis: muat topik acak berikutnya di latar belakang (tanpa akhir).
        if (items.size - i <= 3 && !feedLoading) loadFeed()
        items.getOrNull(i + 1)?.let { Repo.prefetch(it.url) }
        Repo.fetchStream(item.url) { info, err ->
            if (isFinishing || isDestroyed || my != token) return@fetchStream
            if (info == null) {
                say(err ?: "Gagal memuat video ini.")
                ui.postDelayed({ if (my == token) next() }, 1500)
                return@fetchStream
            }
            val res = StreamResolver.resolve(info, false, 480)
            if (res == null) {
                say("Video ini tidak punya aliran yang bisa diputar. Lanjut ke berikutnya.")
                ui.postDelayed({ if (my == token) next() }, 1500)
                return@fetchStream
            }
            curInfo = info
            curChannelId = YtApi.channelIdFromUrl(info.uploaderUrl)
            updateSub()
            val mi = MediaItem.Builder().setUri(res.uri)
                .apply { if (res.hls) setMimeType(MimeTypes.APPLICATION_M3U8) }
                .build()
            if (res.audioUri == null) {
                player.setMediaItem(mi)
            } else {
                val v = sourceFactory.createMediaSource(mi)
                val a = sourceFactory.createMediaSource(MediaItem.fromUri(res.audioUri))
                player.setMediaSource(MergingMediaSource(v, a))
            }
            player.prepare()
            player.playWhenReady = true
            wasPlaying = true
        }
    }

    private fun bind(item: VideoItem) {
        uploaderView.text = item.uploader
        titleView.text = item.title
        btnSub.visibility = View.GONE
        progress.scaleX = 0f
        updateLike()
        touch.contentDescription = "Shorts ${index + 1}. ${item.title}. Oleh ${item.uploader}. " +
            "Ketuk dua kali untuk jeda atau putar. Gunakan Tindakan untuk video berikutnya."
    }

    private fun next() {
        if (index + 1 < items.size) {
            play(index + 1)
        } else if (feedLoading) {
            wantNext = true
            say("Memuat Shorts berikutnya, mohon tunggu.")
        } else if (items.isNotEmpty()) {
            wantNext = true
            say("Memuat Shorts berikutnya, mohon tunggu.")
            loadFeed()
        }
    }

    private fun previous() {
        if (index > 0) play(index - 1) else refreshFeed()
    }

    private fun togglePause() {
        if (player.playbackState == Player.STATE_IDLE) return
        val now = !player.playWhenReady
        player.playWhenReady = now
        wasPlaying = now
        touch.announceForAccessibility(if (now) "Diputar" else "Dijeda")
    }

    // ---- aksi sisi kanan dan subscribe

    private fun updateLike() {
        val fav = items.getOrNull(index)?.let { Store.isFavorite(this, it.url) } == true
        btnLike.setColorFilter(if (fav) 0xFFFF4E45.toInt() else Color.WHITE)
    }

    private fun toggleLike() {
        val item = items.getOrNull(index) ?: return
        val added = Store.toggleFavorite(this, item)
        updateLike()
        Toast.makeText(this, if (added) "Ditambahkan ke video yang disukai" else "Dihapus dari video yang disukai", Toast.LENGTH_SHORT).show()
    }

    private fun downloadDialog() {
        val item = items.getOrNull(index) ?: return
        val labels = arrayOf(getString(R.string.action_download_video), getString(R.string.action_download_audio), getString(R.string.action_download_mp3))
        val keys = arrayOf(DownloadOptions.KEY_VIDEO_BEST, DownloadOptions.KEY_AUDIO, DownloadOptions.KEY_MP3_BEST)
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setItems(labels) { _, which -> Downloads.request(this, item.url, item.title, keys[which]) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun updateSub() {
        val cid = curChannelId
        if (cid == null) { btnSub.visibility = View.GONE; return }
        val subscribed = SubscribeHelper.isSubscribed(this, cid)
        val name = items.getOrNull(index)?.uploader.orEmpty()
        btnSub.visibility = View.VISIBLE
        btnSub.contentDescription = SubscribeHelper.label(this, cid, name)
        if (subscribed) {
            btnSub.text = "Disubscribe"
            btnSub.setTextColor(Color.WHITE)
            btnSub.background = GradientDrawable().apply { setColor(0x66FFFFFF); cornerRadius = dp(20).toFloat() }
        } else {
            btnSub.text = "Subscribe"
            btnSub.setTextColor(Color.BLACK)
            btnSub.background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(20).toFloat() }
        }
    }

    private fun toggleSub() {
        val cid = curChannelId ?: return
        val name = items.getOrNull(index)?.uploader.orEmpty()
        SubscribeHelper.toggle(this, cid, name, { Toast.makeText(this, it, Toast.LENGTH_SHORT).show() }) { updateSub() }
    }

    private fun openInPlayer(audio: Boolean?, item: VideoItem? = items.getOrNull(index)) {
        val v = item ?: return
        if (audio != null) Store.setAudioOnly(this, audio)
        player.playWhenReady = false
        wasPlaying = false
        Repo.prefetch(v.url)
        PlayQueue.set(listOf(v), PlayQueue.newSourceId(), null)
        startActivity(PlayerActivity.intent(this, v))
    }

    // ---- daur hidup

    override fun onResume() {
        super.onResume()
        if (::btnSub.isInitialized) { updateSub(); updateLike() }
    }

    override fun onStop() {
        super.onStop()
        wasPlaying = player.playWhenReady
        player.playWhenReady = false
    }

    override fun onStart() {
        super.onStart()
        if (wasPlaying && player.playbackState != Player.STATE_IDLE) player.playWhenReady = true
    }

    override fun onDestroy() {
        token++
        ui.removeCallbacksAndMessages(null)
        player.release()
        super.onDestroy()
    }
}
