package id.ytplayer

import android.app.Activity
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import androidx.annotation.RequiresApi

/**
 * Pendaftaran tombol Kembali gaya Android 13 ke atas, dipisah ke kelas sendiri supaya
 * Android 12 ke bawah (termasuk Android 7 sampai 10) tidak pernah memuat kelas OnBackInvokedCallback.
 * Hanya dipanggil bila Build.VERSION.SDK_INT >= 33.
 */
@RequiresApi(33)
class BackApi33(private val onBack: () -> Unit) {
    private val cb = OnBackInvokedCallback { onBack() }
    private var registered = false

    fun register(act: Activity) {
        if (registered) return
        act.onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb)
        registered = true
    }

    fun unregister(act: Activity) {
        if (!registered) return
        act.onBackInvokedDispatcher.unregisterOnBackInvokedCallback(cb)
        registered = false
    }
}
