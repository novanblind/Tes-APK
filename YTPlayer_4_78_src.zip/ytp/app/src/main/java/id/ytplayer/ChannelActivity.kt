package id.ytplayer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Outline
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Layar channel ala YouTube (tab Subscription, setelah memilih satu channel): bilah atas dengan
 * judul channel, baris foto channel yang di-subscribe (yang terpilih berlingkar; ketuk untuk
 * berpindah channel), tombol "Kunjungi channel" (membuka [ChannelPageActivity]), lalu daftar video
 * terbaru channel (RSS, sampai 15) berupa kartu besar.
 */
class ChannelActivity : Activity() {

    companion object {
        private const val EXTRA_ID = "channel_id"
        private const val EXTRA_NAME = "channel_name"
        fun intent(c: Context, id: String, name: String): Intent =
            Intent(c, ChannelActivity::class.java).putExtra(EXTRA_ID, id).putExtra(EXTRA_NAME, name)
    }

    private lateinit var status: TextView
    private lateinit var titleView: TextView
    private lateinit var strip: LinearLayout
    private lateinit var stripScroll: HorizontalScrollView
    private lateinit var list: RecyclerView
    private lateinit var adapter: VideoAdapter
    private var channelId = ""
    private var channelName = ""
    private var loadSeq = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        channelId = intent.getStringExtra(EXTRA_ID).orEmpty()
        channelName = intent.getStringExtra(EXTRA_NAME).orEmpty().ifBlank { "Channel" }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            fitsSystemWindows = true
        }

        // Bilah atas: kembali, judul, cari.
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val back = iconButton(R.drawable.ic_arrow_back, "Kembali") { finish() }
        titleView = TextView(this).apply {
            text = channelName
            setTextColor(getColor(R.color.text))
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(8), 0)
        }
        ViewCompat.setAccessibilityHeading(titleView, true)
        val search = iconButton(R.drawable.ic_search, "Cari semua video channel ini") {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(MainActivity.EXTRA_QUERY, channelName)
            )
        }
        bar.addView(back)
        bar.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(search)

        // Baris foto channel.
        stripScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        stripScroll.addView(strip)

        // Tombol "Kunjungi channel" di kanan.
        val visit = Button(this).apply {
            text = "Kunjungi channel"
            isAllCaps = false
            setTextColor(getColor(R.color.text))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setBackgroundResource(R.drawable.btn_bg)
            minHeight = dp(48)
            minimumHeight = dp(48)
            setPadding(dp(16), 0, dp(20), 0)
            compoundDrawablePadding = dp(8)
            setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_person, 0, 0, 0)
            setOnClickListener { startActivity(ChannelPageActivity.intent(this@ChannelActivity, channelId, channelName)) }
        }

        status = TextView(this).apply {
            setTextColor(getColor(R.color.text_secondary))
            textSize = 14f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }

        list = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@ChannelActivity) }
        adapter = VideoAdapter(
            onOpen = { item, audio -> openVideo(item, audio) },
            layoutRes = R.layout.item_video_big,
            avatarUrl = { YtApi.cachedChannels.firstOrNull { it.id == channelId }?.thumb }
        )
        list.adapter = adapter

        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))
        root.addView(stripScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(
            visit,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.END
                marginEnd = dp(16)
                topMargin = dp(4)
                bottomMargin = dp(8)
            }
        )
        root.addView(status)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        renderStrip()
        // Daftar channel belum pernah dimuat (mis. dibuka dari pemutar): muat sekali di latar.
        if (YtApi.cachedChannels.isEmpty() && YtAccount.isLoggedIn(this)) {
            Thread {
                YtApi.listSubscriptions(this)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    renderStrip()
                    list.adapter?.notifyDataSetChanged()
                }
            }.start()
        }
        load()
    }

    private fun iconButton(icon: Int, desc: String, onClick: () -> Unit) = ImageButton(this).apply {
        setImageResource(icon)
        contentDescription = desc
        val tv = android.util.TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        setBackgroundResource(tv.resourceId)
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        setOnClickListener { onClick() }
    }

    /** Channel di baris foto: daftar subscribe; bila channel ini belum ada di dalamnya, ditaruh paling depan. */
    private fun stripChannels(): List<YtApi.Channel> {
        val base = YtApi.cachedChannels
        return if (base.any { it.id == channelId }) base
        else listOf(YtApi.Channel(channelId, channelName, "", null)) + base
    }

    private fun renderStrip() {
        strip.removeAllViews()
        var selectedView: View? = null
        for (ch in stripChannels()) {
            val selected = ch.id == channelId
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(4), dp(6), dp(4))
                isClickable = true
                isFocusable = true
                contentDescription =
                    if (selected) "Channel ${ch.title}, sedang dibuka"
                    else "Channel ${ch.title}. Ketuk untuk melihat video channel ini"
            }
            val box = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(dp(64), dp(64)) }
            val inset = if (selected) dp(7) else dp(4)
            val img = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundResource(R.drawable.avatar_bg)
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
                }
                clipToOutline = true
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            box.addView(img, FrameLayout.LayoutParams(dp(64) - 2 * inset, dp(64) - 2 * inset, Gravity.CENTER))
            ImageLoader.load(img, ch.thumb)
            if (selected) {
                val ring = View(this).apply {
                    setBackgroundResource(R.drawable.avatar_ring)
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }
                box.addView(ring, FrameLayout.LayoutParams(dp(64), dp(64)))
            }
            val tv = TextView(this).apply {
                text = ch.title
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(getColor(R.color.text))
                if (selected) setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(4), 0, 0)
                layoutParams = LinearLayout.LayoutParams(dp(72), ViewGroup.LayoutParams.WRAP_CONTENT)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            col.addView(box)
            col.addView(tv)
            col.setOnClickListener { if (ch.id != channelId) select(ch) }
            strip.addView(col)
            if (selected) selectedView = col
        }
        // "Semua": daftar lengkap channel yang di-subscribe.
        val all = TextView(this).apply {
            text = "Semua"
            contentDescription = "Semua channel yang di-subscribe"
            setTextColor(getColor(R.color.accent))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            minHeight = dp(48)
            setPadding(dp(16), 0, dp(16), 0)
            isClickable = true
            isFocusable = true
            setOnClickListener { startActivity(Intent(this@ChannelActivity, SubscriptionsActivity::class.java)) }
        }
        strip.addView(all, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(64)).apply { topMargin = dp(4) })
        selectedView?.let { v -> stripScroll.post { stripScroll.scrollTo(maxOf(0, v.left - dp(16)), 0) } }
    }

    private fun select(ch: YtApi.Channel) {
        channelId = ch.id
        channelName = ch.title
        titleView.text = ch.title
        renderStrip()
        load()
    }

    private fun load() {
        val my = ++loadSeq
        val id = channelId
        val name = channelName
        status.visibility = View.VISIBLE
        status.text = "Memuat video $name, mohon tunggu."
        Thread {
            val items = YtFeed.channelVideos(id)
            runOnUiThread {
                if (isFinishing || isDestroyed || my != loadSeq) return@runOnUiThread
                if (items == null) {
                    adapter.set(emptyList())
                    status.text = "Gagal memuat video $name. Periksa sambungan internet."
                } else if (items.isEmpty()) {
                    adapter.set(emptyList())
                    status.text = "Belum ada video di channel $name."
                } else {
                    adapter.set(items)
                    list.scrollToPosition(0)
                    status.visibility = View.GONE
                    list.announceForAccessibility("${items.size} video terbaru dari $name")
                }
            }
            // Tahap 2: lengkapi durasi dan keterangan "Streaming ..." dari youtubei; gagal = daftar RSS tetap.
            if (items != null && items.isNotEmpty()) {
                val extra = YtChannel.details(this, id)
                if (extra.isNotEmpty()) {
                    val merged = items.map { v ->
                        val d = extra[v.url] ?: return@map v
                        v.copy(
                            durationSec = if (d.durationSec != 0L) d.durationSec else v.durationSec,
                            date = d.date.ifBlank { v.date },
                            viewsText = d.viewsText
                        )
                    }
                    runOnUiThread {
                        if (isFinishing || isDestroyed || my != loadSeq) return@runOnUiThread
                        adapter.set(merged)
                    }
                }
            }
        }.start()
    }

    private fun openVideo(item: VideoItem, audio: Boolean?) {
        if (audio != null) Store.setAudioOnly(this, audio)
        Repo.prefetch(item.url)
        PlayQueue.set(adapter.snapshot(), adapter.sourceId, null)
        startActivity(PlayerActivity.intent(this, item))
    }
}
