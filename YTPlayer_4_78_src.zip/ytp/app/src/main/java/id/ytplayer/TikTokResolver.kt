package id.ytplayer

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.GZIPInputStream

/** Galat TikTok dengan pesan Bahasa Indonesia siap tampil. fatal = tidak perlu coba cara lain. */
class TikTokException(message: String, val fatal: Boolean = false) : IOException(message)

/**
 * Mengambil alamat video TikTok tanpa watermark.
 *
 * Cara 1: membaca halaman video TikTok (data JSON di dalam halaman), lengkap dengan cookie-nya.
 * Cara 2 (cadangan bila cara 1 gagal): layanan pihak ketiga tikwm.com. Tautan video dikirim ke
 * layanan itu, jadi hanya dipakai bila cara 1 tidak berhasil.
 * Cara 2b: halaman sematan (embed) TikTok, jarang diblokir.
 * Cara 3 (cadangan lagi): WebView tersembunyi yang memuat halaman video seperti peramban sungguhan
 * (JavaScript, cookie), lalu membaca data video dari halaman itu.
 *
 * Keduanya tidak resmi dan bisa berhenti bekerja kapan saja bila TikTok mengubah sistemnya.
 */
object TikTokResolver {
    const val PREFIX = "tt:"
    const val KEY_MP4 = "tt:mp4:"   // diikuti tinggi video; 0 = terbaik
    const val KEY_M4A = "tt:m4a"
    const val KEY_MP3 = "tt:mp3:"   // diikuti kbps

    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"

    /** Cadangan penyamaran peramban: tiap putaran percobaan memakai yang berbeda. */
    private const val UA_MOBILE =
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 " +
            "(KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
    private const val UA_ANDROID =
        "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"
    private val UAS = listOf(UA, UA_MOBILE, UA_ANDROID)

    private class Cached(val time: Long, val info: Info)
    private val cache = LinkedHashMap<String, Cached>()
    private const val CACHE_TTL_MS = 10 * 60 * 1000L

    @Synchronized
    private fun cacheGet(link: String): Info? {
        val c = cache[link] ?: return null
        if (System.currentTimeMillis() - c.time > CACHE_TTL_MS) {
            cache.remove(link)
            return null
        }
        return c.info
    }

    @Synchronized
    private fun cachePut(link: String, info: Info) {
        cache[link] = Cached(System.currentTimeMillis(), info)
        while (cache.size > 8) cache.remove(cache.keys.first())
    }

    /** height 0 = tidak diketahui. Daftar diurutkan dari yang terbaik. */
    /**
     * [audioUrl] hanya dipakai bila video dan suaranya terpisah (mis. DASH Facebook): video diunduh dari [url],
     * suaranya dari [audioUrl], lalu digabung di HP. Null = [url] sudah berisi suara.
     */
    class Quality(
        val label: String,
        val height: Int,
        val url: String,
        val alts: List<String> = emptyList(),
        val audioUrl: String? = null
    )

    class Info(
        val id: String,
        val title: String,
        val author: String,
        val durationSec: Long,
        val qualities: List<Quality>,
        val headers: Map<String, String>
    ) {
        fun displayName(): String = title.ifBlank { "Video TikTok" }
    }

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /** Hasil dikirim di thread utama. Pesan galat sudah Bahasa Indonesia. */
    fun resolveAsync(link: String, cb: (Info?, String?) -> Unit) {
        io.execute {
            try {
                val info = resolve(link)
                main.post { cb(info, null) }
            } catch (e: Exception) {
                val msg = if (e is TikTokException) e.message else Repo.friendly(e)
                main.post { cb(null, msg) }
            }
        }
    }

    /**
     * Memblokir thread; panggil dari thread latar. Hasil disimpan 10 menit supaya halaman pilihan
     * dan unduhan memakai data yang sama (tanpa mengambil ulang); [fresh] = abaikan simpanan.
     * Dicoba sampai 3 putaran (halaman TikTok, layanan cadangan, lalu WebView tersembunyi; tiap putaran
     * dengan penyamaran peramban berbeda dan jeda makin lama) sebelum menyerah.
     */
    fun resolve(link: String, fresh: Boolean = false): Info {
        if (!fresh) cacheGet(link)?.let { return it }
        val expanded = try { expandLink(link) } catch (e: Exception) { link }
        val vidId = Regex("/video/(\\d{8,})").find(expanded)?.groupValues?.get(1)
            ?: Regex("/video/(\\d{8,})").find(link)?.groupValues?.get(1)
        var net: IOException? = null
        var last: TikTokException? = null
        // Galat terakhir per sumber, ditampilkan di pesan akhir supaya kelihatan siapa yang menolak.
        val detail = LinkedHashMap<String, String>()
        fun note(src: String, e: Exception) {
            detail[src] = (e.message ?: e.javaClass.simpleName).replace('\n', ' ').take(140)
        }
        for (round in 0 until 3) {
            if (round > 0) Thread.sleep(1200L * round)
            try {
                return viaPage(link, UAS[round % UAS.size]).also { cachePut(link, it) }
            } catch (e: TikTokException) {
                if (e.fatal) throw e
                last = e
                note("Halaman TikTok", e)
            } catch (e: IOException) {
                net = e
                note("Halaman TikTok", e)
            } catch (e: Exception) {
                note("Halaman TikTok (data tidak terbaca)", e)
            }
            // Halaman sematan (embed) TikTok jauh jarang diblokir dibanding halaman video biasa.
            if (vidId != null) {
                try {
                    return viaEmbed(vidId, UAS[round % UAS.size]).also { cachePut(link, it) }
                } catch (e: TikTokException) {
                    if (e.fatal) throw e
                    last = e
                    note("Halaman sematan TikTok", e)
                } catch (e: IOException) {
                    net = e
                    note("Halaman sematan TikTok", e)
                } catch (e: Exception) {
                    note("Halaman sematan TikTok (data tidak terbaca)", e)
                }
            }
            try {
                return viaTikwm(expanded, UAS[round % UAS.size]).also { cachePut(link, it) }
            } catch (e: TikTokException) {
                if (e.fatal) throw e
                last = e
                note("tikwm.com", e)
            } catch (e: IOException) {
                net = e
                note("tikwm.com", e)
            } catch (e: Exception) {
                note("tikwm.com (data tidak terbaca)", e)
            }
            // WebView lebih lambat (memuat halaman penuh): hanya di putaran pertama dan terakhir.
            if (round % 2 == 0) {
                // Putaran pertama: halaman video biasa; putaran terakhir: halaman sematan (lebih ringan).
                val wvUrl = if (round > 0 && vidId != null) "https://www.tiktok.com/embed/v2/$vidId" else expanded
                val wvName = if (wvUrl === expanded) "WebView" else "WebView (sematan)"
                try {
                    return viaWebView(wvUrl).also { cachePut(link, it) }
                } catch (e: TikTokException) {
                    if (e.fatal) throw e
                    last = e
                    note(wvName, e)
                } catch (e: Exception) {
                    note(wvName, e)
                }
            }
        }
        if (net != null && last == null) throw net
        throw TikTokException(
            "Gagal mengambil video TikTok setelah beberapa kali mencoba. TikTok sering mengubah sistemnya " +
                "atau memblokir permintaan. Pastikan videonya publik, lalu coba lagi nanti." +
                (if (detail.isEmpty()) "" else " Rincian: " + detail.entries.joinToString("; ") { "${it.key}: ${it.value}" })
        )
    }

    /**
     * Ikuti tautan pendek (vm./vt.tiktok.com, tiktok.com/t/...) sampai alamat video aslinya tanpa
     * membaca isi halaman; layanan cadangan lebih andal dengan alamat lengkap. Gagal = pakai apa adanya.
     */
    private fun expandLink(link: String): String {
        var url = link
        for (hop in 0 until 5) {
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 10_000
                conn.readTimeout = 10_000
                conn.setRequestProperty("User-Agent", UA)
                val code = conn.responseCode
                if (code !in 300..399) break
                val loc = conn.getHeaderField("Location") ?: break
                url = URL(URL(url), loc).toString()
            } finally {
                conn.disconnect()
            }
        }
        return if (url.contains("/video/")) url.substringBefore('?') else url
    }

    // ------------------------------------------------------------------ cara 1: halaman TikTok

    private fun viaPage(link: String, ua: String): Info {
        val cookies = LinkedHashMap<String, String>()
        val r = get(link, cookies = cookies, ua = ua)
        val cookieHeader = cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }
        return parsePage(r.url, r.body, ua, cookieHeader)
    }

    /** Membaca data video dari HTML halaman TikTok (dipakai cara 1 dan cara 3). */
    private fun parsePage(pageUrl: String, body: String, ua: String, cookieHeader: String): Info {
        val idRe = Regex("/(video|photo)/(\\d{8,})")
        val found = idRe.find(pageUrl)
            ?: Regex("tiktok\\.com/@[^/\"]+/(video|photo)/(\\d{8,})").find(body)
            ?: throw TikTokException("Tautan TikTok ini bukan video yang dikenali.")
        if (found.groupValues[1] == "photo") {
            throw TikTokException("Ini postingan foto atau slide TikTok, belum didukung.", fatal = true)
        }
        val id = found.groupValues[2]

        val script = Regex(
            "<script[^>]*id=\"__UNIVERSAL_DATA_FOR_REHYDRATION__\"[^>]*>(.*?)</script>",
            RegexOption.DOT_MATCHES_ALL
        ).find(body) ?: throw TikTokException("Halaman TikTok tidak berisi data video.")
        val root = JSONObject(script.groupValues[1])
        val scope = root.optJSONObject("__DEFAULT_SCOPE__")
        val detail = scope?.optJSONObject("webapp.video-detail")
            ?: throw TikTokException(
                "bagian video-detail tidak ada di halaman (isi halaman: " +
                    (scope?.keys()?.asSequence()?.take(8)?.joinToString(",").orEmpty().ifEmpty { "kosong" }) + ")"
            )
        when (detail.optInt("statusCode", 0)) {
            0 -> {}
            10204, 10216 -> throw TikTokException("Video ini tidak ditemukan atau sudah dihapus.", fatal = true)
            10222 -> throw TikTokException("Video ini privat, tidak bisa diunduh.", fatal = true)
            else -> throw TikTokException("TikTok menolak permintaan untuk video ini.")
        }
        val item = detail.optJSONObject("itemInfo")?.optJSONObject("itemStruct")
            ?: throw TikTokException(
                "data video kosong (kode ${detail.optInt("statusCode", 0)}" +
                    detail.optString("statusMsg").let { if (it.isEmpty()) "" else ", $it" } + ")"
            )
        val video = item.optJSONObject("video") ?: throw TikTokException("data video tidak memuat bagian video")

        class Cand(val bitrate: Long, val p: Int, val url: String, val alts: List<String>, val h264: Boolean)
        val cands = ArrayList<Cand>()
        val br = video.optJSONArray("bitrateInfo")
        if (br != null) {
            for (i in 0 until br.length()) {
                val b = br.optJSONObject(i) ?: continue
                val pa = b.optJSONObject("PlayAddr") ?: continue
                val urls = ArrayList<String>()
                pa.optJSONArray("UrlList")?.let { arr ->
                    for (k in 0 until arr.length()) arr.optString(k).takeIf { it.isNotEmpty() }?.let { urls += it }
                }
                if (urls.isEmpty()) continue
                val u = urls[0]
                val w = pa.optInt("Width", 0)
                val h = pa.optInt("Height", 0)
                val p = if (w > 0 && h > 0) minOf(w, h) else maxOf(w, h)
                val codec = b.optString("CodecType").lowercase()
                cands += Cand(b.optLong("Bitrate", 0), p, u, urls.drop(1), codec.contains("h264") || codec.isEmpty())
            }
        }
        val pool = cands.filter { it.h264 }.ifEmpty { cands }
        val list = ArrayList<Quality>()
        val seen = HashSet<Int>()
        pool.sortedByDescending { it.bitrate }.forEach { c ->
            if (seen.add(c.p)) {
                list += Quality(if (c.p > 0) "MP4 ${c.p}p (tanpa watermark)" else "MP4 (tanpa watermark)", c.p, c.url, c.alts)
            }
        }
        if (list.isEmpty()) {
            val play = video.optString("playAddr")
            if (play.isNotEmpty()) list += Quality("MP4 (tanpa watermark)", 0, play)
        }
        if (list.isEmpty()) throw TikTokException("Alamat video TikTok tidak ditemukan.")

        val author = item.optJSONObject("author")
        val name = author?.optString("uniqueId").orEmpty().ifEmpty { author?.optString("nickname").orEmpty() }
        val headers = LinkedHashMap<String, String>()
        headers["User-Agent"] = ua
        headers["Referer"] = "https://www.tiktok.com/"
        if (cookieHeader.isNotEmpty()) headers["Cookie"] = cookieHeader
        return Info(id, item.optString("desc").trim(), name, video.optLong("duration", 0), list, headers)
    }

    // ------------------------------------------------------------------ halaman sematan (embed)

    /**
     * Membaca halaman sematan https://www.tiktok.com/embed/v2/ID. Halaman ini memuat data video untuk pemutar
     * sematan dan jarang menampilkan halaman verifikasi. Alamat video dicari lewat pola alamat (bukan nama
     * bagian JSON tertentu) supaya tetap jalan bila susunan datanya berubah.
     */
    private fun viaEmbed(id: String, ua: String): Info {
        val cookies = LinkedHashMap<String, String>()
        val r = get(
            "https://www.tiktok.com/embed/v2/$id",
            extra = mapOf("Referer" to "https://www.tiktok.com/"), cookies = cookies, ua = ua
        )
        val cookieHeader = cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }
        val text = r.body.replace("\\u002F", "/").replace("\\/", "/")
            .replace("\\u0026", "&").replace("&amp;", "&")
        val urls = LinkedHashSet<String>()
        Regex("https?://[^\"'\\s<>\\\\]+").findAll(text).forEach { m ->
            if (looksLikeVideo(m.value)) urls.add(m.value)
        }
        if (urls.isEmpty()) {
            throw TikTokException("halaman sematan tidak berisi alamat video (isi ${r.body.length} karakter)")
        }
        fun jsonStr(re: Regex): String = try {
            val raw = re.find(r.body)?.groupValues?.get(1)
            if (raw == null) "" else (JSONTokener("\"$raw\"").nextValue() as? String).orEmpty()
        } catch (_: Exception) { "" }
        val desc = jsonStr(Regex("\"desc\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\""))
        val author = jsonStr(Regex("\"(?:uniqueId|unique_id)\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\""))
        val list = urls.toList()
        val headers = LinkedHashMap<String, String>()
        headers["User-Agent"] = ua
        headers["Referer"] = "https://www.tiktok.com/"
        if (cookieHeader.isNotEmpty()) headers["Cookie"] = cookieHeader
        return Info(
            id, desc.trim(), author, 0L,
            listOf(Quality("MP4 (dari halaman sematan)", 0, list[0], list.drop(1))), headers
        )
    }

    // ------------------------------------------------------------------ cara 2: tikwm.com

    private fun viaTikwm(link: String, ua: String): Info {
        val enc = URLEncoder.encode(link, "UTF-8")
        // Bila satu cara ditolak (mis. HTTP 403), coba cara dan alamat lain milik layanan yang sama.
        val variants = listOf("GET" to "www.tikwm.com", "POST" to "www.tikwm.com", "POST" to "tikwm.com")
        var json: JSONObject? = null
        var lastTik: TikTokException? = null
        var lastIo: IOException? = null
        for ((i, v) in variants.withIndex()) {
            try {
                val body = if (v.first == "GET") {
                    get("https://${v.second}/api/?hd=1&url=$enc", extra = mapOf("Accept" to "application/json"), ua = ua).body
                } else {
                    postForm("https://${v.second}/api/", "url=$enc&count=12&cursor=0&web=1&hd=1", ua, "https://${v.second}/")
                }
                val j = JSONObject(body)
                if (j.optInt("code", -1) == 0) {
                    json = j
                    break
                }
                val msg = j.optString("msg")
                if (msg.contains("limit", ignoreCase = true) && i < variants.size - 1) Thread.sleep(1500L)
                lastTik = TikTokException("Layanan cadangan menolak: ${msg.ifEmpty { "tidak ada keterangan" }}")
            } catch (e: TikTokException) {
                lastTik = e
            } catch (e: IOException) {
                lastIo = e
            } catch (e: org.json.JSONException) {
                lastTik = TikTokException("Layanan cadangan membalas dengan data yang tidak terbaca.")
            }
        }
        if (json == null) throw lastTik ?: lastIo ?: TikTokException("Layanan cadangan tidak mengembalikan data.")
        val d = json?.optJSONObject("data") ?: throw TikTokException("Layanan cadangan tidak mengembalikan data.")
        fun abs(u: String) = if (u.startsWith("/")) "https://www.tikwm.com$u" else u
        val list = ArrayList<Quality>()
        d.optString("hdplay").takeIf { it.isNotEmpty() }?.let { list += Quality("MP4 HD (tanpa watermark)", 2, abs(it)) }
        d.optString("play").takeIf { it.isNotEmpty() }?.let { list += Quality("MP4 standar (tanpa watermark)", 1, abs(it)) }
        if (list.isEmpty()) throw TikTokException("Layanan cadangan tidak memberi alamat video.")
        val a = d.optJSONObject("author")
        val name = a?.optString("unique_id").orEmpty().ifEmpty { a?.optString("nickname").orEmpty() }
        val headers = mapOf("User-Agent" to ua, "Referer" to "https://www.tikwm.com/")
        return Info(d.optString("id"), d.optString("title").trim(), name, d.optLong("duration", 0), list, headers)
    }

    // ------------------------------------------------------------------ cara 3: WebView tersembunyi

    private fun looksLikeVideo(u: String): Boolean {
        val l = u.lowercase()
        return l.startsWith("http") &&
            (l.contains("/video/tos/") || l.contains("mime_type=video_mp4") || l.substringBefore('?').endsWith(".mp4"))
    }

    /**
     * Memuat halaman video di WebView yang tidak tampak (JavaScript dan cookie seperti peramban
     * sungguhan), menunggu data video muncul di halaman, lalu membacanya dengan [parsePage]. Bila data video
     * tidak ada di halaman, alamat video dari elemen pemutar atau dari permintaan jaringan halaman dipakai.
     * Memblokir thread pemanggil (maks. sekitar 45 detik); jangan dipanggil dari thread utama.
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun viaWebView(link: String): Info {
        val app = App.ctx ?: throw TikTokException("WebView belum siap.")
        if (Looper.myLooper() == Looper.getMainLooper()) throw TikTokException("WebView tidak bisa dipakai dari thread utama.")
        val done = CountDownLatch(1)
        val html = AtomicReference<String?>(null)
        val pageUrl = AtomicReference(link)
        val cookieStr = AtomicReference("")
        val error = AtomicReference<String?>(null)
        val mainStatus = AtomicInteger(0)
        val mainErr = AtomicReference<String?>(null)
        val evalCount = AtomicInteger(0)   // berapa kali evaluasi JS di halaman benar-benar menjawab
        val finished = AtomicBoolean(false)
        val holder = arrayOfNulls<WebView>(1)   // hanya disentuh di thread utama

        val videoInfo = AtomicReference<Info?>(null)
        val sniffed = java.util.concurrent.CopyOnWriteArrayList<String>()   // alamat video yang diminta halaman
        val lastTitle = AtomicReference("")
        val lastBody = AtomicReference("")

        fun diag(w: WebView?): String =
            "muat ${w?.progress ?: 0}%, evaluasi JS ${evalCount.get()} kali, " +
                "judul \"${lastTitle.get().take(40)}\", teks \"${lastBody.get().take(100)}\", " +
                "alamat video terpantau ${sniffed.size}" +
                (mainStatus.get().let { if (it >= 400) ", HTTP $it" else "" }) +
                (mainErr.get()?.let { ", $it" } ?: "")

        fun finish(h: String?, err: String?) {   // thread utama
            if (!finished.compareAndSet(false, true)) return
            val w = holder[0]
            if (h != null) {
                html.set(h)
                try { w?.url?.let { pageUrl.set(it) } } catch (_: Exception) {}
                try { CookieManager.getInstance().getCookie("https://www.tiktok.com")?.let { cookieStr.set(it) } } catch (_: Exception) {}
            } else {
                error.set(err)
            }
            try { w?.stopLoading(); w?.destroy() } catch (_: Exception) {}
            holder[0] = null
            done.countDown()
        }

        /** Dipakai bila data video tidak ada di halaman tetapi pemutar halaman sudah memuat alamat videonya. */
        fun finishVideo(src: String, name: String) {   // thread utama
            if (!finished.compareAndSet(false, true)) return
            val w = holder[0]
            try {
                val page = try { w?.url } catch (_: Exception) { null } ?: link
                val cm = CookieManager.getInstance()
                val ck = listOfNotNull(cm.getCookie(src), cm.getCookie("https://www.tiktok.com"))
                    .flatMap { it.split(";") }.map { it.trim() }.filter { it.isNotEmpty() }
                    .distinctBy { it.substringBefore('=') }.joinToString("; ")
                val id = Regex("/video/(\\d+)").find(page)?.groupValues?.get(1).orEmpty()
                val author = Regex("/@([^/?]+)").find(page)?.groupValues?.get(1).orEmpty()
                val headers = LinkedHashMap<String, String>()
                headers["User-Agent"] = UA_ANDROID
                headers["Referer"] = "https://www.tiktok.com/"
                if (ck.isNotEmpty()) headers["Cookie"] = ck
                videoInfo.set(
                    Info(id, name.trim().take(200), author, 0L,
                        listOf(Quality("MP4 (dari pemutar halaman)", 0, src)), headers)
                )
            } catch (e: Exception) {
                error.set("gagal menyusun data dari pemutar halaman (${e.message ?: e.javaClass.simpleName})")
            }
            try { w?.stopLoading(); w?.destroy() } catch (_: Exception) {}
            holder[0] = null
            done.countDown()
        }

        fun poll(tries: Int) {   // thread utama
            val w = holder[0] ?: return
            val answered = AtomicBoolean(false)
            fun next() {   // thread utama: lanjut memeriksa, atau menyerah setelah 32 kali
                if (finished.get()) return
                if (tries >= 32) {
                    finish(null, "halaman tidak berisi data video (" + diag(w) + ")")
                } else {
                    main.postDelayed({ poll(tries + 1) }, 1000)
                }
            }
            // Jaga bila jawaban evaluasi JS tidak pernah datang: tetap lanjut setelah 4 detik.
            main.postDelayed({ if (answered.compareAndSet(false, true)) next() }, 4000)
            // Mengembalikan: vd = data video ada di halaman, h = HTML halaman, t = judul, b = cuplikan teks,
            // v = alamat video di elemen pemutar, o = og:title. Video dibisukan dan diputar agar alamatnya dimuat.
            val js = "(function(){" +
                "var e=document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');" +
                "var vd=!!(e&&e.textContent.indexOf('webapp.video-detail')>=0);" +
                "var vs=document.querySelectorAll('video');var src='';" +
                "for(var i=0;i<vs.length;i++){var x=vs[i];x.muted=true;" +
                "try{var p=x.play();if(p&&p.catch)p.catch(function(){});}catch(z){}" +
                "if(!src)src=x.currentSrc||x.src||'';}" +
                "var m=document.querySelector('meta[property=\"og:title\"]');" +
                "var b=(document.body?document.body.innerText:'').replace(/[\\n\\r\\t ]+/g,' ').slice(0,120);" +
                "return JSON.stringify({vd:vd,h:vd?document.documentElement.outerHTML:'',t:document.title||''," +
                "b:b,v:src,o:m?m.content:''});" +
                "})()"
            w.evaluateJavascript(js) { v ->
                val o = try {
                    (JSONTokener(v).nextValue() as? String)?.let { JSONObject(it) }
                } catch (_: Exception) { null }
                if (o != null) {
                    lastTitle.set(o.optString("t"))
                    lastBody.set(o.optString("b"))
                    val src = o.optString("v")
                    val cand = if (src.startsWith("http")) src else sniffed.firstOrNull()
                    if (o.optBoolean("vd")) {
                        finish(o.optString("h"), null)
                    } else if (cand != null) {
                        finishVideo(cand, o.optString("o").ifEmpty { o.optString("t") })
                    } else {
                        evalCount.incrementAndGet()
                        if (answered.compareAndSet(false, true)) next()
                    }
                } else {
                    evalCount.incrementAndGet()
                    if (answered.compareAndSet(false, true)) next()
                }
            }
        }

        main.post {
            try {
                val cm = CookieManager.getInstance()
                cm.setAcceptCookie(true)
                cm.removeAllCookies(null)   // mulai bersih: cookie lama yang diblokir tidak ikut
                val w = WebView(app)
                holder[0] = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.userAgentString = UA_ANDROID
                w.settings.blockNetworkImage = true
                w.settings.mediaPlaybackRequiresUserGesture = true
                cm.setAcceptThirdPartyCookies(w, true)
                var polling = false
                fun startPolling() {   // thread utama; dipanggil sekali
                    if (!polling) {
                        polling = true
                        poll(0)
                    }
                }
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        startPolling()
                    }

                    // Mencatat alamat video yang diminta halaman (seperti pengunduh berbasis WebView).
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val u = request?.url?.toString().orEmpty()
                        if (looksLikeVideo(u) && sniffed.size < 6) sniffed.add(u)
                        return null
                    }

                    // TikTok sering mengalihkan ke alamat khusus aplikasi (snssdk1233://, tiktok://) agar
                    // aplikasi TikTok terbuka; WebView tidak bisa membukanya (ERR_UNKNOWN_URL_SCHEME) dan
                    // halaman jadi galat. Blokir alihan non-web supaya tetap di halaman video.
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val sc = request?.url?.scheme?.lowercase()
                        return sc != "http" && sc != "https" && sc != "about"
                    }

                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true) {
                            mainErr.set("galat muat ${error?.errorCode ?: 0} ${error?.description ?: ""}".trim())
                        }
                    }

                    override fun onReceivedHttpError(
                        view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?
                    ) {
                        if (request?.isForMainFrame == true) mainStatus.set(errorResponse?.statusCode ?: 0)
                    }
                }
                w.loadUrl(link)
                // Jangan hanya menunggu onPageFinished (bisa tidak pernah datang bila ada sumber yang menggantung):
                // mulai memeriksa data halaman setelah 3 detik.
                main.postDelayed({ startPolling() }, 3000)
            } catch (e: Exception) {
                finish(null, "WebView gagal dibuka (${e.message ?: e.javaClass.simpleName})")
            }
        }
        main.postDelayed({
            val w = holder[0]
            finish(null, "waktu habis menunggu halaman (" + diag(w) + ")")
        }, 42_000)
        done.await(48, TimeUnit.SECONDS)

        videoInfo.get()?.let { return it }
        val h = html.get() ?: throw TikTokException(error.get() ?: "tidak mendapat data video")
        return parsePage(pageUrl.get(), h, UA_ANDROID, cookieStr.get())
    }

    // ------------------------------------------------------------------ HTTP

    private class Resp(val url: String, val body: String)

    /** POST formulir (urlencoded) untuk layanan cadangan; mengembalikan isi balasan. */
    private fun postForm(url: String, form: String, ua: String, referer: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 20_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("User-Agent", ua)
            conn.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01")
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            conn.setRequestProperty("X-Requested-With", "XMLHttpRequest")
            conn.setRequestProperty("Referer", referer)
            conn.outputStream.use { it.write(form.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code == 429) throw TikTokException("dibatasi (HTTP 429), coba lagi beberapa saat lagi")
            if (code >= 400) throw TikTokException("ditolak dengan galat HTTP $code")
            val raw = conn.inputStream
            val stream = if ("gzip".equals(conn.contentEncoding, ignoreCase = true)) GZIPInputStream(raw) else raw
            return stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    /** GET dengan pengalihan manual agar cookie dari setiap lompatan terkumpul. */
    private fun get(
        start: String,
        extra: Map<String, String> = emptyMap(),
        cookies: LinkedHashMap<String, String> = LinkedHashMap(),
        ua: String = UA
    ): Resp {
        var url = start
        for (hop in 0 until 6) {
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 20_000
                conn.readTimeout = 20_000
                conn.setRequestProperty("User-Agent", ua)
                conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8")
                if (cookies.isNotEmpty()) {
                    conn.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
                }
                extra.forEach { (k, v) -> conn.setRequestProperty(k, v) }
                val code = conn.responseCode
                for ((k, vs) in conn.headerFields) {
                    if (k != null && k.equals("Set-Cookie", ignoreCase = true)) {
                        vs.forEach { c ->
                            val nv = c.substringBefore(';')
                            val name = nv.substringBefore('=').trim()
                            if (name.isNotEmpty()) cookies[name] = nv.substringAfter('=', "").trim()
                        }
                    }
                }
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location")
                        ?: throw TikTokException("TikTok mengalihkan tautan tanpa tujuan.")
                    url = URL(URL(url), loc).toString()
                    continue
                }
                if (code == 429) throw TikTokException("dibatasi (HTTP 429), coba lagi beberapa saat lagi")
                if (code >= 400) throw TikTokException("ditolak dengan galat HTTP $code")
                val raw = conn.inputStream
                val stream = if ("gzip".equals(conn.contentEncoding, ignoreCase = true)) GZIPInputStream(raw) else raw
                val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                return Resp(url, body)
            } finally {
                conn.disconnect()
            }
        }
        throw TikTokException("Tautan TikTok dialihkan terlalu banyak kali.")
    }
}
