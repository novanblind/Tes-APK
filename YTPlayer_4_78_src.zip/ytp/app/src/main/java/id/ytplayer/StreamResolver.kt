package id.ytplayer

import android.net.Uri
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamType

/** Memilih aliran (stream) yang tepat dari StreamInfo untuk mode video / audio saja. */
object StreamResolver {
    /** [audioUri] != null → [uri] hanya video; audio terpisah digabung di pemutar. */
    class Resolved(
        val uri: String,
        val audioOnly: Boolean,
        val hls: Boolean,
        val audioUri: String? = null,
        val height: Int = 0
    )

    /** quality: tinggi video yang diminta (mis. 720); 0 = otomatis. */
    fun resolve(info: StreamInfo, wantAudioOnly: Boolean, quality: Int = 0, audioLevel: Int = Store.AUDIO_TERBAIK): Resolved? {
        val live = info.streamType == StreamType.LIVE_STREAM ||
            info.streamType == StreamType.AUDIO_LIVE_STREAM
        if (live) {
            val hls = info.hlsUrl
            if (!hls.isNullOrEmpty()) return Resolved(hls, wantAudioOnly, true)
        }

        // Suara asli video (bukan dubbing), M4A diutamakan.
        val audio = DownloadOptions.pickAudio(info)

        if (wantAudioOnly && audio != null) {
            val chosen = DownloadOptions.pickAudioForPlayback(info, audioLevel) ?: audio
            return Resolved(chosen.content, true, false)
        }

        // Suara untuk video: Opus (seperti YouTube asli) bila ada, jika tidak M4A terbaik.
        val videoAudio = DownloadOptions.pickAudioForVideo(info)?.content

        if (quality > 0) {
            val plans = DownloadOptions.videoPlans(info) // urut dari tertinggi
            val plan = plans.firstOrNull { it.height == quality }
                ?: plans.firstOrNull { it.height < quality }
                ?: plans.lastOrNull()
            if (plan != null) {
                val a = if (plan.audioUrl != null) (videoAudio ?: plan.audioUrl) else null
                return Resolved(plan.videoUrl, false, false, a, plan.height)
            }
        } else {
            // Otomatis: video terpisah sampai 360p + audio terbaik (bukan aliran gabungan
            // yang audionya hanya sekitar 96 kbps).
            val plan = DownloadOptions.videoPlans(info)
                .firstOrNull { it.audioUrl != null && it.height <= 360 }
            if (plan != null) {
                return Resolved(plan.videoUrl, false, false, videoAudio ?: plan.audioUrl, plan.height)
            }
        }

        val muxed = info.videoStreams
            .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.isUrl && !it.isVideoOnly() }
            .sortedByDescending { it.getHeight() }
        val pick = muxed.firstOrNull { it.getHeight() <= 360 } ?: muxed.lastOrNull()
        if (pick != null) return Resolved(pick.content, false, false, null, pick.getHeight())

        // Tidak ada video gabungan → pakai audio saja sebagai cadangan.
        if (audio != null) return Resolved(audio.content, true, false)
        return null
    }

    /** Data yang dikirim ke PlaybackService (perintah LOAD). */
    fun toBundle(key: String, info: StreamInfo, res: Resolved, startMs: Long): Bundle = Bundle().apply {
        putString("id", key)
        putString("uri", res.uri)
        putString("audio", res.audioUri)
        putString("title", info.name)
        putString("artist", info.uploaderName)
        putString("art", Repo.bestThumb(info.thumbnails))
        putBoolean("hls", res.hls)
        putLong("start", startMs)
    }

    fun mediaItem(key: String, info: StreamInfo, res: Resolved): MediaItem =
        mediaItemFrom(toBundle(key, info, res, 0L))

    fun mediaItemFrom(b: Bundle): MediaItem {
        val meta = MediaMetadata.Builder()
            .setTitle(b.getString("title"))
            .setArtist(b.getString("artist"))
            .setArtworkUri(b.getString("art")?.let { Uri.parse(it) })
            .build()
        val item = MediaItem.Builder()
            .setMediaId(b.getString("id").orEmpty())
            .setUri(b.getString("uri"))
            .setMediaMetadata(meta)
        if (b.getBoolean("hls")) item.setMimeType(MimeTypes.APPLICATION_M3U8)
        return item.build()
    }
}
