package id.ytplayer

import android.net.Uri

/**
 * Mengenali tautan video Facebook: facebook.com/watch/?v=ID, /reel/ID, /videos/ID, /share/v/..., /share/r/...,
 * fb.watch/..., juga versi m. / web. / mbasic. dan tautan postingan yang memuat video.
 */
object FacebookLink {
    private val urlRe = Regex("https?://\\S+")

    private fun isFbHost(host: String): Boolean =
        host == "facebook.com" || host.endsWith(".facebook.com") ||
            host == "fb.watch" || host == "fb.com" || host.endsWith(".fb.com")

    /** Mengembalikan tautan Facebook pertama pada teks (apa adanya), atau null. */
    fun extract(text: String?): String? {
        if (text.isNullOrBlank()) return null
        for (m in urlRe.findAll(text)) {
            val raw = m.value.trimEnd('.', ',', ')', '"', '\'')
            val u = try {
                Uri.parse(raw)
            } catch (e: Exception) {
                continue
            }
            val host = u.host?.lowercase() ?: continue
            if (!isFbHost(host)) continue
            // Tautan pendek fb.watch selalu mengarah ke video.
            if (host == "fb.watch" || host.endsWith(".fb.watch")) return raw
            val path = u.path.orEmpty().lowercase()
            val hasVideoQuery = u.getQueryParameter("v") != null || u.getQueryParameter("video_id") != null
            if (path.startsWith("/watch") && hasVideoQuery ||
                path.contains("/videos/") || path.startsWith("/video.php") ||
                path.startsWith("/reel/") || path.startsWith("/reels/") ||
                path.startsWith("/share/v/") || path.startsWith("/share/r/") || path.startsWith("/share/p/") ||
                path.contains("/posts/") || path.startsWith("/permalink.php") || path.startsWith("/story.php") ||
                path.contains("/permalink/")
            ) return raw
        }
        return null
    }

    /** True bila alamat ini tautan Facebook yang dikenali. */
    fun isFacebook(link: String?): Boolean = extract(link) != null
}
