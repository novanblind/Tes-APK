package id.ytplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Data halaman channel lewat youtubei browse (klien WEB): kepala channel (nama, @handle, foto, banner,
 * jumlah subscriber dan video, deskripsi), daftar tab (Beranda, Video, Shorts, Live, Postingan, ...),
 * dan isi tab berupa bagian-bagian (mis. "Live streaming sebelumnya") berisi video.
 *
 * Bentuk respons YouTube sering berubah, jadi semuanya dibaca dengan memindai pohon JSON (seperti
 * YtApi.listSubscriptions), mengenali bentuk lama (videoRenderer) dan baru (lockupViewModel).
 * Memblokir jaringan: panggil dari utas latar. Bila sudah masuk akun dipakai cookie akun; bila belum
 * atau sesi ditolak, dipakai panggilan tanpa akun.
 */
object YtChannel {

    class Tab(val title: String, val params: String?, val selected: Boolean)
    class Post(val text: String, val date: String)
    class Section(val title: String, val items: List<VideoItem>, val posts: List<Post> = emptyList())

    class Info(
        val id: String, val title: String, val handle: String, val avatar: String?, val banner: String?,
        val subs: String, val videos: String, val description: String, val tabs: List<Tab>
    )

    /** [more] = token lanjutan untuk "Muat lagi"; null bila sudah habis. */
    class Page(val info: Info, val sections: List<Section>, val more: String?)
    class TabData(val sections: List<Section>, val more: String?)

    sealed class Load {
        class Ok(val page: Page) : Load()
        class Error(val message: String) : Load()
    }

    private fun call(c: Context, body: JSONObject): JSONObject {
        if (YtAccount.isLoggedIn(c)) {
            try {
                return YtApi.post(c, "browse", body)
            } catch (e: IOException) {
                val m = e.message.orEmpty()
                if (!(m.startsWith("HTTP 401") || m.startsWith("HTTP 403"))) throw e
            }
        }
        return YtApi.post(c, "browse", body, anon = true)
    }

    /** Beranda channel: kepala, tab, dan bagian-bagian tab Beranda. */
    fun load(c: Context, channelId: String): Load = try {
        val json = call(c, JSONObject().put("browseId", channelId))
        val info = parseInfo(json, channelId)
        val data = parseSections(json, info.title, channelId)
        Load.Ok(Page(info, data.sections, data.more))
    } catch (e: IOException) {
        Load.Error(e.message ?: "galat jaringan")
    } catch (e: Exception) {
        Load.Error(e.javaClass.simpleName)
    }

    /** Isi satu tab selain Beranda. Melempar IOException bila jaringan gagal. */
    @Throws(IOException::class)
    fun loadTab(c: Context, info: Info, tab: Tab): TabData {
        val body = JSONObject().put("browseId", info.id)
        if (!tab.params.isNullOrEmpty()) body.put("params", tab.params)
        return parseSections(call(c, body), info.title, info.id)
    }

    /** Halaman lanjutan sebuah tab. */
    @Throws(IOException::class)
    fun loadMore(c: Context, info: Info, token: String): TabData =
        parseSections(call(c, JSONObject().put("continuation", token)), info.title, info.id)

    private val detailCache = HashMap<String, Map<String, VideoItem>>()

    /**
     * Rincian video channel (durasi, teks "Streaming 1 hari yang lalu", penonton) dari beranda, tab Video,
     * dan tab Live, dengan kunci tautan video. Dipakai melengkapi daftar RSS di layar channel.
     * Kosong bila gagal (tidak pernah melempar). Hasil disimpan selama aplikasi berjalan.
     */
    fun details(c: Context, channelId: String): Map<String, VideoItem> {
        synchronized(detailCache) { detailCache[channelId]?.let { return it } }
        val out = HashMap<String, VideoItem>()
        try {
            val ok = load(c, channelId) as? Load.Ok ?: return out
            val info = ok.page.info
            for (t in info.tabs) {
                val low = t.title.trim().lowercase()
                if (low == "video" || low == "videos" || low == "live") {
                    try {
                        for (sec in loadTab(c, info, t).sections) for (v in sec.items) out.putIfAbsent(v.url, v)
                    } catch (_: Exception) {
                    }
                }
            }
            for (sec in ok.page.sections) for (v in sec.items) out.putIfAbsent(v.url, v)
        } catch (_: Exception) {
        }
        if (out.isNotEmpty()) synchronized(detailCache) { detailCache[channelId] = out }
        return out
    }

    // ---- kepala channel

    private fun lastUrl(arr: JSONArray?): String? {
        if (arr == null || arr.length() == 0) return null
        val u = arr.optJSONObject(arr.length() - 1)?.optString("url").orEmpty()
        return when {
            u.isEmpty() -> null
            u.startsWith("//") -> "https:$u"
            else -> u
        }
    }

    private fun parseInfo(json: JSONObject, channelId: String): Info {
        val meta = YtApi.findKey(json, "channelMetadataRenderer") as? JSONObject
        val c4 = YtApi.findKey(json, "c4TabbedHeaderRenderer") as? JSONObject
        val title = meta?.optString("title").orEmpty().ifBlank { c4?.optString("title").orEmpty() }.ifBlank { channelId }
        val avatar = lastUrl(meta?.optJSONObject("avatar")?.optJSONArray("thumbnails"))
            ?: lastUrl(c4?.optJSONObject("avatar")?.optJSONArray("thumbnails"))
            ?: lastUrl((YtApi.findKey(json, "avatarViewModel") as? JSONObject)?.optJSONObject("image")?.optJSONArray("sources"))
        val banner = lastUrl(c4?.optJSONObject("banner")?.optJSONArray("thumbnails"))
            ?: lastUrl((YtApi.findKey(json, "imageBannerViewModel") as? JSONObject)?.optJSONObject("image")?.optJSONArray("sources"))

        var handle = ""
        var subs = YtApi.textOf(c4?.optJSONObject("subscriberCountText"))
        var videos = YtApi.textOf(c4?.optJSONObject("videosCountText"))
        // Bentuk baru: baris metadata di pageHeaderViewModel (@handle, jumlah subscriber, jumlah video).
        val header = YtApi.findKey(json, "pageHeaderViewModel")
        val parts = ArrayList<String>()
        collectMetadataParts(header, parts)
        for (p in parts) {
            val low = p.lowercase()
            when {
                p.startsWith("@") -> if (handle.isEmpty()) handle = p
                low.contains("subscriber") || low.contains("pelanggan") -> if (subs.isBlank()) subs = p
                low.endsWith(" video") || low.endsWith(" videos") -> if (videos.isBlank()) videos = p
            }
        }
        if (handle.isEmpty()) {
            val v = meta?.optString("vanityChannelUrl").orEmpty().substringAfterLast('/')
            if (v.startsWith("@")) handle = v
        }
        if (videos.isNotBlank() && !videos.lowercase().contains("video")) videos = "$videos video"
        val description = meta?.optString("description").orEmpty().ifBlank { c4?.optString("tagline").orEmpty() }
        return Info(channelId, title, handle, avatar, banner, subs, videos, description.trim(), parseTabs(json))
    }

    private fun collectMetadataParts(node: Any?, out: MutableList<String>) {
        when (node) {
            is JSONObject -> {
                val parts = node.optJSONArray("metadataParts")
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val t = parts.optJSONObject(i)?.optJSONObject("text")?.optString("content").orEmpty()
                        if (t.isNotBlank()) out += t
                    }
                }
                val ks = node.keys()
                while (ks.hasNext()) collectMetadataParts(node.opt(ks.next()), out)
            }
            is JSONArray -> for (i in 0 until node.length()) collectMetadataParts(node.opt(i), out)
        }
    }

    private fun parseTabs(json: JSONObject): List<Tab> {
        val out = ArrayList<Tab>()
        fun walk(node: Any?) {
            when (node) {
                is JSONObject -> {
                    val tr = node.optJSONObject("tabRenderer")
                    if (tr != null) {
                        val t = tr.optString("title")
                        if (t.isNotBlank() && out.none { it.title == t }) {
                            val params = tr.optJSONObject("endpoint")?.optJSONObject("browseEndpoint")
                                ?.optString("params")?.takeIf { it.isNotEmpty() }
                            out += Tab(t, params, tr.optBoolean("selected"))
                        }
                    }
                    val ks = node.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        if (k != "tabRenderer") walk(node.opt(k))
                    }
                }
                is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i))
            }
        }
        walk(json.optJSONObject("contents"))
        return out
    }

    // ---- isi tab

    private val SHELVES = setOf("shelfRenderer", "richShelfRenderer", "reelShelfRenderer")
    private val VIDEO_KEYS = setOf(
        "videoRenderer", "gridVideoRenderer", "compactVideoRenderer",
        "lockupViewModel", "shortsLockupViewModel", "reelItemRenderer"
    )

    private class Ctx(val uploader: String, val channelId: String) {
        val seen = HashSet<String>()
    }

    private fun parseSections(json: JSONObject, uploader: String, channelId: String): TabData {
        val ctx = Ctx(uploader, channelId)
        val sections = ArrayList<Section>()
        val loose = ArrayList<VideoItem>()
        val posts = ArrayList<Post>()
        walk(json.opt("contents") ?: json.opt("onResponseReceivedActions"), ctx, sections, loose, posts)
        if (loose.isNotEmpty() || posts.isNotEmpty()) sections += Section("", loose, posts)
        val tok = (YtApi.findKey(json, "continuationItemRenderer") as? JSONObject)
            ?.optJSONObject("continuationEndpoint")?.optJSONObject("continuationCommand")
            ?.optString("token")?.takeIf { it.isNotEmpty() }
        return TabData(sections, tok)
    }

    private fun walk(
        node: Any?, ctx: Ctx, sections: MutableList<Section>,
        loose: MutableList<VideoItem>, posts: MutableList<Post>
    ) {
        when (node) {
            is JSONObject -> {
                val ks = node.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    val v = node.opt(k)
                    var handled = false
                    if (v is JSONObject) {
                        if (k in SHELVES) {
                            val items = ArrayList<VideoItem>()
                            scan(v, ctx, items)
                            if (items.isNotEmpty()) sections += Section(YtApi.textOf(v.optJSONObject("title")), items)
                            handled = true
                        } else if (k == "backstagePostRenderer") {
                            parsePost(v)?.let { posts += it }
                            handled = true
                        } else if (k in VIDEO_KEYS) {
                            parseVideo(k, v, ctx)?.let { if (ctx.seen.add(it.url)) loose += it }
                            handled = true
                        }
                    }
                    if (!handled) walk(v, ctx, sections, loose, posts)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i), ctx, sections, loose, posts)
        }
    }

    /** Mengumpulkan semua video di bawah [node] (dipakai isi satu bagian/rak). */
    private fun scan(node: Any?, ctx: Ctx, out: MutableList<VideoItem>) {
        when (node) {
            is JSONObject -> {
                val ks = node.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    val v = node.opt(k)
                    if (v is JSONObject && k in VIDEO_KEYS) {
                        parseVideo(k, v, ctx)?.let { if (ctx.seen.add(it.url)) out += it }
                    } else {
                        scan(v, ctx, out)
                    }
                }
            }
            is JSONArray -> for (i in 0 until node.length()) scan(node.opt(i), ctx, out)
        }
    }

    private fun parsePost(o: JSONObject): Post? {
        val text = YtApi.textOf(o.optJSONObject("contentText")).trim()
        if (text.isEmpty()) return null
        return Post(text, YtApi.textOf(o.optJSONObject("publishedTimeText")))
    }

    // ---- satu video

    /** "1:15:03" atau "1.15.03" jadi detik; 0 bila tidak terbaca. */
    private fun parseClock(t: String): Long {
        val parts = t.trim().split(':', '.')
        if (parts.size !in 2..3) return 0L
        var total = 0L
        for (p in parts) total = total * 60 + (p.trim().toLongOrNull() ?: return 0L)
        return total
    }

    private val COUNT_RE = Regex("([0-9][0-9.,]*)\\s*(rb|ribu|jt|juta|miliar|m|k|b)?(?![A-Za-z])", RegexOption.IGNORE_CASE)

    /** "306 rb x ditonton" jadi 306000; -1 bila tidak terbaca. */
    private fun parseCount(text: String): Long {
        val m = COUNT_RE.find(text) ?: return -1L
        val num = m.groupValues[1].trimEnd('.', ',')
        val suf = m.groupValues[2].lowercase()
        val mult = when (suf) {
            "rb", "ribu", "k" -> 1e3
            "jt", "juta" -> 1e6
            "miliar", "b" -> 1e9
            "m" -> if (Regex("view|subscriber|watching", RegexOption.IGNORE_CASE).containsMatchIn(text)) 1e6 else 1e9
            else -> 1.0
        }
        val v = if (suf.isEmpty()) num.replace(".", "").replace(",", "").toDoubleOrNull()
        else num.replace(",", ".").toDoubleOrNull()
        return if (v == null) -1L else (v * mult).toLong()
    }

    private fun isViewsText(t: String): Boolean {
        val low = t.lowercase()
        return low.contains("ditonton") || low.contains("views") || low.contains("tontonan")
    }

    private fun isDateText(t: String): Boolean {
        val low = t.lowercase()
        return low.contains("lalu") || low.contains(" ago") || low.startsWith("streaming") ||
            low.startsWith("disiarkan") || low.startsWith("streamed") || low.startsWith("tayang") ||
            low.startsWith("premiered")
    }

    private fun parseVideo(key: String, o: JSONObject, ctx: Ctx): VideoItem? = when (key) {
        "lockupViewModel" -> parseLockup(o, ctx)
        "shortsLockupViewModel" -> parseShortsLockup(o, ctx)
        "reelItemRenderer" -> parseReel(o, ctx)
        else -> parseRenderer(o, ctx)
    }

    private fun item(
        id: String, title: String, thumb: String?, dur: Long, viewsText: String, date: String,
        ctx: Ctx, isShort: Boolean = false
    ) = VideoItem(
        url = "https://www.youtube.com/watch?v=$id",
        title = title,
        uploader = ctx.uploader,
        thumb = thumb,
        durationSec = dur,
        views = if (isViewsText(viewsText)) parseCount(viewsText) else -1L,
        date = date,
        isShort = isShort,
        channelId = ctx.channelId,
        publishedAt = 0L,
        viewsText = viewsText
    )

    /** videoRenderer / gridVideoRenderer / compactVideoRenderer (bentuk lama). */
    private fun parseRenderer(o: JSONObject, ctx: Ctx): VideoItem? {
        val id = o.optString("videoId")
        if (id.isEmpty()) return null
        val title = YtApi.textOf(o.optJSONObject("title")).ifBlank { return null }
        var dur = parseClock(YtApi.textOf(o.optJSONObject("lengthText")))
        var live = o.toString().contains("BADGE_STYLE_TYPE_LIVE_NOW")
        val overlays = o.optJSONArray("thumbnailOverlays")
        if (overlays != null) {
            for (i in 0 until overlays.length()) {
                val tr = overlays.optJSONObject(i)?.optJSONObject("thumbnailOverlayTimeStatusRenderer") ?: continue
                if (tr.optString("style") == "LIVE") live = true
                if (dur <= 0L) dur = parseClock(YtApi.textOf(tr.optJSONObject("text")))
            }
        }
        return item(
            id, title, lastUrl(o.optJSONObject("thumbnail")?.optJSONArray("thumbnails")),
            if (live) -1L else dur,
            YtApi.textOf(o.optJSONObject("viewCountText")),
            YtApi.textOf(o.optJSONObject("publishedTimeText")), ctx
        )
    }

    /** lockupViewModel (bentuk baru); hanya yang bertipe video. */
    private fun parseLockup(o: JSONObject, ctx: Ctx): VideoItem? {
        val id = o.optString("contentId")
        if (id.isEmpty() || !o.optString("contentType").contains("VIDEO")) return null
        val meta = o.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel")
        val title = meta?.optJSONObject("title")?.optString("content").orEmpty().ifBlank { return null }
        val thumb = lastUrl(
            o.optJSONObject("contentImage")?.optJSONObject("thumbnailViewModel")
                ?.optJSONObject("image")?.optJSONArray("sources")
        )
        var dur = 0L
        var live = false
        val badges = ArrayList<JSONObject>()
        collectKey(o.optJSONObject("contentImage"), "thumbnailBadgeViewModel", badges)
        for (b in badges) {
            val t = b.optString("text")
            if (t.equals("LIVE", true) || t.equals("LANGSUNG", true)) live = true
            else if (dur <= 0L) dur = parseClock(t)
        }
        val texts = ArrayList<String>()
        collectMetadataParts(meta, texts)
        val views = texts.firstOrNull { isViewsText(it) }.orEmpty()
        val date = texts.firstOrNull { isDateText(it) }.orEmpty()
        return item(id, title, thumb, if (live) -1L else dur, views, date, ctx)
    }

    private fun parseShortsLockup(o: JSONObject, ctx: Ctx): VideoItem? {
        val id = (YtApi.findKey(o, "videoId") as? String).orEmpty()
        if (id.isEmpty()) return null
        val ov = o.optJSONObject("overlayMetadata")
        val title = ov?.optJSONObject("primaryText")?.optString("content").orEmpty().ifBlank { "Shorts" }
        val thumb = lastUrl(o.optJSONObject("thumbnail")?.optJSONArray("sources"))
            ?: lastUrl(YtApi.findKey(o, "sources") as? JSONArray)
        val views = ov?.optJSONObject("secondaryText")?.optString("content").orEmpty()
        return item(id, title, thumb, 0L, views, "", ctx, isShort = true)
    }

    private fun parseReel(o: JSONObject, ctx: Ctx): VideoItem? {
        val id = o.optString("videoId")
        if (id.isEmpty()) return null
        val title = YtApi.textOf(o.optJSONObject("headline")).ifBlank { "Shorts" }
        return item(
            id, title, lastUrl(o.optJSONObject("thumbnail")?.optJSONArray("thumbnails")), 0L,
            YtApi.textOf(o.optJSONObject("viewCountText")), "", ctx, isShort = true
        )
    }

    private fun collectKey(node: Any?, key: String, out: MutableList<JSONObject>) {
        when (node) {
            is JSONObject -> {
                val ks = node.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    val v = node.opt(k)
                    if (k == key && v is JSONObject) out += v else collectKey(v, key, out)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) collectKey(node.opt(i), key, out)
        }
    }
}
