package id.ytplayer.music

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager

/** Kunci dan pembantu untuk pengaturan aplikasi. */
object Prefs {
    const val CROSSFADE = "crossfade"              // detik; "0" = gapless (tanpa jeda)
    const val CROSSFADE_MANUAL = "crossfade_manual"
    const val SKIP_SILENCE = "skip_silence"
    const val PREV_RESTART = "prev_restart"
    const val PREV_RESTART_SEC = "prev_restart_sec" // detik; berlaku di Music Player, YouTube Music, YT Player
    const val PAUSE_UNPLUG = "pause_unplug"
    const val REMEMBER_QUEUE = "remember_queue"
    const val AUTO_START_OUTPUT = "auto_start_output" // putar otomatis saat headset/Bluetooth tersambung
    const val ADVANCE_FOLDER = "advance_folder"       // lanjut ke folder berikutnya setelah folder selesai
    const val ANNOUNCE = "announce_track"
    const val DUCK_MODE = "duck_mode"                 // notifikasi/pembaca layar: "duck", "pause", "ignore"
    const val DUCK_PERCENT = "duck_percent"           // volume (%) saat dikecilkan
    const val FOCUS_TRANSIENT = "focus_transient"     // panggilan/suara lain sementara: "pause_resume", "pause", "ignore"
    const val FOCUS_LOSS = "focus_loss"               // fokus hilang permanen: "pause", "ignore"
    const val TRACK_POS = "track_pos"                 // simpan posisi per lagu
    const val TRACK_POS_MIN = "track_pos_min"         // menit; 0 = semua lagu
    const val RG_MODE = "rg_mode"                     // "off", "track", "album"
    const val RG_PREAMP = "rg_preamp"                 // dB untuk lagu bertag
    const val RG_UNTAGGED = "rg_untagged"             // dB untuk lagu tanpa tag
    const val AUDIO_FOCUS = "audio_focus"
    const val SEEK_STEP = "seek_step"
    const val THEME = "theme"
    const val SORT = "sort"
    const val MIN_DURATION = "min_duration"

    /** Pengaturan yang diubah lewat layar Pengaturan. */
    fun of(c: Context): SharedPreferences = PreferenceManager.getDefaultSharedPreferences(c)

    /** Status pemutar (antrean terakhir, mode ulang/acak, kecepatan). */
    fun state(c: Context): SharedPreferences = c.getSharedPreferences("state", Context.MODE_PRIVATE)

    fun crossfadeSec(c: Context): Int = of(c).getString(CROSSFADE, "3")?.toIntOrNull() ?: 3

    /** Batas "sebelumnya": lewat dari ini, tombol mengulang lagu dari awal (bawaan 10 detik). */
    val PREV_RESTART_CHOICES = listOf(3, 5, 10, 15, 20, 30)

    fun prevRestartSec(c: Context): Int =
        (of(c).getString(PREV_RESTART_SEC, "10")?.toIntOrNull() ?: 10)
            .let { if (it in PREV_RESTART_CHOICES) it else 10 }

    fun prevRestartMs(c: Context): Long = prevRestartSec(c) * 1000L

    fun setPrevRestartSec(c: Context, sec: Int) =
        of(c).edit().putString(PREV_RESTART_SEC, sec.toString()).apply()

    fun seekStepMs(c: Context): Long =
        (of(c).getString(SEEK_STEP, "10")?.toLongOrNull() ?: 10L) * 1000L

    fun librarySig(c: Context): String =
        "${of(c).getString(SORT, "path")}|${of(c).getString(MIN_DURATION, "0")}"

    fun applyTheme(c: Context) {
        val mode = when (of(c).getString(THEME, "system")) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }
}
