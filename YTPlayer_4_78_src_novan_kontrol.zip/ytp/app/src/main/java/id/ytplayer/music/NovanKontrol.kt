package id.ytplayer.music

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import java.util.Locale

/**
 * Pintu kendali dari luar untuk skrip Lua (main.lua "Mesin audio Novan").
 * Alamat: content://id.ytplayer.novan.kontrol
 * Skrip memanggil ContentResolver.call(alamat, perintah, isian, null). Hasilnya Bundle berisi teks:
 * ok ("1" atau "0"), pesan (kalimat singkat untuk diucapkan), data (keadaan lengkap, satu baris kunci=nilai),
 * dan teks (hanya untuk "kurva_salin"). Semua fitur layar Mesin audio Novan tersedia di sini.
 */
class NovanKontrolProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        val ctx = context ?: return null
        val h = NovanKontrol.jalankan(ctx, method, arg.orEmpty())
        return Bundle().apply {
            putString("ok", if (h.ok) "1" else "0")
            putString("pesan", h.pesan)
            if (h.teks != null) putString("teks", h.teks)
            putString("data", NovanKontrol.dump(ctx))
        }
    }

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?,
    ): Cursor? = null

    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}

class NovanHasil(val ok: Boolean, val pesan: String, val teks: String? = null)

object NovanKontrol {
    private fun ok(p: String, teks: String? = null) = NovanHasil(true, p, teks)
    private fun gagal(p: String) = NovanHasil(false, p)

    private fun angka(a: String): Double? = a.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() }
    private fun bulat(a: String): Int? = angka(a)?.let { Math.round(it).toInt() }

    /** "1" hidup, "0" mati, "t" balik dari keadaan sekarang. */
    private fun saklar(a: String, sekarang: Boolean): Boolean? = when (a.trim().lowercase()) {
        "1", "true", "ya" -> true
        "0", "false", "tidak" -> false
        "t" -> !sekarang
        else -> null
    }

    private fun fmt(v: Double): String =
        if (v == Math.rint(v)) v.toInt().toString() else String.format(Locale("id"), "%.1f", v)

    private fun ucapDb(v: Double): String = when {
        v > 0 -> "naik ${fmt(v)} desibel"
        v < 0 -> "turun ${fmt(-v)} desibel"
        else -> "datar, 0 desibel"
    }

    private fun persen(v: Int) = if (v <= 0) "mati" else "$v persen"

    private fun plain(v: Double): String = if (v == Math.rint(v)) v.toInt().toString() else v.toString()

    private fun hzLabel(hz: Double): String =
        if (hz >= 1000) String.format(Locale("id"), "%.2f kHz", hz / 1000.0).replace(",00", "")
        else "${hz.toInt()} Hz"

    /** Sama dengan NovanEngineActivity.put: ubah satu angka, kembalikan mode suara ke Kustom bila perlu, lalu muat ulang. */
    private fun put(ctx: Context, key: String, value: Int) {
        val e = Prefs.of(ctx).edit().putInt(key, value)
        when (key) {
            NovanEngine.K_REV_MIX, NovanEngine.K_REV_ROOM, NovanEngine.K_REV_DAMP ->
                e.putInt(NovanEngine.K_ROOM_PRESET, -1)
            NovanEngine.K_COMP_THR, NovanEngine.K_COMP_RATIO, NovanEngine.K_COMP_ATK, NovanEngine.K_COMP_REL,
            NovanEngine.K_COMP_MK, NovanEngine.K_OUTGAIN, NovanEngine.K_LIM_CEIL, NovanEngine.K_LIM_REL -> {
            }
            else -> e.putInt(NovanEngine.K_PRESET, -1)
        }
        e.apply()
        NovanEngine.reload(ctx)
    }

    private fun atur(ctx: Context, a: String, key: String, lo: Int, hi: Int, pesan: (Int) -> String): NovanHasil {
        val v = (bulat(a) ?: return gagal("Nilai tidak sah.")).coerceIn(lo, hi)
        put(ctx, key, v)
        return ok(pesan(v))
    }

    private fun tombol(ctx: Context, key: String, a: String, def: Boolean, hidup: String, mati: String): NovanHasil {
        val p = Prefs.of(ctx)
        val v = saklar(a, p.getBoolean(key, def)) ?: return gagal("Nilai tidak sah.")
        p.edit().putBoolean(key, v).apply()
        NovanEngine.reload(ctx)
        return ok(if (v) hidup else mati)
    }

    fun jalankan(ctx: Context, m: String, a: String): NovanHasil {
        val p = Prefs.of(ctx)
        val mode = NovanEngine.mode(ctx)
        return try {
            when (m) {
                "status" -> ok(ringkas(ctx))

                // ── Mesin dan mode ──
                "aktif" -> tombol(ctx, NovanEngine.K_ON, a, false, "Mesin audio aktif.", "Mesin audio mati.")
                "mode" -> {
                    val i = bulat(a) ?: return gagal("Nilai tidak sah.")
                    if (i == -1) {
                        p.edit().putInt(NovanEngine.K_PRESET, -1).apply()
                        ok("Mode Kustom.")
                    } else {
                        val pr = NovanEngine.PRESETS.getOrNull(i) ?: return gagal("Mode tidak ditemukan.")
                        NovanEngine.applyPreset(ctx, i)
                        ok("Mode ${pr.name}.")
                    }
                }

                // ── Kelola kurva ──
                "kurva_simpan" -> {
                    val nama = a.trim()
                    if (nama.isEmpty()) gagal("Nama kosong, tidak disimpan.")
                    else {
                        NovanEngine.saveCustom(ctx, mode, nama, NovanEngine.gains(ctx, mode))
                        ok("Tersimpan: $nama.")
                    }
                }
                "kurva_pilih" -> {
                    val g = NovanEngine.customs(ctx, mode)[a.trim()] ?: return gagal("Mode kustom tidak ada.")
                    p.edit().putBoolean(NovanEngine.K_ON, true).apply()
                    NovanEngine.setCurve(ctx, mode, g)
                    ok("Mode kustom ${a.trim()} dipakai.")
                }
                "kurva_hapus" -> {
                    if (!NovanEngine.customs(ctx, mode).containsKey(a.trim())) gagal("Mode kustom tidak ada.")
                    else {
                        NovanEngine.deleteCustom(ctx, mode, a.trim())
                        ok("Dihapus: ${a.trim()}.")
                    }
                }
                "kurva_salin" -> ok("Kurva disalin.", NovanEngine.exportCurve(ctx, mode))
                "kurva_tempel" ->
                    if (NovanEngine.importCurve(ctx, a)) ok("Kurva ditempel.") else gagal("Teks itu bukan kurva yang sah.")
                "datar" -> {
                    NovanEngine.setCurve(ctx, mode, DoubleArray(mode))
                    ok("Kurva datar.")
                }

                // ── Penguat awal dan pita ──
                "preamp" -> atur(ctx, a, NovanEngine.K_PREAMP, -12, 12) { "Preamp ${ucapDb(it.toDouble())}." }
                "headroom" -> tombol(ctx, NovanEngine.K_HEADROOM, a, false, "Headroom otomatis hidup.", "Headroom otomatis mati.")
                "jumlah_pita" -> {
                    val n = bulat(a)?.takeIf { it == 10 || it == 32 } ?: return gagal("Pilih 10 atau 32.")
                    p.edit().putString(NovanEngine.K_MODE, n.toString()).apply()
                    NovanEngine.reload(ctx)
                    ok("$n pita.")
                }
                "langkah" -> {
                    val v = saklar(a, p.getBoolean(NovanEngine.K_FINE, false)) ?: return gagal("Nilai tidak sah.")
                    p.edit().putBoolean(NovanEngine.K_FINE, v).apply()
                    ok(if (v) "Langkah 0 koma 5 desibel." else "Langkah 1 desibel.")
                }
                // isian: nomor pita (mulai 0) ; nilai dB
                "gain" -> {
                    val x = a.split(";")
                    if (x.size != 2) return gagal("Format salah.")
                    val i = x[0].trim().toIntOrNull()?.takeIf { it in 0 until mode } ?: return gagal("Nomor pita tidak sah.")
                    val v = angka(x[1]) ?: return gagal("Nilai tidak sah.")
                    val db = (Math.round(v.coerceIn(-12.0, 12.0) * 2.0) / 2.0)
                    NovanEngine.setGain(ctx, mode, i, db)
                    ok("Pita ${i + 1}, ${hzLabel(NovanEngine.hz(mode)[i])}, ${ucapDb(db)}.")
                }

                // ── Nada dan penyempurna suara ──
                "bass" -> atur(ctx, a, NovanEngine.K_BASS, -12, 12) { "Bass ${ucapDb(it.toDouble())}." }
                "treble" -> atur(ctx, a, NovanEngine.K_TREBLE, -12, 12) { "Treble ${ucapDb(it.toDouble())}." }
                "kejernihan" -> atur(ctx, a, NovanEngine.K_CLARITY, 0, 100) { "Kejernihan vokal ${persen(it)}." }
                "bass_cerdas" -> atur(ctx, a, NovanEngine.K_SMARTBASS, 0, 100) { "Bass cerdas ${persen(it)}." }
                "suara_pelan" -> atur(ctx, a, NovanEngine.K_SOFTVOL, 0, 100) { "Penguat suara pelan ${persen(it)}." }
                "karakter_bass" -> {
                    val i = bulat(a)?.takeIf { it in NovanEngine.BASS_CHARS.indices } ?: return gagal("Pilihan tidak sah.")
                    p.edit().putInt(NovanEngine.K_BASSCHAR, i).apply()
                    NovanEngine.reload(ctx)
                    ok("Karakter bass ${NovanEngine.BASS_CHARS[i].first}.")
                }

                // ── Kompresor 3 pita ──
                "komp_aktif" -> tombol(ctx, NovanEngine.K_COMP_ON, a, false, "Kompresor hidup.", "Kompresor mati.")
                "komp_ambang" -> atur(ctx, a, NovanEngine.K_COMP_THR, -60, 0) { "Ambang kompresor $it desibel." }
                "komp_rasio" -> atur(ctx, a, NovanEngine.K_COMP_RATIO, 1, 20) { "Rasio kompresor $it banding 1." }
                "komp_serang" -> atur(ctx, a, NovanEngine.K_COMP_ATK, 1, 200) { "Waktu serang $it milidetik." }
                "komp_lepas" -> atur(ctx, a, NovanEngine.K_COMP_REL, 10, 2000) { "Waktu lepas $it milidetik." }
                "komp_makeup" -> atur(ctx, a, NovanEngine.K_COMP_MK, 0, 12) { "Penguat makeup $it desibel." }

                // ── Ruang suara dan reverb ──
                "lebar" -> atur(ctx, a, NovanEngine.K_WIDTH, 0, 200) { "Lebar stereo $it persen." }
                "keseimbangan" -> atur(ctx, a, NovanEngine.K_BALANCE, -100, 100) {
                    when {
                        it > 0 -> "Keseimbangan kanan $it persen."
                        it < 0 -> "Keseimbangan kiri ${-it} persen."
                        else -> "Keseimbangan tengah."
                    }
                }
                "mono" -> tombol(ctx, NovanEngine.K_MONO, a, false, "Campur ke mono hidup.", "Campur ke mono mati.")
                "mode_ruang" -> {
                    val i = bulat(a) ?: return gagal("Nilai tidak sah.")
                    if (i == -1) {
                        p.edit().putInt(NovanEngine.K_ROOM_PRESET, -1).apply()
                        ok("Mode ruang Kustom.")
                    } else {
                        val r = NovanEngine.ROOMS.getOrNull(i) ?: return gagal("Mode ruang tidak ditemukan.")
                        NovanEngine.applyRoom(ctx, i)
                        ok("Mode ruang ${r.name}.")
                    }
                }
                "reverb_jumlah" -> atur(ctx, a, NovanEngine.K_REV_MIX, 0, 100) { "Jumlah reverb ${persen(it)}." }
                "reverb_ruang" -> atur(ctx, a, NovanEngine.K_REV_ROOM, 0, 100) { "Ukuran ruang $it persen." }
                "reverb_peredam" -> atur(ctx, a, NovanEngine.K_REV_DAMP, 0, 100) { "Peredam nada tinggi $it persen." }

                // ── Keluaran ──
                "hires" -> tombol(ctx, NovanEngine.K_HIRES, a, true, "Keluaran Hi-Res hidup.", "Keluaran Hi-Res mati.")
                "laju" -> {
                    val v = a.trim()
                    if (v !in listOf("auto", "file", "48000", "96000", "192000", "384000")) return gagal("Pilihan tidak sah.")
                    p.edit().putString(NovanEngine.K_RATE, v).apply()
                    NovanEngine.reload(ctx)
                    ok("Laju keluaran diubah.")
                }
                "bitperfect" -> {
                    if (Build.VERSION.SDK_INT < 34) return gagal("Bit-perfect perlu Android 14 ke atas.")
                    tombol(ctx, NovanEngine.K_BITPERFECT, a, false, "Bit-perfect hidup.", "Bit-perfect mati.")
                }
                "per_perangkat" -> {
                    val v = saklar(a, NovanEngine.perDeviceEnabled(ctx)) ?: return gagal("Nilai tidak sah.")
                    NovanEngine.setPerDevice(ctx, v)
                    ok(if (v) "Suara per perangkat hidup." else "Suara per perangkat mati.")
                }

                // ── Pengaman ──
                "penguat_akhir" -> atur(ctx, a, NovanEngine.K_OUTGAIN, -12, 12) { "Penguat akhir ${ucapDb(it.toDouble())}." }
                "limiter" -> tombol(ctx, NovanEngine.K_LIMITER, a, true, "Limiter hidup.", "Limiter mati.")
                // isian dalam dB (mis. -0.5); disimpan per 0,1 dB
                "limiter_batas" -> {
                    val d = angka(a) ?: return gagal("Nilai tidak sah.")
                    val v = Math.round(d * 10.0).toInt().coerceIn(-300, 0)
                    put(ctx, NovanEngine.K_LIM_CEIL, v)
                    ok("Batas limiter ${fmt(v / 10.0)} desibel.")
                }
                "limiter_lepas" -> atur(ctx, a, NovanEngine.K_LIM_REL, 10, 1000) { "Pelepasan limiter $it milidetik." }

                "reset_semua" -> {
                    NovanEngine.resetAll(ctx)
                    ok("Semua pengaturan diatur ulang.")
                }
                else -> gagal("Perintah tidak dikenal.")
            }
        } catch (e: Throwable) {
            gagal("Gagal: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun ringkas(ctx: Context): String {
        val p = Prefs.of(ctx)
        val on = p.getBoolean(NovanEngine.K_ON, false)
        if (!on) return "Mesin audio mati."
        val idx = p.getInt(NovanEngine.K_PRESET, -1)
        val nama = NovanEngine.PRESETS.getOrNull(idx)?.name ?: "Kustom"
        val dev = NovanEngine.DEV_NAMES[NovanEngine.deviceCategory(ctx)] ?: "Speaker HP"
        return "Mesin audio aktif, ${NovanEngine.mode(ctx)} pita, mode $nama, keluaran $dev."
    }

    fun dump(ctx: Context): String {
        val p = Prefs.of(ctx)
        val mode = NovanEngine.mode(ctx)
        val g = NovanEngine.gains(ctx, mode)
        val f = NovanEngine.hz(mode)
        fun b(x: Boolean) = if (x) "1" else "0"
        fun bersih(s: String) = s.replace("|", " ").replace("~", " ").replace("\n", " ")
        return buildString {
            fun k(n: String, v: Any) { append(n).append('=').append(v).append('\n') }
            k("aktif", b(p.getBoolean(NovanEngine.K_ON, false)))
            k("status", bersih(ringkas(ctx)))
            k("preset", p.getInt(NovanEngine.K_PRESET, -1))
            k("preset_nama", NovanEngine.PRESETS.joinToString("|") { bersih(it.name) })
            k("preset_info", NovanEngine.PRESETS.joinToString("|") { bersih(it.desc) })
            k("preamp", p.getInt(NovanEngine.K_PREAMP, 0))
            k("headroom", b(p.getBoolean(NovanEngine.K_HEADROOM, false)))
            k("jumlah_pita", mode)
            k("langkah_halus", b(p.getBoolean(NovanEngine.K_FINE, false)))
            k("pita", f.joinToString("|") { hzLabel(it) })
            k("gain", g.joinToString("|") { plain(it) })
            k("mode_kustom", NovanEngine.customs(ctx, mode).keys.joinToString("|") { bersih(it) })
            k("bass", p.getInt(NovanEngine.K_BASS, 0))
            k("treble", p.getInt(NovanEngine.K_TREBLE, 0))
            k("kejernihan", p.getInt(NovanEngine.K_CLARITY, 0))
            k("bass_cerdas", p.getInt(NovanEngine.K_SMARTBASS, 0))
            k("karakter_bass", p.getInt(NovanEngine.K_BASSCHAR, 0))
            k("karakter_nama", NovanEngine.BASS_CHARS.joinToString("|") { bersih(it.first) })
            k("karakter_info", NovanEngine.BASS_CHARS.joinToString("|") { bersih(it.second) })
            k("suara_pelan", p.getInt(NovanEngine.K_SOFTVOL, 0))
            k("komp_aktif", b(p.getBoolean(NovanEngine.K_COMP_ON, false)))
            k("komp_ambang", p.getInt(NovanEngine.K_COMP_THR, -24))
            k("komp_rasio", p.getInt(NovanEngine.K_COMP_RATIO, 3))
            k("komp_serang", p.getInt(NovanEngine.K_COMP_ATK, 10))
            k("komp_lepas", p.getInt(NovanEngine.K_COMP_REL, 200))
            k("komp_makeup", p.getInt(NovanEngine.K_COMP_MK, 0))
            k("lebar", p.getInt(NovanEngine.K_WIDTH, 100))
            k("keseimbangan", p.getInt(NovanEngine.K_BALANCE, 0))
            k("mono", b(p.getBoolean(NovanEngine.K_MONO, false)))
            k("ruang_preset", p.getInt(NovanEngine.K_ROOM_PRESET, -1))
            k("ruang_nama", NovanEngine.ROOMS.joinToString("|") { bersih(it.name) })
            k("ruang_info", NovanEngine.ROOMS.joinToString("|") { bersih(it.desc) })
            k("reverb_jumlah", p.getInt(NovanEngine.K_REV_MIX, 0))
            k("reverb_ruang", p.getInt(NovanEngine.K_REV_ROOM, 50))
            k("reverb_peredam", p.getInt(NovanEngine.K_REV_DAMP, 50))
            k("hires", b(p.getBoolean(NovanEngine.K_HIRES, true)))
            k("laju", p.getString(NovanEngine.K_RATE, "auto") ?: "auto")
            k("bitperfect", b(p.getBoolean(NovanEngine.K_BITPERFECT, false)))
            k("bitperfect_ok", b(Build.VERSION.SDK_INT >= 34))
            k("per_perangkat", b(NovanEngine.perDeviceEnabled(ctx)))
            k("perangkat", NovanEngine.DEV_NAMES[NovanEngine.deviceCategory(ctx)] ?: "Speaker HP")
            k("penguat_akhir", p.getInt(NovanEngine.K_OUTGAIN, 0))
            k("limiter", b(p.getBoolean(NovanEngine.K_LIMITER, true)))
            k("limiter_batas", p.getInt(NovanEngine.K_LIM_CEIL, -5) / 10.0)
            k("limiter_lepas", p.getInt(NovanEngine.K_LIM_REL, 150))
            k("info", bersih(runCatching { NovanEngine.deviceInfo(ctx) }.getOrDefault("")))
        }
    }
}
