package com.novan.equalizer

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager

/**
 * Pintu kendali dari luar untuk skrip Lua (main.lua). Alamat: content://com.novan.equalizer.kontrol
 * Skrip memanggil ContentResolver.call(alamat, perintah, isian, null). Hasilnya Bundle berisi teks:
 * ok ("1" atau "0"), pesan (kalimat singkat untuk diucapkan), data (keadaan lengkap, satu baris kunci=nilai),
 * dan teks (hanya untuk "kurva_salin").
 */
class KontrolProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        val ctx = context ?: return null
        EqEngine.init(ctx)
        val h = KontrolLuar.jalankan(ctx, method, arg.orEmpty())
        // Efek suara hanya hidup selama proses aplikasi hidup. Tanpa layanan latar, proses ini cepat
        // dimatikan sistem dan perubahan dari skrip tidak terdengar lagi, jadi pastikan layanan berjalan.
        if (EqEngine.state.value.enabled) EqService.start(ctx)
        return Bundle().apply {
            putString("ok", if (h.ok) "1" else "0")
            putString("pesan", h.pesan)
            if (h.teks != null) putString("teks", h.teks)
            putString("data", KontrolLuar.dump(ctx))
        }
    }

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?,
    ): Cursor? = null

    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}

class Hasil(val ok: Boolean, val pesan: String, val teks: String? = null)

object KontrolLuar {
    private fun ok(p: String, teks: String? = null) = Hasil(true, p, teks)
    private fun gagal(p: String) = Hasil(false, p)

    private fun angka(a: String): Float? = a.trim().replace(',', '.').toFloatOrNull()?.takeIf { it.isFinite() }
    private fun bulat(a: String): Int? = angka(a)?.let { Math.round(it) }

    /** "1" hidup, "0" mati, "t" balik dari keadaan sekarang. */
    private fun saklar(a: String, sekarang: Boolean): Boolean? = when (a.trim().lowercase()) {
        "1", "true", "ya" -> true
        "0", "false", "tidak" -> false
        "t" -> !sekarang
        else -> null
    }

    private fun num(v: Float): String {
        val r = Math.round(v * 10) / 10f
        return if (r % 1f == 0f) r.toInt().toString() else r.toString().replace('.', ',')
    }

    private fun ucap(v: Float) = num(v).replace(",", " koma ")

    private fun db(v: Float) = when {
        v > 0f -> "plus ${ucap(v)} desibel"
        v < 0f -> "minus ${ucap(-v)} desibel"
        else -> "nol desibel"
    }

    private fun persen(v: Int) = if (v <= 0) "mati" else "$v persen"

    private val namaRute = listOf("Otomatis", "Hanya global", "Hanya sesi aplikasi")
    private val namaGaya = listOf("Mati", "Ringan", "Sedang", "Kuat")

    private fun label(ctx: Context, pkg: String): String = runCatching {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    /** Isian filter parametrik: jenis;frekuensi;penguatan;Q. */
    private fun bandDari(a: String): PeqBand? {
        val p = a.split(";")
        if (p.size != 4) return null
        val t = bulat(p[0])?.takeIf { it in Peq.typeNames.indices } ?: return null
        val f = angka(p[1]) ?: return null
        val g = angka(p[2]) ?: return null
        val q = angka(p[3]) ?: return null
        return Peq.clean(PeqBand(t, f, g, q))
    }

    private fun uraian(i: Int, b: PeqBand): String =
        "Filter ${i + 1}, ${Peq.typeNames[b.type]}, ${Bands.spoken(b.freq)}" +
            (if (Peq.usesGain(b.type)) ", ${db(b.gain)}" else "") + ", Q ${ucap(b.q)}."

    private fun din(a: String, lo: Float, hi: Float, f: (Dyn, Float) -> Dyn, pesan: (Float) -> String): Hasil {
        val v = (angka(a) ?: return gagal("Nilai tidak sah.")).coerceIn(lo, hi)
        EqEngine.updateDyn { f(it, v) }
        return ok(pesan(v))
    }

    private fun persenAtur(a: String, atur: (Int) -> Unit, nama: String): Hasil {
        val v = (bulat(a) ?: return gagal("Nilai tidak sah.")).coerceIn(0, 100)
        atur(v)
        return ok("$nama ${persen(v)}.")
    }

    fun jalankan(ctx: Context, m: String, a: String): Hasil {
        val st = EqEngine.state.value
        val d = st.dyn
        val butuhDinamika = m.startsWith("komp_") || m.startsWith("pembatas_") ||
            m == "gaya_dinamika" || m == "reset_dinamika" || m == "keseimbangan"
        if (butuhDinamika && !FxFactory.fullDynamics) return gagal("Tidak tersedia di Android 7 sampai 8.1.")
        return try {
            when (m) {
                "status" -> ok(EqEngine.status.value)

                // ── Mode ──
                "aktif" -> {
                    val v = saklar(a, st.enabled) ?: return gagal("Nilai tidak sah.")
                    EqEngine.setEnabled(v)
                    if (v) EqService.start(ctx)
                    ok(if (v) "Equalizer aktif." else "Equalizer mati.")
                }
                "mode" -> {
                    val semua = Presets.names + st.customs().keys.filter { it !in Presets.names }
                    val nama = semua.firstOrNull { it == a.trim() } ?: return gagal("Mode tidak ditemukan.")
                    if (!st.enabled) EqEngine.setEnabled(true)
                    EqEngine.applyPreset(nama)
                    EqService.start(ctx)
                    ok("Mode $nama.")
                }
                "mode_berikut" -> {
                    if (!st.enabled) EqEngine.setEnabled(true)
                    EqEngine.nextPreset()
                    EqService.start(ctx)
                    ok("Mode ${EqEngine.state.value.preset}.")
                }

                // ── Kelola kurva ──
                "kurva_simpan" ->
                    if (EqEngine.saveCustomPreset(a)) ok("Preset disimpan.")
                    else gagal("Nama tidak sah atau sudah dipakai preset bawaan.")
                "kurva_hapus" ->
                    if (a !in st.customs().keys) gagal("Preset tidak ada.")
                    else { EqEngine.deleteCustomPreset(a); ok("Preset dihapus.") }
                "kurva_salin" -> ok("Kurva disalin.", EqEngine.exportCurve())
                "kurva_tempel" ->
                    if (EqEngine.importCurve(a)) ok("Kurva ditempel.") else gagal("Teks itu bukan kurva yang sah.")
                "datar" -> { EqEngine.reset(); ok("Kembali ke datar.") }

                // ── Nada dan lebar stereo ──
                "bass" -> {
                    val v = (angka(a) ?: return gagal("Nilai tidak sah.")).coerceIn(-12f, 12f)
                    EqEngine.setTone(v, st.treble)
                    ok("Bass ${db(v)}.")
                }
                "treble" -> {
                    val v = (angka(a) ?: return gagal("Nilai tidak sah.")).coerceIn(-12f, 12f)
                    EqEngine.setTone(st.bass, v)
                    ok("Treble ${db(v)}.")
                }
                "bass_cerdas" -> persenAtur(a, { EqEngine.setSmartBass(it) }, "Bass cerdas")
                "kejernihan" -> persenAtur(a, { EqEngine.setClarity(it) }, "Kejernihan vokal")
                "suara_pelan" -> persenAtur(a, { EqEngine.setSoftVolume(it) }, "Penguat suara pelan")
                "lebar" -> persenAtur(a, { EqEngine.setWidth(it) }, "Lebar stereo")
                "karakter_bass" -> {
                    val i = bulat(a)?.takeIf { it in BassChars.names.indices } ?: return gagal("Pilihan tidak sah.")
                    EqEngine.setBassChar(i)
                    ok("Karakter bass ${BassChars.names[i]}.")
                }
                "reverb" -> {
                    val i = bulat(a)?.takeIf { it in Rooms.names.indices } ?: return gagal("Pilihan tidak sah.")
                    EqEngine.setRoom(i)
                    ok("Reverb ${Rooms.names[i]}.")
                }

                // ── Pita ──
                "jumlah_pita" -> {
                    val n = bulat(a)?.takeIf { it == 10 || it == 32 } ?: return gagal("Pilih 10 atau 32.")
                    EqEngine.setBandCount(n)
                    ok("$n pita.")
                }
                "langkah" -> {
                    val v = saklar(a, st.fine) ?: return gagal("Nilai tidak sah.")
                    EqEngine.setFine(v)
                    ok(if (v) "Langkah 0 koma 5 desibel." else "Langkah 1 desibel.")
                }
                // isian: nomor pita (mulai 0) ; nilai dB
                "gain" -> {
                    if (st.peqOn) return gagal("Mode parametrik hidup. Matikan dulu untuk mengatur pita grafis.")
                    val p = a.split(";")
                    if (p.size != 2) return gagal("Format salah.")
                    val i = p[0].trim().toIntOrNull()?.takeIf { it in 0 until st.bandCount } ?: return gagal("Nomor pita tidak sah.")
                    val v = (angka(p[1]) ?: return gagal("Nilai tidak sah.")).coerceIn(-12f, 12f)
                    EqEngine.setGain(i, v)
                    ok("Pita ${i + 1}, ${Bands.spoken(Bands.centers(st.bandCount)[i])}, ${db(v)}.")
                }

                // ── Dinamika ──
                "gaya_dinamika" -> {
                    val i = bulat(a)?.takeIf { it in 0..3 } ?: return gagal("Pilihan tidak sah.")
                    EqEngine.dynStyle(i)
                    ok("Gaya dinamika ${namaGaya[i]}.")
                }
                "komp_aktif" -> {
                    val v = saklar(a, d.compOn) ?: return gagal("Nilai tidak sah.")
                    EqEngine.updateDyn { it.copy(compOn = v) }
                    ok(if (v) "Kompresor hidup." else "Kompresor mati.")
                }
                "komp_ambang" -> din(a, -60f, 0f, { x, v -> x.copy(compThr = v) }) { "Ambang kompresor ${db(it)}." }
                "komp_rasio" -> din(a, 1f, 20f, { x, v -> x.copy(compRatio = v) }) { "Rasio kompresor ${ucap(it)} banding satu." }
                "komp_serang" -> din(a, 1f, 200f, { x, v -> x.copy(compAtk = v) }) { "Waktu serang kompresor ${ucap(it)} milidetik." }
                "komp_lepas" -> din(a, 10f, 2000f, { x, v -> x.copy(compRel = v) }) { "Waktu lepas kompresor ${ucap(it)} milidetik." }
                "komp_susulan" -> din(a, 0f, 12f, { x, v -> x.copy(compMakeup = v) }) { "Penguat susulan kompresor ${db(it)}." }
                "pembatas_aktif" -> {
                    val v = saklar(a, d.limOn) ?: return gagal("Nilai tidak sah.")
                    EqEngine.updateDyn { it.copy(limOn = v) }
                    ok(if (v) "Pembatas hidup." else "Pembatas mati.")
                }
                "pembatas_ambang" -> din(a, -30f, 0f, { x, v -> x.copy(limThr = v) }) { "Ambang pembatas ${db(it)}." }
                "pembatas_rasio" -> din(a, 1f, 20f, { x, v -> x.copy(limRatio = v) }) { "Rasio pembatas ${ucap(it)} banding satu." }
                "pembatas_serang" -> din(a, 0.5f, 50f, { x, v -> x.copy(limAtk = v) }) { "Waktu serang pembatas ${ucap(it)} milidetik." }
                "pembatas_lepas" -> din(a, 10f, 1000f, { x, v -> x.copy(limRel = v) }) { "Waktu lepas pembatas ${ucap(it)} milidetik." }
                "reset_dinamika" -> { EqEngine.resetDyn(); ok("Dinamika dan keluaran direset.") }

                // ── Keluaran ──
                "preamp" -> {
                    val v = (angka(a) ?: return gagal("Nilai tidak sah.")).coerceIn(-12f, 12f)
                    EqEngine.setPreamp(v)
                    ok("Penguat awal ${db(v)}.")
                }
                "headroom" -> {
                    val v = saklar(a, st.headroom) ?: return gagal("Nilai tidak sah.")
                    EqEngine.setHeadroom(v)
                    ok(if (v) "Headroom otomatis hidup." else "Headroom otomatis mati.")
                }
                "penguat_akhir" -> din(a, -12f, 12f, { x, v -> x.copy(outGain = v) }) { "Penguat akhir ${db(it)}." }
                "keseimbangan" -> din(a, -12f, 12f, { x, v -> x.copy(balance = v) }) {
                    when {
                        it > 0f -> "Condong ke kanan, kiri turun ${ucap(it)} desibel."
                        it < 0f -> "Condong ke kiri, kanan turun ${ucap(-it)} desibel."
                        else -> "Keseimbangan di tengah."
                    }
                }

                // ── Parametrik (nomor filter mulai 0) ──
                "peq_aktif" -> {
                    val v = saklar(a, st.peqOn) ?: return gagal("Nilai tidak sah.")
                    EqEngine.setPeqOn(v)
                    if (v && !st.enabled) { EqEngine.setEnabled(true); EqService.start(ctx) }
                    ok(if (v) "Mode parametrik hidup." else "Mode parametrik mati.")
                }
                // isian: jenis;frekuensi;penguatan;Q  (jenis 0 sampai 6, lihat peq_jenis)
                "peq_tambah" -> {
                    val b = bandDari(a) ?: return gagal("Format: jenis;frekuensi;penguatan;Q.")
                    if (EqEngine.addPeqBand(b)) ok(uraian(EqEngine.state.value.peq.size - 1, b))
                    else gagal("Maksimum ${Peq.MAX} filter.")
                }
                // isian: nomor;jenis;frekuensi;penguatan;Q
                "peq_ubah" -> {
                    val p = a.split(";", limit = 2)
                    val i = p[0].trim().toIntOrNull()?.takeIf { it in st.peq.indices } ?: return gagal("Nomor filter tidak sah.")
                    val b = bandDari(p.getOrElse(1) { "" }) ?: return gagal("Format: nomor;jenis;frekuensi;penguatan;Q.")
                    EqEngine.setPeqBand(i, b.copy(on = st.peq[i].on))
                    ok(uraian(i, b))
                }
                "peq_hapus" -> {
                    val i = bulat(a)?.takeIf { it in st.peq.indices } ?: return gagal("Nomor filter tidak sah.")
                    EqEngine.removePeqBand(i)
                    ok("Filter ${i + 1} dihapus.")
                }
                // isian: nomor;1 atau 0 (nyala atau lewati filter)
                "peq_nyala" -> {
                    val p = a.split(";")
                    val i = p.getOrNull(0)?.trim()?.toIntOrNull()?.takeIf { it in st.peq.indices } ?: return gagal("Nomor filter tidak sah.")
                    val v = saklar(p.getOrElse(1) { "" }, st.peq[i].on) ?: return gagal("Nilai tidak sah.")
                    EqEngine.setPeqBand(i, st.peq[i].copy(on = v))
                    ok(if (v) "Filter ${i + 1} nyala." else "Filter ${i + 1} dilewati.")
                }
                "peq_gandakan" -> {
                    val i = bulat(a)?.takeIf { it in st.peq.indices } ?: return gagal("Nomor filter tidak sah.")
                    if (EqEngine.duplicatePeqBand(i)) ok("Filter ${i + 1} digandakan.") else gagal("Maksimum ${Peq.MAX} filter.")
                }
                "peq_urutkan" -> { EqEngine.sortPeq(); ok("Filter diurutkan menurut frekuensi.") }
                "peq_kosongkan" -> { EqEngine.clearPeq(); ok("Filter dikosongkan.") }
                "peq_simpan" ->
                    if (EqEngine.savePeqPreset(a)) ok("Preset parametrik disimpan.")
                    else gagal("Nama tidak sah atau filter kosong.")
                "peq_pilih" -> {
                    if (!st.enabled) { EqEngine.setEnabled(true); EqService.start(ctx) }
                    if (EqEngine.applyPeqPreset(a.trim())) ok("Preset parametrik ${a.trim()}.")
                    else gagal("Preset tidak ada.")
                }
                "peq_hapus_preset" ->
                    if (a.trim() !in st.peqPresets.keys) gagal("Preset tidak ada.")
                    else { EqEngine.deletePeqPreset(a.trim()); ok("Preset parametrik dihapus.") }

                // ── Cadangan ──
                "cadangan_salin" -> ok("Cadangan disalin.", EqEngine.backupJson())
                "cadangan_pulih" ->
                    if (EqEngine.restoreBackup(a)) ok("Pengaturan dipulihkan.") else gagal("Teks itu bukan cadangan yang sah.")
                "simpan_otomatis" -> {
                    val v = saklar(a, st.autoSave) ?: return gagal("Nilai tidak sah.")
                    EqEngine.setAutoSave(v)
                    ok(if (v) "Simpan otomatis hidup." else "Simpan otomatis mati.")
                }
                "tahan_sesi" -> {
                    val v = saklar(a, st.keepSession) ?: return gagal("Nilai tidak sah.")
                    EqEngine.setKeepSession(v)
                    ok(if (v) "Tahan sesi hidup." else "Tahan sesi mati.")
                }

                // ── Per aplikasi dan lanjutan ──
                "per_aplikasi" -> {
                    val v = saklar(a, st.perApp) ?: return gagal("Nilai tidak sah.")
                    EqEngine.setPerApp(v)
                    ok(if (v) "Profil per aplikasi hidup." else "Profil per aplikasi mati.")
                }
                "profil_app_simpan" -> {
                    val pkg = EqEngine.apps.value.firstOrNull { it.pkg == a.trim() }?.pkg ?: return gagal("Aplikasi tidak dikenal.")
                    EqEngine.saveAppProfile(pkg)
                    ok("Profil ${label(ctx, pkg)} disimpan.")
                }
                "profil_app_hapus" -> {
                    val pkg = EqEngine.apps.value.firstOrNull { it.pkg == a.trim() }?.pkg ?: return gagal("Aplikasi tidak dikenal.")
                    EqEngine.deleteAppProfile(pkg)
                    ok("Profil ${label(ctx, pkg)} dihapus.")
                }
                "profil_otomatis" -> {
                    val v = saklar(a, st.autoProfile) ?: return gagal("Nilai tidak sah.")
                    EqEngine.setAutoProfile(v)
                    ok(if (v) "Profil otomatis hidup." else "Profil otomatis mati.")
                }
                "mode_kerja" -> {
                    val i = bulat(a)?.takeIf { it in 0..2 } ?: return gagal("Pilihan tidak sah.")
                    EqEngine.setRoute(i)
                    ok("Mode kerja ${namaRute[i]}.")
                }

                else -> gagal("Perintah tidak dikenal.")
            }
        } catch (t: Throwable) {
            gagal("Gagal: ${t.message ?: "kesalahan tak dikenal"}")
        }
    }

    /** Keadaan lengkap, satu baris kunci=nilai. Daftar dipisah "|". */
    fun dump(ctx: Context): String {
        val st = EqEngine.state.value
        val d = st.dyn
        val c = Bands.centers(st.bandCount)
        val semua = Presets.names + st.customs().keys.filter { it !in Presets.names }
        val bat = runCatching {
            ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
        }.getOrDefault(false)
        fun b(x: Boolean) = if (x) "1" else "0"
        fun bersih(s: String) = s.replace("|", " ").replace("~", " ").replace("\n", " ")
        return buildString {
            fun k(n: String, v: Any) { append(n).append('=').append(v).append('\n') }
            k("aktif", b(st.enabled))
            k("layanan", b(EqService.running))
            k("status", EqEngine.status.value.replace("\n", " "))
            k("preset", st.preset)
            k("mode_daftar", semua.joinToString("|"))
            k("mode_kustom", st.customs().keys.joinToString("|"))
            k("jumlah_pita", st.bandCount)
            k("langkah_halus", b(st.fine))
            k("gain", st.gains().joinToString("|"))
            k("pita", c.joinToString("|") { Bands.label(it) })
            k("pita_ucap", c.joinToString("|") { Bands.spoken(it) })
            k("preamp", st.preamp)
            k("bass", st.bass)
            k("treble", st.treble)
            k("bass_cerdas", st.smartBass)
            k("karakter_bass", st.bassChar)
            k("karakter_nama", BassChars.names.joinToString("|"))
            k("karakter_info", BassChars.hints.joinToString("|"))
            k("kejernihan", st.clarity)
            k("suara_pelan", st.softVolume)
            k("lebar", st.width)
            k("reverb", st.room)
            k("reverb_nama", Rooms.names.joinToString("|"))
            k("headroom", b(st.headroom))
            k("peq_aktif", b(st.peqOn))
            k("peq_jenis", Peq.typeNames.joinToString("|"))
            k("peq", st.peq.joinToString("|") { "${it.type},${it.freq},${it.gain},${it.q},${if (it.on) 1 else 0}" })
            k("peq_preset", st.peqName)
            k("peq_preset_daftar", st.peqPresets.keys.joinToString("|"))
            k("simpan_otomatis", b(st.autoSave))
            k("tahan_sesi", b(st.keepSession))
            k("perangkat", EqEngine.outputLabel())
            k("komp_aktif", b(d.compOn))
            k("komp_ambang", d.compThr)
            k("komp_rasio", d.compRatio)
            k("komp_serang", d.compAtk)
            k("komp_lepas", d.compRel)
            k("komp_susulan", d.compMakeup)
            k("pembatas_aktif", b(d.limOn))
            k("pembatas_ambang", d.limThr)
            k("pembatas_rasio", d.limRatio)
            k("pembatas_serang", d.limAtk)
            k("pembatas_lepas", d.limRel)
            k("penguat_akhir", d.outGain)
            k("keseimbangan", d.balance)
            k("mode_kerja", st.route)
            k("profil_otomatis", b(st.autoProfile))
            k("per_aplikasi", b(st.perApp))
            k("aplikasi", EqEngine.apps.value.joinToString("|") { "${it.pkg}~${bersih(label(ctx, it.pkg))}~${b(it.hasProfile)}" })
            k("dinamika_penuh", b(FxFactory.fullDynamics))
            k("baterai_ok", b(bat))
        }
    }
}
