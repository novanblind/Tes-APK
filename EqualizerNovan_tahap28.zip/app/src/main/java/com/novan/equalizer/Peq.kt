package com.novan.equalizer

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Satu filter parametrik. [type] adalah indeks ke [Peq.typeNames]. */
data class PeqBand(
    val type: Int = 0,
    val freq: Float = 1000f,
    val gain: Float = 0f,
    val q: Float = 1f,
    /** False: filter dilewati tanpa dihapus. */
    val on: Boolean = true,
)

/**
 * Equalizer parametrik. Tiap filter dihitung sebagai biquad (rumus RBJ, laju contoh 48 kHz),
 * lalu tanggapan gabungan (kaskade, dijumlahkan dalam dB) diambil pada titik tengah pita
 * dan diteruskan ke jalur 32 pita yang sudah ada.
 */
object Peq {
    const val MAX = 16

    val typeNames = listOf("Puncak", "Rak bass", "Rak treble", "Lolos tinggi", "Lolos rendah", "Lolos pita", "Penolak pita")
    val typeHints = listOf(
        "Mengangkat atau menurunkan sekitar satu frekuensi.",
        "Mengangkat atau menurunkan semua suara di bawah frekuensi.",
        "Mengangkat atau menurunkan semua suara di atas frekuensi.",
        "Memotong suara di bawah frekuensi.",
        "Memotong suara di atas frekuensi.",
        "Hanya meloloskan sekitar frekuensi.",
        "Menolak sekitar satu frekuensi.",
    )

    private const val FS = 48000.0
    /** Jenis yang memakai penguatan (dB). Jenis lain hanya memakai frekuensi dan Q. */
    fun usesGain(type: Int) = type in 0..2

    private fun fin(x: Float, d: Float) = if (x.isFinite()) x else d

    fun clean(b: PeqBand) = PeqBand(
        b.type.coerceIn(0, typeNames.size - 1),
        fin(b.freq, 1000f).coerceIn(20f, 20000f),
        fin(b.gain, 0f).coerceIn(-12f, 12f),
        fin(b.q, 1f).coerceIn(0.1f, 10f),
        b.on,
    )

    /** Frekuensi ke indeks slider: langkah satu semiton (1/12 oktaf) mulai 20 Hz. */
    fun toIdx(f: Float): Float =
        (12.0 * ln(f.coerceIn(20f, 20000f).toDouble() / 20.0) / ln(2.0)).toFloat().coerceIn(0f, 120f)

    fun fromIdx(i: Float): Float = (20.0 * Math.pow(2.0, i / 12.0)).toFloat().coerceIn(20f, 20000f)

    private fun coeffs(b: PeqBand): DoubleArray {
        val w0 = 2.0 * PI * b.freq / FS
        val cw = cos(w0)
        val sw = sin(w0)
        val alpha = sw / (2.0 * b.q)
        val a = Math.pow(10.0, b.gain / 40.0)
        val sa = 2.0 * sqrt(a) * alpha
        return when (b.type) {
            1 -> doubleArrayOf(
                a * ((a + 1) - (a - 1) * cw + sa),
                2 * a * ((a - 1) - (a + 1) * cw),
                a * ((a + 1) - (a - 1) * cw - sa),
                (a + 1) + (a - 1) * cw + sa,
                -2 * ((a - 1) + (a + 1) * cw),
                (a + 1) + (a - 1) * cw - sa,
            )
            2 -> doubleArrayOf(
                a * ((a + 1) + (a - 1) * cw + sa),
                -2 * a * ((a - 1) + (a + 1) * cw),
                a * ((a + 1) + (a - 1) * cw - sa),
                (a + 1) - (a - 1) * cw + sa,
                2 * ((a - 1) - (a + 1) * cw),
                (a + 1) - (a - 1) * cw - sa,
            )
            3 -> doubleArrayOf((1 + cw) / 2, -(1 + cw), (1 + cw) / 2, 1 + alpha, -2 * cw, 1 - alpha)
            4 -> doubleArrayOf((1 - cw) / 2, 1 - cw, (1 - cw) / 2, 1 + alpha, -2 * cw, 1 - alpha)
            5 -> doubleArrayOf(alpha, 0.0, -alpha, 1 + alpha, -2 * cw, 1 - alpha)
            6 -> doubleArrayOf(1.0, -2 * cw, 1.0, 1 + alpha, -2 * cw, 1 - alpha)
            else -> doubleArrayOf(
                1 + alpha * a, -2 * cw, 1 - alpha * a,
                1 + alpha / a, -2 * cw, 1 - alpha / a,
            )
        }
    }

    private fun responseDb(c: DoubleArray, f: Double): Double {
        val w = 2.0 * PI * f / FS
        val c1 = cos(w)
        val s1 = sin(w)
        val c2 = cos(2.0 * w)
        val s2 = sin(2.0 * w)
        val nr = c[0] + c[1] * c1 + c[2] * c2
        val ni = -(c[1] * s1 + c[2] * s2)
        val dr = c[3] + c[4] * c1 + c[5] * c2
        val di = -(c[4] * s1 + c[5] * s2)
        val num = nr * nr + ni * ni
        val den = dr * dr + di * di
        return 10.0 * log10(max(num, 1e-12) / max(den, 1e-12))
    }

    /** Tanggapan gabungan semua filter (dB) pada titik tengah [n] pita, dibatasi -18 sampai +18 dB. */
    fun curve(bands: List<PeqBand>, n: Int): List<Float> {
        val cs = bands.filter { it.on }.map { coeffs(clean(it)) }
        return Bands.centers(n).map { f ->
            var s = 0.0
            for (c in cs) s += responseDb(c, f.toDouble())
            s.toFloat().coerceIn(-18f, 18f)
        }
    }

    // ── Penyimpanan ──

    fun serialize(l: List<PeqBand>): String = l.joinToString("/") { "${it.type},${it.freq},${it.gain},${it.q},${if (it.on) 1 else 0}" }

    fun parse(s: String): List<PeqBand> {
        if (s.isBlank()) return emptyList()
        return s.split("/").mapNotNull { part ->
            val p = part.split(",")
            if (p.size != 4 && p.size != 5) return@mapNotNull null
            val t = p[0].toIntOrNull() ?: return@mapNotNull null
            val f = p[1].toFloatOrNull() ?: return@mapNotNull null
            val g = p[2].toFloatOrNull() ?: return@mapNotNull null
            val q = p[3].toFloatOrNull() ?: return@mapNotNull null
            clean(PeqBand(t, f, g, q, p.getOrNull(4) != "0"))
        }.take(MAX)
    }
}
