package com.novan.equalizer

import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Ubin Pengaturan Cepat: ketuk untuk menyalakan atau mematikan equalizer. */
class EqTileService : TileService() {
    override fun onStartListening() {
        refresh()
    }

    override fun onClick() {
        EqEngine.init(applicationContext)
        val on = !EqEngine.state.value.enabled
        EqEngine.setEnabled(on)
        if (on) EqService.start(applicationContext)
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        EqEngine.init(applicationContext)
        val on = EqEngine.state.value.enabled
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Equalizer"
        t.icon = Icon.createWithResource(this, R.drawable.ic_stat_eq)
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (on) "Aktif" else "Mati"
        t.updateTile()
    }
}
