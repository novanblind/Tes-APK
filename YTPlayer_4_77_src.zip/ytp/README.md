# YT music player

Pemutar video bergaya aplikasi video (beranda, kategori, kartu video, mini player) dengan:

- **Putar di latar belakang** – tetap berbunyi saat layar mati / aplikasi ditutup; kontrol dari notifikasi, layar kunci, dan tombol headset.
- **Mode audio saja** – hanya mengunduh & memutar audio (hemat kuota). Bisa diganti kapan saja, posisi lanjut.
- **Ramah tunanetra (TalkBack)**
  - Setiap video satu elemen fokus yang dibacakan lengkap (judul, channel, jumlah tonton, durasi, tanggal).
  - Menu *Tindakan* TalkBack pada tiap video: "Putar audio saja" / "Putar dengan video".
  - Tombol besar berlabel teks (Putar/Jeda, Mundur 10 detik, Maju 10 detik, Video berikutnya).
  - Bilah posisi yang bisa digeser TalkBack dengan deskripsi status ("1 menit 20 detik dari 4 menit").
  - Status (memuat, menyangga, error, hasil pencarian) dibacakan otomatis lewat *live region*.
  - Judul/bagian ditandai sebagai heading, fokus TalkBack pindah ke judul saat video baru dibuka.
  - Kecepatan putar, pewaktu tidur (15/30/45/60 menit), putar otomatis video berikutnya.
  - Mengikuti ukuran font sistem, tema terang/gelap otomatis, target sentuh ≥ 48 dp.
- **Unduh (v1.1)** – tombol *Unduh…* di halaman tonton: **audio M4A** (kualitas asli YouTube, tanpa konversi) atau **video MP4** (pilih 360p–1080p; bila perlu video & audio digabung di HP). Di daftar video, menu *Tindakan* TalkBack punya "Unduh audio M4A" dan "Unduh video MP4". Juga ada **audio MP3** (192 atau 128 kbps; dikonversi di HP dengan FFmpeg, jadi prosesnya lebih lama dan kualitas sedikit di bawah M4A asli). Hasil: `Music/YTPlayer` (audio) dan `Movies/YTPlayer` (video). Ada notifikasi progres dengan tombol *Batal*.
- **Resolusi & kecepatan (v1.3)** – tombol *Resolusi* (Otomatis, 144p sampai 1080p atau lebih bila tersedia; video dan audio terpisah digabung otomatis) dan *Kecepatan* (0,25x sampai 3x), bisa diganti saat video sedang diputar.
- **Fitur ala YouTube (v1.3)** – favorit (chip *Favorit*), ulangi video, bagikan tautan, video lain dari channel yang sama, hapus riwayat. Semua keterangan (waktu unggah, durasi, jumlah tonton) berbahasa Indonesia.
- **Unduh (v1.4)** – pilih format dulu (**MP3**, **M4A**, **MP4**), lalu kualitasnya: MP3 64–320 kbps, M4A sesuai bitrate yang tersedia, MP4 per resolusi.
- **Segarkan halaman (v1.4)** – otomatis saat aplikasi dibuka dan saat dibuka lagi setelah lebih dari semenit; manual lewat tombol *Segarkan* atau usap dua jari ke bawah (TalkBack) saat daftar sudah di paling atas.
- Android 7.0 (API 24) sampai Android 16 (API 36).


## Satu APK untuk 32-bit dan 64-bit
Sejak v4.25 proyek ini digabung: **satu APK** untuk HP 32-bit (armeabi-v7a) dan 64-bit (arm64-v8a); Android memilih pustaka yang cocok. Mesin konversi MP3 (FFmpeg) membawa pustaka kedua ABI. Hasil build: `YTPlayer.apk`. Nama aplikasi **YT music player** (tanpa keterangan bit), nama paket tetap `id.ytplayer`.

## Yang baru di v4.77

- **Perbaikan Ulangi satu lagu di Music Player saat Mesin audio Novan aktif.** Lagu yang habis memang terputar lagi tetapi tanpa suara sampai Maju 10 detik ditekan. Sekarang, setiap lagu mengulang sendiri dan mesin audio aktif, pemutar langsung melompat ke awal lagu sehingga jalur audio disegarkan seperti saat Maju 10 detik. Bila setelah ini masih sunyi, kirim keterangan: laju dan format lagunya serta isi baris "Jalur lagu terakhir" di layar Mesin audio Novan.

## Yang baru di v4.76

Mesin audio Novan disamakan dengan mesin proyek EqualizerNovan (tahap 19). Semua hitungan tetap 64-bit di dalam aplikasi, jadi hasilnya bukan lewat efek bawaan Android.

- **Kompresor 3 pita** (batas 250 Hz dan 2,5 kHz, pembagi Linkwitz-Riley orde 4 yang jumlahnya rata): ambang, rasio, waktu serang, waktu lepas, dan penguat makeup, lutut lunak 6 dB.
- **Penguat suara pelan** 0 sampai 100 persen: kompresor yang sama dengan ambang, rasio, dan makeup (sampai 4,5 dB) naik bertahap.
- **Kejernihan vokal** (bell lebar sekitar 2,6 kHz, sampai +4,5 dB) dan **Bass cerdas** (rak bawah sampai +4,5 dB, potongan sekitar 245 Hz sampai -2,2 dB). Keduanya filter biquad 64-bit, bukan pendekatan per pita.
- **Headroom otomatis** (bawaan MATI, jadi volume sama seperti sebelumnya): bila dinyalakan, penguatan diturunkan sebesar puncak respons gabungan semua filter ditambah makeup kompresor supaya tidak pecah, dihitung dari respons sebenarnya. Saat nyala, memilih mode suara tidak menurunkan preamp lagi; saat mati, preamp mode turun separuh puncak seperti dulu.
- **Limiter bisa diatur**: batas (-30 sampai 0 dB; bawaan -0,5 dB, dulu -0,3 dB) dan waktu lepas. **Penguat akhir** -12 sampai +12 dB sebelum limiter.
- **Langkah pita halus 0,5 dB** dan **Kelola kurva**: simpan, pilih, dan hapus mode kustom (terpisah untuk 10 dan 32 pita), salin dan tempel kurva (format EQN1 yang sama dengan Equalizer Novan, jadi kurva bisa dipindah di antara dua aplikasi), datarkan kurva.
- Semua pengaturan baru ikut tersimpan per perangkat (speaker, kabel, Bluetooth, USB) dan ikut *Atur ulang semua*. Penggeser memakai langkah bulat atau daftar nilai tetap agar nyaman dengan TalkBack.

## Yang baru di v4.75

- **Mesin audio Novan lebih mudah dipakai.** Penggeser equalizer diberi nomor: Pita 1, Pita 2, dan seterusnya, lengkap dengan frekuensi dan desibelnya. Keterangan di layar dipersingkat, termasuk deskripsi mode.
- **Mode suara bertambah** dari 12 jadi 17: Hip hop, Elektronik, Dangdut, Metal, dan Film (ditambah di akhir daftar, jadi mode tersimpan tidak bergeser).

## Yang baru di v4.74

- **Tombol Kembali aman untuk Android 12 ke bawah.** Pendaftaran tombol Kembali gaya Android 13 dipindah ke kelas terpisah (BackApi33) yang hanya dimuat di Android 13 ke atas. Android 7 sampai 12 memakai onBackPressed() biasa dengan perilaku yang sama (kembali ke Beranda dulu, baru keluar). Nomor versi 4.73 ke 4.74 (versionCode 99 ke 100).

## Yang baru di v4.73

- **Tombol Kembali seperti YouTube asli.** Dari Subscription, Shorts, kategori lain, layar Anda, atau hasil pencarian, Kembali satu kali sekarang menuju Beranda aplikasi, bukan keluar. Baru dari Beranda, Kembali keluar dari aplikasi. Di Android 13 ke atas (target 36) metode lama onBackPressed tidak dipanggil lagi, jadi tombol Kembali kini didaftarkan lewat OnBackInvokedCallback yang hanya aktif saat bukan di Beranda. Nomor versi 4.72 ke 4.73 (versionCode 98 ke 99).

## Yang baru di v4.72

- **Memilih video yang sedang diputar tidak mengulang dari awal.** Dari beranda atau hasil pencarian, bila video yang dipilih sama dengan yang sedang diputar (sedang jalan atau dijeda), aplikasi hanya membuka halaman pemutaran dan posisi, keadaan putar atau jeda tetap. Bila videonya sudah selesai, berhenti total, atau mode audio saja diubah lewat pilihan lama-tekan, pemutaran tetap dimulai seperti biasa. Nomor versi 4.71 ke 4.72 (versionCode 97 ke 98).

## Yang baru di v4.71

- **Tambah akun tanpa mengeluarkan akun utama.** Sebelumnya layar masuk membuka alamat keluar-Google dengan cookie akun yang lama masih di WebView, sehingga sesi akun utama ikut berakhir di server Google. Sekarang cookie WebView dikosongkan lebih dulu (salinan akun tersimpan tidak disentuh), baru halaman masuk dibuka, jadi tiap akun punya sesi sendiri dan bisa dipilih bergantian lewat daftar akun, seperti di YouTube asli. Akun yang namanya belum terbaca diberi nomor ("Akun 2").
- **Tes gambar saat Tambah akun.** Mengosongkan semua cookie WebView membuat perangkat tampak baru bagi Google sehingga muncul tes "pilih semua gambar dengan mobil", yang tidak mungkin dilalui pengguna tunanetra. Sekarang hanya cookie sesi akun yang dibuang; cookie penanda perangkat dan persetujuan (NID, SOCS, dan sejenisnya) dipertahankan. Bila sesi lama masih tersisa, semua cookie dibuang sebagai cadangan. Tes tetap bisa muncul bila Google menilai jaringan atau akun mencurigakan; layar masuk kini mengingatkan adanya tombol verifikasi audio.
- Durasi video dari umpan Subscription dan layar channel tetap dilengkapi dari halaman channel (v4.70). Nomor versi 4.70 ke 4.71 (versionCode 96 ke 97).

## Yang baru di v4.70

- **Durasi video di Subscription.** Kartu video dari umpan Subscription tadinya tanpa lencana durasi (RSS YouTube tidak memuat durasi) dan TalkBack membacakan "Durasi 0 detik". Sekarang durasi dilengkapi di latar belakang dari halaman channel untuk video teratas, lencana muncul di pojok kanan bawah gambar, dan durasi yang belum diketahui tidak lagi dibacakan.
- **Tombol "Tambah akun YouTube"** langsung di Pengaturan (satu ketukan membuka layar masuk untuk akun lain, akun yang sekarang tersimpan). Pindah dan keluar akun tetap lewat tombol Akun. Nomor versi 4.69 ke 4.70 (versionCode 95 ke 96).

## Yang baru di v4.69

- **Beberapa akun YouTube (tahap 1).** Tombol Akun (tab Anda) dan Pengaturan > Akun YouTube kini membuka daftar akun: pilih akun untuk pindah ("Pindah ke akun ..."), **Tambah akun** (layar masuk untuk akun lain tanpa mengeluarkan yang sekarang), dan **Keluar dari akun ini** (hanya akun yang sedang dipakai; bila ada akun lain, akun itu yang dipakai berikutnya). Tiap akun menyimpan cookie (terenkripsi), nama, foto, daftar langganan, dan penanda titik biru sendiri. Akun yang sama yang ditambah dua kali digabung otomatis begitu namanya terbaca. Nomor versi 4.68 ke 4.69 (versionCode 94 ke 95).

## Yang baru di v4.68

- **Shorts acak dan tanpa akhir.** Setiap dimuat, aplikasi memilih topik acak (lucu, bola, musik, masak, religi, dan lain-lain), mengacak urutannya, dan melewati video yang sudah pernah ditonton (400 terakhir diingat). Saat tinggal 3 video lagi, topik acak berikutnya dimuat sendiri, jadi tidak pernah habis.
- **Usap ke bawah di Shorts pertama** memuat Shorts baru (seperti YouTube asli), bukan lagi hanya pesan "Ini Shorts pertama". Nomor versi 4.67 ke 4.68 (versionCode 93 ke 94).

## Yang baru di v4.67

- **Shorts: tombol navigasi HP bisa ditekan lagi.** Di v4.64 bilah status dan navigasi disembunyikan, sehingga tombol Kembali sulit ditekan. Sekarang keduanya tampil tetap, dan video memenuhi area di antaranya seperti YouTube asli (latar buram untuk video lebar tetap ada). Nomor versi 4.66 ke 4.67 (versionCode 92 ke 93).

## Yang baru di v4.66

- **Login akun disalin persis dari YMusic.** Hasil membaca kode YMusic: alamat masuknya lewat halaman keluar Google lalu YouTube HP (bukan ServiceLogin), dan layar masuknya memakai identitas peramban bawaan WebView tanpa diubah (identitas desktop hanya dipakai YMusic untuk pemeriksaan, bukan untuk layar masuk). Semua tambahan dari v4.62 sampai v4.65 dibuang (alamat ServiceLogin, pembersihan cookie, penyamaran Chrome, pustaka androidx.webkit). Cookie disimpan ke disk setiap halaman selesai dimuat, seperti YMusic. Nomor versi 4.65 ke 4.66 (versionCode 91 ke 92).

## Yang baru di v4.65

- **Login akun dibuat lebih mirip peramban asli.** Layar masuk kini tampil sebagai Chrome HP biasa (tanda WebView dibuang dari identitasnya) dan tidak mengirim nama aplikasi ke Google. Ini untuk mengatasi pesan "Browser atau aplikasi ini mungkin tidak aman". Menambah pustaka androidx.webkit 1.12.1. Nomor versi 4.64 ke 4.65 (versionCode 90 ke 91).

## Yang baru di v4.64

- **Shorts benar-benar layar penuh.** Bilah status dan navigasi disembunyikan (muncul sebentar bila diusap dari tepi layar). Video vertikal memenuhi seluruh layar. Video lebar tetap utuh di tengah, dengan latar buram dari warna videonya sendiri (seperti YouTube), bukan hitam polos.
- **Usap ke bawah kembali ke Shorts sebelumnya.** Usap kini dihitung dari jarak saja (tanpa syarat kecepatan), jadi lebih mudah terbaca. Di Shorts pertama, ada ucapan "Ini Shorts pertama". Nomor versi 4.63 ke 4.64 (versionCode 89 ke 90).

## Yang baru di v4.63

- **Pesan "Belum masuk akun YouTube" tidak lagi dobel** di tab Subscription. Hanya tersisa satu, di atas tombol *Masuk akun YouTube*. Nomor versi 4.62 ke 4.63 (versionCode 88 ke 89).

## Yang baru di v4.62

- **Perbaikan login akun YouTube.** Layar masuk tidak lagi memakai identitas peramban desktop buatan, yang membuat Google menolak dengan pesan "Browser atau aplikasi ini mungkin tidak aman". Kini memakai identitas bawaan WebView dan alur masuk YouTube Music (ltmpl=music), seperti aplikasi musik pihak ketiga. Sesi lama dibersihkan sebelum masuk, dan sesi terdeteksi juga dari youtube.com maupun music.youtube.com. Nomor versi 4.61 ke 4.62 (versionCode 87 ke 88).

## Yang baru di v4.61

- **Shorts layar penuh ala YouTube.** Tab bawah *Shorts* kini membuka layar Shorts: video vertikal layar penuh, usap ke atas untuk video berikutnya dan ke bawah untuk sebelumnya, ketuk untuk jeda atau putar, video berulang, dan bilah kemajuan tipis di dasar. Di layar ada nama pengunggah dengan tombol *Subscribe*, judul, titik tiga (putar audio saja, favorit, bagikan, unduh), serta tombol *Suka* (menambah ke video yang disukai), *Unduh*, dan *Bagikan*. Sumber: pencarian Shorts (video sampai 3 menit). Untuk TalkBack: satu elemen fokus dengan Tindakan *Video berikutnya*, *Video sebelumnya*, dan *Putar audio saja* (juga lewat gerakan gulir TalkBack).
- **Tombol + dihapus** dari tab bawah. Menyalin tautan dari aplikasi lain lalu membuka aplikasi ini tetap otomatis membuka pilihan unduh. Nomor versi 4.60 ke 4.61 (versionCode 86 ke 87).

## Yang baru di v4.60

- **Layar channel dilengkapi.** Kartu video kini menampilkan lencana durasi dan keterangan seperti *Streaming 1 hari yang lalu* (diambil dari beranda, tab Video, dan tab Live channel setelah daftar RSS tampil; bila gagal, daftar RSS tetap seperti sebelumnya). Shorts diberi lencana *SHORTS*, dan tab Postingan di halaman channel dirapikan (isi, tanggal, garis pemisah, dibacakan satu per satu). Nomor versi 4.59 ke 4.60 (versionCode 85 ke 86).

## Yang baru di v4.59

- **Layar channel ala YouTube (Subscription).** Setelah memilih channel di tab Subscription, layar kini punya bilah atas (kembali, nama channel, cari), baris foto channel yang di-subscribe (channel terpilih berlingkar, ketuk foto lain untuk berpindah, *Semua* membuka daftar lengkap), tombol *Kunjungi channel*, dan daftar video berupa kartu besar dengan foto channel, judul, keterangan, dan titik tiga (putar audio saja, putar dengan video, favorit, bagikan, unduh). Tombol subscribe dipindah ke halaman channel.
- **Halaman channel (Kunjungi channel).** Layar baru: banner, foto, nama, @handle, jumlah subscriber dan video, deskripsi ringkas (ketuk untuk selengkapnya), tombol *Subscribe* / *Disubscribe*, tab (Beranda, Video, Shorts, Live, Postingan, dan lainnya sesuai channel), bagian-bagian seperti *Live streaming sebelumnya*, dan tombol *Muat lagi*. Data dari youtubei; bila gagal, ditampilkan video terbaru (RSS). Nomor versi 4.58 ke 4.59 (versionCode 84 ke 85).

## Yang baru di v4.58

- **Tampilan lebih mirip YouTube asli.** Tab bawah kini punya ikon dan lima item: *Beranda*, *Shorts*, tombol *+* (tempel tautan YouTube, TikTok, atau Facebook untuk diputar atau diunduh), *Subscription*, dan *Anda*. Warna, huruf, dan sudut tombol disesuaikan dengan YouTube (tema terang dan gelap), bilah atas dan kotak cari memakai ikon, serta kartu video memakai judul dan keterangan seperti YouTube.
- **Halaman pemutaran.** Tombol fitur kini tiga sejajar per baris, dan tombol Subscribe / Berhenti subscribe ada di kanan judul video.
- **Layar Anda menggantikan dialog.** Berisi tombol *Akun* (masuk, keluar, menu aplikasi), ikon notifikasi, cari, dan pengaturan; foto, nama, dan handle akun; tombol *Lihat channel* dan *Dapatkan Premium* (dibuka di peramban); *Histori* (kartu gulir ke samping, titik tiga untuk putar, putar audio saja, atau hapus); dan *Koleksi* (Video yang disukai = favorit, Unduhan, Channel yang di-subscribe). Tombol Kembali dari layar Anda menuju Beranda. Semua elemen berlabel dan punya aksi TalkBack seperti kartu video di Beranda. Nomor versi 4.57 ke 4.58 (versionCode 83 ke 84).

## Yang baru di v4.53

- **Tab Subscription saat belum masuk akun.** Muncul pemberitahuan "Belum masuk akun YouTube" (juga dibacakan lewat keterangan status) dan tombol *Masuk akun YouTube*. Setelah berhasil masuk dan kembali ke beranda, umpan Subscription dimuat otomatis. Nomor versi 4.52 ke 4.53 (versionCode tetap 79).

## Yang baru di v4.52

- **Subscribe dan berhenti subscribe di mana pun (tahap 6).** Tombol subscribe di pemutar selalu tampil untuk channel YouTube: *Subscribe: nama* bila belum, *Berhenti subscribe: nama* bila sudah (berhenti subscribe minta konfirmasi). Tombol yang sama ada di halaman channel, dan daftar channel punya Berhenti subscribe.
- **Halaman channel.** Tombol *Buka channel* di pemutar, ketuk channel di baris channel, atau di daftar channel membuka halaman channel: tombol subscribe, video terbaru channel (RSS, sampai 15), dan *Cari semua video channel ini*.
- **Tab Subscription seperti YouTube asli.** Di atas daftar ada baris channel (foto bulat dan nama) dengan tombol *Semua*. Filter *Tanggal unggah* berlaku di umpan (diterapkan tanpa mengunduh ulang selama 5 menit). Nomor versi 4.51 ke 4.52 (versionCode tetap 79).

## Yang baru di v4.51

- **Tampilan seperti YouTube asli (tahap 5).** Tab bawah *Beranda*, *Subscription*, *Anda*. *Subscription* menampilkan video terbaru dari channel yang di-subscribe (RSS tiap channel, sampai 60 channel, maksimal 5 video terbaru per channel, Shorts dilewati, lencana durasi tidak ada karena RSS tidak memuatnya) dan tombol *Lihat daftar channel yang di-subscribe*. *Anda* berisi akun YouTube (masuk atau keluar), riwayat, favorit, unduhan, daftar channel, dan pengaturan. Di pemutar, tombol *Subscribe: nama channel* hanya muncul bila channel belum di-subscribe. Nomor versi 4.50 ke 4.51 (versionCode tetap 79).

## Yang baru di v4.50

- **Daftar channel yang di-subscribe (tahap 4).** Laci menu punya item baru *Langganan*: daftar channel akun yang sedang masuk (sampai 10 halaman), tombol *Segarkan daftar*, dan ketuk channel untuk *Lihat video channel* atau *Berhenti subscribe*. ID channel yang di-subscribe disimpan di HP sehingga tombol subscribe di pemutar kini berlabel "Sudah subscribe: ..." untuk channel yang sudah diketahui. Nomor versi 4.49 ke 4.50 (versionCode 78 ke 79).

## Yang baru di v4.49

- **Subscribe dan berhenti subscribe (tahap 3).** Di layar pemutar ada tombol baru di bawah "Video lain dari ..." berisi pilihan *Subscribe* dan *Berhenti subscribe* untuk channel video yang sedang diputar (ID channel diambil dari tautan channel NewPipe). Bila belum masuk, ditawari masuk dulu. Hasilnya diumumkan lewat keterangan status. Nomor versi 4.48 ke 4.49 (versionCode 77 ke 78).

## Yang baru di v4.48

- **Login akun YouTube (tahap 1 dan 2).** Pengaturan punya tombol *Akun YouTube*: belum masuk membuka layar masuk (WebView ke akun Google, layar menutup sendiri begitu sesi terdeteksi); sudah masuk menampilkan *Periksa status akun* dan *Keluar*. Cookie sesi disimpan terenkripsi (AES-GCM, kunci Android Keystore) dan tidak masuk log atau laporan galat. Panggilan akun (`YtApi`) memakai header Cookie dan `Authorization: SAPISIDHASH`, terpisah dari NewPipe sehingga pemutaran dan unduhan tidak terpengaruh. Subscribe dan daftar channel menyusul di tahap berikutnya. Nomor versi 4.47 ke 4.48 (versionCode 76 ke 77).

## Yang baru di v4.47

- **Bagian atas beranda diringkas** (YT Player dan YouTube Music) supaya lebih banyak video terlihat. Judul, Menu, dan Segarkan satu baris; kolom cari, Suara, dan Cari satu baris; Kategori dan Tanggal unggah berdampingan; tombol dan tulisan dikecilkan; keterangan status dua baris. Jarak antarkartu video juga dirapatkan. Semua tombol tetap berlabel dan berukuran sentuh minimal 48 dp. Nomor versi 4.46 ke 4.47 (versionCode tetap 76).

## Yang baru di v4.46

- **Judul video berbahasa Indonesia.** Permintaan ke YouTube kini memakai bahasa `id` (sebelumnya `id-ID`, yang bisa tidak dikenali sehingga judul video channel Indonesia muncul terjemahan Inggris). Ditambah header Accept-Language dan cookie PREF `hl=id`. Berlaku untuk hasil pencarian, beranda, video terkait, dan halaman tonton. Nomor versi 4.45 ke 4.46 (versionCode tetap 76).

## Yang baru di v4.45

- **APK lebih kecil, tanpa mengubah kode.** Pustaka native 32-bit dan 64-bit (`libytmp3.so`) kini dikompres di dalam APK (`useLegacyPackaging = true`), dan terjemahan bahasa lain bawaan pustaka dibuang (hanya Inggris dan Indonesia). R8/minify sengaja tidak dipakai agar fitur tidak rusak. Tetap satu APK untuk 32-bit dan 64-bit. Nomor versi 4.44 ke 4.45 (versionCode 75 ke 76).

## Yang baru di v4.44

- Membangun di HP: clang Termux dijalankan dengan `-no-canonical-prefixes` agar proses `-cc1` yang dipanggil clang sendiri lewat hook TerminalNovan memakai jalur clang yang benar, bukan linker (galat `expected absolute path: "-cc1"`).
- Folder kerja `native/build-native.sh` kini `~/.cache/ytp-native` (di luar proyek), jadi sumber FFmpeg dan hasil kompilasi dipakai ulang di versi berikutnya. Bila hasilnya aneh setelah mengubah skrip, hapus folder itu. Nomor versi 4.43 ke 4.44 (versionCode 74 ke 75).

## Yang baru di v4.43

- Perbaikan `native/build-native.sh`: pengujian kompiler NDK tidak lagi menghentikan skrip bila kompiler NDK gagal dijalankan, sehingga beralih ke clang Termux seperti dimaksud di v4.42. Nomor versi 4.42 ke 4.43 (versionCode 73 ke 74).

## Yang baru di v4.42

- **Membangun di Termux/TerminalNovan di HP.** `native/build-native.sh` sekarang menguji kompiler NDK dengan mengompilasi berkas kecil. Bila biner kompiler NDK tidak bisa dijalankan (misal NDK di HP bertipe non-PIE statis, galat `unexpected e_type: 2`), skrip otomatis memakai clang, lld, dan llvm-ar milik Termux dengan header dan pustaka dari sysroot NDK. Di GitHub Actions dan PC tidak ada perubahan. Di HP perlu `pkg install llvm`.
- Nomor versi 4.41 ke 4.42 (versionCode 72 ke 73).

## Yang baru di v4.41

- **Equalizer bawaan HP (efek Android) dihapus.** Equalizer, bass boost, virtualizer, dan penguat volume bawaan Android tidak ada lagi di Music Player maupun pemutar video. Semua efek suara sekarang hanya lewat **Mesin audio Novan** (pemrosesan 64-bit sendiri di dalam aplikasi). Tombol *Equalizer dan mesin audio* di halaman pemutaran langsung membuka Mesin audio Novan. Fitur *Volume stabil* di pemutar video tetap ada.
- **Equalizer parametrik dihapus** dari Mesin audio Novan (termasuk impor/ekspor AutoEq). Equalizer yang tersedia: grafis 10 atau 32 pita.
- **Hi-Res, laju sampel keluaran, dan bit-perfect mengikuti mesin audio Novan.** Mesin audio mati berarti ketiganya mati (suara 16-bit pada laju berkas, tanpa bit-perfect); mesin menyala berarti ketiganya mengikuti pengaturannya masing-masing. Berlaku mulai lagu berikutnya.
- Nomor versi 4.40 ke 4.41 (versionCode 71 ke 72).

## Yang baru di v4.39

- **Mesin audio Novan sekarang juga ada di YT Player dan YouTube Music.** Pemutar video/lagu online kini memakai pemrosesan suara 64-bit yang sama dengan Music Player (equalizer grafis 10/32 pita, equalizer parametrik, bass, treble, lebar stereo, reverb, limiter, keluaran Hi-Res, laju keluaran, bit-perfect, dan pengaturan suara per perangkat), terpisah dari efek bawaan Android.
- **Satu pengaturan** untuk YT Player dan YouTube Music: Menu > Pengaturan, tombol *Mesin audio Novan*. Pengaturannya satu dan sama untuk YT Player, YouTube Music, dan Music Player; layar Mesin audio Novan di Music Player membuka pengaturan yang sama.
- Halaman Pengaturan YT Player dan YouTube Music diberi judul yang jelas bahwa isinya berlaku untuk keduanya. Tombol equalizer lama diganti namanya menjadi *Equalizer bawaan Android* agar tidak tertukar dengan Mesin audio Novan.
- Mesin audio ikut aktif saat video diputar dengan kecepatan 0,25x sampai 3x. ReplayGain tetap khusus Music Player (tidak berlaku untuk video).
- Nomor versi 4.38 ke 4.39 (versionCode 69 ke 70).

## Yang baru di v4.38

- Pengaturan suara per perangkat (lihat di bawah, dibuat bersama v4.37).

## Yang baru di v4.37

- **Pengaturan suara per perangkat** (Mesin audio Novan > *Atur suara per perangkat*): speaker HP, headphone kabel, Bluetooth, dan USB masing-masing mengingat pengaturan suaranya sendiri (equalizer, bass, treble, reverb, preamp, dan lainnya) dan berganti otomatis saat perangkat keluaran berganti. Pengaturan Hi-Res dan laju keluaran tetap satu untuk semua.
- **Nada (pitch)** terpisah dari kecepatan: Menu > *Nada (pitch)*, -6 sampai +6 setengah nada. Tempo bisa diubah tanpa mengubah nada dan sebaliknya; nilainya diingat setelah aplikasi ditutup.
- Belum ada: profil headphone AutoEq, format DSD/APE/WV/WMA, DVC.

## Yang baru di v4.36

Tahap 3 mesin audio ala Poweramp: **equalizer parametrik** (Pengaturan Music Player > Mesin audio Novan > Equalizer parametrik).

- Sampai 16 pita bebas. Tiap pita: jenis filter (puncak, rak bawah, rak atas, lolos bawah, lolos atas, penolak/notch), frekuensi 20 Hz sampai 20 kHz, penguatan -20 sampai +20 dB (langkah 0,5 dB), dan lebar Q 0,1 sampai 10. Setiap pita bisa dimatikan sendiri-sendiri.
- Grafik respons gabungan semua pita, dan tombol **Preamp otomatis** yang menurunkan preamp sebesar puncak kurva supaya suara tidak pecah.
- Bila menyala, equalizer parametrik menggantikan equalizer grafis 10/32 pita (memilih Mode suara mematikannya kembali). Hitungan tetap 64-bit di mesin Novan; layar dan penggeser ramah TalkBack.
- Belum ada: database AutoEq di dalam aplikasi (pilih model headphone), format DSD/APE/WV, tempo tanpa mengubah nada, DVC.

## Yang baru di v4.35

Tahap 2 mesin audio ala Poweramp (Pengaturan Music Player):

- **ReplayGain** (Mati / Per lagu / Per album): membaca tag ReplayGain dari MP3 (ID3 TXXX), FLAC/OGG/Opus (komentar Vorbis, termasuk R128 untuk Opus), dan M4A. Penguatan dihitung 64-bit di mesin Novan, berlaku juga saat equalizer mati. Ada tambahan penguatan untuk lagu bertag dan untuk lagu tanpa tag (-12 sampai +12 dB). Penguat di atas 0 dB dijaga limiter (bila limiter dimatikan di layar Mesin audio Novan, suara bisa pecah).
- **Fokus audio dan ducking** diurus sendiri, bukan lagi oleh ExoPlayer: pilihan saat notifikasi/pembaca layar/navigasi berbunyi (kecilkan volume, jeda lalu lanjut, abaikan), **persentase volume saat dikecilkan** (0 sampai 100, bawaan 20), pilihan saat panggilan atau alarm (jeda lalu lanjut otomatis, jeda tanpa lanjut, abaikan), dan pilihan saat aplikasi lain mengambil alih pemutaran. Sakelar Fokus audio tetap bawaan mati.
- **Simpan posisi per lagu** (bawaan mati): mengingat detik terakhir lagu panjang, dengan pilihan durasi minimum (semua lagu, 5, 10, 20, 30, 60 menit). Lagu dilanjutkan dari posisi terakhir saat dipilih lagi; posisi dihapus bila lagu sudah selesai atau tinggal kurang dari 8 detik.
- Belum ada (tahap berikutnya): equalizer parametrik, database AutoEq, format DSD/APE/WV, tempo tanpa mengubah nada, DVC.

## Yang baru di v4.34

- Keluaran Hi-Res: pilihan **laju sampel keluaran** (Otomatis, ikuti berkas, 48, 96, 192, 384 kHz). Mesin Novan menaikkan laju sendiri dengan resampler 64-bit (polifase, filter sinc Kaiser 96 titik), sehingga pengubah laju bawaan Android tidak perlu bekerja. Otomatis memilih laju mixer perangkat, atau 96/192 kHz bila DAC USB menerimanya langsung. Laju tidak pernah diturunkan.
- Mode **bit-perfect** (Android 14 ke atas, perangkat keluaran yang mendukung, umumnya DAC USB): mixer Android dikunci ke format perangkat sehingga suara dikirim tanpa resampling dan tanpa pengaturan volume sistem. Ada konfirmasi sebelum diaktifkan.
- Bila perangkat menolak laju atau mode pilihan, pemutar otomatis kembali ke laju berkas lagu dan melanjutkan.
- Layar mesin audio menampilkan kemampuan perangkat keluaran dan jalur lagu terakhir.

## Yang baru di v4.33

- Music Player: tekan lama judul lagu, pilih **Hapus lagu dari penyimpanan**. Muncul konfirmasi, lalu berkas lagu benar-benar dihapus dari penyimpanan internal (Android 11 ke atas memunculkan kotak izin sistem). Lagu juga otomatis keluar dari antrean, favorit, dan daftar putar.

## Yang baru di v4.32

- Jalur cadangan dihapus: tidak ada lagi pematian Hi-Res otomatis, pesan "Gagal memutar lagu", maupun lompat otomatis saat lagu gagal diputar.

## Yang baru di v4.31

- Perbaikan Music Player tidak mau memutar lagu: jalur audio Novan (keluaran float Hi-Res) dipasang setelah pengatur kecepatan/lewati-hening bawaan, dan ada pengubah ke 16-bit di awal rantai untuk masukan 24/32-bit atau float.

## Yang baru di v4.29

- Mesin audio Novan: "Mode suara" siap pakai (Bass kuat, Vokal jernih, Pop, Rock, Jazz, Klasik, Dance, Akustik, Podcast, Volume pelan) dan "Mode ruang" untuk reverb (Kamar kecil, Ruang tamu, Studio, Aula konser, Katedral).

## Yang baru di v4.28

- Reverb di Mesin audio Novan: jumlah, ukuran ruang, dan peredam nada tinggi (dihitung 64-bit, mengikuti laju sampel).
- Keluaran Hi-Res: suara dikirim sebagai float 32-bit tanpa dither (bisa dimatikan di layar Mesin audio Novan; berlaku mulai lagu berikutnya).

## Yang baru di v4.27

Mesin audio sendiri ala Poweramp, tahap 1 (Menu Music Player > Mesin audio Novan):

- **Prosesor audio 64-bit sendiri** di jalur ExoPlayer (di luar efek bawaan Android; efek lama tetap ada dan terpisah). Hitungan memakai Double; masukan 16/24/32-bit atau float, keluaran 16-bit dengan dither. Juga berlaku pada pemain crossfade.
- **Equalizer grafis 10 atau 32 pita** (+-12 dB, langkah 1 dB), preamp, bass, treble, lebar stereo, campur ke mono, keseimbangan kiri-kanan, dan limiter.
- Bawaan mati. Tahap berikutnya: equalizer parametrik + AutoEq, keluaran Hi-Res, ReplayGain, pengatur ducking, simpan posisi per trek.

## Yang baru di v4.26

Tahap 1 penyempurnaan Music Player (Pengaturan Music Player > Pemutaran):

- **Putar otomatis saat headset tersambung** (bawaan mati): lagu terakhir diputar otomatis saat kabel headset/USB dicolokkan atau perangkat Bluetooth (A2DP, BLE, alat bantu dengar) tersambung. Perangkat yang sudah tersambung saat pemutar dimulai tidak memicu apa-apa. Bila sakelar ini aktif dan antrean ada, layanan tidak ditutup saat aplikasi digeser dari daftar aplikasi terbaru, supaya sambungan baru tetap terdeteksi.
- **Lanjut folder otomatis** (bawaan mati): memutar dari dalam sebuah folder (lagu mana pun, atau tombol Putar folder) membuat antrean disambung dengan folder berikutnya menurut urutan nama, jadi pemutaran berlanjut ke folder selanjutnya setelah folder aktif selesai.

## Yang baru di v4.25

- **Proyek 32-bit dan 64-bit digabung** menjadi satu proyek dan satu APK (`YTPlayer.apk`); nama aplikasi tidak lagi memakai keterangan 32-bit/64-bit.
- **Unduh MP4 dari lagu YouTube Musik kini ada suaranya**: penggabung video+audio salah menganggap audio habis bila waktu sampel pertama negatif (umum pada lagu \"Topic\"). Kini diperbaiki; hasil gabungan dicek punya suara, dan bila senyap dicoba jalur audio cadangan.
- **Kualitas audio MP4 tetap terbaik** di YouTube (AAC stereo bitrate tertinggi), Facebook (AAC bitrate tertinggi, bukan Opus/E-AC-3) dan TikTok (suara asli berkas).
- Nomor versi 4.20 ke 4.25 (versionCode 51 ke 56).

## Yang baru di v4.20

- **Unduh Facebook diperkuat supaya benar-benar berhasil**:
  - Mengikuti pengalihan tautan (fb.watch, /share/v/, /share/r/) sampai ketemu nomor video, lalu mencoba halaman asli, halaman baku `/watch/?v=NOMOR`, dan halaman sematan (embed) Facebook.
  - Bila halaman memuat banyak video (daftar Reels, video terkait), hanya bagian di sekitar nomor video yang diminta yang dibaca, jadi tidak salah ambil video lain.
  - Membaca format **DASH** (video dan suara terpisah): kualitas 1080p dan lain-lain muncul di pilihan MP4. Video dan suaranya diunduh terpisah lalu digabung di HP tanpa mengubah kualitas. Untuk M4A dan MP3, hanya trek suaranya yang diunduh (lebih kecil dan cepat).
  - Cadangan WebView tersembunyi kini juga menangkap alamat berkas video yang diminta pemutar Facebook, bukan hanya membaca isi halaman.
  - Header peramban yang lebih lengkap (Sec-Fetch dan lainnya) agar Facebook tidak memberi halaman kosong.
  - Waktu mencoba dibatasi sekitar 80 detik; bila gagal, pesan galat tetap memuat rincian per cara.
- Nomor versi 4.19 ke 4.20 (versionCode 50 ke 51).

## Yang baru di v4.19

- **Unduh dari link Facebook**: bagikan atau salin tautan video Facebook (facebook.com/watch, /reel, /videos, /share, fb.watch, juga versi m. dan mbasic.), lalu pilih **MP4**, **M4A**, atau **MP3**, sama seperti YouTube dan TikTok. Tautan yang disalin otomatis terdeteksi saat aplikasi dibuka.
- Cara kerja: membaca halaman video Facebook dengan beberapa penyamaran peramban (desktop, perayap pratinjau tautan, seluler) dan alamat (www, m, mbasic); bila gagal, memakai WebView tersembunyi. Kualitas yang tersedia umumnya **HD** dan **standar**.
- **Hanya video publik.** Video privat, grup tertutup, atau yang meminta login tidak bisa diunduh. Facebook sering mengubah sistemnya, jadi cara ini bisa berhenti bekerja sewaktu-waktu; bila gagal, pesan galat menampilkan rincian per cara.
- Nomor versi 4.18 ke 4.19 (versionCode 49 ke 50).

## Yang baru di v4.18

- **Tombol "sebelumnya" kini bisa diatur batas waktunya**: pilihan 3, 5, 10, 15, 20, atau 30 detik, **bawaan 10 detik** (sebelumnya tetap 3 detik). Bila lagu sudah berjalan melewati batas itu, tombol mengulang dari awal; bila belum, pindah ke lagu/video sebelumnya.
- Satu pengaturan untuk **Music Player, YouTube Music, dan YT Player**. Atur di *Pengaturan > Batas waktu tombol sebelumnya* (Music Player) atau tombol *Tombol sebelumnya mengulang setelah* (Pengaturan YT Player). Sakelar *Tombol sebelumnya mengulang lagu* tetap berlaku di ketiganya; bila dimatikan, tombol selalu pindah ke item sebelumnya.
- **Tombol media "selanjutnya/sebelumnya" dari pembaca layar (Jieshuo), headset, dan Bluetooth kini berfungsi di YT Player dan YouTube Music**, sama seperti di Music Player.
- Nomor versi 4.17 ke 4.18 (versionCode 48 ke 49).

## Yang baru di v4.17

- **Video/lagu berikutnya dan sebelumnya kini mengikuti daftar yang sedang tampil** saat sebuah video dipilih: hasil pencarian, beranda, favorit, atau riwayat. Sebelumnya "berikutnya" selalu mengambil video terkait milik video yang sedang diputar, bukan urutan hasil pencarian.
- Berlaku di **YT Player** dan **YouTube Music**, pada tombol berikutnya di layar pemutar, notifikasi, layar kunci, tombol headset, dan putar otomatis.
- **Tombol \"sebelumnya\"** (notifikasi, layar kunci, headset) kembali ke item sebelumnya di daftar itu; bila sudah lewat 3 detik, mengulang dari awal. Di layar pemutar ada tombol baru **Video sebelumnya** (di mode YouTube Music: **Lagu sebelumnya**).
- Saat hasil pencarian dimuat lagi (gulir ke bawah), antrean ikut bertambah. Mendekati ujung antrean, halaman hasil berikutnya dimuat otomatis.
- Siaran langsung dilewati. Bila sebuah item gagal dimuat, item sesudahnya dicoba (sampai 5 kali). Info video berikutnya disiapkan lebih dulu supaya langsung bunyi.
- Bila video yang diputar tidak ada di daftar (mis. dibuka dari daftar \"video terkait\" atau dari tautan), atau daftar sudah habis, cara lama dipakai: video terkait pertama yang belum diputar.
- Nomor versi 4.16 ke 4.17 (versionCode 47 ke 48).

## Yang baru di v4.16

- **Tombol "berikutnya" di notifikasi sekarang bisa dipilih** (juga di layar kunci dan tombol headset). Sebelumnya pemutar hanya memuat satu video, jadi Android menganggap tidak ada item berikutnya dan tombolnya tidak bisa dipilih. Kini tombol itu memutar video terkait pertama yang belum diputar, sama seperti putar otomatis. Berlaku di **YT Player** dan **YouTube Music**.
- **Putar otomatis dan tombol "berikutnya" tidak lagi bolak-balik** ke video yang sudah diputar di sesi itu (daftar yang sama dipakai notifikasi, layar pemutar, dan putar otomatis).
- Bila info video sudah kedaluwarsa dari cache, daftar video terkait diambil ulang supaya tombol berikutnya tetap berfungsi.
- Di mode YouTube Music, tulisan di layar pemutar memakai istilah **lagu** (Lagu berikutnya, Lagu terkait, Putar otomatis lagu berikutnya).
- **Tombol "sebelumnya" di notifikasi** kini kembali ke video/lagu yang diputar sebelumnya (bila sudah lewat 3 detik atau belum ada video sebelumnya, mengulang dari awal).
- Bila semua video terkait sudah pernah diputar, tombol "berikutnya" (notifikasi dan layar pemutar) memulai daftar dari awal, tidak lagi diam saja.
- Unduhan: layanan kini berhenti dengan rapi saat batas waktu layanan sinkronisasi data Android 15+ habis, sehingga aplikasi tidak ditutup paksa.
- Perpindahan mode lewat menu navigasi (YT Player dan YouTube Music) kini langsung membuka halaman yang dipilih dengan sekali klik; centang menu tidak lagi memulihkan status lama.
- Nomor versi 4.15 ke 4.16 (versionCode 46 ke 47).

## Yang baru di v4.15

- **Unduhan MP3 kini VBR** (LAME, mode kualitas V0 sampai V9), bukan CBR lagi. Daftar pilihan tetap seperti sebelumnya (320 sampai 64 kbps), tetapi angkanya kini target rata-rata: 320 dan 256 = V0, 224 = V1, 192 = V2, 160 = V4, 128 = V5, 112 = V6, 96 = V7, 80 = V8, 64 = V9. Tampilan pilihan dan nama berkas tidak berubah ("MP3 N kbps"). Header Xing tetap ditulis supaya durasi dan lompat posisi akurat. Unduhan M4A/MP4 tidak berubah (AAC asli YouTube).
- Nomor versi 4.14 ke 4.15 (versionCode 45 ke 46).

## Yang baru di v4.14

- **YouTube Music** di laci menu (di bawah YT Player). Memakai layar pencarian yang sama, tetapi hasilnya hanya lagu dari katalog YouTube Music. Pilihan *Jenis hasil* bisa diganti antara **Lagu** (bawaan) dan **Video musik**. Kategori khusus musik: Populer Indonesia, Pop, Dangdut, Religi, Barat, K-pop, Kenangan. Riwayat, favorit, dan riwayat pencarian YouTube Music **terpisah** dari YT Player. Filter tanggal unggah tidak dipakai di mode ini.
- **Suara online memakai Opus (VBR)**, seperti YouTube asli. Di mode audio saja: Hemat = Opus bitrate terendah, Normal = Opus sedang (sampai 100 kbps), Terbaik = Opus bitrate tertinggi (sekitar 160 kbps). Bila sebuah video tidak punya Opus, dipakai M4A seperti sebelumnya. Video online sudah memakai Opus sejak sebelumnya. Unduhan M4A dan konversi MP3 (CBR) tidak berubah.
- Nomor versi 4.13 ke 4.14 (versionCode 44 ke 45).

## Yang baru di v4.13

- Tombol putar/jeda di notifikasi dan layar kunci kini **tetap muncul saat unduhan berjalan**. Penyebabnya, notifikasi unduhan memakai ID 1001 yang sama dengan notifikasi media Media3 sehingga saling menimpa. ID notifikasi unduhan diganti menjadi 1500.
- Equalizer: saat satu pita digeser, hanya pita itu yang diterapkan ke efek (tidak lagi semua pita setiap langkah).
- Nomor versi 4.12 ke 4.13 (versionCode 43 ke 44), sama untuk 32-bit dan 64-bit.

## Yang baru di v4.12

- Equalizer video kini **terpisah** dari equalizer Music Player: aktif/mati, preset, pita frekuensi, bass, dan virtualizer masing-masing punya pengaturan sendiri (kunci penyimpanan video berawalan `video_`). Pengaturan Music Player yang lama tidak berubah. Layar equalizernya tetap sama.
- Nomor versi 4.11 ke 4.12 (versionCode 42 ke 43), sama untuk 32-bit dan 64-bit.

## Yang baru di v4.11

- Pemutar video kini punya **equalizer, bass boost, dan virtualizer** (efek bawaan Android pada sesi audio ExoPlayer video). Dibuka lewat tombol *Equalizer, bass, dan virtualizer* di halaman putar video, atau lewat Pengaturan. Layar yang sama dengan equalizer Music Player (preset, pita frekuensi, bass, virtualizer, atur ulang) dan memakai pengaturan yang sama, tetapi efek dipasang terpisah di tiap pemutar. Berlaku juga di mode audio saja dan saat layar mati. Penguat volume tidak ada di sini karena pemutar video sudah punya "Volume stabil".
- Nomor versi 4.10 ke 4.11 (versionCode 41 ke 42), sama untuk 32-bit dan 64-bit.

## Yang baru di v4.10

- Nomor versi dinaikkan dari 4.5 ke 4.10 (versionCode 36 ke 41), sama untuk 32-bit dan 64-bit.
- Perbaikan galat `NoSuchMethodError URLEncoder.encode(String, Charset)`: pustaka desugaring diganti ke `desugar_jdk_libs_nio:2.1.5` di kedua versi (sebelumnya hanya 64-bit).

## Yang baru di v4.5

- Pustaka konversi MP3 dirampingkan: tidak lagi memakai FFmpeg-Kit penuh (sekitar 34 MB per ABI, 15–17 MB di APK), melainkan `libytmp3.so` buatan sendiri (sekitar 1–2 MB) yang hanya memuat dekoder AAC/Opus/Vorbis, pembuka M4A/MP4/WebM/Ogg, encoder LAME, dan penulis MP3. Sumber dan skrip build di folder `native/` (`bash native/build-native.sh arm64-v8a`, otomatis di CI dan Gradle; butuh Android NDK). Tetap satu jalur, tanpa cadangan. Channel lebih dari 2 diturunkan ke stereo oleh resampler.

## Yang baru di v4.4

- Unduhan MP3 kini hanya memakai satu jalur: FFmpeg (libmp3lame). Semua jalur cadangan dihapus (konversi MediaCodec + LAME, kode native LAME, pergantian ke aliran M4A, dan penyimpanan audio asli sebagai M4A). Bila konversi gagal setelah 3 percobaan, unduhan dinyatakan gagal dan tidak menyimpan berkas lain.

## Yang baru di v4.3

- Pilihan lompat mundur/maju (10, 20, 30 detik) kini hanya ada di Pengaturan; tidak lagi muncul di halaman putar video (tombol Mundur dan Maju tetap ada dan mengikuti pilihan itu).
- Di halaman putar, tombol Unduh dan Pewaktu tidur bertukar tempat.

## Yang baru di v4.2

- Unduhan MP3 kini mengambil audio Opus terbaik lebih dulu lalu mengonversinya ke MP3; bila gagal atau tidak ada Opus, otomatis jatuh ke M4A. Pilihan M4A tetap memakai audio M4A asli.
- Resolusi video bawaan ("Otomatis") 360p, dengan audio Opus terbaik. Resolusi lain tetap bisa dipilih manual.

## Yang baru di v4.1

- Resolusi video bawaan ("Otomatis") dibatasi sampai 480p agar gambar cukup jelas tanpa boros data; suara tetap memakai audio terbaik (Opus). Resolusi lebih tinggi tetap bisa dipilih manual.

## Yang baru di v4.0 (suara lebih jernih)

- Video online kini memakai audio terpisah terbaik (Opus, sekitar 160 kbps, seperti YouTube asli); bila tidak ada Opus dipakai M4A terbaik. Mode kualitas video "Otomatis" tidak lagi memakai aliran gabungan beraudio rendah (sekitar 96 kbps).
- Mode audio saja: bawaan tetap "Normal"; level "Terbaik" kini memakai Opus. Tombol kualitas audio hanya tampil saat mode audio saja aktif (di halaman putar dan di pengaturan).
- Pengaturan baru "Volume stabil" (bawaan mati): memperkuat dan membatasi suara agar lebih jelas dan seragam.
- Unduhan tidak berubah (tetap M4A/MP3/MP4).

## Yang baru di v3.9 (penguatan kode)
- Tombol mundur/maju di pemutar latar belakang memanggil fungsi pembaca lompatan secara eksplisit (menghindari kerancuan penamaan antara fungsi dan properti Java di Kotlin 2).
- Pemeriksaan statis ulang atas semua berkas Kotlin (kurung seimbang, tanda tangan fungsi yang berubah, nama ganda) dan semua rujukan sumber daya: tidak ditemukan masalah.

## Yang baru di v3.8 (pemeriksaan ulang)
- **Tombol kembali di Music Player:** bila laci menu terbuka, kembali menutup laci dulu (sebelumnya bisa lebih dulu naik satu folder).
- **Pindah tampilan tidak membuat tumpukan ganda:** membuka aplikasi dari ikon saat mode Music Player aktif memakai ulang halaman musik yang sudah ada.
- Nama lama "Musik Player Novan" di judul Music Player, kotak dialog, dan Mini Player diganti menjadi "Music Player" / "YT music player".
- Diperiksa: semua rujukan sumber daya (id, layout, xml, gaya, warna), semua kelas di manifest, dan kelengkapan berkas proyek musik (10 berkas Kotlin, 3 layout, pengaturan, larik pilihan, tema) tersalin lengkap.

## Yang baru di v3.7 (tahap 2)
- **Menu laci di pojok kiri atas** (tombol *Menu*) di halaman utama YT Player dan di Music Player. Isinya: **YT Player** (tercentang bawaan), **Music Player** (tidak tercentang), dan **Pengaturan**. Tombol kembali menutup laci lebih dulu.
- **Music Player:** proyek MusikPlayerNovan kini menjadi bagian aplikasi (paket `id.ytplayer.music`). Memilih *Music Player* di laci mengubah tampilan utama aplikasi menjadi pemutar musik (folder, daftar putar, mini player, equalizer, crossfade, dan seterusnya). Pilihan ini diingat: membuka aplikasi dari ikon langsung ke tampilan yang terakhir dipilih. Memilih *YT Player* mengembalikannya.
- Aplikasi juga muncul di daftar "Buka dengan" untuk berkas audio, dengan pilihan Music Player biasa dan Mini Player.
- **Pengaturan:** layar baru berisi kualitas audio pemutaran, lompat mundur, lompat maju, mode audio saja (YT Player), dan tombol **Pengaturan Music Player** untuk pengaturan bawaan proyek musik.
- Satu pemutar aktif: saat pindah tampilan, layanan pemutar tampilan yang ditinggalkan dihentikan.
- Dependensi baru: appcompat, material, preference, drawerlayout. Belum diuji di HP.

## Yang baru di v3.6 (tahap 1)
- **Nama aplikasi kini "YT music player"** (versi 64-bit dan 32-bit sama-sama memakai nama ini; keduanya tetap tidak bisa terpasang bersamaan karena nama paketnya sama).
- **Kualitas audio pemutaran:** tombol baru *Kualitas audio* di halaman putar dengan tiga pilihan: **Hemat** (bitrate audio terendah), **Normal** (bawaan; bitrate tertinggi yang tidak lebih dari 160 kbps, biasanya sekitar 128 kbps), dan **Terbaik** (bitrate tertinggi). Berlaku di mode audio saja; ganti saat memutar langsung memuat ulang di posisi yang sama.
- **Lompat mundur dan maju bisa dipilih 10, 20, atau 30 detik,** masing-masing sendiri (tombol *Lompat mundur* dan *Lompat maju*). Berlaku juga untuk tombol di notifikasi, layar kunci, dan headset.
- Mode audio saja tetap nonaktif sebagai bawaan.
- Tahap berikutnya: menu laci di pojok kiri atas (YT Player, Music Player, Pengaturan) dan memasukkan proyek MusikPlayerNovan sebagai tampilan Music Player.

## Yang baru di v3.5
- **Halaman gagal TikTok lebih rapi:** bila video tidak bisa diambil, tombol Unduh M4A / MP3 / MP4 (dan tombol putar di halaman YouTube) disembunyikan, karena memang tidak ada yang bisa diunduh. Yang tersisa hanya pesan galat, **Coba lagi**, dan **Tutup**. Tombol muncul lagi otomatis saat Coba lagi berhasil.
- **Sumber baru TikTok: halaman sematan (embed).** Setelah halaman video biasa gagal, aplikasi membaca https://www.tiktok.com/embed/v2/ID yang jarang diblokir, lalu mencari alamat video di dalamnya. Di putaran terakhir, WebView tersembunyi juga memuat halaman sematan ini (lebih ringan dari halaman biasa). Belum diuji di HP.
- **tikwm.com dicoba dengan beberapa cara:** GET di www.tikwm.com, lalu POST di www.tikwm.com, lalu POST di tikwm.com, supaya satu penolakan (mis. HTTP 403) tidak langsung mengakhiri sumber ini.
- Rincian galat kini juga menyebut "Halaman sematan TikTok" dan "WebView (sematan)".

## Yang baru di v3.4
- **WebView TikTok tidak lagi berhenti di halaman kerangka tanpa data video.** Halaman hanya diterima bila data video benar-benar ada. Kalau tidak, aplikasi menunggu pemutar halaman dan memakai alamat videonya (dari elemen pemutar, atau dari permintaan jaringan halaman, seperti pengunduh berbasis WebView). Video dibisukan dan dihentikan begitu alamatnya didapat.
- **Pesan galat WebView lebih rinci:** menyebut judul dan cuplikan teks halaman (mis. halaman verifikasi atau "video tidak tersedia"), dan berapa alamat video yang terpantau.

## Yang baru di v3.3
- **WebView TikTok tidak lagi tersangkut alihan "buka di aplikasi":** TikTok mengalihkan halaman ke alamat khusus aplikasi (snssdk1233://, tiktok://) yang tidak bisa dibuka WebView (galat ERR_UNKNOWN_URL_SCHEME, kode -10). Alihan non-web kini diblokir supaya WebView tetap di halaman video.
- **Pemeriksaan data halaman lebih tahan macet:** bila jawaban evaluasi JS tidak datang dalam 4 detik, pemeriksaan tetap lanjut. Pesan galat menyebut berapa kali evaluasi JS benar-benar menjawab.

## Yang baru di v3.2
- **WebView tersembunyi tidak lagi bergantung pada "halaman selesai dimuat":** data video diperiksa mulai 3 detik setelah dibuka dan terus sampai sekitar 35 detik. Bila gagal, pesan galat memuat progres muat, judul halaman, dan kode galat.
- **Pesan galat halaman TikTok lebih rinci:** menyebut bagian data yang hilang (isi halaman, kode status) supaya kelihatan apakah TikTok mengirim halaman verifikasi atau halaman tanpa data video.

## Yang baru di v3.1
- **Unduh TikTok punya cara ketiga: WebView tersembunyi.** Bila halaman TikTok dan layanan cadangan tikwm.com sama-sama gagal (mis. HTTP 403), aplikasi memuat halaman video di WebView yang tidak tampak (JavaScript dan cookie seperti peramban sungguhan), lalu membaca data video dari halaman itu. Dicoba di putaran pertama dan terakhir. Belum diuji di HP.
- **Pesan galat TikTok lebih jelas:** di akhir pesan ada rincian galat terakhir per sumber (Halaman TikTok, tikwm.com, WebView), jadi kelihatan siapa yang menolak dan dengan kode apa.
- Tombol di halaman TikTok kini bertuliskan "Unduh M4A (audio asli TikTok)" (sebelumnya salah menulis YouTube).

## Yang baru di v3.0 (belum diuji di HP)
- **Konverter MP3 utama diganti FFmpeg** (libmp3lame): alurnya tetap unduh M4A lalu otomatis dikonversi ke MP3, tanpa dekoder bawaan HP. Sejak v4.5 memakai build ramping sendiri (lihat v4.5).
- **Kategori diringkas:** di halaman utama semua kategori kini satu tombol "Kategori: …" yang membuka daftar pilihan (sebelumnya deretan tombol).
- **MP3 TikTok kini sama dengan YouTube:** ambil audio M4A dulu, lalu konversi ke MP3 sampai 3 percobaan (ke-2 dekoder perangkat lunak, ke-3 unduh ulang dengan data video baru); baru bila semua gagal disimpan sebagai M4A.
- Catatan lisensi: AAR itu dibangun dengan opsi `--enable-gpl` (GPL v3). Cocok untuk pemakaian pribadi; bila APK dibagikan ke orang lain, kode sumber aplikasi harus ikut tersedia.

## Yang baru di v2.9
- **Unduh playlist YouTube tidak gampang gagal:**
  - Daftar playlist diambil dengan coba ulang; bila halaman lanjutan gagal terus, video yang sudah terkumpul tetap diunduh (bukan gagal total).
  - Bila YouTube membatasi permintaan atau meminta verifikasi bot, semua permintaan menunggu masa tenang (15 → 30 → 60 → 120 detik) dan jeda antar video melebar otomatis, lalu menyempit lagi bila lancar.
  - Bila internet putus, unduhan menunggu sampai tersambung (maks. 10 menit per kejadian) dan lanjut dari byte terakhir, bukan dihitung gagal.
  - Video yang gagal diulang sampai 2 putaran lagi setelah yang lain selesai (kecuali yang memang tidak bisa: privat, dihapus, siaran langsung, ruang penuh).
  - Video yang sudah berhasil dicatat 6 jam: menjalankan playlist yang sama lagi hanya mengulang yang belum selesai (tidak ada berkas dobel).
  - CPU dijaga aktif selama seluruh playlist (layar mati pun lanjut).
- **M4A kini punya pengaman seperti MP3/MP4:** hingga 3 kali percobaan penuh dengan info video diambil ulang. Semua berkas (M4A, MP3 sumber, MP4) dicek isinya sebelum disimpan, jadi halaman galat tidak tersimpan sebagai audio/video.
- **Pengambilan info video dicoba sampai 4 kali** dengan jeda bertahap; sebelumnya satu kali gagal langsung dianggap video gagal.
- **Unduhan per potongan lebih tahan:** bila YouTube menolak header Range (HTTP 403), potongan diminta lewat parameter `range` di alamat sebelum tautan dianggap kedaluwarsa.
- Tautan `youtu.be/ID?list=...` kini juga menawarkan *Unduh seluruh playlist*.

### Alur kerja unduhan (YouTube dan TikTok)
1. **Tautan masuk** dari menu Bagikan, clipboard, atau tempel. `YtLink` mengenali video / playlist YouTube, `TikTokLink` mengenali video TikTok.
2. **Halaman pilihan** (`LinkActivity`): YouTube video → M4A / MP3 / MP4 (pilih kualitas); playlist YouTube → semua video dengan satu format; TikTok → M4A / MP3 / MP4 tanpa watermark.
3. **Layanan unduhan** (`DownloadService`, satu antrean): 
   - YouTube: info video (coba ulang) → M4A asli | MP3 (unduh M4A → FFmpeg) | MP4 (video + audio digabung) → cek berkas → simpan.
   - TikTok: halaman TikTok → bila gagal tikwm.com → semua alamat alternatif dan kualitas → cek MP4 → M4A (salin trek suara) atau MP3 (FFmpeg) → simpan. Bila MP3 gagal, unduhan gagal.
   - Playlist: daftar video → satu per satu dengan alur YouTube di atas → putaran ulang untuk yang gagal → ringkasan.
4. **Hasil** di `Music/YTPlayer` (audio) dan `Movies/YTPlayer` (video); playlist di subfolder bernama playlist dengan nomor urut.

## Yang baru di v2.8
- **Unduh playlist YouTube:** tempel atau bagikan tautan playlist (`youtube.com/playlist?list=...`), lalu pilih *Unduh semua sebagai M4A / MP3 / MP4*. Semua video diunduh satu per satu berurutan, diberi nomor urut ("01 - Judul") dan disimpan di subfolder bernama playlist (`Music/YTPlayer/<playlist>` atau `Movies/YTPlayer/<playlist>`). Untuk MP4 dipilih kualitas tertinggi hingga batas yang Anda tentukan (video yang tidak punya kualitas sebesar itu memakai kualitas terbawahnya). Maksimal 1000 video pertama per playlist; siaran langsung dilewati.
- Progres playlist ada di satu notifikasi ("Nama playlist (3/20)") dengan tombol *Batal* yang menghentikan seluruh playlist. Video yang gagal dilewati; ringkasan berhasil dan gagal tampil di akhir.
- Video yang dibuka dari dalam playlist (tautan `watch?v=...&list=...`) kini punya tombol tambahan *Unduh seluruh playlist video ini*. Daftar putar otomatis "Mix" tidak didukung.

## Yang baru di v2.5
- **Unduh MP3 benar-benar MP3 di semua HP:** encoder diganti dengan LAME open source yang dikompilasi langsung di proyek dan membawa pustaka native untuk arm64-v8a dan armeabi-v7a (sebelumnya memakai pustaka pihak ketiga yang bisa gagal dimuat, lalu hasilnya jatuh ke M4A). Berkas MP3 kini juga memuat bingkai Info/LAME sehingga durasi tepat.

## Yang baru di v2.4
- **Layar tetap menyala saat memutar video** (seperti YouTube asli): selama halaman pemutar terbuka dan video berjalan, layar tidak mati sendiri. Dijeda, selesai, atau mode audio saja = ikut pengaturan HP. Suara tetap berbunyi saat layar dimatikan atau aplikasi ditutup.

## Yang baru di v2.3
- Video tampil bertahap per 15 (sebelumnya 10); perbaikan galat kompilasi pada fungsi unduh.

## Yang baru di v2.2
- **Unduh TikTok lebih andal:** data video yang sudah diambil di halaman pilihan dipakai ulang saat mengunduh (tidak mengambil ulang); pengambilan data dicoba sampai 3 putaran dengan penyamaran peramban berbeda, tautan pendek diurai dulu untuk layanan cadangan, dan layanan cadangan dicoba ulang bila dibatasi.
- Saat mengunduh: semua alamat alternatif dari TikTok dicoba, lalu kualitas lain, lalu seluruh proses diulang dengan data baru bila alamat kedaluwarsa (sampai 3 kali). Berkas hasil dicek agar benar-benar video MP4 sebelum disimpan. Untuk M4A/MP3 dipakai kualitas terendah (lebih cepat dan hemat kuota).

## Yang baru di v2.1
- **Unduh MP4 memakai suara asli video:** YouTube kini menyediakan beberapa jalur audio (dubbing otomatis). Dulu yang terambil bisa jalur dubbing bahasa Inggris; sekarang jalur *asli* diutamakan untuk unduhan MP4, M4A, MP3, dan juga pemutaran video di aplikasi.
- **Ukuran MP4 lebih kecil:** untuk tiap resolusi dipilih aliran 30 fps yang paling kecil (bukan 60 fps atau versi bitrate "premium"), dan aliran gabungan lama tidak lagi menggantikan pasangan video+audio asli.
- **Daftar video muncul bertahap:** 15 video pertama tampil secepatnya (beranda dan hasil pencarian), lalu ditambah 15 demi 15 selagi sisanya dimuat; saat menggulir, halaman berikutnya juga masuk per 15 video.
- Perbaikan kecil: video dari pencarian lama tidak lagi ikut masuk ke daftar baru, dan pemuatan latar dihentikan bila pencarian diganti.

## Yang baru di v2.0
- **Unduh MP4 lebih andal:** cek ruang kosong sebelum mulai, unduhan per potongan dengan coba ulang dan pembaruan tautan kedaluwarsa (video dan audio), hingga 3 kali percobaan penuh, penggabungan video+audio dengan buffer lebih besar, dan sisa berkas percobaan gagal dihapus.
- **Daftar kualitas lebih sederhana:** hanya resolusi dan ukuran, mis. `1080p • 85 MB` (ukuran dihilangkan bila tidak diketahui; untuk video+audio terpisah ukurannya gabungan).

## Yang baru di v1.9
- **Unduh MP3 lebih andal:** unduhan dicoba ulang otomatis dengan jeda bertahap dan lanjut dari byte terakhir; bila tautan YouTube kedaluwarsa (HTTP 403/404/410) tautan baru diambil lalu unduhan dilanjutkan; seluruh proses (unduh + konversi) dicoba sampai 3 kali, dan percobaan berikutnya memakai aliran audio lain bila konversi yang gagal. Audio surround 5.1 kini dirapatkan ke stereo (sebelumnya gagal), dekoder yang macet terdeteksi, dan CPU dijaga aktif (wake lock) saat layar mati. Bila semua percobaan gagal, audio aslinya tetap disimpan sebagai M4A.
- **Lebih banyak video:** hasil pencarian langsung memuat beberapa halaman sekaligus (hanya video, tanpa channel/daftar putar) dan terus bertambah saat digulir; beranda memakai lebih banyak sumber (8 video terakhir, 6 pencarian terakhir, 4 channel, plus video populer dari beberapa kategori) dengan hingga 200 video.
- **Filter tanggal unggah seperti YouTube:** tombol *Tanggal unggah* (Kapan saja, Satu jam terakhir, Hari ini, Minggu ini, Bulan ini, Tahun ini) berlaku untuk pencarian, kategori, dan beranda. Penyaringan dilakukan di HP berdasarkan keterangan waktu unggah (YouTube hanya memberi perkiraan seperti "3 minggu lalu"), sehingga halaman tambahan dimuat otomatis sampai hasilnya cukup.

## Yang baru di v1.8
- Pemutaran video yang dipilih lebih cepat: aliran diambil lebih awal (saat dipilih / saat fokus TalkBack bertahan), berbarengan dengan layar pemutar dibuka; koneksi dipakai ulang; buffer awal 1 detik.

## Yang baru di v1.7

- **Unduh dari TikTok:** salin tautan video dari aplikasi TikTok (Bagikan lalu Salin tautan) lalu buka aplikasi ini, atau pakai menu Bagikan TikTok dan pilih *YT Player: putar atau unduh*. Halaman pilihan menawarkan Unduh M4A (suara asli), Unduh MP3, dan Unduh MP4 tanpa watermark. Tampilannya sama dengan halaman YouTube dan tetap ramah TalkBack.
- **Cara kerja dan batasannya:** video diambil dari halaman TikTok; bila gagal, dicoba lewat layanan pihak ketiga tikwm.com (tautan videonya dikirim ke layanan itu). Keduanya tidak resmi dan bisa berhenti bekerja bila TikTok berubah. Hanya video publik; postingan foto/slide belum didukung. Pemutaran TikTok tidak ada di aplikasi ini.

## Yang baru di v1.6

- **Bagikan dari YouTube asli:** di menu Bagikan YouTube pilih *YT Player: putar atau unduh*. Muncul halaman dengan pilihan Putar video, Putar audio saja, Unduh M4A, Unduh MP3, dan Unduh MP4 (lalu pilih kualitas).
- **Tautan di clipboard (seperti SnapTube):** salin tautan video dari YouTube asli, lalu buka aplikasi ini. Halaman pilihan putar/unduh terbuka otomatis. Tautan yang sama tidak ditawarkan berulang kali.
- **Beranda berisi rekomendasi** dari riwayat tontonan dan pencarian Anda (video terkait tontonan terakhir, hasil pencarian terakhir, dan video dari channel yang sering ditonton). Bila belum ada riwayat, tampil video populer.
- **Penyegaran ala YouTube:** tarik daftar ke bawah, ketuk kategori yang sedang aktif (sekali = ke atas, di atas = segarkan), atau tombol Segarkan. Dibuka lagi setelah lebih dari 30 menit = beranda dimuat ulang; sebentar saja = tampilan dan posisi gulir dipertahankan.
- **Hapus riwayat:** di kategori Riwayat, tombol *Hapus riwayat* menawarkan hapus riwayat tontonan, riwayat pencarian, atau semuanya. Satu video juga bisa dihapus lewat menu Tindakan TalkBack ("Hapus dari riwayat").

## Cara membangun APK (GitHub Actions)

1. Buat repo GitHub baru, unggah seluruh isi folder ini (termasuk folder `keystore` dan `.github`).
2. Buka tab **Actions** → workflow **Build APK** berjalan otomatis (atau jalankan manual: *Run workflow*).
3. Setelah selesai, unduh **YTPlayer-apk** dari bagian *Artifacts* → ekstrak → `YTPlayer.apk` → pasang di HP.
4. Membuat tag `v1.0` (`git tag v1.0 && git push --tags`) juga membuat *Release* dengan APK terlampir.

APK ditandatangani dengan keystore di `keystore/ytplayer.jks` (untuk pemakaian pribadi), sehingga versi baru bisa menimpa versi lama tanpa uninstall.

## Cara kerja

Aplikasi memakai [NewPipeExtractor](https://github.com/TeamNewPipe/NewPipeExtractor) untuk mencari video dan mengambil alamat aliran audio/video tanpa API key. Pemutaran memakai Media3 (ExoPlayer) di dalam `PlaybackService` (foreground service + MediaSession).

- `MainActivity` – beranda: pencarian, kategori, riwayat, mini player.
- `PlayerActivity` – halaman tonton + kontrol aksesibel.
- `PlaybackService` – pemutar latar belakang, pewaktu tidur, putar otomatis, ganti mode audio/video di posisi yang sama.
- `Repo` / `StreamResolver` – pencarian dan pemilihan aliran (audio terbaik / video gabungan ≤ 720p / HLS untuk siaran langsung).
- `DownloadService` / `DownloadOptions` / `Downloads` – unduhan latar belakang (per potongan 4 MB, coba ulang otomatis), penggabungan video+audio dengan `MediaMuxer`, penyimpanan lewat MediaStore.

## Catatan penting

- **Lisensi:** NewPipeExtractor berlisensi **GPL-3.0**, maka proyek ini juga harus dibagikan di bawah GPL-3.0 bila didistribusikan (lihat `LICENSE`).
- **Ketentuan layanan:** mengambil aliran di luar aplikasi/pemutar resmi YouTube dan memutar di latar belakang tanpa langganan Premium bertentangan dengan Ketentuan Layanan YouTube. Gunakan untuk keperluan pribadi dan atas risiko sendiri. Aplikasi ini tidak berafiliasi dengan YouTube/Google; nama, logo, dan ikon di sini adalah desain sendiri.
- **Bisa rusak sewaktu-waktu:** YouTube sering mengubah sistemnya. Bila video gagal dimuat, naikkan versi `NewPipeExtractor` di `app/build.gradle.kts` ke rilis terbaru lalu bangun ulang.
- Kualitas video dibatasi ke aliran gabungan (umumnya 360p–720p) agar stabil; mode audio saja memakai audio berbitrate terbaik.
- Beranda memakai kategori berbasis pencarian (YouTube telah menghapus halaman *Trending*).
- YouTube tidak menyediakan MP3. Opsi MP3 mengunduh audio asli lalu mengonversinya di HP memakai **FFmpeg (libmp3lame)**, satu-satunya jalur (tanpa cadangan). Pustaka native ramping dibangun dari `native/` oleh `native/build-native.sh`. Kualitas sedikit turun dibanding M4A. Bila konversi gagal, unduhan gagal.
- Video 720p ke atas biasanya tersedia sebagai aliran terpisah, jadi diunduh dua bagian lalu digabung (butuh ruang kosong sekitar 2× ukuran video selama proses).
- Mengunduh video dari YouTube bertentangan dengan Ketentuan Layanan YouTube dan dapat melanggar hak cipta. Gunakan hanya untuk konten yang Anda berhak simpan.
- Tidak ada fitur komentar.
