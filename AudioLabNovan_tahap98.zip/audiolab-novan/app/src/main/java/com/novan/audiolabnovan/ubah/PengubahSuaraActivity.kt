package com.novan.audiolabnovan.ubah

import android.content.ContentValues
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.novan.audiolabnovan.Converter
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.Opts
import com.novan.audiolabnovan.OutFmt
import com.novan.audiolabnovan.R
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Tahap 53: Pengubah Suara.
 *
 * Pengguna memilih berkas audio (atau berkas yang sudah dipilih di layar utama), memilih salah satu suara dari daftar
 * (pria jadi wanita, anak kecil, raksasa, monster, robot, alien, hantu, megafon, dan lain-lain), boleh menambah
 * penyetelan nada, kecepatan, gema ruang, bass, dan volume, mendengarkan contoh 10 detik, lalu menyimpan hasilnya
 * (MP3 bawaan, atau M4A, FLAC, WAV). Semua perubahan dilakukan oleh FFmpeg; durasi tetap kecuali kecepatan diubah.
 */
class PengubahSuaraActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_NAMA = "nama"
    }

    private class Suara(val nama: String, val keterangan: String, val filter: List<String>)

    /** Ubah nada tanpa mengubah lama (faktor 0,5 sampai 2). */
    private fun geser(f: Double): List<String> {
        val r = Math.round(44100 * f).toInt()
        return listOf(
            "aresample=44100", "asetrate=$r", "aresample=44100",
            "atempo=" + String.format(Locale.US, "%.6f", 1.0 / f)
        )
    }

    /** Modulasi cincin: suara dikalikan gelombang sinus, hasilnya bernada logam seperti robot atau vokoder sederhana. */
    private fun ring(hz: Int): List<String> = listOf(
        "aformat=channel_layouts=stereo",
        "aeval=val(0)*sin(2*PI*t*$hz)|val(1)*sin(2*PI*t*$hz):c=same",
        "alimiter=limit=0.95"
    )

    private val daftarSuara: List<Suara> by lazy {
        listOf(
            Suara("Suara asli (tanpa perubahan)", "Hanya memakai penyetelan di bawah", emptyList()),
            Suara("Pria jadi wanita", "Nada dinaikkan, suara lebih tipis", geser(1.35) + "treble=g=2"),
            Suara("Wanita jadi pria", "Nada diturunkan, suara lebih berat", geser(0.78) + "bass=g=3"),
            Suara("Anak kecil", "Nada tinggi dan ringan", geser(1.5) + "treble=g=2"),
            Suara("Tupai", "Sangat tinggi dan cempreng", Converter.voiceFilters(Opts(voice = 1))),
            Suara("Raksasa", "Sangat rendah dan menggelegar", Converter.voiceFilters(Opts(voice = 2))),
            Suara("Monster", "Sangat rendah dengan gema pendek", geser(0.6) + listOf("aecho=0.8:0.8:40:0.5", "bass=g=4", "alimiter=limit=0.95")),
            Suara("Robot", "Suara mesin datar", Converter.voiceFilters(Opts(voice = 3))),
            Suara("Alien", "Tinggi dan bergelombang", geser(1.3) + "vibrato=f=8:d=0.6"),
            Suara("Hantu", "Rendah, bergema panjang, bergetar halus",
                geser(0.85) + listOf("vibrato=f=5:d=0.3", "lowpass=f=4500", "aecho=0.8:0.9:500|1000:0.4|0.3", "alimiter=limit=0.95")),
            Suara("Radio atau telepon", "Terdengar dari radio atau telepon", Converter.voiceFilters(Opts(voice = 4))),
            Suara("Megafon", "Keras dan sempit seperti pengeras suara", listOf(
                "highpass=f=500", "lowpass=f=3500", "acompressor=threshold=-24dB:ratio=6:makeup=4", "aecho=0.8:0.7:60:0.3", "alimiter=limit=0.95")),
            Suara("Telepon tua", "Sangat sempit dan kecil", listOf("highpass=f=400", "lowpass=f=2800", "acompressor=threshold=-24dB:ratio=4:makeup=3")),
            Suara("Berbisik", "Tipis dan ringan", listOf("highpass=f=700", "lowpass=f=6000", "volume=4dB", "alimiter=limit=0.95")),
            Suara("Bergetar", "Suara naik turun cepat", Converter.voiceFilters(Opts(voice = 5))),
            Suara("Paduan suara (chorus)", "Terdengar seperti beberapa orang", listOf("chorus=0.7:0.9:55:0.4:0.25:2")),
            Suara("Dalam gua", "Gema sangat panjang", Converter.echoFilters(Opts(echoMode = 6))),
            Suara("Vokoder robot rendah", "Suara bernada logam, mirip vokoder (modulasi cincin 30 Hz)", ring(30)),
            Suara("Vokoder robot tinggi", "Suara logam lebih tajam (modulasi cincin 80 Hz)", ring(80))
        )
    }

    private val daftarRuang = listOf("Tanpa gema", "Ruang kecil", "Aula", "Gema (echo)", "Studio vokal", "Karaoke", "Katedral", "Kamar mandi", "Panggung konser", "Reverb ruang tamu", "Reverb aula besar")
    private val daftarBass = listOf(0, 3, 6, 9, 12)
    private val daftarVolume = listOf(-6, -3, 0, 3, 6, 9)
    private val daftarKbps = listOf(64, 96, 128, 192, 256, 320)
    private val daftarFormat = OutFmt.values().toList()   // MP3 paling atas = terpilih bawaan

    private val pref by lazy { getSharedPreferences("ubah_suara", MODE_PRIVATE) }

    private var sumber: Uri? = null
    private var namaSumber = ""
    @Volatile private var sibuk = false
    @Volatile private var sesi: FFmpegSession? = null
    private var player: MediaPlayer? = null
    private var hasilFile: File? = null
    private var hasilUri: Uri? = null
    private var hasilFmt: OutFmt = OutFmt.MP3
    private var hasilNama: String = ""
    private var terakhirUmum = -1
    private val dialogHasil by lazy { DialogHasil(this) }
    private var menyiapkanContoh = false
    private var jedaContoh = false

    private lateinit var tvBerkas: TextView
    private lateinit var spSuara: Spinner
    private lateinit var tvKet: TextView
    private lateinit var seekNada: SeekBar
    private lateinit var seekCepat: SeekBar
    private lateinit var tvNada: TextView
    private lateinit var tvCepat: TextView
    private lateinit var spRuang: Spinner
    private lateinit var spBass: Spinner
    private lateinit var spVolume: Spinner
    private lateinit var cbRata: CheckBox
    private lateinit var spFormat: Spinner
    private lateinit var spKbps: Spinner
    private lateinit var btnPilih: Button
    private lateinit var btnContoh: Button
    private lateinit var btnUbah: Button
    private lateinit var btnBatal: Button
    private lateinit var progress: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvStatus: TextView
    private lateinit var panelHasil: LinearLayout
    private lateinit var tvHasil: TextView
    private lateinit var btnPutar: Button
    private lateinit var btnBagikan: Button
    private lateinit var btnSimpan: Button

    private val pilihBerkas = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) setSumber(uri, namaDari(uri))
    }

    private val simpanSebagai = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data
        val f = hasilFile
        if (r.resultCode == RESULT_OK && uri != null && f != null && f.exists()) {
            thread {
                val err = try { Converter.copyTo(this, f, uri); null } catch (e: Exception) { e.message ?: "galat" }
                runOnUiThread {
                    if (err == null) { hasilUri = uri; btnBagikan.isEnabled = true; status("Berkas tersimpan.") }
                    else status("Gagal menyimpan: $err")
                }
            }
        } else status("Penyimpanan dibatalkan.")
    }

    // =====================================================================================
    //  Tampilan
    // =====================================================================================

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun LinearLayout.tambah(v: View) {
        addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun judul(teks: String, untuk: View? = null) = TextView(this).apply {
        text = teks
        textSize = 16f
        setPadding(0, dp(14), 0, dp(2))
        if (untuk != null) {
            if (untuk.id == View.NO_ID) untuk.id = View.generateViewId()
            labelFor = untuk.id
        }
    }

    private fun subjudul(teks: String) = TextView(this).apply {
        text = teks
        textSize = 20f
        setPadding(0, dp(22), 0, dp(4))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        ViewCompat.setAccessibilityHeading(this, true)
    }

    private fun tombol(teks: String, aksi: () -> Unit) = Button(this).apply {
        text = teks
        minHeight = dp(52)
        isAllCaps = false
        setOnClickListener { aksi() }
    }

    private fun isiSpinner(sp: Spinner, items: List<String>, pilih: Int) {
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        if (items.isNotEmpty()) sp.setSelection(pilih.coerceIn(0, items.size - 1), false)
    }

    private fun spinner(items: List<String>, awal: Int = 0, saatPilih: (Int) -> Unit = {}): Spinner {
        val sp = Spinner(this)
        sp.minimumHeight = dp(48)
        isiSpinner(sp, items, awal)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { saatPilih(position) }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return sp
    }

    private fun seek(maks: Int, awal: Int, nama: String, format: (Int) -> String, label: TextView, saatUbah: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = maks
        s.progress = awal.coerceIn(0, maks)
        s.minimumHeight = dp(48)
        s.contentDescription = nama
        fun segarkan(p: Int) {
            label.text = "$nama: ${format(p)}"
            ViewCompat.setStateDescription(s, format(p))
        }
        segarkan(s.progress)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { segarkan(p); saatUbah(p) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }

    private fun semiNada(p: Int) = p - 6                      // 0..12 -> -6..+6
    private fun fmtNada(p: Int): String = when {
        semiNada(p) == 0 -> "tidak diubah"
        semiNada(p) > 0 -> "naik ${semiNada(p)} nada"
        else -> "turun ${-semiNada(p)} nada"
    }
    private fun kecepatan(p: Int) = 0.5 + p * 0.05             // 0..30 -> 0,5..2,0
    private fun fmtCepat(p: Int): String = if (p == 10) "normal" else String.format(Locale("id", "ID"), "%.2f kali", kecepatan(p))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.judul_ubah)

        val akar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(akar) })

        akar.tambah(subjudul("Berkas suara"))
        tvBerkas = TextView(this).apply { textSize = 16f; text = "Belum ada berkas dipilih." }
        akar.tambah(tvBerkas)
        btnPilih = tombol("Pilih berkas audio atau video") { pilihBerkas.launch(arrayOf("audio/*", "video/*")) }
        akar.tambah(btnPilih)

        akar.tambah(subjudul("Pilih suara"))
        spSuara = spinner(daftarSuara.map { it.nama }, pref.getInt("suara", 1)) { pos ->
            pref.edit().putInt("suara", pos).apply()
            tvKet.text = "Keterangan: " + daftarSuara[pos].keterangan
        }
        akar.tambah(judul("Jenis suara", spSuara))
        akar.tambah(spSuara)
        tvKet = TextView(this).apply { textSize = 16f; text = "Keterangan: " + daftarSuara[spSuara.selectedItemPosition.coerceAtLeast(0)].keterangan }
        akar.tambah(tvKet)

        akar.tambah(subjudul("Penyetelan tambahan"))
        tvNada = judul("")
        akar.tambah(tvNada)
        seekNada = seek(12, 6, "Nada tambahan", { fmtNada(it) }, tvNada) {}
        akar.tambah(seekNada)
        tvCepat = judul("")
        akar.tambah(tvCepat)
        seekCepat = seek(30, 10, "Kecepatan bicara", { fmtCepat(it) }, tvCepat) {}
        akar.tambah(seekCepat)
        spRuang = spinner(daftarRuang, pref.getInt("ruang", 0)) { pref.edit().putInt("ruang", it).apply() }
        akar.tambah(judul("Gema ruang", spRuang))
        akar.tambah(spRuang)
        spBass = spinner(daftarBass.map { if (it == 0) "Mati" else "Plus $it dB" }, pref.getInt("bass", 0)) { pref.edit().putInt("bass", it).apply() }
        akar.tambah(judul("Penguat bass", spBass))
        akar.tambah(spBass)
        spVolume = spinner(daftarVolume.map { if (it == 0) "Normal" else if (it > 0) "Plus $it dB" else "Minus ${-it} dB" }, pref.getInt("volume", 2)) {
            pref.edit().putInt("volume", it).apply()
        }
        akar.tambah(judul("Volume hasil", spVolume))
        akar.tambah(spVolume)
        cbRata = CheckBox(this).apply {
            text = "Ratakan volume (normalisasi)"
            minHeight = dp(48)
            isChecked = pref.getBoolean("rata", false)
            setOnCheckedChangeListener { _, c -> pref.edit().putBoolean("rata", c).apply() }
        }
        akar.tambah(cbRata)

        akar.tambah(subjudul("Format audio"))
        spFormat = spinner(daftarFormat.map { it.label }, pref.getInt("format", 0)) {
            pref.edit().putInt("format", it).apply()
            segarkanTombol()
        }
        akar.tambah(judul("Format hasil (bawaan MP3)", spFormat))
        akar.tambah(spFormat)
        spKbps = spinner(daftarKbps.map { "$it kbps" }, pref.getInt("kbps", 2)) { pref.edit().putInt("kbps", it).apply() }
        akar.tambah(judul("Kualitas (bitrate)", spKbps))
        akar.tambah(spKbps)

        akar.tambah(subjudul("Ubah suara"))
        btnContoh = tombol("Dengarkan contoh 10 detik") { klikContoh() }
        akar.tambah(btnContoh)
        btnUbah = tombol("Ubah suara dan simpan") { jalankan(false) }
        akar.tambah(btnUbah)
        btnBatal = tombol("Berhenti atau batalkan") { hentikanSemua() }
        akar.tambah(btnBatal)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        akar.tambah(progress)
        tvProgress = TextView(this).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(0, dp(4), 0, 0)
        }
        akar.tambah(tvProgress)
        tvStatus = TextView(this).apply {
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            textSize = 16f
            setPadding(0, dp(8), 0, 0)
        }
        akar.tambah(tvStatus)

        panelHasil = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        panelHasil.tambah(subjudul("Hasil"))
        tvHasil = TextView(this).apply { textSize = 16f }
        panelHasil.tambah(tvHasil)
        btnPutar = tombol("Buka menu hasil: putar, jeda, bagikan, ubah nama, hapus") { bukaMenuHasil() }
        panelHasil.tambah(btnPutar)
        btnBagikan = tombol("Bagikan") { bagikan() }
        panelHasil.tambah(btnBagikan)
        btnSimpan = tombol("Simpan sebagai…") { simpanKeLokasi() }
        panelHasil.tambah(btnSimpan)
        akar.tambah(panelHasil)

        val u = intent.getStringExtra(EXTRA_URI)?.let { Uri.parse(it) }
        if (u != null) setSumber(u, intent.getStringExtra(EXTRA_NAMA).orEmpty().ifBlank { namaDari(u) })
        else status("Pilih berkas audio dulu.")
        segarkanTombol()
    }

    private fun namaDari(uri: Uri): String {
        var nama = uri.lastPathSegment ?: "berkas"
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { nama = it }
            }
        } catch (_: Exception) { }
        return nama
    }

    private fun setSumber(uri: Uri, nama: String) {
        sumber = uri
        namaSumber = nama
        tvBerkas.text = "Berkas: $nama"
        hapusHasil()
        status("Berkas dipilih. Pilih jenis suara, lalu tekan Dengarkan contoh atau Ubah suara dan simpan.")
        segarkanTombol()
    }

    // =====================================================================================
    //  Proses
    // =====================================================================================

    private fun susunFilter(): List<String> {
        val s = daftarSuara[spSuara.selectedItemPosition.coerceIn(0, daftarSuara.size - 1)]
        val f = ArrayList<String>()
        f += s.filter
        val semi = semiNada(seekNada.progress)
        if (semi != 0) f += geser(Math.pow(2.0, semi / 12.0))
        val cepat = kecepatan(seekCepat.progress)
        if (seekCepat.progress != 10) f += "atempo=" + String.format(Locale.US, "%.4f", cepat)
        val o = Opts(
            normalize = cbRata.isChecked,
            gainDb = daftarVolume[spVolume.selectedItemPosition.coerceIn(0, daftarVolume.size - 1)],
            bassDb = daftarBass[spBass.selectedItemPosition.coerceIn(0, daftarBass.size - 1)],
            echoMode = spRuang.selectedItemPosition.coerceIn(0, daftarRuang.size - 1),
            sampleRate = 44100
        )
        f += Converter.tailFilters(o, 0.0)
        return f
    }

    private fun jalankan(contoh: Boolean) {
        val src = sumber
        if (src == null) { status("Pilih berkas audio dulu."); return }
        if (sibuk) return
        hapusHasil()
        val fmt = if (contoh) OutFmt.WAV else daftarFormat[spFormat.selectedItemPosition.coerceIn(0, daftarFormat.size - 1)]
        val kbps = daftarKbps[spKbps.selectedItemPosition.coerceIn(0, daftarKbps.size - 1)]
        val saringan = susunFilter()
        val judulBerkas = namaSumber.substringBeforeLast('.', namaSumber).take(60)
        val kecepatanPakai = kecepatan(seekCepat.progress)
        val dest = File(cacheDir, "ubah_" + System.currentTimeMillis() + "." + fmt.ext)

        menyiapkanContoh = contoh
        setSibuk(true)
        progres(0, if (contoh) "Menyiapkan contoh" else "Menyiapkan")
        status(if (contoh) "Membuat contoh 10 detik…" else "Mengubah suara. Biarkan layar menyala sampai selesai.")

        thread {
            val durMs = Converter.probeDurationMs(this, src)
            val keluarMs = (if (contoh) minOf(durMs, 10_000L) else durMs).let { if (it > 0) (it / kecepatanPakai).toLong() else 0L }
            val path = try { FFmpegKitConfig.getSafParameterForRead(this, src) } catch (e: Throwable) { null }
            if (path == null) {
                runOnUiThread { selesaiGagal("Berkas tidak bisa dibuka.") }
                return@thread
            }
            val args = ArrayList<String>()
            args += listOf("-y", "-nostdin", "-i", path, "-vn")
            if (contoh) args += listOf("-t", "10")
            if (saringan.isNotEmpty()) args += listOf("-af", saringan.joinToString(","))
            args += listOf("-ar", "44100")
            args += fmt.codecArgs(kbps)
            if (!contoh) args += listOf("-metadata", "title=$judulBerkas", "-metadata", "artist=AudioLab novan", "-metadata", "album=Pengubah Suara")
            args += dest.absolutePath

            sesi = FFmpegKit.executeWithArgumentsAsync(
                args.toTypedArray(),
                { s ->
                    when {
                        ReturnCode.isCancel(s.returnCode) -> { dest.delete(); runOnUiThread { selesaiGagal("Dibatalkan.") } }
                        ReturnCode.isSuccess(s.returnCode) && dest.length() > 0 -> {
                            if (contoh) runOnUiThread { selesaiContoh(dest) } else simpanDanTampilkan(dest, fmt)
                        }
                        else -> {
                            dest.delete()
                            val log = (s.allLogsAsString ?: "").takeLast(300).replace('\n', ' ')
                            runOnUiThread { selesaiGagal("Gagal mengubah suara (kode ${s.returnCode}): $log") }
                        }
                    }
                },
                null,
                { st ->
                    if (keluarMs > 0) {
                        val p = (st.time.toLong() * 100L / keluarMs).toInt().coerceIn(0, 99)
                        runOnUiThread { progres(p, if (contoh) "Membuat contoh" else "Mengubah suara") }
                    }
                }
            )
        }
    }

    private fun selesaiGagal(pesan: String) {
        menyiapkanContoh = false
        setSibuk(false)
        progres(0, "")
        status(pesan)
    }

    private fun selesaiContoh(f: File) {
        menyiapkanContoh = false
        setSibuk(false)
        progres(100, "Contoh siap")
        hasilFile = f
        hasilUri = null
        mainkan(f)
        status("Memutar contoh. Tombol contoh sekarang jadi Jeda. Bila cocok, tekan Ubah suara dan simpan.")
    }

    private fun simpanDanTampilkan(f: File, fmt: OutFmt) {
        val stempel = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
        val nama = "UbahSuara_$stempel.${fmt.ext}"
        var uri: Uri? = null
        var galat: String? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try { uri = simpanOtomatis(f, nama, fmt) } catch (e: Exception) { galat = e.message ?: "galat" }
        }
        val u = uri
        val g = galat
        val lama = try {
            val d = com.arthenica.ffmpegkit.FFprobeKit.getMediaInformation(f.absolutePath).mediaInformation?.duration
            Converter.durasiTeks(d?.toDoubleOrNull() ?: 0.0)
        } catch (_: Throwable) { "tidak diketahui" }
        runOnUiThread {
            hasilFile = f
            hasilUri = u
            hasilFmt = fmt
            setSibuk(false)
            progres(100, "Selesai")
            panelHasil.visibility = View.VISIBLE
            tvHasil.text = when {
                u != null -> "Selesai, lama $lama. Tersimpan di folder Musik, AudioLab Novan, Pengubah Suara, dengan nama $nama."
                g != null -> "Selesai, lama $lama, tetapi tidak bisa disimpan otomatis ($g). Tekan Simpan sebagai."
                else -> "Selesai, lama $lama. Tekan Simpan sebagai untuk memilih lokasi simpan."
            }
            status(tvHasil.text.toString())
            btnBagikan.isEnabled = u != null
            hasilNama = if (u != null) nama else f.name
            segarkanTombol()
            bukaMenuHasil()
        }
    }

    /** Dialog menu hasil: putar, jeda, lanjutkan, bagikan, ubah nama, hapus. Muncul otomatis saat selesai. */
    private fun bukaMenuHasil() {
        val f = hasilFile
        val u = hasilUri ?: f?.takeIf { it.exists() }?.let { Uri.fromFile(it) }
        if (u == null) { status("Belum ada hasil."); return }
        dialogHasil.saatDiubah = { h ->
            if (h.uri.scheme == "file") hasilFile = File(h.uri.path ?: "") else hasilUri = h.uri
            hasilNama = h.nama
            tvHasil.text = "Nama berkas sekarang ${h.nama}."
        }
        dialogHasil.saatDihapus = {
            hasilUri = null
            hasilFile?.delete()
            hasilFile = null
            panelHasil.visibility = View.GONE
            btnBagikan.isEnabled = false
            status("Hasil sudah dihapus.")
        }
        dialogHasil.tampilkan(u, hasilNama.ifEmpty { u.lastPathSegment ?: "hasil" }, hasilFmt.mime)
    }

    /** Satu tombol contoh: Dengarkan contoh, Batalkan contoh, Jeda, Lanjutkan. */
    private fun klikContoh() {
        val p = player
        when {
            menyiapkanContoh -> hentikanSemua()
            p != null -> {
                if (jedaContoh) {
                    try { p.start() } catch (_: Exception) { }
                    jedaContoh = false
                    status("Contoh dilanjutkan.")
                } else {
                    try { p.pause() } catch (_: Exception) { }
                    jedaContoh = true
                    status("Contoh dijeda. Tekan Lanjutkan untuk meneruskan.")
                }
                segarkanTombol()
            }
            else -> jalankan(true)
        }
    }

    @android.annotation.TargetApi(Build.VERSION_CODES.Q)
    private fun simpanOtomatis(src: File, nama: String, fmt: OutFmt): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, nama)
            put(MediaStore.Audio.Media.MIME_TYPE, fmt.mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/AudioLab Novan/Pengubah Suara")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val koleksi = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val u = contentResolver.insert(koleksi, cv) ?: throw java.io.IOException("MediaStore menolak berkas")
        try {
            Converter.copyTo(this, src, u)
            contentResolver.update(u, ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            try { contentResolver.delete(u, null, null) } catch (_: Exception) { }
            throw e
        }
        return u
    }

    // =====================================================================================
    //  Hasil: putar, bagikan, simpan
    // =====================================================================================

    private fun hapusHasil() {
        dialogHasil.hentikanSuara()
        hentikanPutar()
        hasilFile?.delete()
        hasilFile = null
        hasilUri = null
        panelHasil.visibility = View.GONE
    }

    private fun mainkan(f: File) {
        hentikanPutar()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { hentikanPutar() }
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            status("Tidak bisa memutar: ${e.message}")
        }
        segarkanTombol()
    }

    private fun hentikanPutar() {
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        jedaContoh = false
        if (::btnPutar.isInitialized) segarkanTombol()
    }

    private fun bagikan() {
        val u = hasilUri
        if (u == null) { status("Simpan dulu hasilnya dengan tombol Simpan sebagai."); return }
        try {
            val kirim = Intent(Intent.ACTION_SEND).apply {
                type = hasilFmt.mime
                putExtra(Intent.EXTRA_STREAM, u)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(kirim, "Bagikan hasil").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            status("Menu Bagikan tidak bisa dibuka: ${e.message}")
        }
    }

    private fun simpanKeLokasi() {
        val f = hasilFile
        if (f == null || !f.exists()) { status("Belum ada hasil untuk disimpan."); return }
        val stempel = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
        simpanSebagai.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = hasilFmt.mime
            putExtra(Intent.EXTRA_TITLE, "UbahSuara_$stempel.${hasilFmt.ext}")
        })
    }

    // =====================================================================================
    //  Status, progres, tombol
    // =====================================================================================

    private fun status(t: String) { tvStatus.text = t }

    private fun progres(p: Int, teks: String) {
        progress.progress = p
        tvProgress.text = if (teks.isEmpty()) "" else "$teks, $p persen."
        val kelompok = p / 10
        tvProgress.accessibilityLiveRegion =
            if (kelompok == terakhirUmum) View.ACCESSIBILITY_LIVE_REGION_NONE else View.ACCESSIBILITY_LIVE_REGION_POLITE
        terakhirUmum = kelompok
    }

    private fun setSibuk(s: Boolean) {
        sibuk = s
        if (s) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        segarkanTombol()
    }

    private fun segarkanTombol() {
        if (!::btnUbah.isInitialized) return
        val bisa = sumber != null && !sibuk
        btnUbah.isEnabled = bisa
        btnContoh.isEnabled = bisa || menyiapkanContoh || player != null
        btnContoh.text = when {
            menyiapkanContoh -> "Batalkan contoh"
            player != null -> if (jedaContoh) "Lanjutkan" else "Jeda"
            else -> "Dengarkan contoh 10 detik"
        }
        btnPilih.isEnabled = !sibuk
        btnBatal.isEnabled = sibuk || player != null
        listOf(spSuara, spRuang, spBass, spVolume, spFormat, seekNada, seekCepat, cbRata).forEach { it.isEnabled = !sibuk }
        spKbps.isEnabled = !sibuk && daftarFormat[spFormat.selectedItemPosition.coerceIn(0, daftarFormat.size - 1)].lossy
        btnSimpan.isEnabled = !sibuk
    }

    private fun hentikanSemua() {
        if (sibuk) {
            try { sesi?.cancel() } catch (_: Exception) { }
            status("Membatalkan…")
        }
        if (player != null) { hentikanPutar(); status("Pemutaran dihentikan.") }
        segarkanTombol()
    }

    override fun onStop() {
        super.onStop()
        if (!sibuk) { hentikanPutar(); dialogHasil.hentikanSuara() }
    }

    override fun onDestroy() {
        try { sesi?.cancel() } catch (_: Exception) { }
        dialogHasil.lepas()
        hentikanPutar()
        if (!isChangingConfigurations) {
            hasilFile?.delete()
            cacheDir.listFiles { f -> f.name.startsWith("ubah_") }?.forEach { it.delete() }
        }
        super.onDestroy()
    }
}
