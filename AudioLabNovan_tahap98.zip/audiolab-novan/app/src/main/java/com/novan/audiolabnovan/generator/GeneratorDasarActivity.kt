package com.novan.audiolabnovan.generator

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.text.InputType
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.ffmpegkit.FFmpegKit
import com.novan.audiolabnovan.DialogHasil
import com.novan.audiolabnovan.OutFmt
import com.novan.audiolabnovan.pengolah.AlatUi
import com.novan.audiolabnovan.pengolah.PenulisWav
import com.novan.audiolabnovan.pengolah.PenyimpanHasil
import com.novan.audiolabnovan.sfx.TambahSfxActivity
import java.io.File

/**
 * Tahap 91: kerangka bersama untuk fitur yang MEMBUAT suara dari rumus tanpa berkas masukan
 * (Noise Generator dan Wave Generator). Kerangka ini mengurus durasi, fade masuk dan keluar, format hasil,
 * contoh 10 detik, tulis WAV bertahap, penyandian FFmpeg, penyimpanan, dan dialog menu hasil.
 * Kelas turunan hanya menambah kolom khususnya dan menyiapkan [Penghasil].
 */
abstract class GeneratorDasarActivity : AppCompatActivity() {

    /** Pembuat sampel: mengisi [buf] dengan [frame] frame (bergantian antar kanal), dipanggil berurutan dari awal. */
    interface Penghasil {
        val kanal: Int
        fun isi(buf: ShortArray, frame: Int)
    }

    /** Hasil membaca isian: [nama] dipakai untuk nama berkas dan judul, [ringkasan] dibacakan sesudah selesai. */
    class Rencana(val penghasil: Penghasil, val nama: String, val ringkasan: String)

    companion object {
        const val SR = 44_100
        const val MAKS_DETIK = 30 * 60
        private const val BLOK = 8192
        private const val RAMP_MIN = 220 // sekitar 5 md, mencegah bunyi "klik" di awal dan akhir
        private val FADE = listOf(0.0, 0.5, 1.0, 3.0, 5.0, 10.0)
    }

    protected abstract val judulLayar: String
    protected abstract val keterangan: String
    protected abstract val subfolder: String

    /** Tambahkan kolom khusus ke [akar] (dipanggil sebelum kolom durasi). */
    protected abstract fun tambahKolom(akar: LinearLayout)

    /**
     * Baca isian khusus. [durasiDetik] = lama hasil (untuk contoh: paling lama 10 detik, jadi sapuan frekuensi
     * tetap terdengar utuh di contoh). Bila isian tidak valid, panggil [status] dengan pesan lalu kembalikan null.
     */
    protected abstract fun siapkan(durasiDetik: Double): Rencana?

    private val daftarFormat = listOf(OutFmt.MP3, OutFmt.AAC, OutFmt.FLAC, OutFmt.WAV)

    private lateinit var etDurasi: EditText
    private lateinit var spFadeMasuk: Spinner
    private lateinit var spFadeKeluar: Spinner
    private lateinit var spFormat: Spinner
    private lateinit var tombolContoh: Button
    private lateinit var tombolProses: Button
    private lateinit var tombolBatal: Button
    private lateinit var tvStatus: TextView
    private lateinit var bar: ProgressBar

    @Volatile private var batal = false
    @Volatile private var sibuk = false
    private var pemutar: AudioTrack? = null

    private val dialogHasil by lazy { DialogHasil(this) }

    private class Dibatalkan : Exception()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = judulLayar
        val c = this
        val akar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        akar.addView(AlatUi.judul(c, judulLayar))
        akar.addView(AlatUi.label(c, keterangan))

        tambahKolom(akar)

        etDurasi = EditText(this).apply {
            setText("1:00")
            hint = "Contoh 30, 1:30, atau 10:00"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        akar.addView(AlatUi.label(c, "Lama (detik atau menit:detik, paling lama 30 menit)", etDurasi))
        akar.addView(etDurasi, AlatUi.margin(c))

        spFadeMasuk = AlatUi.spinner(c, FADE.map { teksFade(it) })
        akar.addView(AlatUi.label(c, "Fade masuk", spFadeMasuk))
        akar.addView(spFadeMasuk, AlatUi.margin(c))
        spFadeKeluar = AlatUi.spinner(c, FADE.map { teksFade(it) })
        akar.addView(AlatUi.label(c, "Fade keluar", spFadeKeluar))
        akar.addView(spFadeKeluar, AlatUi.margin(c))

        spFormat = AlatUi.spinner(c, daftarFormat.map { it.label })
        akar.addView(AlatUi.label(c, "Format hasil", spFormat))
        akar.addView(spFormat, AlatUi.margin(c))

        tombolContoh = AlatUi.tombol(c, "Dengarkan contoh 10 detik") { contoh() }
        akar.addView(tombolContoh, AlatUi.margin(c))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        akar.addView(bar, AlatUi.margin(c))
        tombolProses = AlatUi.tombol(c, "Buat suara dan simpan") { proses() }
        akar.addView(tombolProses, AlatUi.margin(c))
        tombolBatal = AlatUi.tombol(c, "Batalkan") { batal = true; try { FFmpegKit.cancel() } catch (_: Throwable) { } }
        tombolBatal.isEnabled = false
        akar.addView(tombolBatal, AlatUi.margin(c))

        tvStatus = TextView(this).apply {
            textSize = 16f
            setTextIsSelectable(true)
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(AlatUi.dp(c, 20), AlatUi.dp(c, 8), AlatUi.dp(c, 20), AlatUi.dp(c, 16))
        }
        akar.addView(tvStatus, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlatUi.pasang(this, akar)
    }

    private fun teksFade(d: Double): String = when (d) {
        0.0 -> "Tanpa fade"
        0.5 -> "Setengah detik"
        else -> "${d.toInt()} detik"
    }

    protected fun status(t: String, umumkan: Boolean = false) {
        runOnUiThread {
            tvStatus.text = t
            if (umumkan) tvStatus.announceForAccessibility(t)
        }
    }

    private fun progres(p: Int) = runOnUiThread { bar.progress = p.coerceIn(0, 100) }

    private fun bacaDurasi(): Double? {
        val d = TambahSfxActivity.bacaWaktu(etDurasi.text.toString())
        if (d == null || d < 1.0) {
            status("Lama tidak valid. Contoh: 30 atau 1:30. Paling singkat 1 detik.", true)
            return null
        }
        if (d > MAKS_DETIK) {
            status("Terlalu panjang. Paling lama 30 menit.", true)
            return null
        }
        return d
    }

    /** Menerapkan fade (dan ramp 5 md) pada [buf] yang mewakili frame [mulai] sampai [mulai]+[n] dari [total]. */
    private fun terapkanFade(buf: ShortArray, n: Int, kanal: Int, mulai: Long, total: Long, masuk: Long, keluar: Long) {
        val m = maxOf(masuk, RAMP_MIN.toLong())
        val k = maxOf(keluar, RAMP_MIN.toLong())
        val akhirMasuk = m
        val awalKeluar = total - k
        if (mulai >= akhirMasuk && mulai + n <= awalKeluar) return
        for (i in 0 until n) {
            val idx = mulai + i
            var g = 1.0
            if (idx < akhirMasuk) g = idx.toDouble() / m
            if (idx >= awalKeluar) g = minOf(g, (total - idx).toDouble() / k)
            if (g < 1.0) {
                if (g < 0.0) g = 0.0
                for (c in 0 until kanal) {
                    val p = i * kanal + c
                    buf[p] = (buf[p] * g).toInt().toShort()
                }
            }
        }
    }

    private fun fadeFrame(sp: Spinner, total: Long): Long {
        val d = FADE[sp.selectedItemPosition.coerceIn(0, FADE.size - 1)]
        return minOf((d * SR).toLong(), total / 2)
    }

    // ----------------------------------------------------------------- contoh

    private fun contoh() {
        if (pemutar != null) { hentikanContoh(); status("Contoh dihentikan.", true); return }
        if (sibuk) return
        val durasi = bacaDurasi() ?: return
        val r = siapkan(minOf(durasi, 10.0)) ?: return
        try {
            val total = (minOf(durasi, 10.0) * SR).toLong().coerceAtLeast(SR.toLong())
            val kanal = r.penghasil.kanal
            val pcm = ShortArray((total * kanal).toInt())
            val tmp = ShortArray(BLOK * kanal)
            val masuk = fadeFrame(spFadeMasuk, total)
            val keluar = fadeFrame(spFadeKeluar, total)
            var selesai = 0L
            while (selesai < total) {
                val n = minOf(BLOK.toLong(), total - selesai).toInt()
                r.penghasil.isi(tmp, n)
                terapkanFade(tmp, n, kanal, selesai, total, masuk, keluar)
                System.arraycopy(tmp, 0, pcm, (selesai * kanal).toInt(), n * kanal)
                selesai += n
            }
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(if (kanal == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO)
                    .build())
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm, 0, pcm.size)
            t.setNotificationMarkerPosition(total.toInt())
            t.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(track: AudioTrack?) {
                    runOnUiThread {
                        if (pemutar === track) {
                            hentikanContoh()
                            tvStatus.text = "Contoh selesai."
                        }
                    }
                }
                override fun onPeriodicNotification(track: AudioTrack?) { }
            })
            t.play()
            pemutar = t
            tombolContoh.text = "Hentikan contoh"
            status("Memutar contoh. ${r.ringkasan}", true)
        } catch (e: Throwable) {
            hentikanContoh()
            status("Contoh tidak bisa dibuat: ${e.message ?: e.javaClass.simpleName}", true)
        }
    }

    private fun hentikanContoh() {
        try { pemutar?.stop() } catch (_: Throwable) { }
        try { pemutar?.release() } catch (_: Throwable) { }
        pemutar = null
        if (::tombolContoh.isInitialized) tombolContoh.text = "Dengarkan contoh 10 detik"
    }

    // ----------------------------------------------------------------- proses

    private fun proses() {
        if (sibuk) { Toast.makeText(this, "Masih bekerja. Tunggu atau batalkan dulu.", Toast.LENGTH_SHORT).show(); return }
        hentikanContoh()
        val durasi = bacaDurasi() ?: return
        val r = siapkan(durasi) ?: return
        val fmt = daftarFormat[spFormat.selectedItemPosition.coerceIn(0, daftarFormat.size - 1)]
        val kanal = r.penghasil.kanal
        val total = Math.round(durasi * SR)
        val ukuranWav = total * kanal * 2L + 44
        if (cacheDir.usableSpace < ukuranWav * 3 / 2) {
            status("Ruang penyimpanan HP kurang. Butuh sekitar ${(ukuranWav * 3 / 2 / 1_000_000)} MB kosong. Pilih lama yang lebih singkat atau kosongkan penyimpanan.", true)
            return
        }
        val masuk = fadeFrame(spFadeMasuk, total)
        val keluar = fadeFrame(spFadeKeluar, total)

        sibuk = true
        batal = false
        tombolProses.isEnabled = false
        tombolContoh.isEnabled = false
        tombolBatal.isEnabled = true
        bar.progress = 0
        bar.visibility = View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status("Membuat suara. Biarkan layar menyala sampai selesai.", true)

        Thread {
            var pesan: String? = null
            var uriHasil: Uri? = null
            var namaHasil = ""
            val stamp = System.currentTimeMillis()
            val tmpWav = File(cacheDir, "gen_$stamp.wav")
            val tmpOut = File(cacheDir, "gen_$stamp.${fmt.ext}")
            try {
                val tmp = ShortArray(BLOK * kanal)
                var selesai = 0L
                var terakhir = -10
                PenulisWav(tmpWav, SR, kanal).use { w ->
                    while (selesai < total) {
                        if (batal) throw Dibatalkan()
                        val n = minOf(BLOK.toLong(), total - selesai).toInt()
                        r.penghasil.isi(tmp, n)
                        terapkanFade(tmp, n, kanal, selesai, total, masuk, keluar)
                        w.tulis(tmp, n * kanal)
                        selesai += n
                        val p = (selesai * 100 / total).toInt()
                        progres(p * 85 / 100)
                        if (p - terakhir >= 10) { terakhir = p; status("Membuat suara $p persen...") }
                    }
                }
                if (batal) throw Dibatalkan()
                status("Menyandi hasil...", true)
                progres(90)
                val galat = PenyimpanHasil.sandi(tmpWav, tmpOut, fmt, 192, r.nama.replace('_', ' '), judulLayar)
                if (galat != null) { pesan = galat; return@Thread }
                namaHasil = r.nama + "_" + PenyimpanHasil.stempel() + "." + fmt.ext
                uriHasil = PenyimpanHasil.simpan(this, tmpOut, namaHasil, fmt, subfolder)
            } catch (e: Dibatalkan) {
                pesan = "Dibatalkan."
            } catch (e: Throwable) {
                pesan = "Gagal: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                tmpWav.delete()
                tmpOut.delete()
                val u = uriHasil
                val n = namaHasil
                val p = pesan
                runOnUiThread { selesaiProses(u, n, p, fmt, r.ringkasan) }
            }
        }.start()
    }

    private fun selesaiProses(uri: Uri?, nama: String, pesan: String?, fmt: OutFmt, ringkasan: String) {
        sibuk = false
        tombolProses.isEnabled = true
        tombolContoh.isEnabled = true
        tombolBatal.isEnabled = false
        bar.visibility = View.GONE
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (uri != null) {
            status("Selesai. $ringkasan Tersimpan di folder Musik, AudioLab Novan, $subfolder, dengan nama $nama.", true)
            dialogHasil.tampilkan(uri, nama, fmt.mime)
        } else {
            status(pesan ?: "Gagal.", true)
        }
    }

    override fun onStop() {
        hentikanContoh()
        super.onStop()
    }

    override fun onDestroy() {
        batal = true
        hentikanContoh()
        try { dialogHasil.lepas() } catch (_: Throwable) { }
        super.onDestroy()
    }
}
